import requests
import json
import threading

class XtreamCodesClient:
    def __init__(self, base_url, username, password):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.user_info = {}
        self.server_info = {}
        self.auth_data = None
        self._lock = threading.Lock()
        self.last_error = None  # Code de diagnostic sans URL ni identifiants

    def _request_json(self, params, timeout):
        """Retourne les données ou None; ne journalise jamais l'URL sensible."""
        url = f"{self.base_url}/player_api.php"
        try:
            # Read the JSON body from the response stream. This avoids keeping
            # requests' cached response.content alongside the decoded JSON.
            # json.load still materializes the full parsed object in memory.
            with self.session.get(url, params=params, timeout=timeout, stream=True) as response:
                response.raise_for_status()
                response.raw.decode_content = True
                data = json.load(response.raw)
        except requests.exceptions.Timeout:
            error = "timeout"
        except requests.exceptions.HTTPError:
            error = "http_error"
        except requests.exceptions.RequestException:
            error = "network_error"
        except (ValueError, TypeError, UnicodeError):
            error = "invalid_json"
        except OSError:
            error = "network_error"
        else:
            with self._lock:
                self.last_error = None
            return data
        with self._lock:
            self.last_error = error
        return None

    def _get(self, action, **kwargs):
        params = {"username": self.username, "password": self.password, "action": action}
        params.update(kwargs)
        return self._request_json(params, timeout=15)

    def get_live_categories(self):
        return self._get("get_live_categories")

    def get_live_streams(self, category_id):
        return self._get("get_live_streams", category_id=category_id)

    def get_vod_categories(self):
        return self._get("get_vod_categories")

    def get_vod_streams(self, category_id=None):
        if category_id:
            return self._get("get_vod_streams", category_id=category_id)
        return self._get("get_vod_streams")

    def get_vod_info(self, vod_id):
        return self._get("get_vod_info", vod_id=vod_id)

    def get_series_categories(self):
        return self._get("get_series_categories")

    def get_series_list(self, category_id=None):
        if category_id:
            return self._get("get_series", category_id=category_id)
        return self._get("get_series")

    def get_series_info(self, series_id):
        return self._get("get_series_info", series_id=series_id)

    def get_general_info(self):
        """Récupère les informations du compte sans changer le contrat existant."""
        params = {"username": self.username, "password": self.password}
        data = self._request_json(params, timeout=10)
        if not isinstance(data, dict):
            with self._lock:
                self.last_error = "invalid_account_response" if data is not None else self.last_error
            return None
        with self._lock:
            self.user_info = data.get("user_info", {}) if isinstance(data.get("user_info"), dict) else {}
            self.server_info = data.get("server_info", {}) if isinstance(data.get("server_info"), dict) else {}
            self.auth_data = data
        return data

    def get_live_url(self, stream_id, extension="ts"):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.{extension}"

    def get_vod_url(self, stream_id, extension="mp4"):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.{extension}"

    def get_series_episode_url(self, episode_id, extension="mp4"):
        return f"{self.base_url}/series/{self.username}/{self.password}/{episode_id}.{extension}"
