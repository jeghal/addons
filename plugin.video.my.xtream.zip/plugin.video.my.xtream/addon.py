"""Kodi plugin entry point. All logic lives in ``resources/lib``."""
from resources.lib.app import run

if __name__ == "__main__":
    run()
