import sys
from urllib.parse import parse_qsl, urlsplit
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmcvfs
import requests
import json
import threading
import time
import os
import hashlib
import uuid
import ast

from resources.lib.client import XtreamCodesClient
from resources.lib.utils import build_url, parse_duration, translate_to_arabic, get_safe_image, sort_vod, sort_series
from resources.lib.history import HistoryManager
from resources.lib.gui import create_list_item, show_notification, show_yesno_dialog
from resources.lib.cache import CacheManager
from resources.lib.catalog import CATEGORY_GROUPS, group_categories
from resources.lib.live import list_live_categories, list_live_streams
from resources.lib.vod import recent_vod, list_vod_categories, list_vod_streams, show_vod_info
from resources.lib.series import recent_series, list_series_categories, list_series, list_seasons, list_episodes
from resources.lib.search import search_tmdb_xtream, search_vod, search_global, search_series
from resources.lib.home import main_menu
from resources.lib.account import show_account_info
from resources.lib.cinema import (
    cinema_filters,
    cinema_home,
    cinema_list,
    cinema_person_credits,
    cinema_search,
    cinema_sections,
)
from resources.lib.tmdb_client import TmdbClient

# --- Configuration ---
# Récupération des paramètres de l'URL du plugin

URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PARAMS = dict(parse_qsl(sys.argv[2][1:]))

ADDON = xbmcaddon.Addon()

# --- Defaults ---
ADDON_ID = ADDON.getAddonInfo("id")
img_path = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "img")) # Using resources/img for custom icons
DEFAULT_VOD_ICON = "DefaultMovies.png"
DEFAULT_SERIES_ICON = "DefaultTVShows.png"
DEFAULT_FANART = "special://home/addons/plugin.video.my.xtream/fanart.jpg" # Fallback global si dispo


def get_settings():
    base_url = ADDON.getSetting("server_url")
    username = ADDON.getSetting("username")
    password = ADDON.getSetting("password")
    
    if not base_url or not username or not password:
        return None, None, None
    return base_url, username, password


def is_safe_playback_route(route):
    if not isinstance(route, str) or any(char in route for char in ('"', "\n", "\r", "\x00")):
        return False
    parsed = urlsplit(route)
    if parsed.scheme != "plugin" or parsed.netloc != ADDON_ID or parsed.path != "/":
        return False
    route_params = dict(parse_qsl(parsed.query))
    if route_params.get("mode") != "play_channel" or "url" in route_params:
        return False
    decoded_values = "\n".join(route_params.values())
    if USERNAME and (USERNAME in route or USERNAME in decoded_values):
        return False
    if PASSWORD and (PASSWORD in route or PASSWORD in decoded_values):
        return False
    return bool(client and client.get_stream_url(
        route_params.get("media_type"),
        route_params.get("media_id"),
        route_params.get("extension"),
    ))

# Initialisation du client si les réglages sont présents
BASE_URL, USERNAME, PASSWORD = get_settings()
client = None
if BASE_URL and USERNAME and PASSWORD:
    client = XtreamCodesClient(BASE_URL, USERNAME, PASSWORD)

# Suffixe pour les fichiers cache (ex: "vod_streams_12345.json")
# On utilise le hash des credentials pour éviter les conflits si plusieurs comptes
credentials_hash = hashlib.sha256(
    f"{BASE_URL}\0{USERNAME}\0{PASSWORD}".encode("utf-8")
).hexdigest()

# --- Managers ---
# History Manager
history_manager = HistoryManager(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
# Cache Manager (Nouvelle implémentation 24h)
cache_manager = CacheManager(
    xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
    credentials_hash,
)
tmdb_language = ADDON.getSetting("tmdb_language")
if tmdb_language not in ("ar", "en-US"):
    tmdb_language = "ar"
tmdb_read_access_token = ADDON.getSetting("tmdb_read_access_token").strip() or "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjNTdhMjEyOWVhM2I0ZDU0MGVmMTU5OWI2OWEyNzQxMSIsIm5iZiI6MTYxMjU2NTk4Ni43MDg5OTk5LCJzdWIiOiI2MDFkY2RlMmQyMGM4NzAwM2YwN2Y3ODkiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.5eXj9w-DTy2FjkiXb74nearYsrnRKMnZbbFFIhpK_-U"
tmdb_client = TmdbClient(
    tmdb_read_access_token,
    xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
    language=tmdb_language,
)

def pre_cache_data():
    """
    Lance le téléchargement en arrière-plan APRÈS UN DÉLAI de 3 secondes.
    Cela permet au menu principal de s'afficher instantanément.
    Le cache est SAUVEGARDÉ TRIÉ pour optimisation.
    """
    if not client or not cache_manager.acquire_job("precache"):
        return

    def _delayed_cache():
        try:
            monitor = xbmc.Monitor()
            if monitor.waitForAbort(3):
                return

            if not cache_manager.is_valid("vod"):
                xbmc.log("[Xtream] Pre-caching VOD...", xbmc.LOGINFO)
                cache_manager.get_or_fetch_catalog(
                    "vod", client.get_vod_streams, sort_vod
                )

            if monitor.abortRequested():
                return

            if not cache_manager.is_valid("series"):
                xbmc.log("[Xtream] Pre-caching Series...", xbmc.LOGINFO)
                cache_manager.get_or_fetch_catalog(
                    "series", client.get_series_list, sort_series
                )
        finally:
            cache_manager.release_job("precache")

    threading.Thread(target=_delayed_cache, daemon=True).start()



def router(params):
    mode = params.get("mode")

    if mode == "cinema_home":
        cinema_home(HANDLE)
        return
    if mode == "cinema_sections":
        cinema_sections(HANDLE, params.get("media_type"))
        return
    if mode == "cinema_filters":
        cinema_filters(HANDLE, params.get("media_type"), params.get("group"))
        return
    if mode == "cinema_list":
        cinema_list(
            HANDLE,
            tmdb_client,
            params.get("media_type"),
            params.get("section"),
            params.get("page"),
            params.get("filter_value"),
        )
        return
    if mode == "cinema_search":
        cinema_search(
            HANDLE,
            tmdb_client,
            params.get("query"),
            params.get("page", 1),
        )
        return
    if mode == "cinema_person_credits":
        cinema_person_credits(
            HANDLE,
            tmdb_client,
            params.get("person_id"),
            params.get("name"),
        )
        return
    if mode == "cinema_xtream_search":
        search_tmdb_xtream(
            HANDLE,
            client,
            cache_manager,
            DEFAULT_VOD_ICON,
            DEFAULT_SERIES_ICON,
            params.get("media_type"),
            params.get("title"),
            params.get("year"),
            params.get("tmdb_id"),
        )
        return
    
    # Vérification des credentials avant tout
    if not client:
        xbmcgui.Dialog().ok("Erreur Configuration", "Veuillez configurer l'URL, Identifiant et Mot de passe dans les paramètres de l'extension.")
        ADDON.openSettings()
        return

    if mode is None:
        main_menu(HANDLE, img_path, pre_cache_data)
    elif mode == "live_categories":
        list_live_categories(HANDLE, client, cache_manager, params.get("group_id"))
    elif mode == "live_streams":
        list_live_streams(HANDLE, client, cache_manager, params.get("category_id"))
    elif mode == "search_global":
        search_global(HANDLE, client, cache_manager, DEFAULT_VOD_ICON, DEFAULT_SERIES_ICON)
    elif mode == "vod_categories":
        list_vod_categories(HANDLE, client, cache_manager, params.get("group_id"))
    elif mode == "vod_streams":
        list_vod_streams(HANDLE, client, cache_manager, DEFAULT_VOD_ICON, params.get("category_id"))
    elif mode == "vod_info":
        show_vod_info(HANDLE, client, DEFAULT_VOD_ICON, params.get("vod_id"))
    elif mode == "series_categories":
        list_series_categories(HANDLE, client, cache_manager, params.get("group_id"))
    elif mode == "series_list":
        list_series(HANDLE, client, cache_manager, DEFAULT_SERIES_ICON, params.get("category_id"))
    elif mode == "series_info":
        list_seasons(HANDLE, client, DEFAULT_SERIES_ICON, params.get("series_id"))
    elif mode == "series_episodes":
        list_episodes(HANDLE, URL, client, DEFAULT_SERIES_ICON, params.get("series_id"), params.get("season_num"))
    elif mode == "account_info":
        show_account_info(HANDLE, client)
    elif mode == "search_vod":
        search_vod(HANDLE, client, cache_manager, DEFAULT_VOD_ICON)
    elif mode == "search_series":
        search_series(HANDLE, client, cache_manager, DEFAULT_SERIES_ICON)
    elif mode == "recent_vod":
        recent_vod(HANDLE, ADDON, client, cache_manager, DEFAULT_VOD_ICON)
    elif mode == "recent_series":
        recent_series(HANDLE, ADDON, client, cache_manager, DEFAULT_SERIES_ICON)
    elif mode == "history_vod":
        list_history("vod")
    elif mode == "history_series":
        list_history("series")
    elif mode == "play_channel":
        play_video(
            url=params.get("url"),
            title=params.get("title"),
            icon=params.get("icon"),
            media_type=params.get("media_type"),
            media_id=params.get("media_id"),
            meta=params.get("meta"),
            next_url=params.get("next_url"),
            group_id=params.get("group_id"),
            extension=params.get("extension")
        )
    elif mode == "clear_history":
        history_manager.clear_history(params.get("media_type"))
        xbmc.executebuiltin("Container.Refresh")
    elif mode == "remove_history":
        history_manager.remove_item(params.get("media_type"), params.get("item_id"))
        xbmc.executebuiltin("Container.Refresh")
    elif mode == "clear_cache":
        if show_yesno_dialog("Vider le Cache", "Voulez-vous vraiment vider le cache et forcer le téléchargement des données ?"):
            cache_manager.clear()
            xbmcgui.Dialog().notification("Xtream", "Cache vidé avec succès", xbmcgui.NOTIFICATION_INFO, 3000)
            # Re-run pre-caching immediately
            pre_cache_data()

# --- History Manager ---
# Now initialized at top of file
# history_manager = HistoryManager(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))

def play_video(url, title, icon, media_type=None, media_id=None, meta=None, next_url=None, group_id=None, extension=None):
    resolved_stream = client.resolve_stream_url(
        media_type,
        media_id,
        extension,
        legacy_url=url,
    )
    if not resolved_stream:
        xbmc.log("[Xtream] Rejected invalid playback identity", xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=create_list_item(label=title))
        return
    url, media_type, media_id, extension = resolved_stream

    try:
        meta_dict = ast.literal_eval(meta) if isinstance(meta, str) else (meta if isinstance(meta, dict) else {})
        if not isinstance(meta_dict, dict):
            meta_dict = {}
    except (ValueError, SyntaxError, TypeError, MemoryError):
        meta_dict = {}
    # Use the same Kodi InfoTagVideo path as manually selected directory entries.
    li = create_list_item(
        label=title,
        icon=icon,
        thumb=icon,
        poster=meta_dict.get("poster") or meta_dict.get("thumb") or icon,
        fanart=meta_dict.get("fanart"),
        info={"video": meta_dict} if meta_dict else None,
        path=url
    )
    
    # Calcul dynamique du 'next_url' si absent (ex: lancement depuis l'historique)
    if media_type == "series" and not next_url and group_id and media_id:
        try:
            data = client.get_series_info(group_id)
            if isinstance(data, dict):
                episodes_data = data.get("episodes")
                if not isinstance(episodes_data, dict):
                    episodes_data = {}
                info = data.get("info")
                if not isinstance(info, dict):
                    info = {}
                series_name = str(info.get("name") or "")
                series_cover = info.get("cover") or ""

                all_episodes = []
                season_keys = sorted(
                    episodes_data.keys(),
                    key=lambda value: int(str(value)) if str(value).isdigit() else 999,
                )
                for season_key in season_keys:
                    episodes = episodes_data.get(season_key)
                    if isinstance(episodes, list):
                        all_episodes.extend(
                            episode for episode in episodes if isinstance(episode, dict)
                        )

                current_idx = -1
                for idx, ep in enumerate(all_episodes):
                    if str(ep.get("id")) == str(media_id):
                        current_idx = idx
                        break

                if current_idx != -1 and current_idx + 1 < len(all_episodes):
                    next_ep = all_episodes[current_idx + 1]
                    next_id = next_ep.get("id")
                    if next_id is not None:
                        next_ext = str(next_ep.get("container_extension") or "mp4")
                        next_title = str(next_ep.get("title") or f"Episode {next_id}")
                        if series_name and series_name not in next_title:
                            next_full_title = f"{series_name} - {next_title}"
                        else:
                            next_full_title = next_title

                        next_info = next_ep.get("info")
                        if not isinstance(next_info, dict):
                            next_info = {}
                        next_thumb = next_info.get("movie_image") or series_cover

                        from urllib.parse import urlencode
                        next_params = {
                            "mode": "play_channel",
                            "title": next_full_title,
                            "icon": next_thumb,
                            "media_type": "series",
                            "media_id": next_id,
                            "group_id": group_id,
                            "extension": next_ext,
                            "meta": str({
                                "title": next_title,
                                "mediatype": "episode",
                                "tvshowtitle": series_name,
                                "season": int(next_ep.get("season") or 0),
                                "episode": int(next_ep.get("episode_num") or 0),
                                "plot": str(next_info.get("plot") or info.get("plot") or ""),
                                "duration": int(next_info.get("duration_secs") or 0),
                                "thumb": next_thumb,
                                "poster": series_cover,
                            }),
                        }
                        next_url = f"{URL}?{urlencode(next_params)}"
        except Exception as error:
            xbmc.log(
                f"[Xtream] Next episode metadata rejected: {type(error).__name__}",
                xbmc.LOGWARNING,
            )

    playback_window = xbmcgui.Window(10000)
    session_id = uuid.uuid4().hex
    playback_window.clearProperty('xtream_next_url')
    playback_window.clearProperty('xtream_next_session')
    playback_window.clearProperty('xtream_media_type')
    playback_window.clearProperty('xtream_media_id')
    playback_window.setProperty('xtream_session_id', session_id)

    if next_url and is_safe_playback_route(next_url):
        playback_window.setProperty('xtream_next_url', next_url)
        playback_window.setProperty('xtream_next_session', session_id)
    elif next_url:
        xbmc.log("[Xtream] Rejected unsafe next episode route", xbmc.LOGWARNING)
    
    # Save to history if valid metadata provided
    if media_type in ("vod", "series") and media_id:

        item_data = {
            "id": media_id,
            "name": title,
            "icon": icon,
            "meta": meta_dict,
            "extension": extension or "mp4"
        }

        # Communication avec le Service pour le Resume Point
        # Pour le service, media_id doit être unique pour le contenu exact.
        # Donc c'est bien media_id (episode_id ou vod_id), pas group_id.
        playback_window.setProperty('xtream_media_type', str(media_type))
        playback_window.setProperty('xtream_media_id', str(media_id))

        try:
            history_manager.add_item(media_type, item_data, group_id=group_id)
        except Exception as error:
            xbmc.log(
                f"[Xtream] History update failed: {type(error).__name__}",
                xbmc.LOGWARNING,
            )

        # Check Resume Point
        try:
            history = history_manager.load_history()
        except Exception as error:
            xbmc.log(
                f"[Xtream] History read failed: {type(error).__name__}",
                xbmc.LOGWARNING,
            )
            history = {}
        saved_items = history.get(media_type, [])
        resume_time = 0
        
        # On cherche l'item dans la liste history
        # Attention: pour les séries, l'item stocké est l'épisode.
        for it in saved_items:
            if str(it.get("id")) == str(media_id):
                resume_time = it.get("resume_time", 0)
                break
        
        if resume_time > 60:
             resume_str = time.strftime('%H:%M:%S', time.gmtime(resume_time))
             if xbmcgui.Dialog().yesno("Reprendre la lecture", f"Reprendre à {resume_str} ?"):
                 try:
                     # Kodi 20+ Modern approach
                     tag = li.getVideoInfoTag()
                     tag.setResumePoint(float(resume_time))
                     xbmc.log(f"[Xtream] SetResumePoint Success: {resume_time}", xbmc.LOGINFO)
                 except Exception as e:
                     xbmc.log(f"[Xtream] SetResumePoint Failed: {e}", xbmc.LOGERROR)
                 
                 # Fallback helpers
                 li.setProperty('StartOffset', str(float(resume_time)))
                 
                 # Calculate StartPercent if duration is known (helps some skins/players)
                 if meta_dict.get('duration'):
                     try:
                         total_sec = float(meta_dict['duration'])
                         if total_sec > 0:
                             percent = (float(resume_time) / total_sec) * 100
                             li.setProperty('StartPercent', str(percent))
                     except: pass 
                 
    # Force duration property from meta if available (critical for resume)
    if meta_dict:
        dur = meta_dict.get('duration')
        if dur:
            li.setProperty('TotalTime', str(dur))

    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)

def list_history(media_type):
    if media_type == "vod": xbmcplugin.setContent(HANDLE, 'movies')
    elif media_type == "series": xbmcplugin.setContent(HANDLE, 'tvshows')
    
    items = history_manager.get_list(media_type)
    
    if not items:
        xbmcgui.Dialog().notification("Historique", "Votre historique est vide", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Add "Clear History" button
    li_clear = create_list_item(label="[B][COLOR red]Tout Effacer[/COLOR][/B]", icon="DefaultClose.png")
    url_clear = build_url({"mode": "clear_history", "media_type": media_type})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url_clear, listitem=li_clear, isFolder=False)

    for item in items:
        name = item.get("name")
        item_id = item.get("id")
        icon = item.get("icon")
        meta = item.get("meta", {})
        extension = item.get("extension") or "mp4" # Handle missing key AND None value
        
        li = create_list_item(
            label=name,
            icon=icon,
            thumb=icon,
            poster=icon,
            info={"video": meta} if meta else None,
            properties={'IsPlayable': 'true'}
        )
        
        # Context Menu: Remove Item
        remove_url = build_url({"mode": "remove_history", "media_type": media_type, "item_id": item_id})
        li.addContextMenuItems([
            ("Retirer de l'historique", f"RunPlugin({remove_url})")
        ])
        
        # On relance via play_channel mais sans ré-enregistrer l'historique de manière asynchrone ?
        # Si on appelle play_channel, ca va rappeler play_video et re-pusher en haut de l'historique. 
        # C'est parfait, c'est le comportement attendu (Latest Used).
        
        # Il faut passer les mêmes arguments pour que ça marche (next_url, group_id, etc.)
        # Cependant next_url est dynamique... Si on relance depuis l'historique, on perd le "Auto-Play Next" 
        # car on ne recalcule pas ici le next_url.
        # Pour faire simple V1 : Pas de next_url depuis l'historique. (Ou alors faudrait fetcher...)
        
        group_id = item.get("group_id")
        
        url_params = {
            "mode": "play_channel",
            "title": name,
            "icon": icon,
            "media_type": media_type,
            "media_id": item_id,
            "meta": str(meta),
            "extension": extension
        }
        if group_id: url_params["group_id"] = group_id
        
        url = build_url(url_params)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    router(PARAMS)
