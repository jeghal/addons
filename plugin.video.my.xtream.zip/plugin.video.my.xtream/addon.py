import sys
from urllib.parse import parse_qsl
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmcvfs
import requests
import json
import threading
import time
import os
import hashlib

from resources.lib.client import XtreamCodesClient
from resources.lib.utils import build_url, parse_duration, translate_to_arabic
from resources.lib.history import HistoryManager
from resources.lib.gui import create_list_item, show_notification, show_yesno_dialog
from resources.lib.cache import CacheManager

# --- Configuration ---
# Récupération des paramètres de l'URL du plugin

URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PARAMS = dict(parse_qsl(sys.argv[2][1:]))

ADDON = xbmcaddon.Addon()

# --- Defaults ---
ADDON_ID = ADDON.getAddonInfo("id")
img_path = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo("path"), "resources", "assets")) # Using assets folder for custom icons
DEFAULT_VOD_ICON = "DefaultMovies.png"
DEFAULT_SERIES_ICON = "DefaultTVShows.png"
DEFAULT_FANART = "special://home/addons/plugin.video.my.xtream/fanart.jpg" # Fallback global si dispo


def get_safe_image(url, default):
    """
    Retourne l'URL de l'image si valide, sinon retourne l'image par défaut.
    Gère les URLs vides, nulles, ou invalides.
    """
    if not url or url == "" or url == "null":
        return default
    # Vérifier si l'URL commence par http (basique mais efficace)
    if not str(url).startswith("http"):
        return default
    return url


def get_settings():
    base_url = ADDON.getSetting("server_url")
    username = ADDON.getSetting("username")
    password = ADDON.getSetting("password")
    
    if not base_url or not username or not password:
        return None, None, None
    return base_url, username, password

# Grouping Configuration
CATEGORY_GROUPS = [
    # France
    {"prefix": "|FR|", "label": "France", "icon": "https://flagcdn.com/h240/fr.png"},
    {"prefix": "|FR |", "label": "France", "icon": "https://flagcdn.com/h240/fr.png"},
    {"prefix": "FR |", "label": "France", "icon": "https://flagcdn.com/h240/fr.png"},
    {"prefix": "┃FR┃", "label": "France", "icon": "https://flagcdn.com/h240/fr.png"},
    {"prefix": "BE |", "label": "Belgique", "icon": "https://flagcdn.com/h240/be.png"},
    {"prefix": "┃BE┃", "label": "Belgique", "icon": "https://flagcdn.com/h240/be.png"},
    {"prefix": "|BE|", "label": "Belgique", "icon": "https://flagcdn.com/h240/be.png"},

    # Arabe (Utilisation du drapeau Arab League ou Saudi Arabia comme proxy)
    {"prefix": "|AR|", "label": "Arabe", "icon": "https://flagcdn.com/h240/sa.png"},
    {"prefix": "AR |", "label": "Arabe", "icon": "https://flagcdn.com/h240/sa.png"},
    {"prefix": "AR|", "label": "Arabe", "icon": "https://flagcdn.com/h240/sa.png"},
    {"prefix": "┃AR┃", "label": "Arabe", "icon": "https://flagcdn.com/h240/sa.png"},

    # Monde Anglophone (US/UK/CA)
    {"prefix": "|ENG|", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/gb.png"},
    {"prefix": "|EN|", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/gb.png"},
    {"prefix": "UK |", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/gb.png"},
    {"prefix": "US |", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/us.png"},
    {"prefix": "US|", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/us.png"},
    {"prefix": "┃USA┃", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/us.png"},
    {"prefix": "CA |", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/ca.png"},
    {"prefix": "┃CA┃", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/ca.png"},
    {"prefix": "AU |", "label": "English / US / UK", "icon": "https://flagcdn.com/h240/au.png"},

    # Espagne / Amerique Latine
    {"prefix": "|ES|", "label": "Espagne / Latino", "icon": "https://flagcdn.com/h240/es.png"},
    {"prefix": "ES |", "label": "Espagne / Latino", "icon": "https://flagcdn.com/h240/es.png"},

    # Italie
    {"prefix": "|IT|", "label": "Italie", "icon": "https://flagcdn.com/h240/it.png"},
    {"prefix": "IT |", "label": "Italie", "icon": "https://flagcdn.com/h240/it.png"},
    {"prefix": "IT I", "label": "Italie", "icon": "https://flagcdn.com/h240/it.png"},

    # Allemagne
    {"prefix": "|DE|", "label": "Allemagne", "icon": "https://flagcdn.com/h240/de.png"},
    {"prefix": "DE |", "label": "Allemagne", "icon": "https://flagcdn.com/h240/de.png"},
    {"prefix": "AT |", "label": "Allemagne", "icon": "https://flagcdn.com/h240/at.png"}, # Autriche

    # Turquie
    {"prefix": "|TR|", "label": "Turquie", "icon": "https://flagcdn.com/h240/tr.png"},
    {"prefix": "TR |", "label": "Turquie", "icon": "https://flagcdn.com/h240/tr.png"},

    # Portugal / Bresil
    {"prefix": "|PT|", "label": "Portugal / Brésil", "icon": "https://flagcdn.com/h240/pt.png"},
    {"prefix": "PT |", "label": "Portugal / Brésil", "icon": "https://flagcdn.com/h240/pt.png"},
    {"prefix": "BR |", "label": "Portugal / Brésil", "icon": "https://flagcdn.com/h240/br.png"},

    # Pays-Bas
    {"prefix": "|NL|", "label": "Pays-Bas", "icon": "https://flagcdn.com/h240/nl.png"},
    {"prefix": "NL |", "label": "Pays-Bas", "icon": "https://flagcdn.com/h240/nl.png"},

    # Afrique
    {"prefix": "|AF|", "label": "Afrique", "icon": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Africa_%28orthographic_projection%29.svg/240px-Africa_%28orthographic_projection%29.svg.png"}, # Generic Map
    {"prefix": "AF |", "label": "Afrique", "icon": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Africa_%28orthographic_projection%29.svg/240px-Africa_%28orthographic_projection%29.svg.png"},
    {"prefix": "AF|", "label": "Afrique", "icon": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Africa_%28orthographic_projection%29.svg/240px-Africa_%28orthographic_projection%29.svg.png"},

    # Europe / Autres
    {"prefix": "|PL|", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/pl.png"}, # Pologne comme proxy pour Est
    {"prefix": "EU |", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/eu.png"},
    {"prefix": "┃SE┃", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/se.png"},
    {"prefix": "┃DK┃", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/dk.png"},
    {"prefix": "┃NO┃", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/no.png"},
    {"prefix": "┃SK┃", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/sk.png"},
    {"prefix": "UKR |", "label": "Europe de l'Est", "icon": "https://flagcdn.com/h240/ua.png"},

    # Asie
    {"prefix": "AS |", "label": "Asie", "icon": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Asia_%28orthographic_projection%29.svg/240px-Asia_%28orthographic_projection%29.svg.png"},
    {"prefix": "IND |", "label": "Asie", "icon": "https://flagcdn.com/h240/in.png"},
    {"prefix": "IS |", "label": "Asie", "icon": "https://flagcdn.com/h240/il.png"},

    # Divers
    {"prefix": "|MULTI|", "label": "International / Multi", "icon": "https://flagcdn.com/h240/un.png"},
    {"prefix": "|8K-MULTI|", "label": "Contenu 4K / 8K", "icon": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/4K_Ultra_HD_logo.svg/240px-4K_Ultra_HD_logo.svg.png"},
]

def group_categories(categories):
    """
    Groups categories based on prefixes defined in CATEGORY_GROUPS.
    Returns:
    - groups: Dict { "Label": [cat1, cat2...] }
    - orphans: List [catX, catY...] (no prefix match)
    """
    groups = {}
    orphans = []
    
    # Initialize groups in order
    for g in CATEGORY_GROUPS:
        if g["label"] not in groups:
            groups[g["label"]] = []

    for cat in categories:
        name = cat.get("category_name", "").upper()
        matched = False
        for g in CATEGORY_GROUPS:
            if name.startswith(g["prefix"].upper()):
                groups[g["label"]].append(cat)
                matched = True
                break
        
        if not matched:
            orphans.append(cat)
            
    # Filter out empty groups
    final_groups = {k: v for k, v in groups.items() if len(v) > 0}
    return final_groups, orphans

# Initialisation du client si les réglages sont présents
BASE_URL, USERNAME, PASSWORD = get_settings()
client = None
if BASE_URL and USERNAME and PASSWORD:
    client = XtreamCodesClient(BASE_URL, USERNAME, PASSWORD)

# Suffixe pour les fichiers cache (ex: "vod_streams_12345.json")
# On utilise le hash des credentials pour éviter les conflits si plusieurs comptes
credentials_hash = hashlib.md5(f"{USERNAME}{PASSWORD}{BASE_URL}".encode()).hexdigest() # Changed SERVER_URL to BASE_URL

# --- Managers ---
# History Manager
history_manager = HistoryManager(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
# Cache Manager (Nouvelle implémentation 24h)
cache_manager = CacheManager(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))

# Helper: Triers centralisés pour garantir que le cache est toujours trié
def sort_vod(data):
    try:
        return sorted(
            data, 
            key=lambda x: int(x.get("added")) if x.get("added") and str(x.get("added")).isdigit() else 0, 
            reverse=True
        )
    except:
        return data

def sort_series(data):
    try:
        return sorted(
            data, 
            key=lambda x: int(x.get("last_modified") or x.get("series_id")) if str(x.get("last_modified") or x.get("series_id")).isdigit() else 0, 
            reverse=True
        )
    except:
        return data

def pre_cache_data():
    """
    Lance le téléchargement en arrière-plan APRÈS UN DÉLAI de 3 secondes.
    Cela permet au menu principal de s'afficher instantanément.
    Le cache est SAUVEGARDÉ TRIÉ pour optimisation.
    """
    if not client: return
    
    def _delayed_cache():
        # Attendre 3 secondes pour laisser le menu s'afficher
        time.sleep(3)
        
        def _refresh_vod():
            if not cache_manager.is_valid("vod"):
                xbmc.log("[Xtream] Pre-caching VOD...", xbmc.LOGINFO)
                data = client.get_vod_streams()
                if data: 
                    # Tri avant sauvegarde
                    sorted_data = sort_vod(data)
                    cache_manager.set("vod", sorted_data)
                
        def _refresh_series():
            if not cache_manager.is_valid("series"):
                xbmc.log("[Xtream] Pre-caching Series...", xbmc.LOGINFO)
                data = client.get_series_list()
                if data: 
                    # Tri avant sauvegarde
                    sorted_data = sort_series(data)
                    cache_manager.set("series", sorted_data)
        
        # Lancer les threads de cache après le délai
        threading.Thread(target=_refresh_vod).start()
        threading.Thread(target=_refresh_series).start()
    
    # Lancer le délai dans un thread séparé pour ne pas bloquer
    threading.Thread(target=_delayed_cache).start()



def router(params):
    # DEBUG: Log raw params and parsed dict
    xbmc.log(f"[Xtream] Router Raw Params (sys.argv[2]): {sys.argv[2]}", xbmc.LOGINFO)
    xbmc.log(f"[Xtream] Router Parsed Params: {params}", xbmc.LOGINFO)

    mode = params.get("mode")
    
    # Vérification des credentials avant tout
    if not client:
        xbmcgui.Dialog().ok("Erreur Configuration", "Veuillez configurer l'URL, Identifiant et Mot de passe dans les paramètres de l'extension.")
        ADDON.openSettings()
        return

    if mode is None:
        main_menu()
    elif mode == "live_categories":
        list_live_categories(params.get("group_id"))
    elif mode == "live_streams":
        list_live_streams(params.get("category_id"))
    elif mode == "search_global":
        search_global()
    elif mode == "vod_categories":
        list_vod_categories(params.get("group_id"))
    elif mode == "vod_streams":
        list_vod_streams(params.get("category_id"))
    elif mode == "vod_info":
        show_vod_info(params.get("vod_id"))
    elif mode == "series_categories":
        list_series_categories(params.get("group_id"))
    elif mode == "series_list":
        list_series(params.get("category_id"))
    elif mode == "series_info":
        list_seasons(params.get("series_id"))
    elif mode == "series_episodes":
        list_episodes(params.get("series_id"), params.get("season_num"))
    elif mode == "account_info":
        show_account_info()
    elif mode == "search_vod":
        search_vod()
    elif mode == "search_series":
        search_series()
    elif mode == "recent_vod":
        recent_vod()
    elif mode == "recent_series":
        recent_series()
    elif mode == "history_vod":
        list_history("vod")
    elif mode == "history_series":
        list_history("series")
    elif mode == "play_channel":
        play_video(
            url=params.get("url"),
            title=params.get("title"),
            icon=params.get("icon"),
            media_type=params.get("media_type"),
            media_id=params.get("media_id"),
            meta=params.get("meta"),
            next_url=params.get("next_url"),
            group_id=params.get("group_id"),
            extension=params.get("extension")
        )
    elif mode == "clear_history":
        history_manager.clear_history(params.get("media_type"))
        xbmc.executebuiltin("Container.Refresh")
    elif mode == "remove_history":
        history_manager.remove_item(params.get("media_type"), params.get("item_id"))
        xbmc.executebuiltin("Container.Refresh")
    elif mode == "clear_cache":
        if show_yesno_dialog("Vider le Cache", "Voulez-vous vraiment vider le cache et forcer le téléchargement des données ?"):
            cache_manager.clear()
            xbmcgui.Dialog().notification("Xtream", "Cache vidé avec succès", xbmcgui.NOTIFICATION_INFO, 3000)
            # Re-run pre-caching immediately
            pre_cache_data()

def main_menu():
    # Menu Principal
    # Chemins absolus ou relatifs aux assets
    # Kodi gère bien les chemins relatifs à l'addon si on utilise special://home/addons/...
    # Ou juste le chemin relatif si on setIcon ? Non, il vaut mieux le chemin complet.
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    img_path = os.path.join(addon_path, "resources", "img")

    menus = [
        {"label": "[COLOR red]Recherche Globale[/COLOR]", "mode": "search_global", "icon": os.path.join(img_path, "search_pro.png")},
        {"label": "Télévision", "mode": "live_categories", "icon": os.path.join(img_path, "tv_pro.png")},
        {"label": "Films", "mode": "vod_categories", "icon": os.path.join(img_path, "movies_pro.png")},
        {"label": "Séries", "mode": "series_categories", "icon": os.path.join(img_path, "series_pro.png")},
        {"label": "Espace Client", "mode": "account_info", "icon": os.path.join(img_path, "account_pro.png")},
        {"label": "[COLOR yellow]Mettre à jour (Vider Cache)[/COLOR]", "mode": "clear_cache", "icon": "DefaultAddonService.png"}
    ]
    
    for item in menus:
        li = create_list_item(
             label=item["label"],
             icon=item.get("icon", "DefaultFolder.png"),
             thumb=item.get("icon", "DefaultFolder.png")
        )
        url = build_url({"mode": item["mode"]})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)

    # Lancement du pré-chargement en arrière-plan
    pre_cache_data()

def get_user_input(prompt):
    keyboard = xbmc.Keyboard("", prompt)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None

def search_vod():
    query = get_user_input("Rechercher un film :")
    if not query or len(query) < 2: return
    
    # 1. Tenter de lire le cache disque
    all_streams = cache_manager.get("vod")
    
    # 2. Si pas de cache, forcer le téléchargement maintenant
    if not all_streams:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Recherche', 'Téléchargement de la liste des films...')
        
        all_streams = client.get_vod_streams()
        if all_streams:
            # Tri et sauvegarde
            all_streams = sort_vod(all_streams)
            cache_manager.set("vod", all_streams)
        
        pDialog.close()
        
    if not all_streams:
        xbmcgui.Dialog().notification("Info", "Aucun contenu trouvé", xbmcgui.NOTIFICATION_INFO)
        return
    
    # Filtrage local ultra-rapide
    query_lower = query.lower()
    results = [s for s in all_streams if query_lower in s.get("name", "").lower()]
    
    if not results:
        xbmcgui.Dialog().notification("Info", "Aucun résultat pour : " + query, xbmcgui.NOTIFICATION_INFO)
        return
    
    # Limiter à 50 résultats pour affichage plus rapide
    if len(results) > 50:
        xbmcgui.Dialog().notification("Info", f"{len(results)} trouvés. Affichage des 50 premiers.", xbmcgui.NOTIFICATION_INFO, 3000)
        results = results[:50]
    
    # Affichage optimisé
    xbmcplugin.setContent(HANDLE, 'movies')
    for stream in results:
        name = stream.get("name")
        stream_id = stream.get("stream_id")
        icon = stream.get("stream_icon") or DEFAULT_VOD_ICON
        rating = stream.get("rating")
        
        info_tag = {
            "title": name,
            "rating": float(rating) if rating and str(rating).replace('.', '', 1).isdigit() else 0.0,
            "mediatype": "movie"
        }

        li = create_list_item(
             label=name,
             icon=icon,
             thumb=icon,
             poster=icon,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "vod_info", "vod_id": stream_id})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def recent_vod():
    # 1. Lire le cache
    all_streams = cache_manager.get("vod")
    
    if not all_streams:
       # Si pas de cache, on tente de le récupérer
       all_streams = client.get_vod_streams()
       if all_streams: 
           all_streams = sort_vod(all_streams)
           cache_manager.set("vod", all_streams)
    
    if not all_streams:
        xbmcgui.Dialog().notification("Info", "Aucun contenu disponible", xbmcgui.NOTIFICATION_INFO)
        return

    # 2. Cache supposé déjà trié ! (Optimisation)
    # Plus besoin de trier ici.
    
    # Récupérer la limite paramétrable
    limit = 50
    try:
        limit = int(ADDON.getSetting("recent_limit"))
    except:
        pass
        
    results = all_streams[:limit]

    xbmcplugin.setContent(HANDLE, 'movies')
    for stream in results:
        name = stream.get("name")
        stream_id = stream.get("stream_id")
        icon = stream.get("stream_icon") or DEFAULT_VOD_ICON
        rating = stream.get("rating")
        added = stream.get("added")
        
        # Date added formatting
        date_added = ""
        if added and str(added).isdigit():
            import datetime
            try:
                dt = datetime.datetime.fromtimestamp(int(added))
                date_added = dt.strftime("%d/%m/%Y")
            except: pass

        info_tag = {
            "title": name,
            "rating": float(rating) if rating and str(rating).replace('.', '', 1).isdigit() else 0.0,
            "mediatype": "movie",
            "plot": f"Ajouté le: {date_added}"
        }

        li = create_list_item(
             label=f"{name} ([COLOR green]{date_added}[/COLOR])",
             icon=icon,
             thumb=icon,
             poster=icon,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "vod_info", "vod_id": stream_id})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def search_global():
    query = get_user_input("Recherche Globale :")
    if not query or len(query) < 2: return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Recherche Globale', 'Chargement des données...')

    # --- 1. Recherche VOD ---
    pDialog.update(10, 'Recherche dans les films...')
    all_vod = cache_manager.get("vod")
    if not all_vod:
        all_vod = client.get_vod_streams()
        if all_vod:
            all_vod = sort_vod(all_vod)
            cache_manager.set("vod", all_vod)
    
    vod_results = []
    if all_vod:
        query_lower = query.lower()
        vod_results = [s for s in all_vod if query_lower in s.get("name", "").lower()]

    # --- 2. Recherche Series ---
    pDialog.update(50, 'Recherche dans les séries...')
    all_series = cache_manager.get("series")
    if not all_series:
        all_series = client.get_series_list()
        if all_series:
            all_series = sort_series(all_series)
            cache_manager.set("series", all_series)

    series_results = []
    if all_series:
        query_lower = query.lower()
        series_results = [s for s in all_series if query_lower in s.get("name", "").lower()]
    
    pDialog.close()

    if not vod_results and not series_results:
        xbmcgui.Dialog().notification("Info", "Aucun résultat trouvé", xbmcgui.NOTIFICATION_INFO)
        return

    # Limites
    max_results = 30
    if len(vod_results) > max_results: vod_results = vod_results[:max_results]
    if len(series_results) > max_results: series_results = series_results[:max_results]

    xbmcplugin.setContent(HANDLE, 'files') # Mixed content type for better compatibility

    # --- Affichage FILMS ---
    if vod_results:
        li_sep = create_list_item(label="[B][COLOR yellow]--- FILMS ---[/COLOR][/B]", icon="DefaultMovies.png")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_sep, isFolder=False)
        
        for stream in vod_results:
            name = stream.get("name")
            stream_id = stream.get("stream_id")
            icon = stream.get("stream_icon") or DEFAULT_VOD_ICON
            rating = stream.get("rating")
            
            li = create_list_item(
                 label=name,
                 icon=icon,
                 thumb=icon,
                 poster=icon,
                 info={"video": {"title": name, "mediatype": "movie", "rating": float(rating) if rating and str(rating).replace('.', '', 1).isdigit() else 0.0}}
            )
            url = build_url({"mode": "vod_info", "vod_id": stream_id})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    # --- Affichage SERIES ---
    if series_results:
        li_sep = create_list_item(label="[B][COLOR yellow]--- SERIES ---[/COLOR][/B]", icon="DefaultTVShows.png")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_sep, isFolder=False)

        for s in series_results:
            name = s.get("name")
            series_id = s.get("series_id")
            cover = s.get("cover") or DEFAULT_SERIES_ICON
            plot = s.get("plot")
            
            li = create_list_item(
                 label=name,
                 icon=cover,
                 thumb=cover,
                 poster=cover,
                 info={"video": {"title": name, "plot": plot, "mediatype": "tvshow"}}
            )
            url = build_url({"mode": "series_info", "series_id": series_id})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            
    xbmcplugin.endOfDirectory(HANDLE)

def search_series():
    query = get_user_input("Rechercher une série :")
    if not query or len(query) < 2: return
    
    # 1. Tenter de lire le cache disque
    all_series = cache_manager.get("series")
    
    # 2. Si pas de cache, forcer le téléchargement
    if not all_series:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Recherche', 'Téléchargement des séries...')
        
        all_series = client.get_series_list()
        if all_series:
            all_series = sort_series(all_series)
            cache_manager.set("series", all_series)
            
        pDialog.close()
        
    if not all_series:
        xbmcgui.Dialog().notification("Info", "Aucun contenu trouvé", xbmcgui.NOTIFICATION_INFO)
        return

    # Filtrage local ultra-rapide
    query_lower = query.lower()
    results = [s for s in all_series if query_lower in s.get("name", "").lower()]
    
    if not results:
        xbmcgui.Dialog().notification("Info", "Aucun résultat pour : " + query, xbmcgui.NOTIFICATION_INFO)
        return

    # Limiter à 50 résultats pour affichage plus rapide
    if len(results) > 50:
        xbmcgui.Dialog().notification("Info", f"{len(results)} trouvés. Affichage des 50 premiers.", xbmcgui.NOTIFICATION_INFO, 3000)
        results = results[:50]

    # Affichage optimisé
    xbmcplugin.setContent(HANDLE, 'tvshows')
    for s in results:
        name = s.get("name")
        series_id = s.get("series_id")
        cover = s.get("cover") or DEFAULT_SERIES_ICON
        plot = s.get("plot")
        
        li = create_list_item(
             label=name,
             icon=cover,
             thumb=cover,
             poster=cover,
             info={"video": {"title": name, "plot": plot, "mediatype": "tvshow"}}
        )
        
        url = build_url({"mode": "series_info", "series_id": series_id})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def recent_series():
    # 1. Lire le cache
    all_series = cache_manager.get("series")
    
    if not all_series:
        all_series = client.get_series_list()
        if all_series: 
            all_series = sort_series(all_series)
            cache_manager.set("series", all_series)

    if not all_series:
        xbmcgui.Dialog().notification("Info", "Aucun contenu disponible", xbmcgui.NOTIFICATION_INFO)
        return

    # 2. Cache supposé déjà trié !
    
    # Récupérer la limite paramétrable
    limit = 50
    try:
        limit = int(ADDON.getSetting("recent_limit"))
    except:
        pass
        
    results = all_series[:limit]

    xbmcplugin.setContent(HANDLE, 'tvshows')
    for s in results:
        name = s.get("name")
        series_id = s.get("series_id")
        cover = s.get("cover") or DEFAULT_SERIES_ICON
        plot = s.get("plot")
        
        # Last Modified date format (souvent vide mais on essaie)
        last_mod = s.get("last_modified")
        date_str = ""
        if last_mod and str(last_mod).isdigit():
             import datetime
             try:
                 dt = datetime.datetime.fromtimestamp(int(last_mod))
                 date_str = dt.strftime("%d/%m/%Y")
             except: pass

        li = create_list_item(
             label=f"{name} ([COLOR green]{date_str}[/COLOR])" if date_str else name,
             icon=cover,
             thumb=cover,
             poster=cover,
             info={"video": {"title": name, "plot": f"Mis à jour: {date_str}\n{plot}" if plot else f"Mis à jour: {date_str}", "mediatype": "tvshow"}}
        )
        
        url = build_url({"mode": "series_info", "series_id": series_id})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_account_info():
    data = client.get_general_info()
    if not data: 
        xbmcgui.Dialog().notification("Erreur", "Impossible de récupérer les infos du compte", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    user_info = data.get("user_info", {})
    server_info = data.get("server_info", {})

    # Helper date formatting
    def format_ts(ts):
        if not ts: return "N/A"
        if str(ts).isdigit():
            import datetime
            try:
                dt = datetime.datetime.fromtimestamp(int(ts))
                return dt.strftime("%d/%m/%Y")
            except: pass
        return str(ts)

    # 1. Abonnement Status
    status = user_info.get("status", "Inconnu")
    exp_date = format_ts(user_info.get("exp_date"))
    created_at = format_ts(user_info.get("created_at"))
    is_trial = user_info.get("is_trial") == "1"
    
    status_color = "green" if status == "Active" else "red"
    status_label = f"[COLOR {status_color}]{status}[/COLOR]"
    if is_trial: status_label += " (Essai)"

    li_status = create_list_item(
        label=f"Statut Abonnement: {status_label}",
        icon="DefaultIcon.png", # Fallback generic icon
        info={"video": {"plot": f"Date d'expiration: {exp_date}\nCréé le: {created_at}\n\nVotre abonnement est actuellement {status_color}."}}
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_status, isFolder=False)

    # 2. Connexions
    active_cons = user_info.get("active_cons", "0")
    max_connections = user_info.get("max_connections", "1")
    
    # Simple ASCII Bar for fun? or just text
    try:
        ac = int(active_cons)
        mc = int(max_connections)
        percent = int((ac / mc) * 100) if mc > 0 else 0
        bar = "[" + "=" * int(percent/10) + " " * (10 - int(percent/10)) + "]"
    except:
        bar = ""

    li_cons = create_list_item(
        label=f"Connexions: [COLOR blue]{active_cons} / {max_connections}[/COLOR]",
        icon="DefaultNetwork.png", # Network icon for connections
        info={"video": {"plot": f"Connexions actives: {ac}\nAutorisées: {mc}\n{bar}"}}
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_cons, isFolder=False)

    # 3. Serveur Info
    server_url = server_info.get("url", "N/A")
    server_port = server_info.get("port", "80")
    https_port = server_info.get("https_port", "443")
    protocol = server_info.get("server_protocol", "http")
    
    time_now = server_info.get("time_now", "N/A")
    
    li_server = create_list_item(
        label=f"Serveur: {protocol}://{server_url}",
        icon="DefaultAddonService.png", # Service icon for server
        info={"video": {"plot": f"Port: {server_port} (HTTPS: {https_port})\nHeure Serveur: {time_now}"}}
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_server, isFolder=False)

    # 4. User details (Protected?)
    username = user_info.get("username", "Inconnu")
    li_user = create_list_item(
        label=f"Utilisateur: [COLOR yellow]{username}[/COLOR]",
        icon="DefaultUser.png", # User profile icon
        info={"video": {"plot": "Identifiants de connexion sécurisés."}}
    )
    xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_user, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def list_live_categories(group_id=None):
    categories = client.get_live_categories()
    if not categories: return
    
    # Grouping Logic
    groups, orphans = group_categories(categories)

    # 1. Si on est à la racine, on affiche les GROUPES + les ORPHELINS
    if not group_id:
        # Afficher les dossiers de groupe
        for label, cats in groups.items():
            count = len(cats)
            # On prend l'icone du premier groupe config qui matche ce label
            icon = "DefaultFolder.png"
            for g in CATEGORY_GROUPS:
                if g["label"] == label:
                    icon = g["icon"]
                    break
            
            li = create_list_item(label=f"{label} ({count})", icon=icon)
            url = build_url({"mode": "live_categories", "group_id": label})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
        # Afficher les orphelins (sous les groupes)
        if orphans:
             # Separator
            li_sep = create_list_item(label="[B]--- Autres ---[/B]", icon="DefaultSeparator.png")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_sep, isFolder=False)
            
            for cat in orphans:
                li = create_list_item(label=cat.get("category_name", "Unknown"))
                url = build_url({"mode": "live_streams", "category_id": cat.get("category_id")})
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    # 2. Si un groupe est sélectionné
    else:
        # On récupère les catégories du groupe demandé
        group_cats = groups.get(group_id, [])
        for cat in group_cats:
            li = create_list_item(label=cat.get("category_name", "Unknown"))
            url = build_url({"mode": "live_streams", "category_id": cat.get("category_id")})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_live_streams(category_id):
    streams = client.get_live_streams(category_id)
    if not streams: return

    for stream in streams:
        name = stream.get("name")
        stream_id = stream.get("stream_id")
        icon = stream.get("stream_icon")
        num = stream.get("num")
        epg_id = stream.get("epg_channel_id")
        
        # Format label with channel number if available
        label = f"{num} | {name}" if num else name
        
        info_tag = {
            "title": name,
            "mediatype": "video",
            "plot": f"Numéro: {num}\nEPG ID: {epg_id}" if epg_id else f"Numéro: {num}"
        }

        play_url = client.get_live_url(stream_id)
        
        li = create_list_item(
             label=label,
             icon=icon,
             thumb=icon,
             info={"video": info_tag},
             properties={'IsPlayable': 'true'}
        )
        
        url = build_url({"mode": "play_channel", "url": play_url, "title": name, "icon": icon})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def list_vod_categories(group_id=None):
    # Si aucun groupe sélectionné (Racine)
    if not group_id:
        # Ajout du bouton Recherche en premier
        li = create_list_item(label="[B][COLOR red]Rechercher un Film[/COLOR][/B]", icon="DefaultMovies.png")
        url = build_url({"mode": "search_vod"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

        # Ajout du bouton Derniers Ajouts
        li = create_list_item(label="[B][COLOR red]Derniers Ajouts[/COLOR][/B]", icon="DefaultAddonImages.png")
        url = build_url({"mode": "recent_vod"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

        # Ajout du bouton Historique en deuxième
        li = create_list_item(label="[B][COLOR red]Continuer à regarder[/COLOR][/B]", icon="DefaultRecentlyAddedMovies.png")
        url = build_url({"mode": "history_vod"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    categories = client.get_vod_categories()
    if not categories: 
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Grouping Logic
    groups, orphans = group_categories(categories)

    # 1. Si on est à la racine, on affiche les GROUPES + les ORPHELINS
    if not group_id:
        # Afficher les dossiers de groupe
        for label, cats in groups.items():
            count = len(cats)
            # On prend l'icone du premier groupe config qui matche ce label
            icon = "DefaultFolder.png"
            for g in CATEGORY_GROUPS:
                if g["label"] == label:
                    icon = g["icon"]
                    break
            
            li = create_list_item(label=f"{label} ({count})", icon=icon)
            url = build_url({"mode": "vod_categories", "group_id": label})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
        # Afficher les orphelins (ceux qui n'ont pas de préfixe connu)
        # On peut les mettre dans un dossier "Autres" ou les lister directement.
        # Ici on les liste directement en dessous pour plus de visibilité, ou dans un dossier "Autres" si trop nombreux ?
        # Listing direct pour l'instant:
        if orphans:
             # Separator
            li_sep = create_list_item(label="[B]--- Autres ---[/B]", icon="DefaultSeparator.png")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_sep, isFolder=False)
            
            for cat in orphans:
                li = create_list_item(label=cat.get("category_name", "Unknown"))
                url = build_url({"mode": "vod_streams", "category_id": cat.get("category_id")})
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    # 2. Si un groupe est sélectionné, on affiche SEULEMENT les catégories de ce groupe
    else:
        # On récupère les catégories du groupe demandé
        group_cats = groups.get(group_id, [])
        for cat in group_cats:
            li = create_list_item(label=cat.get("category_name", "Unknown"))
            url = build_url({"mode": "vod_streams", "category_id": cat.get("category_id")})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_vod_streams(category_id):
    xbmcplugin.setContent(HANDLE, 'movies')
    streams = client.get_vod_streams(category_id)
    if not streams: return

    for stream in streams:
        name = stream.get("name")
        stream_id = stream.get("stream_id")
        # VOD streams list usually has basics. 
        # For 'vod_info' to work, we need to pass vod_id.
        # But 'vod_streams' endpoint gives us 'stream_id' which IS the 'vod_id' for get_vod_info.
        
        icon = get_safe_image(stream.get("stream_icon"), DEFAULT_VOD_ICON)
        
        rating = stream.get("rating_5based") # Use 5-based rating directly if available
        if not rating:
             r = stream.get("rating")
             if r and str(r).replace('.','',1).isdigit():
                 rating = float(r) / 2 # Normalize 10-based to 5-based often expected by Kodi skins or just display
        
        added = stream.get("added")
        container_extension = stream.get("container_extension") or "mp4"
        
        # Date added formatting
        date_added = ""
        if added and str(added).isdigit():
            import datetime
            try:
                dt = datetime.datetime.fromtimestamp(int(added))
                date_added = dt.strftime("%Y-%m-%d")
            except: pass

        info_tag = {
            "title": name,
            "mediatype": "movie",
            "plot": f"Ajouté le: {date_added}",
            "rating": float(rating) if rating else 0.0,
            "dateadded": f"{date_added} 00:00:00" if date_added else None
        }
        
        # Add TMDB ID if available for skins to scrape extra info
        tmdb_id = stream.get("tmdb")
        if tmdb_id:
            info_tag["tmdb_id"] = tmdb_id # Unofficial tag, but used by some fetchers
            info_tag["code"] = f"tmdb:{tmdb_id}"
            info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

        li = create_list_item(
            label=name,
            icon=icon,
            thumb=icon,
            poster=icon,
            info={"video": info_tag}
        )
        
        # Here we have a choice:
        # 1. Play directly (fastest)
        # 2. Open Info page (richer)
        # We'll use the Info page as intermediate.
        
        url = build_url({"mode": "vod_info", "vod_id": stream_id})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def show_vod_info(vod_id):
    xbmcplugin.setContent(HANDLE, 'movies')
    data = client.get_vod_info(vod_id)
    if not data: return

    info = data.get("info", {})
    if isinstance(info, list): info = {} # Handle API anomaly where info is []
    movie_data = data.get("movie_data", {})
    
    # Basic Info
    name = info.get("name") or movie_data.get("name")
    original_title = info.get("o_name")
    stream_id = movie_data.get("stream_id")
    # Check movie_data then info for extension
    container_extension = movie_data.get("container_extension") or info.get("container_extension") or "mp4"
    
    # Images
    icon = get_safe_image(info.get("movie_image"), DEFAULT_VOD_ICON)
    
    backdrop_path = info.get("backdrop_path")
    fanart = backdrop_path[0] if backdrop_path and isinstance(backdrop_path, list) else None
    
    # Metadata
    plot = info.get("description") or info.get("plot")
    
    # Translate plot to Arabic if enabled
    if plot:
        arabic_plot = translate_to_arabic(plot)
        if arabic_plot and arabic_plot != plot:
            # Show Arabic translation first, then original
            plot = f"[B][COLOR yellow]الترجمة العربية:[/COLOR][/B]\n{arabic_plot}\n\n[B]Original:[/B]\n{plot}"
    
    cast = info.get("cast")
    director = info.get("director")
    genre = info.get("genre")
    release_date = info.get("releasedate")
    duration = info.get("episode_run_time") # Minutes often used here
    rating = info.get("rating")
    youtube_trailer = info.get("youtube_trailer")
    
    # Audio/Video Tech Specs (Optional but cool if skin supports it)
    # Audio/Video Tech Specs
    video_spec = info.get("video", {})
    if isinstance(video_spec, list): video_spec = {} # Handle API edge case where video is a list
    
    # Extract only what we need safely
    width = video_spec.get("width")
    height = video_spec.get("height")
    codec = video_spec.get("codec_name")
    
    # Year extraction
    year = 0
    if release_date:
        parts = release_date.split("-")
        if len(parts) > 0 and parts[0].isdigit():
            year = int(parts[0])

    info_tag = {
        "title": name,
        "originaltitle": original_title,
        "plot": plot,
        "mediatype": "movie",
        "cast": [x.strip() for x in cast.split(",")] if cast else [],
        "director": director,
        "genre": genre,
        "year": year,
        "duration": int(duration) * 60 if duration else 0, # Kodi expects seconds
        "premiered": release_date,
        "trailer": youtube_trailer,
        # Tech details used by skins to show flags (4K, HD, etc.)
        "video_codec": codec,
        "width": width,
        "height": height
    }

    if rating:
        try: info_tag["rating"] = float(rating)
        except: pass

    # TMDB
    tmdb_id = info.get("tmdb_id")
    if tmdb_id:
        info_tag["tmdb_id"] = tmdb_id
        info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

    li = create_list_item(
        label=name,
        icon=icon,
        thumb=icon,
        poster=icon,
        fanart=fanart,
        info={"video": info_tag},
        properties={'IsPlayable': 'true'}
    )
    
    # Play URL
    play_url = client.get_vod_url(stream_id, container_extension)

    url = build_url({
        "mode": "play_channel", 
        "url": play_url, 
        "title": name, 
        "icon": icon, 
        "media_type": "vod", 
        "media_id": stream_id, 
        "extension": container_extension,
        "meta": str(info_tag) # Pass full meta for player overlay
    })
    
    # Here we display the item as a single directory item that looks like the movie page
    # Kodi behavior: When you click this, it triggers play because IsPlayable=true and it is not a folder?
    # Actually show_vod_info is a directory listing of 1 item.
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)



def list_series_categories(group_id=None):
    # Si aucun groupe sélectionné (Racine)
    if not group_id:
        # Ajout du bouton Recherche en premier
        li = create_list_item(label="[B][COLOR red]Rechercher une Série[/COLOR][/B]", icon="DefaultTVShows.png")
        url = build_url({"mode": "search_series"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
        # Ajout du bouton Derniers Ajouts
        li = create_list_item(label="[B][COLOR red]Derniers Ajouts[/COLOR][/B]", icon="DefaultAddonImages.png")
        url = build_url({"mode": "recent_series"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
        # Ajout du bouton Historique en deuxième
        li = create_list_item(label="[B][COLOR red]Continuer à regarder[/COLOR][/B]", icon="DefaultRecentlyAddedEpisodes.png")
        url = build_url({"mode": "history_series"})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    categories = client.get_series_categories()
    if not categories: 
        xbmcplugin.endOfDirectory(HANDLE)
        return
        
    # Grouping Logic
    groups, orphans = group_categories(categories)

    # 1. Si on est à la racine, on affiche les GROUPES + les ORPHELINS
    if not group_id:
        # Afficher les dossiers de groupe
        for label, cats in groups.items():
            count = len(cats)
            # On prend l'icone du premier groupe config qui matche ce label
            icon = "DefaultFolder.png"
            for g in CATEGORY_GROUPS:
                if g["label"] == label:
                    icon = g["icon"]
                    break
            
            li = create_list_item(label=f"{label} ({count})", icon=icon)
            url = build_url({"mode": "series_categories", "group_id": label})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
        # Afficher les orphelins (sous les groupes)
        if orphans:
             # Separator
            li_sep = create_list_item(label="[B]--- Autres ---[/B]", icon="DefaultSeparator.png")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li_sep, isFolder=False)
            
            for cat in orphans:
                li = create_list_item(label=cat.get("category_name", "Unknown"))
                url = build_url({"mode": "series_list", "category_id": cat.get("category_id")})
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    # 2. Si un groupe est sélectionné
    else:
        # On récupère les catégories du groupe demandé
        group_cats = groups.get(group_id, [])
        for cat in group_cats:
            li = create_list_item(label=cat.get("category_name", "Unknown"))
            url = build_url({"mode": "series_list", "category_id": cat.get("category_id")})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_series(category_id):
    xbmcplugin.setContent(HANDLE, 'tvshows')
    series = client.get_series_list(category_id)
    if not series: return

    for s in series:
        name = s.get("name")
        series_id = s.get("series_id")
        cover = get_safe_image(s.get("cover"), DEFAULT_SERIES_ICON)
        
        # Metadata parsing
        plot = s.get("plot")
        cast = s.get("cast")
        director = s.get("director")
        genre = s.get("genre")
        release_date = s.get("releaseDate") or s.get("release_date")
        rating = s.get("rating_5based")
        
        # Fallback rating
        if not rating:
             r = s.get("rating")
             if r and str(r).replace('.','',1).isdigit():
                 rating = float(r) / 2
        
        backdrop_path = s.get("backdrop_path")
        fanart = backdrop_path[0] if backdrop_path and isinstance(backdrop_path, list) and len(backdrop_path) > 0 else None
        
        youtube_trailer = s.get("youtube_trailer")
        episode_run_time = s.get("episode_run_time")
        
        # Year extraction
        year = 0
        if release_date:
            parts = release_date.split("-")
            if len(parts) > 0 and parts[0].isdigit():
                year = int(parts[0])

        info_tag = {
            "title": name,
            "plot": plot,
            "mediatype": "tvshow",
            "cast": [x.strip() for x in cast.split(",")] if cast else [],
            "director": director,
            "genre": genre,
            "year": year,
            "premiered": release_date,
            "rating": float(rating) if rating else 0.0,
            "trailer": youtube_trailer,
            "duration": int(episode_run_time) * 60 if episode_run_time and str(episode_run_time).isdigit() else 0
        }
        
        # TMDB
        tmdb_id = s.get("tmdb")
        if tmdb_id:
            info_tag["tmdb_id"] = tmdb_id
            info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

        li = create_list_item(
             label=name,
             icon=cover,
             thumb=cover,
             poster=cover,
             fanart=fanart,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "series_info", "series_id": series_id})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_seasons(series_id):
    xbmcplugin.setContent(HANDLE, 'seasons')
    data = client.get_series_info(series_id)
    if not data: return

    episodes_data = data.get("episodes", {})
    seasons_data = data.get("seasons", []) 
    info = data.get("info", {})
    
    seasons_map = {}
    for s in seasons_data:
        s_num = s.get("season_number")
        if s_num is not None:
            seasons_map[str(s_num)] = s

    season_keys = sorted(episodes_data.keys(), key=lambda x: int(x) if x.isdigit() else 999)
    
    series_cover = get_safe_image(info.get("cover"), DEFAULT_SERIES_ICON)
    
    backdrop_path = info.get("backdrop_path")
    series_fanart = backdrop_path[0] if isinstance(backdrop_path, list) and backdrop_path else None
    
    if not season_keys:
        xbmcgui.Dialog().notification("Info", "Aucune saison trouvée", xbmcgui.NOTIFICATION_INFO)
        return

    for season_num in season_keys:
        episode_list = episodes_data.get(season_num, [])
        episode_count = len(episode_list)
        
        s_info = seasons_map.get(str(season_num), {})
        
        s_name = s_info.get("name")
        if not s_name or s_name == "null":
            s_name = f"Saison {season_num}"
        
        label = f"{s_name} ({episode_count} épisodes)"
        
        s_cover = s_info.get("cover")
        if not s_cover or s_cover == "" or s_cover == "null":
            s_cover = series_cover 
            
        s_plot = s_info.get("overview") or info.get("plot")
        
        # Translate season plot to Arabic if enabled
        if s_plot:
            arabic_plot = translate_to_arabic(s_plot)
            if arabic_plot and arabic_plot != s_plot:
                # Show Arabic translation first, then original
                s_plot = f"[B][COLOR yellow]الترجمة العربية:[/COLOR][/B]\n{arabic_plot}\n\n[B]Original:[/B]\n{s_plot}"
        
        s_premiered = s_info.get("air_date")

        info_tag = {
            "title": s_name,
            "plot": s_plot,
            "mediatype": "season",
            "season": int(season_num) if str(season_num).isdigit() else 0,
            "premiered": s_premiered,
            "tvshowtitle": info.get("name")
        }

        li = create_list_item(
            label=label,
            icon=s_cover,
            thumb=s_cover,
            poster=s_cover,
            fanart=series_fanart,
            info={"video": info_tag}
        )
        
        url = build_url({"mode": "series_episodes", "series_id": series_id, "season_num": season_num})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(series_id, season_num):
    xbmcplugin.setContent(HANDLE, 'episodes')
    data = client.get_series_info(series_id)
    if not data: return
    
    all_episodes = data.get("episodes", {})
    season_episodes = all_episodes.get(str(season_num), [])
    
    series_info = data.get("info", {})
    series_name = series_info.get("name", "")
    series_cover = get_safe_image(series_info.get("cover"), DEFAULT_SERIES_ICON)
    
    series_backdrop = series_info.get("backdrop_path")
    series_fanart = series_backdrop[0] if isinstance(series_backdrop, list) and series_backdrop else None

    count = len(season_episodes)
    for i in range(count):
        ep = season_episodes[i]
        
        title = ep.get("title")
        episode_num = int(ep.get("episode_num")) if "episode_num" in ep and str(ep.get("episode_num")).isdigit() else i + 1
        
        # Fallback Title logic
        if not title or title.strip() == "" or title.lower() == "null":
            # Format: Series Name SXXEXX
            try:
                s_num = int(season_num)
                e_num = int(episode_num)
                title = f"{series_name} S{s_num:02d}E{e_num:02d}"
            except:
                title = f"{series_name} - Episode {episode_num}"
        
        episode_id = ep.get("id")
        container_extension = ep.get("container_extension") or "mp4"
        play_url = client.get_series_episode_url(episode_id, container_extension)
        
        ep_info = ep.get("info", {})
        if isinstance(ep_info, list): ep_info = {} 

        # Metadata extraction
        plot = ep_info.get("plot") or series_info.get("plot")
        
        rating = ep_info.get("rating")
        releasedate = ep_info.get("releasedate")
        duration_secs = ep_info.get("duration_secs")
        
        # Audio/Video specs
        video = ep_info.get("video", {})
        width = video.get("width")
        height = video.get("height")
        codec = video.get("codec_name")
        
        thumb = ep_info.get("movie_image")
        if not thumb or thumb == "" or thumb == "null":
            thumb = series_cover

        info_tag = {
            "title": title,
            "plot": plot,
            "mediatype": "episode",
            "tvshowtitle": series_name,
            "season": int(season_num) if str(season_num).isdigit() else 0,
            "episode": episode_num,
            "premiered": releasedate,
            "duration": int(duration_secs) if duration_secs else 0,
            "rating": float(rating) if rating else 0.0,
            "video_codec": codec,
            "width": width,
            "height": height
        }
            
        li = create_list_item(
             label=title,
             icon=thumb,
             thumb=thumb,
             poster=thumb,
             fanart=series_fanart,
             info={"video": info_tag},
             properties={'IsPlayable': 'true'}
        )
        
        # History Title
        full_title = f"{series_name} - {title}" if series_name and series_name not in title else title
        
        # Next Episode Logic
        next_url_param = ""
        if i + 1 < count:
            next_ep = season_episodes[i+1]
            next_id = next_ep.get("id")
            next_ext = next_ep.get("container_extension") or "mp4"
            next_play_url = client.get_series_episode_url(next_id, next_ext)
            
            next_title = next_ep.get("title")
            next_ep_num = int(next_ep.get("episode_num")) if "episode_num" in next_ep and str(next_ep.get("episode_num")).isdigit() else i + 2
            
            # Fallback Title logic for Next Episode
            if not next_title or next_title.strip() == "" or next_title.lower() == "null":
                try:
                    s_num = int(season_num)
                    title = f"{series_name} S{s_num:02d}E{next_ep_num:02d}"
                    next_title = title # Update next_title variable
                except:
                   next_title = f"{series_name} - Episode {next_ep_num}"

            next_full_title = f"{series_name} - {next_title}" if series_name and series_name not in next_title else next_title
                
            next_ep_info = next_ep.get("info", {})
            if isinstance(next_ep_info, list): next_ep_info = {}
            
            next_meta = {
                "title": next_title,
                "mediatype": "episode",
                "tvshowtitle": series_name,
                "thumb": series_cover,
                "plot": next_ep_info.get("plot") or series_info.get("plot"),
                "duration": int(next_ep_info.get("duration_secs", 0)),
                "season": info_tag["season"],
                "episode": next_ep_num
            }

            from urllib.parse import urlencode
            next_params = {
                "mode": "play_channel",
                "url": next_play_url,
                "title": next_full_title,
                "icon": next_ep_info.get("movie_image", series_cover),
                "media_type": "series",
                "media_id": next_id,
                "group_id": series_id, 
                "extension": next_ext,
                "meta": str(next_meta)
            }
            next_url_param = f"{URL}?{urlencode(next_params)}"

        url_params = {
            "mode": "play_channel", 
            "url": play_url, 
            "title": full_title, 
            "icon": thumb, 
            "media_type": "series", 
            "media_id": episode_id,
            "group_id": series_id,
            "extension": container_extension,
            "meta": str(info_tag),
            "next_url": next_url_param 
        }
        
        url = build_url(url_params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(HANDLE)


# --- History Manager ---
# Now initialized at top of file
# history_manager = HistoryManager(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))

def play_video(url, title, icon, media_type=None, media_id=None, meta=None, next_url=None, group_id=None, extension=None):
    li = create_list_item(
        label=title,
        icon=icon,
        thumb=icon,
        path=url
    )
    
    # Calcul dynamique du 'next_url' si absent (ex: lancement depuis l'historique)
    if media_type == "series" and not next_url and group_id and media_id:
        try:
            # On récupère les infos de la série
            data = client.get_series_info(group_id)
            if data:
                episodes_data = data.get("episodes", {})
                info = data.get("info", {})
                series_name = info.get("name", "")
                series_cover = info.get("cover", "")
                
                # On aplatit la liste des épisodes pour trouver le suivant
                all_episodes = []
                # Tri des saisons
                season_keys = sorted(episodes_data.keys(), key=lambda x: int(x) if x.isdigit() else 999)
                for k in season_keys:
                    all_episodes.extend(episodes_data[k])
                
                # Recherche de l'index courant
                current_idx = -1
                for idx, ep in enumerate(all_episodes):
                    if str(ep.get("id")) == str(media_id):
                        current_idx = idx
                        break
                
                # S'il y a un suivant
                if current_idx != -1 and current_idx + 1 < len(all_episodes):
                    next_ep = all_episodes[current_idx + 1]
                    
                    next_id = next_ep.get("id")
                    next_ext = next_ep.get("container_extension", "mp4")
                    next_play_url = client.get_series_episode_url(next_id, next_ext)
                    next_title = next_ep.get("title")
                    if series_name and series_name not in next_title:
                        next_full_title = f"{series_name} - {next_title}"
                    else:
                        next_full_title = next_title
                    
                    next_thumb = next_ep.get("info", {}).get("movie_image")
                    if not next_thumb: next_thumb = series_cover
                    
                    # Construction URL
                    from urllib.parse import urlencode
                    next_params = {
                        "mode": "play_channel",
                        "url": next_play_url,
                        "title": next_full_title,
                        "icon": next_thumb,
                        "media_type": "series",
                        "media_id": next_id,
                        "group_id": group_id,
                        "extension": next_ext,
                        "meta": str({"title": series_name, "thumb": series_cover})
                    }
                    next_url = f"{URL}?{urlencode(next_params)}"
        except:
            pass # Si échec, pas d'auto play, pas grave

    # Reset next url property
    xbmcgui.Window(10000).clearProperty('xtream_next_url')
    
    if next_url:
        xbmcgui.Window(10000).setProperty('xtream_next_url', next_url)
    
    # Save to history if valid metadata provided
    if media_type and media_id:
        import ast
        try:
            # meta might be string repr of dict coming from URL params
            if meta and isinstance(meta, str):
                meta_dict = ast.literal_eval(meta)
            else:
                meta_dict = meta if isinstance(meta, dict) else {}
        except:
            meta_dict = {}

        # DEBUG: Log extension being saved
        xbmc.log(f"[Xtream] Saving to History: ID={media_id}, Ext={extension}, Type={media_type}", xbmc.LOGINFO)

        item_data = {
            "id": media_id,
            "name": title,
            "icon": icon,
            "meta": meta_dict,
            "extension": extension or "mp4"
        }
        history_manager.add_item(media_type, item_data, group_id=group_id)
        
        # Communication avec le Service pour le Resume Point
        # Pour le service, media_id doit être unique pour le contenu exact.
        # Donc c'est bien media_id (episode_id ou vod_id), pas group_id.
        xbmcgui.Window(10000).setProperty('xtream_media_type', str(media_type))
        xbmcgui.Window(10000).setProperty('xtream_media_id', str(media_id))
        
        # Check Resume Point
        history = history_manager.load_history()
        saved_items = history.get(media_type, [])
        resume_time = 0
        
        # On cherche l'item dans la liste history
        # Attention: pour les séries, l'item stocké est l'épisode.
        for it in saved_items:
            if str(it.get("id")) == str(media_id):
                resume_time = it.get("resume_time", 0)
                break
        
        if resume_time > 60:
             resume_str = time.strftime('%H:%M:%S', time.gmtime(resume_time))
             if xbmcgui.Dialog().yesno("Reprendre la lecture", f"Reprendre à {resume_str} ?"):
                 try:
                     # Kodi 20+ Modern approach
                     tag = li.getVideoInfoTag()
                     tag.setResumePoint(float(resume_time))
                     xbmc.log(f"[Xtream] SetResumePoint Success: {resume_time}", xbmc.LOGINFO)
                 except Exception as e:
                     xbmc.log(f"[Xtream] SetResumePoint Failed: {e}", xbmc.LOGERROR)
                 
                 # Fallback helpers
                 li.setProperty('StartOffset', str(float(resume_time)))
                 
                 # Calculate StartPercent if duration is known (helps some skins/players)
                 if meta_dict.get('duration'):
                     try:
                         total_sec = float(meta_dict['duration'])
                         if total_sec > 0:
                             percent = (float(resume_time) / total_sec) * 100
                             li.setProperty('StartPercent', str(percent))
                     except: pass 
                 
    # Force duration property from meta if available (critical for resume)
    if meta and isinstance(meta, dict):
        dur = meta.get('duration')
        if dur:
            li.setProperty('TotalTime', str(dur))

    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)

def list_history(media_type):
    if media_type == "vod": xbmcplugin.setContent(HANDLE, 'movies')
    elif media_type == "series": xbmcplugin.setContent(HANDLE, 'tvshows')
    
    items = history_manager.get_list(media_type)
    
    if not items:
        xbmcgui.Dialog().notification("Historique", "Votre historique est vide", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Add "Clear History" button
    li_clear = create_list_item(label="[B][COLOR red]Tout Effacer[/COLOR][/B]", icon="DefaultClose.png")
    url_clear = build_url({"mode": "clear_history", "media_type": media_type})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url_clear, listitem=li_clear, isFolder=False)

    for item in items:
        name = item.get("name")
        item_id = item.get("id")
        icon = item.get("icon")
        meta = item.get("meta", {})
        extension = item.get("extension") or "mp4" # Handle missing key AND None value
        
        li = create_list_item(
            label=name,
            icon=icon,
            thumb=icon,
            poster=icon,
            info={"video": meta} if meta else None,
            properties={'IsPlayable': 'true'}
        )
        
        # Context Menu: Remove Item
        remove_url = build_url({"mode": "remove_history", "media_type": media_type, "item_id": item_id})
        li.addContextMenuItems([
            ("Retirer de l'historique", f"RunPlugin({remove_url})")
        ])
        
        # Direct Play Logic
        play_url = ""
        if media_type == "vod":
             play_url = client.get_vod_url(item_id, extension)
        else:
             play_url = client.get_series_episode_url(item_id, extension)
             
        # On relance via play_channel mais sans ré-enregistrer l'historique de manière asynchrone ?
        # Si on appelle play_channel, ca va rappeler play_video et re-pusher en haut de l'historique. 
        # C'est parfait, c'est le comportement attendu (Latest Used).
        
        # Il faut passer les mêmes arguments pour que ça marche (next_url, group_id, etc.)
        # Cependant next_url est dynamique... Si on relance depuis l'historique, on perd le "Auto-Play Next" 
        # car on ne recalcule pas ici le next_url.
        # Pour faire simple V1 : Pas de next_url depuis l'historique. (Ou alors faudrait fetcher...)
        
        group_id = item.get("group_id")
        
        url_params = {
            "mode": "play_channel",
            "url": play_url,
            "title": name,
            "icon": icon,
            "media_type": media_type,
            "media_id": item_id,
            "meta": str(meta),
            "extension": extension
        }
        if group_id: url_params["group_id"] = group_id
        
        url = build_url(url_params)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    router(PARAMS)
