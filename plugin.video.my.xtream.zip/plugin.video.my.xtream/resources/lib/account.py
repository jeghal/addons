import datetime

import xbmcgui
import xbmcplugin

from resources.lib.gui import create_list_item


def show_account_info(handle, client):
    xbmcplugin.setPluginCategory(handle, "Mon abonnement")

    data = client.get_general_info()
    if not isinstance(data, dict) or not data:
        xbmcgui.Dialog().notification(
            "Erreur",
            "Impossible de récupérer les informations du compte",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    user_info = data.get("user_info", {})
    server_info = data.get("server_info", {})
    if not isinstance(user_info, dict):
        user_info = {}
    if not isinstance(server_info, dict):
        server_info = {}

    def format_ts(timestamp):
        if not timestamp:
            return "N/A"
        if str(timestamp).isdigit():
            try:
                date = datetime.datetime.fromtimestamp(int(timestamp))
                return date.strftime("%d/%m/%Y")
            except (OverflowError, OSError, ValueError):
                pass
        return str(timestamp)

    def format_status(value):
        if not isinstance(value, (str, int, float, bool)):
            value = "Inconnu"
        status = str(value or "Inconnu")
        normalized = status.strip().lower()
        labels = {
            "active": ("Actif", "green"),
            "expired": ("Expiré", "red"),
            "disabled": ("Désactivé", "red"),
            "banned": ("Bloqué", "red"),
            "inactive": ("Inactif", None),
        }
        label, color = labels.get(normalized, (status, None))
        if color:
            label = f"[COLOR {color}]{label}[/COLOR]"
        return label, normalized

    def mask_username(value):
        if value is None or str(value).strip() == "":
            return "Non renseigné"
        username = str(value)
        if len(username) <= 4:
            return "****"
        return f"****{username[-4:]}"

    def format_connection_count(value):
        try:
            return int(value)
        except (TypeError, ValueError):
            return "N/A"

    status_label, status_key = format_status(user_info.get("status", "Inconnu"))
    status_descriptions = {
        "active": "Votre abonnement est actif.",
        "expired": "Votre abonnement a expiré.",
        "disabled": "Votre abonnement est désactivé.",
        "banned": "Votre abonnement est bloqué.",
        "inactive": "Votre abonnement est inactif.",
    }
    status_description = status_descriptions.get(
        status_key,
        "Le statut de votre abonnement n'est pas disponible.",
    )
    if user_info.get("is_trial") == "1":
        status_label += " (essai)"
        status_description += " Il s'agit d'un abonnement d'essai."

    expiration_date = format_ts(user_info.get("exp_date"))
    creation_date = format_ts(user_info.get("created_at"))

    active_connections = user_info.get("active_cons", "0")
    max_connections = user_info.get("max_connections", "1")
    safe_active_connections = format_connection_count(active_connections)
    safe_max_connections = format_connection_count(max_connections)

    server_configured = bool(server_info.get("url"))
    server_label = "Configuré" if server_configured else "Non renseigné"
    server_protocol = server_info.get("server_protocol", "N/A")
    server_port = server_info.get("port", "N/A")
    server_time = server_info.get("time_now", "N/A")

    items = [
        (
            f"Statut de l'abonnement : {status_label}",
            "icons/addonstatus/enabled-normal.png",
            status_description,
        ),
        (
            f"Date d'expiration : {expiration_date}",
            "osd/fullscreen/buttons/calendar.png",
            "Date de fin de l'abonnement.",
        ),
        (
            f"Connexions actives / maximales : {safe_active_connections} / {safe_max_connections}",
            "DefaultNetwork.png",
            "Nombre de connexions utilisées et autorisées.",
        ),
        (
            f"Serveur : {server_label}",
            "DefaultAddonService.png",
            f"Protocole : {server_protocol}\nPort : {server_port}\nHeure du serveur : {server_time}",
        ),
        (
            f"Nom d'utilisateur : {mask_username(user_info.get('username'))}",
            "DefaultUser.png",
            "Le nom d'utilisateur est masqué pour protéger vos informations.",
        ),
        (
            f"Date de création : {creation_date}",
            "osd/fullscreen/buttons/calendar.png",
            "Date de création du compte.",
        ),
    ]

    for label, icon, plot in items:
        list_item = create_list_item(
            label=label,
            icon=icon,
            thumb=icon,
            info={"video": {"plot": plot}},
        )
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url="",
            listitem=list_item,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(handle)
