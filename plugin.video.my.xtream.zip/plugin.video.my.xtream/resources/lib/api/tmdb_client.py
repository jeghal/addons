import email.utils
import hashlib
import json
import os
import tempfile
import threading
import time
from datetime import date

import requests

from resources.lib.core import logger
from resources.lib.storage.file_lock import FileLock


TMDB_API_BASE = "https://api.themoviedb.org/3"
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p"
TMDB_CACHE_NAMESPACE = "cinema_tmdb_v1"
TMDB_CACHE_SCHEMA = 1
TRENDING_TTL = 6 * 60 * 60
TRENDING_STALE_WINDOW = 24 * 60 * 60
MAX_CACHE_FILE_BYTES = 1024 * 1024
MAX_CACHE_BYTES = 8 * 1024 * 1024
MAX_CACHE_FILES = 64
MAX_RETRY_AFTER = 5 * 60
MAX_SEARCH_QUERY_LENGTH = 120
MAX_PERSON_CREDITS = 40
MAX_POSTER_LOOKUPS_PER_LIST = 6  # Bound cold-page latency on LG webOS
VALID_LANGUAGES = frozenset(("ar", "en-US"))
VALID_MEDIA_TYPES = frozenset(("movie", "tv"))
MOVIE_ONLY_SECTIONS = frozenset(("box_office", "current", "upcoming"))
STANDARD_SECTIONS = {
    "trending": "/trending/{media_type}/week",
    "popular": "/{media_type}/popular",
    "top_rated": "/{media_type}/top_rated",
    "current": "/movie/now_playing",
    "upcoming": "/movie/upcoming",
}
PLATFORM_FILTERS = {
    "netflix": {"movie": ("with_companies", "213|178464|145174|171251|198834|185004"), "tv": ("with_networks", "213")},
    "apple": {"movie": ("with_companies", "194232|14801"), "tv": ("with_networks", "2552")},
    "disney": {"movie": ("with_companies", "2"), "tv": ("with_networks", "2739")},
    "hbo": {"movie": ("with_companies", "3268|7429"), "tv": ("with_networks", "49")},
}
SMART_SECTIONS = frozenset((
    "mind_bending", "feel_good", "highly_rated", "arabic", "marvel",
))
GENRE_IDS = {
    "movie": {
        "action": 28,
        "comedy": 35,
        "drama": 18,
        "horror": 27,
        "thriller": 53,
        "scifi": 878,
        "crime": 80,
        "documentary": 99,
        "family": 10751,
    },
    "tv": {
        "action_adventure": 10759,
        "comedy": 35,
        "drama": 18,
        "scifi_fantasy": 10765,
        "crime": 80,
        "documentary": 99,
        "family": 10751,
    },
}


class TmdbError(Exception):
    def __init__(self, code):
        self.code = str(code)
        super().__init__(self.code)


class _TmdbCache:
    def __init__(self, profile_path, clock=time.time, monotonic=time.monotonic):
        self.clock = clock
        self.monotonic = monotonic
        self.cache_dir = os.path.join(profile_path, "cache", TMDB_CACHE_NAMESPACE)
        os.makedirs(self.cache_dir, exist_ok=True)
        self._locks = {}
        self._locks_guard = threading.RLock()

    def _safe_name(self, key):
        return hashlib.sha256(key.encode("utf-8")).hexdigest()

    def path_for(self, key):
        return os.path.join(self.cache_dir, f"{self._safe_name(key)}.json")

    def retry_path_for(self, key):
        return os.path.join(self.cache_dir, f"{self._safe_name(key)}.retry")

    def lock_path_for(self, key):
        return os.path.join(self.cache_dir, f"{self._safe_name(key)}.lock")

    def read(self, key):
        path = self.path_for(key)
        try:
            if os.path.getsize(path) > MAX_CACHE_FILE_BYTES:
                raise ValueError("oversized cache")
            with open(path, "r", encoding="utf-8") as cache_handle:
                envelope = json.load(cache_handle)
            if (
                not isinstance(envelope, dict)
                or envelope.get("schema") != TMDB_CACHE_SCHEMA
                or not isinstance(envelope.get("fetched_at"), (int, float))
                or not isinstance(envelope.get("data"), (list, dict))
            ):
                raise ValueError("invalid cache envelope")
            age = max(0.0, self.clock() - float(envelope["fetched_at"]))
            return envelope["data"], age
        except FileNotFoundError:
            return None, None
        except (OSError, ValueError, TypeError, UnicodeError, json.JSONDecodeError) as error:
            try:
                os.remove(path)
            except OSError:
                pass
            logger.warning(f"Invalid cache ignored: {type(error).__name__}", tag="TMDb")
            return None, None

    def write(self, key, data):
        envelope = {
            "schema": TMDB_CACHE_SCHEMA,
            "fetched_at": self.clock(),
            "data": data,
        }
        encoded = json.dumps(
            envelope,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        if len(encoded) > MAX_CACHE_FILE_BYTES:
            logger.warning("Cache payload exceeds configured limit", tag="TMDb")
            return False

        temporary_path = None
        try:
            descriptor, temporary_path = tempfile.mkstemp(
                prefix="tmdb.",
                suffix=".tmp",
                dir=self.cache_dir,
            )
            with os.fdopen(descriptor, "wb") as cache_handle:
                cache_handle.write(encoded)
                cache_handle.flush()
                os.fsync(cache_handle.fileno())
            os.replace(temporary_path, self.path_for(key))
            self._enforce_bounds()
            return True
        except OSError as error:
            if temporary_path:
                try:
                    os.remove(temporary_path)
                except OSError:
                    pass
            logger.warning(f"Cache write failed: {type(error).__name__}", tag="TMDb")
            return False

    def _enforce_bounds(self):
        try:
            entries = []
            for name in os.listdir(self.cache_dir):
                if not name.endswith(".json"):
                    continue
                path = os.path.join(self.cache_dir, name)
                stat = os.stat(path)
                entries.append((stat.st_mtime, stat.st_size, path))
            entries.sort()
            total_size = sum(entry[1] for entry in entries)
            while len(entries) > MAX_CACHE_FILES or total_size > MAX_CACHE_BYTES:
                _, size, path = entries.pop(0)
                os.remove(path)
                total_size -= size
        except OSError as error:
            logger.warning(f"Cache pruning failed: {type(error).__name__}", tag="TMDb")

    def retry_remaining(self, key):
        try:
            with open(self.retry_path_for(key), "r", encoding="ascii") as retry_handle:
                retry_until = float(retry_handle.read().strip())
            remaining = retry_until - self.clock()
            if remaining > 0:
                return remaining
            os.remove(self.retry_path_for(key))
        except (FileNotFoundError, OSError, ValueError, UnicodeError):
            pass
        return 0.0

    def set_retry_after(self, key, seconds):
        retry_until = self.clock() + min(MAX_RETRY_AFTER, max(0.0, float(seconds)))
        temporary_path = None
        try:
            descriptor, temporary_path = tempfile.mkstemp(
                prefix="tmdb-retry.",
                suffix=".tmp",
                dir=self.cache_dir,
            )
            with os.fdopen(descriptor, "w", encoding="ascii") as retry_handle:
                retry_handle.write(str(retry_until))
                retry_handle.flush()
                os.fsync(retry_handle.fileno())
            os.replace(temporary_path, self.retry_path_for(key))
        except OSError as error:
            if temporary_path:
                try:
                    os.remove(temporary_path)
                except OSError:
                    pass
            logger.warning(f"Retry state write failed: {type(error).__name__}", tag="TMDb")

    def clear_retry(self, key):
        try:
            os.remove(self.retry_path_for(key))
        except OSError:
            pass

    def acquire(self, key, wait_timeout=2.0, stale_after=30.0):
        lock = FileLock(
            self.lock_path_for(key),
            timeout=wait_timeout,
            stale_after=stale_after,
        )
        try:
            token = lock.acquire()
        except (OSError, TimeoutError):
            return None
        with self._locks_guard:
            self._locks[token] = lock
        return token

    def release(self, key, token):
        with self._locks_guard:
            lock = self._locks.pop(token, None)
        if lock is not None:
            lock.release()

    def assert_owned(self, token):
        with self._locks_guard:
            lock = self._locks.get(token)
        if lock is None:
            raise RuntimeError("TMDb cache lock is not registered")
        lock.assert_owned()


class TmdbClient:
    def __init__(
        self,
        token,
        profile_path,
        language="ar",
        session=None,
        clock=time.time,
        today_provider=date.today,
    ):
        self.token = str(token or "").strip()
        self.language = self._validate_language(language)
        self.session = session or requests.Session()
        self.cache = _TmdbCache(profile_path, clock=clock)
        self.today_provider = today_provider
        self.last_error = None

    @staticmethod
    def _validate_language(language):
        value = str(language or "").strip()
        if value not in VALID_LANGUAGES:
            raise TmdbError("invalid_language")
        return value

    @staticmethod
    def _validate_page(page):
        if isinstance(page, bool):
            raise TmdbError("invalid_page")
        try:
            value = int(page)
        except (TypeError, ValueError):
            raise TmdbError("invalid_page")
        if str(page).strip() != str(value) or not 1 <= value <= 20:
            raise TmdbError("invalid_page")
        return value

    @staticmethod
    def _validate_media_type(media_type):
        value = str(media_type or "").strip().lower()
        if value not in VALID_MEDIA_TYPES:
            raise TmdbError("invalid_media_type")
        return value

    @staticmethod
    def _retry_after_seconds(value, now):
        if value is None:
            return 60.0
        try:
            return min(MAX_RETRY_AFTER, max(0.0, float(value)))
        except (TypeError, ValueError):
            try:
                parsed = email.utils.parsedate_to_datetime(str(value))
                return min(MAX_RETRY_AFTER, max(0.0, parsed.timestamp() - now))
            except (TypeError, ValueError, OverflowError):
                return 60.0

    @staticmethod
    def _image_url(path, size):
        value = str(path or "").strip()
        if not value.startswith("/"):
            return ""
        return f"{TMDB_IMAGE_BASE}/{size}{value}"

    @classmethod
    def _map_item(cls, item, media_type):
        if not isinstance(item, dict):
            return None
        try:
            tmdb_id = int(item.get("id"))
        except (TypeError, ValueError):
            return None
        if tmdb_id <= 0:
            return None
        title_key = "title" if media_type == "movie" else "name"
        original_key = "original_title" if media_type == "movie" else "original_name"
        date_key = "release_date" if media_type == "movie" else "first_air_date"
        localized_title = str(item.get(title_key) or "").strip()
        original_title = str(item.get(original_key) or "").strip()
        display_title = original_title or localized_title or "بدون عنوان"
        release_date = str(item.get(date_key) or "").strip()
        try:
            vote_average = float(item.get("vote_average") or 0.0)
        except (TypeError, ValueError):
            vote_average = 0.0
        try:
            popularity = float(item.get("popularity") or 0.0)
        except (TypeError, ValueError):
            popularity = 0.0
        try:
            vote_count = int(item.get("vote_count") or 0)
        except (TypeError, ValueError):
            vote_count = 0
        poster_path = str(item.get("poster_path") or "").strip()
        backdrop_path = str(item.get("backdrop_path") or "").strip()
        return {
            "id": tmdb_id,
            "media_type": media_type,
            "title": display_title,
            "original_title": original_title or localized_title,
            "localized_title": localized_title,
            "release_date": release_date,
            "vote_average": vote_average,
            "popularity": popularity,
            "vote_count": vote_count,
            "overview": str(item.get("overview") or "").strip(),
            "original_language": str(item.get("original_language") or "").strip().lower(),
            "poster_path": poster_path,
            "backdrop_path": backdrop_path,
            "poster_url": cls._image_url(poster_path, "w342"),
            "backdrop_url": cls._image_url(backdrop_path, "w780"),
        }

    @classmethod
    def _map_person(cls, item):
        if not isinstance(item, dict):
            return None
        try:
            person_id = int(item.get("id"))
        except (TypeError, ValueError):
            return None
        name = str(item.get("name") or "").strip()
        if person_id <= 0 or not name:
            return None
        profile_path = str(item.get("profile_path") or "").strip()
        try:
            popularity = float(item.get("popularity") or 0.0)
        except (TypeError, ValueError):
            popularity = 0.0
        return {
            "id": person_id,
            "media_type": "person",
            "name": name,
            "known_for_department": str(item.get("known_for_department") or "").strip(),
            "popularity": popularity,
            "profile_path": profile_path,
            "profile_url": cls._image_url(profile_path, "w342"),
        }

    @staticmethod
    def _validate_query(query):
        value = str(query or "").strip()
        if not value or len(value) > MAX_SEARCH_QUERY_LENGTH:
            raise TmdbError("invalid_query")
        return value

    @staticmethod
    def _validate_person_id(person_id):
        value = str(person_id or "").strip()
        if not value.isdigit() or int(value) <= 0:
            raise TmdbError("invalid_person")
        return int(value)

    @staticmethod
    def _validate_year(year, current_year):
        value = str(year or "").strip()
        if value in ("1990s", "1980s"):
            return value
        if not value.isdigit():
            raise TmdbError("invalid_filter")
        numeric = int(value)
        if not 2000 <= numeric <= current_year:
            raise TmdbError("invalid_filter")
        return str(numeric)

    def _build_request(self, media_type, section, page, filter_value=None):
        media_type = self._validate_media_type(media_type)
        page = self._validate_page(page)
        section = str(section or "").strip().lower()
        if section in MOVIE_ONLY_SECTIONS and media_type != "movie":
            raise TmdbError("invalid_section")
        if section not in ("genre", "year") and filter_value not in (None, ""):
            raise TmdbError("invalid_filter")

        params = {"language": self.language, "page": page}
        if section in STANDARD_SECTIONS:
            endpoint = STANDARD_SECTIONS[section].format(media_type=media_type)
        elif section == "new":
            endpoint = f"/discover/{media_type}"
            date_field = "primary_release_date" if media_type == "movie" else "first_air_date"
            params.update({
                "sort_by": f"{date_field}.desc",
                f"{date_field}.lte": self.today_provider().isoformat(),
                "vote_count.gte": 3,
                "include_adult": "false",
            })
        elif section == "box_office":
            endpoint = "/discover/movie"
            params.update({"sort_by": "revenue.desc", "vote_count.gte": 100})
        elif section in PLATFORM_FILTERS:
            endpoint = f"/discover/{media_type}"
            parameter, value = PLATFORM_FILTERS[section][media_type]
            params.update({"sort_by": "popularity.desc", parameter: value})
        elif section == "mind_bending":
            endpoint = f"/discover/{media_type}"
            params.update({"sort_by": "popularity.desc", "with_keywords": "970"})
        elif section == "feel_good":
            endpoint = f"/discover/{media_type}"
            params.update({"sort_by": "popularity.desc", "with_genres": "35,10751"})
        elif section == "highly_rated":
            endpoint = f"/discover/{media_type}"
            date_field = "primary_release_date" if media_type == "movie" else "first_air_date"
            params.update({
                "sort_by": "vote_average.desc",
                f"{date_field}.lte": self.today_provider().isoformat(),
                "vote_count.gte": 1000,
                "include_adult": "false",
            })
        elif section == "arabic":
            endpoint = f"/discover/{media_type}"
            params.update({"sort_by": "popularity.desc", "with_original_language": "ar"})
        elif section == "marvel":
            endpoint = f"/discover/{media_type}"
            params.update({"sort_by": "popularity.desc", "with_companies": "420"})
        elif section == "genre":
            genre_key = str(filter_value or "").strip().lower()
            genre_id = GENRE_IDS[media_type].get(genre_key)
            if genre_id is None:
                raise TmdbError("invalid_filter")
            endpoint = f"/discover/{media_type}"
            params.update({
                "with_genres": str(genre_id),
                "sort_by": "popularity.desc",
                "include_adult": "false",
            })
        elif section == "year":
            endpoint = f"/discover/{media_type}"
            current_year = self.today_provider().year
            year_value = self._validate_year(filter_value, current_year)
            date_field = "primary_release_date" if media_type == "movie" else "first_air_date"
            params.update({"sort_by": "popularity.desc", "include_adult": "false"})
            if year_value in ("1990s", "1980s"):
                start = "1990" if year_value == "1990s" else "1980"
                end = "1999" if year_value == "1990s" else "1989"
                params[f"{date_field}.gte"] = f"{start}-01-01"
                params[f"{date_field}.lte"] = f"{end}-12-31"
            else:
                year_field = "primary_release_year" if media_type == "movie" else "first_air_date_year"
                params[year_field] = year_value
        else:
            raise TmdbError("invalid_section")
        return media_type, section, page, endpoint, params

    def _catalog_cache_key(self, media_type, section, page, endpoint, params):
        filters = {
            key: value
            for key, value in params.items()
            if key not in ("language", "page")
        }
        return json.dumps({
            "endpoint": endpoint,
            "media_type": media_type,
            "section": section,
            "language": self.language,
            "page": page,
            "filters": filters,
        }, sort_keys=True, separators=(",", ":"))

    def _cache_key(self, page):
        media_type, section, page, endpoint, params = self._build_request(
            "movie", "trending", page
        )
        return self._catalog_cache_key(media_type, section, page, endpoint, params)

    def _cached(self, key):
        data, age = self.cache.read(key)
        fresh = data if age is not None and age <= TRENDING_TTL else None
        stale = (
            data
            if age is not None and age <= TRENDING_TTL + TRENDING_STALE_WINDOW
            else None
        )
        return fresh, stale

    def _fail(self, code, stale=None):
        self.last_error = code
        if stale is not None and code in {
            "rate_limited", "server_error", "timeout", "network_error",
            "invalid_json", "invalid_response", "request_busy",
        }:
            logger.warning(f"{code}; using stale cache", tag="TMDb")
            return stale
        raise TmdbError(code)

    def _request_data(self, endpoint, params, key, transform):
        fresh, stale = self._cached(key)
        if fresh is not None:
            self.last_error = None
            return fresh
        if not self.token:
            return self._fail("missing_token")
        if self.cache.retry_remaining(key) > 0:
            return self._fail("rate_limited", stale)

        owner_token = self.cache.acquire(key, wait_timeout=0.0 if stale is not None else 2.0)
        if owner_token is None:
            fresh, refreshed_stale = self._cached(key)
            if fresh is not None:
                return fresh
            return self._fail("request_busy", refreshed_stale)

        try:
            fresh, stale = self._cached(key)
            if fresh is not None:
                self.last_error = None
                return fresh
            if self.cache.retry_remaining(key) > 0:
                return self._fail("rate_limited", stale)

            response = None
            try:
                response = self.session.get(
                    f"{TMDB_API_BASE}{endpoint}",
                    headers={
                        "Authorization": f"Bearer {self.token}",
                        "Accept": "application/json",
                    },
                    params=params,
                    timeout=(5, 15),
                )
                status = int(response.status_code)
                if status in (401, 403):
                    return self._fail("unauthorized")
                if status == 404:
                    return self._fail("not_found")
                if status == 429:
                    retry_after = self._retry_after_seconds(
                        response.headers.get("Retry-After"),
                        self.cache.clock(),
                    )
                    self.cache.set_retry_after(key, retry_after)
                    return self._fail("rate_limited", stale)
                if status in (500, 502, 503):
                    return self._fail("server_error", stale)
                if status < 200 or status >= 300:
                    return self._fail("http_error", stale)
                try:
                    payload = response.json()
                except (ValueError, TypeError, UnicodeError):
                    return self._fail("invalid_json", stale)
            except requests.exceptions.Timeout:
                return self._fail("timeout", stale)
            except requests.exceptions.RequestException:
                return self._fail("network_error", stale)
            finally:
                if response is not None and callable(getattr(response, "close", None)):
                    response.close()

            data = transform(payload)
            if data is None:
                return self._fail("invalid_response", stale)
            self.cache.assert_owned(owner_token)
            self.cache.write(key, data)
            self.cache.clear_retry(key)
            self.last_error = None
            return data
        finally:
            self.cache.release(key, owner_token)

    def get_catalog(self, media_type, section, page=1, filter_value=None):
        media_type, section, page, endpoint, params = self._build_request(
            media_type,
            section,
            page,
            filter_value=filter_value,
        )
        key = self._catalog_cache_key(media_type, section, page, endpoint, params)
        def transform(payload):
            if not isinstance(payload, dict) or not isinstance(payload.get("results"), list):
                return None
            results = []
            for item in payload["results"][:20]:
                mapped = self._map_item(item, media_type)
                if mapped is not None:
                    results.append(mapped)
            try:
                total_pages = int(payload.get("total_pages") or 1)
            except (TypeError, ValueError):
                total_pages = 1
            return {
                "results": results,
                "page": page,
                "total_pages": min(20, max(1, total_pages)),
            }

        return self._request_data(endpoint, params, key, transform)

    def search_multi(self, query, page=1):
        query = self._validate_query(query)
        page = self._validate_page(page)
        endpoint = "/search/multi"
        params = {
            "query": query,
            "language": self.language,
            "page": page,
            "include_adult": "false",
        }
        key = json.dumps({
            "endpoint": endpoint,
            "language": self.language,
            "page": page,
            "query": query,
        }, sort_keys=True, separators=(",", ":"))

        def transform(payload):
            if not isinstance(payload, dict) or not isinstance(payload.get("results"), list):
                return None
            results = []
            for item in payload["results"][:20]:
                if not isinstance(item, dict):
                    continue
                media_type = str(item.get("media_type") or "").strip().lower()
                if media_type in VALID_MEDIA_TYPES:
                    mapped = self._map_item(item, media_type)
                elif media_type == "person":
                    mapped = self._map_person(item)
                else:
                    mapped = None
                if mapped is not None:
                    results.append(mapped)
            try:
                total_pages = int(payload.get("total_pages") or 1)
            except (TypeError, ValueError):
                total_pages = 1
            return {
                "results": results,
                "page": page,
                "total_pages": min(20, max(1, total_pages)),
                "query": query,
            }

        return self._request_data(endpoint, params, key, transform)

    def get_person_credits(self, person_id):
        person_id = self._validate_person_id(person_id)
        endpoint = f"/person/{person_id}/combined_credits"
        params = {"language": self.language}
        key = json.dumps({
            "endpoint": endpoint,
            "language": self.language,
        }, sort_keys=True, separators=(",", ":"))

        def transform(payload):
            if not isinstance(payload, dict) or not isinstance(payload.get("cast"), list):
                return None
            results = []
            seen = set()
            for item in payload["cast"]:
                if not isinstance(item, dict):
                    continue
                media_type = str(item.get("media_type") or "").strip().lower()
                if media_type not in VALID_MEDIA_TYPES:
                    continue
                mapped = self._map_item(item, media_type)
                if mapped is None:
                    continue
                identity = (media_type, mapped["id"])
                if identity in seen:
                    continue
                seen.add(identity)
                results.append(mapped)
                if len(results) >= MAX_PERSON_CREDITS:
                    break
            return {"results": results, "person_id": person_id}

        return self._request_data(endpoint, params, key, transform)

    @staticmethod
    def _select_original_poster(posters, original_language):
        """Prefer original-language artwork, then textless artwork."""
        if not isinstance(posters, list):
            return ""
        language = str(original_language or "").strip().lower()
        if not language or len(language) != 2 or not language.isalpha():
            return ""

        def quality(poster):
            try:
                votes = float(poster.get("vote_average") or 0)
                count = int(poster.get("vote_count") or 0)
                width = int(poster.get("width") or 0)
            except (TypeError, ValueError, OverflowError):
                return (0, 0, 0)
            return (votes, count, width)

        for preferred_language in (language, None):
            eligible = [poster for poster in posters
                        if isinstance(poster, dict)
                        and poster.get("iso_639_1") == preferred_language
                        and str(poster.get("file_path") or "").startswith("/")]
            if eligible:
                return max(eligible, key=quality)["file_path"]
        return ""

    def original_poster(self, media_type, tmdb_id, original_language, allow_network=True):
        """Return a cached preferred poster URL, or an empty fallback.

        Empty selections are cached as well. This method never raises for
        artwork failures and does not affect the catalog request.
        """
        if media_type not in VALID_MEDIA_TYPES:
            return ""
        try:
            item_id = int(tmdb_id)
        except (ValueError, TypeError):
            return ""
        language = str(original_language or "").strip().lower()
        if item_id <= 0 or len(language) != 2 or not language.isalpha():
            return ""
        key = "poster_v1:%s:%s:%s" % (media_type, item_id, language)
        fresh, stale = self._cached(key)
        if isinstance(fresh, dict):
            return self._image_url(fresh.get("path"), "w342")
        if not allow_network:
            return self._image_url((stale or {}).get("path"), "w342") if isinstance(stale, dict) else ""
        try:
            result = self._request_data(
                "/%s/%s/images" % (media_type, item_id),
                {"include_image_language": "%s,null" % language},
                key,
                lambda payload: {"path": self._select_original_poster(
                    payload.get("posters"), language)} if isinstance(payload, dict)
                    and isinstance(payload.get("posters"), list) else None,
            )
            return self._image_url(result.get("path"), "w342")
        except (TmdbError, ValueError, TypeError):
            return ""

    def enrich_original_posters(self, items, max_requests=MAX_POSTER_LOOKUPS_PER_LIST):
        """Apply cached artwork with a strict budget for uncached requests.

        Invalid catalog records never consume the network budget. Cached
        artwork is reused even after the budget has been exhausted.
        """
        try:
            remaining = max(0, min(int(max_requests), MAX_POSTER_LOOKUPS_PER_LIST))
        except (TypeError, ValueError, OverflowError):
            remaining = 0
        if not isinstance(items, list):
            return items
        for item in items:
            if not isinstance(item, dict):
                continue
            media_type = item.get("media_type")
            language = str(item.get("original_language") or "").strip().lower()
            if media_type not in VALID_MEDIA_TYPES or len(language) != 2 or not language.isalpha():
                continue
            try:
                item_id = int(item.get("id"))
            except (TypeError, ValueError, OverflowError):
                continue
            if item_id <= 0:
                continue
            key = "poster_v1:%s:%s:%s" % (media_type, item_id, language)
            fresh, _ = self._cached(key)
            uncached = fresh is None
            if uncached and remaining <= 0:
                continue
            if uncached:
                remaining -= 1
                preferred = self.original_poster(media_type, item_id, language)
            else:
                preferred = self._image_url(fresh.get("path"), "w342") \
                    if isinstance(fresh, dict) else ""
            if preferred:
                item["poster_url"] = preferred
        return items

    def get_trending_movies(self, page=1):
        return self.get_catalog("movie", "trending", page)["results"]
