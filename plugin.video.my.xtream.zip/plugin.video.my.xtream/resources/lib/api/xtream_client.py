"""HTTP client for the Xtream Codes ``player_api.php`` and stream URLs."""
import json
import re
import threading
from urllib.parse import quote

import requests


class XtreamCodesClient:
    _SAFE_MEDIA_ID = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
    _SAFE_EXTENSION = re.compile(r"^[A-Za-z0-9]{1,10}$")

    def __init__(self, base_url, username, password):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.user_info = {}
        self.server_info = {}
        self.auth_data = None
        self._lock = threading.Lock()
        self.last_error = None  # Code de diagnostic sans URL ni identifiants

    def _request_json(self, params, timeout):
        """Retourne les données ou None; ne journalise jamais l'URL sensible."""
        url = f"{self.base_url}/player_api.php"
        try:
            # Read directly from the decoded response stream to avoid retaining
            # requests' cached response.content alongside the parsed JSON.
            with self.session.get(url, params=params, timeout=timeout, stream=True) as response:
                response.raise_for_status()
                response.raw.decode_content = True
                data = json.load(response.raw)
        except requests.exceptions.Timeout:
            error = "timeout"
        except requests.exceptions.HTTPError:
            error = "http_error"
        except requests.exceptions.RequestException:
            error = "network_error"
        except (ValueError, TypeError, UnicodeError):
            error = "invalid_json"
        except OSError:
            error = "network_error"
        else:
            with self._lock:
                self.last_error = None
            return data
        with self._lock:
            self.last_error = error
        return None

    def _get(self, action, **kwargs):
        params = {"username": self.username, "password": self.password, "action": action}
        params.update(kwargs)
        return self._request_json(params, timeout=15)

    def get_live_categories(self):
        return self._get("get_live_categories")

    def get_live_streams(self, category_id):
        return self._get("get_live_streams", category_id=category_id)

    def get_vod_categories(self):
        return self._get("get_vod_categories")

    def get_vod_streams(self, category_id=None):
        if category_id:
            return self._get("get_vod_streams", category_id=category_id)
        return self._get("get_vod_streams")

    def get_vod_info(self, vod_id):
        return self._get("get_vod_info", vod_id=vod_id)

    def get_series_categories(self):
        return self._get("get_series_categories")

    def get_series_list(self, category_id=None):
        if category_id:
            return self._get("get_series", category_id=category_id)
        return self._get("get_series")

    def get_series_info(self, series_id):
        return self._get("get_series_info", series_id=series_id)

    def get_general_info(self):
        """Récupère les informations du compte sans changer le contrat existant."""
        params = {"username": self.username, "password": self.password}
        data = self._request_json(params, timeout=10)
        if not isinstance(data, dict):
            with self._lock:
                self.last_error = "invalid_account_response" if data is not None else self.last_error
            return None
        with self._lock:
            self.user_info = data.get("user_info", {}) if isinstance(data.get("user_info"), dict) else {}
            self.server_info = data.get("server_info", {}) if isinstance(data.get("server_info"), dict) else {}
            self.auth_data = data
        return data

    def get_live_url(self, stream_id, extension="ts"):
        return f"{self.base_url}/live/{self._encoded_username}/{self._encoded_password}/{stream_id}.{extension}"

    def get_vod_url(self, stream_id, extension="mp4"):
        return f"{self.base_url}/movie/{self._encoded_username}/{self._encoded_password}/{stream_id}.{extension}"

    def get_series_episode_url(self, episode_id, extension="mp4"):
        return f"{self.base_url}/series/{self._encoded_username}/{self._encoded_password}/{episode_id}.{extension}"

    @property
    def _encoded_username(self):
        return quote(str(self.username), safe="")

    @property
    def _encoded_password(self):
        return quote(str(self.password), safe="")

    def get_stream_url(self, media_type, media_id, extension=None):
        media_type = str(media_type or "").strip().lower()
        media_id = str(media_id or "").strip()
        if not self._SAFE_MEDIA_ID.fullmatch(media_id):
            return None

        default_extension = "ts" if media_type == "live" else "mp4"
        extension = str(extension or default_extension).strip().lower()
        if not self._SAFE_EXTENSION.fullmatch(extension):
            return None

        if media_type == "live":
            return self.get_live_url(media_id, extension)
        if media_type == "vod":
            return self.get_vod_url(media_id, extension)
        if media_type == "series":
            return self.get_series_episode_url(media_id, extension)
        return None

    def resolve_stream_url(self, media_type, media_id, extension=None, legacy_url=None):
        stream_url = self.get_stream_url(media_type, media_id, extension)
        if stream_url:
            normalized_type = str(media_type).strip().lower()
            normalized_extension = str(
                extension or ("ts" if normalized_type == "live" else "mp4")
            ).strip().lower()
            return stream_url, normalized_type, str(media_id).strip(), normalized_extension

        if not isinstance(legacy_url, str) or not legacy_url:
            return None
        if any(char in legacy_url for char in ('"', "\n", "\r", "\x00")):
            return None

        builders = (
            ("live", "ts", self.get_live_url),
            ("vod", "mp4", self.get_vod_url),
            ("series", "mp4", self.get_series_episode_url),
        )
        for legacy_type, default_extension, builder in builders:
            prefix = builder("0", default_extension).rsplit("/", 1)[0] + "/"
            if not legacy_url.startswith(prefix):
                continue
            filename = legacy_url[len(prefix):]
            if "." not in filename:
                continue
            legacy_id, legacy_extension = filename.rsplit(".", 1)
            rebuilt = self.get_stream_url(legacy_type, legacy_id, legacy_extension)
            if rebuilt == legacy_url:
                return rebuilt, legacy_type, legacy_id, legacy_extension.lower()
        return None
