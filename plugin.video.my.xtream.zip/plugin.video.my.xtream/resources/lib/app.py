"""Plugin bootstrap: build the context, register one view, dispatch the route."""
import importlib

import xbmcgui
import xbmcplugin

from resources.lib.core.context import PluginContext
from resources.lib.core.constants import Mode
from resources.lib.routing import router


_VIEW_MODULES = {
    Mode.HOME: "home",
    Mode.LIVE_CATEGORIES: "live",
    Mode.LIVE_STREAMS: "live",
    Mode.VOD_CATEGORIES: "vod",
    Mode.VOD_STREAMS: "vod",
    Mode.VOD_INFO: "vod",
    Mode.RECENT_VOD: "vod",
    Mode.SERIES_CATEGORIES: "series",
    Mode.SERIES_LIST: "series",
    Mode.SERIES_INFO: "series",
    Mode.SERIES_EPISODES: "series",
    Mode.RECENT_SERIES: "series",
    Mode.SEARCH_GLOBAL: "search",
    Mode.SEARCH_VOD: "search",
    Mode.SEARCH_SERIES: "search",
    Mode.CINEMA_XTREAM_SEARCH: "search",
    Mode.HISTORY_VOD: "history",
    Mode.HISTORY_SERIES: "history",
    Mode.CLEAR_HISTORY: "history",
    Mode.REMOVE_HISTORY: "history",
    Mode.ACCOUNT_INFO: "account",
    Mode.CLEAR_CACHE: "maintenance",
    Mode.PLAY: "play",
    Mode.CINEMA_SELECTION: "cinema",
    Mode.CINEMA_HOME: "cinema",
    Mode.CINEMA_SECTIONS: "cinema",
    Mode.CINEMA_FILTERS: "cinema",
    Mode.CINEMA_LIST: "cinema",
    Mode.CINEMA_SEARCH: "cinema",
    Mode.CINEMA_PERSON_CREDITS: "cinema",
}


def load_views(mode=None):
    """Import only the view module that owns ``mode``."""
    module_name = _VIEW_MODULES.get(mode)
    if module_name is None and mode is not Mode.HOME:
        return False
    importlib.import_module("resources.lib.views.{}".format(module_name))
    return True


def _ask_for_configuration(ctx):
    xbmcgui.Dialog().ok(
        "Erreur Configuration",
        "Veuillez configurer l'URL, Identifiant et Mot de passe dans les paramètres de l'extension.",
    )
    ctx.addon.openSettings()
    xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)


def run(argv=None):
    ctx = PluginContext(argv)
    load_views(ctx.params.get("mode"))
    if router.resolve(ctx.params.get("mode")) is None:
        xbmcplugin.endOfDirectory(ctx.handle, succeeded=False)
        return
    router.dispatch(ctx, on_missing_account=_ask_for_configuration)
