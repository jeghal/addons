import glob
import hashlib
import json
import os
import tempfile
import time
from typing import Dict, List, Optional, Union

import xbmc


class CacheManager:
    def __init__(self, profile_path: str, namespace: str = "default"):
        namespace_hash = hashlib.sha256(str(namespace).encode("utf-8")).hexdigest()
        self.cache_dir = os.path.join(profile_path, "cache", namespace_hash)
        os.makedirs(self.cache_dir, exist_ok=True)
        self.expiration = 6 * 60 * 60

    def _get_file_path(self, key: str) -> str:
        hashed_key = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{hashed_key}.json")

    def _get_job_lock_path(self, job_name: str) -> str:
        safe_name = hashlib.sha256(job_name.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{safe_name}.lock")

    def get(self, key: str) -> Optional[Union[List, Dict]]:
        file_path = self._get_file_path(key)
        if not os.path.exists(file_path):
            return None

        try:
            if time.time() - os.path.getmtime(file_path) > self.expiration:
                return None
            with open(file_path, "r", encoding="utf-8") as cache_handle:
                return json.load(cache_handle)
        except Exception as error:
            xbmc.log(
                f"[Xtream] Cache read failed: {type(error).__name__}",
                xbmc.LOGERROR,
            )
            return None

    def set(self, key: str, data: Union[List, Dict]) -> None:
        file_path = self._get_file_path(key)
        descriptor, temporary_path = tempfile.mkstemp(
            prefix="cache.",
            suffix=".tmp",
            dir=self.cache_dir,
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as cache_handle:
                json.dump(data, cache_handle, ensure_ascii=False)
                cache_handle.flush()
                os.fsync(cache_handle.fileno())
            os.replace(temporary_path, file_path)
        except Exception as error:
            try:
                os.remove(temporary_path)
            except FileNotFoundError:
                pass
            xbmc.log(
                f"[Xtream] Cache write failed: {type(error).__name__}",
                xbmc.LOGERROR,
            )

    def is_valid(self, key: str) -> bool:
        file_path = self._get_file_path(key)
        try:
            return (
                os.path.exists(file_path)
                and time.time() - os.path.getmtime(file_path) < self.expiration
            )
        except OSError:
            return False

    def acquire_job(self, job_name: str, stale_after: float = 120.0) -> bool:
        lock_path = self._get_job_lock_path(job_name)
        try:
            descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(descriptor)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock_path) > stale_after:
                    os.remove(lock_path)
                    descriptor = os.open(
                        lock_path,
                        os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                    )
                    os.close(descriptor)
                    return True
            except (FileExistsError, FileNotFoundError, OSError):
                pass
            return False

    def release_job(self, job_name: str) -> None:
        try:
            os.remove(self._get_job_lock_path(job_name))
        except FileNotFoundError:
            pass

    def clear(self) -> None:
        for file_path in glob.glob(os.path.join(self.cache_dir, "*.json")):
            try:
                os.remove(file_path)
            except OSError as error:
                xbmc.log(
                    f"[Xtream] Cache clear failed: {type(error).__name__}",
                    xbmc.LOGWARNING,
                )
