import glob
import hashlib
import json
import os
import tempfile
import time
import uuid
from typing import Callable, Dict, List, Optional, Union

import xbmc


DEFAULT_CACHE_EXPIRATION = 6 * 60 * 60
CATALOG_CACHE_EXPIRATION = 24 * 60 * 60
CATALOG_RETRY_COOLDOWN = 5 * 60
CLOCK_SKEW_TOLERANCE = 5 * 60
CATALOG_KEYS = frozenset(("vod", "series"))


class CacheManager:
    def __init__(self, profile_path: str, namespace: str = "default"):
        namespace_hash = hashlib.sha256(str(namespace).encode("utf-8")).hexdigest()
        self.cache_dir = os.path.join(profile_path, "cache", namespace_hash)
        os.makedirs(self.cache_dir, exist_ok=True)
        self.expiration = DEFAULT_CACHE_EXPIRATION

    def _get_file_path(self, key: str) -> str:
        hashed_key = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{hashed_key}.json")

    def _get_job_lock_path(self, job_name: str) -> str:
        safe_name = hashlib.sha256(job_name.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{safe_name}.lock")

    def _get_catalog_retry_path(self, key: str) -> str:
        safe_name = hashlib.sha256(f"catalog-retry:{key}".encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{safe_name}.retry")

    def _get_expiration(self, key: str) -> float:
        if key in CATALOG_KEYS:
            return CATALOG_CACHE_EXPIRATION
        return self.expiration

    def _is_file_fresh(self, key: str, file_path: str) -> bool:
        age = time.time() - os.path.getmtime(file_path)
        return -CLOCK_SKEW_TOLERANCE <= age < self._get_expiration(key)

    def _get_catalog_data(self, key: str, allow_expired: bool = False) -> Optional[List]:
        data = self.get(key, allow_expired=allow_expired)
        if isinstance(data, list):
            return data
        if data is not None:
            xbmc.log(
                f"[Xtream] Invalid {key} catalog cache type ignored",
                xbmc.LOGWARNING,
            )
        return None

    def _catalog_cooldown_active(self, key: str) -> bool:
        retry_path = self._get_catalog_retry_path(key)
        try:
            with open(retry_path, "r", encoding="ascii") as retry_handle:
                failed_at = float(retry_handle.read().strip())
            age = time.time() - failed_at
            if age < -CLOCK_SKEW_TOLERANCE:
                os.remove(retry_path)
                return False
            return age < CATALOG_RETRY_COOLDOWN
        except (FileNotFoundError, ValueError, UnicodeError):
            return False
        except OSError:
            return False

    def _record_catalog_failure(self, key: str) -> None:
        retry_path = self._get_catalog_retry_path(key)
        temporary_path = None
        try:
            descriptor, temporary_path = tempfile.mkstemp(
                prefix="retry.",
                suffix=".tmp",
                dir=self.cache_dir,
            )
            with os.fdopen(descriptor, "w", encoding="ascii") as retry_handle:
                retry_handle.write(str(time.time()))
                retry_handle.flush()
                os.fsync(retry_handle.fileno())
            os.replace(temporary_path, retry_path)
        except OSError as error:
            if temporary_path:
                try:
                    os.remove(temporary_path)
                except OSError:
                    pass
            xbmc.log(
                f"[Xtream] Catalog retry state write failed: {type(error).__name__}",
                xbmc.LOGWARNING,
            )

    def _clear_catalog_failure(self, key: str) -> None:
        try:
            os.remove(self._get_catalog_retry_path(key))
        except FileNotFoundError:
            pass
        except OSError as error:
            xbmc.log(
                f"[Xtream] Catalog retry state clear failed: {type(error).__name__}",
                xbmc.LOGWARNING,
            )

    def _read_lock_token(self, lock_path: str) -> Optional[str]:
        try:
            with open(lock_path, "r", encoding="ascii") as lock_handle:
                return lock_handle.read().strip() or None
        except (OSError, UnicodeError):
            return None

    def _acquire_catalog_lock(
        self,
        key: str,
        wait_timeout: float = 30.0,
        stale_after: float = 300.0,
        poll_interval: float = 0.1,
    ) -> Optional[str]:
        lock_path = self._get_job_lock_path(f"catalog:{key}")
        deadline = time.monotonic() + max(0.0, wait_timeout)

        while True:
            owner_token = uuid.uuid4().hex
            try:
                descriptor = os.open(
                    lock_path,
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                with os.fdopen(descriptor, "w", encoding="ascii") as lock_handle:
                    lock_handle.write(owner_token)
                    lock_handle.flush()
                    os.fsync(lock_handle.fileno())
                return owner_token
            except FileExistsError:
                try:
                    observed_stat = os.stat(lock_path)
                    observed_token = self._read_lock_token(lock_path)
                    if time.time() - observed_stat.st_mtime > stale_after:
                        current_stat = os.stat(lock_path)
                        current_token = self._read_lock_token(lock_path)
                        if (
                            current_token == observed_token
                            and current_stat.st_mtime_ns == observed_stat.st_mtime_ns
                            and current_stat.st_size == observed_stat.st_size
                        ):
                            os.remove(lock_path)
                            continue
                except FileNotFoundError:
                    continue
                except OSError:
                    pass

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            time.sleep(min(poll_interval, remaining))

    def _release_catalog_lock(self, key: str, owner_token: str) -> None:
        lock_path = self._get_job_lock_path(f"catalog:{key}")
        try:
            if self._read_lock_token(lock_path) == owner_token:
                os.remove(lock_path)
        except FileNotFoundError:
            pass
        except OSError as error:
            xbmc.log(
                f"[Xtream] Catalog lock release failed: {type(error).__name__}",
                xbmc.LOGWARNING,
            )

    def get_or_fetch_catalog(
        self,
        key: str,
        fetcher: Callable[[], Optional[Union[List, Dict]]],
        transform: Optional[Callable[[List], List]] = None,
        wait_timeout: float = 30.0,
        stale_after: float = 300.0,
    ) -> Optional[Union[List, Dict]]:
        cached_data = self._get_catalog_data(key)
        if cached_data is not None:
            return cached_data

        stale_data = self._get_catalog_data(key, allow_expired=True)
        if self._catalog_cooldown_active(key):
            return stale_data

        owner_token = self._acquire_catalog_lock(
            key,
            wait_timeout=0.0 if stale_data is not None else wait_timeout,
            stale_after=stale_after,
        )
        if owner_token is None:
            if stale_data is None:
                xbmc.log(
                    f"[Xtream] Timed out waiting for {key} catalog cache",
                    xbmc.LOGWARNING,
                )
                return self._get_catalog_data(key)
            return stale_data

        try:
            cached_data = self._get_catalog_data(key)
            if cached_data is not None:
                return cached_data

            if self._catalog_cooldown_active(key):
                return stale_data

            del stale_data
            try:
                catalog_data = fetcher()
                if not isinstance(catalog_data, list):
                    raise ValueError("invalid catalog response")
                if transform is not None:
                    catalog_data = transform(catalog_data)
                if not isinstance(catalog_data, list):
                    raise ValueError("invalid transformed catalog")
                if not self.set(key, catalog_data):
                    raise OSError("catalog cache write failed")
            except Exception as error:
                self._record_catalog_failure(key)
                xbmc.log(
                    f"[Xtream] {key} catalog refresh failed: {type(error).__name__}",
                    xbmc.LOGWARNING,
                )
                try:
                    del catalog_data
                except UnboundLocalError:
                    pass
                return self._get_catalog_data(key, allow_expired=True)

            self._clear_catalog_failure(key)
            return catalog_data
        finally:
            self._release_catalog_lock(key, owner_token)

    def get(
        self,
        key: str,
        allow_expired: bool = False,
    ) -> Optional[Union[List, Dict]]:
        file_path = self._get_file_path(key)
        if not os.path.exists(file_path):
            return None

        try:
            if not allow_expired and not self._is_file_fresh(key, file_path):
                return None
            with open(file_path, "r", encoding="utf-8") as cache_handle:
                return json.load(cache_handle)
        except (ValueError, UnicodeError) as error:
            # A broken JSON cache must not cause repeated parse failures.
            # Only remove the same file version that failed to decode.
            try:
                failed_stat = os.stat(file_path)
                with open(file_path, "r", encoding="utf-8") as check_handle:
                    json.load(check_handle)
            except (ValueError, UnicodeError):
                try:
                    current_stat = os.stat(file_path)
                    if (current_stat.st_mtime_ns == failed_stat.st_mtime_ns
                            and current_stat.st_size == failed_stat.st_size):
                        os.remove(file_path)
                except OSError:
                    pass
            except OSError:
                pass
            xbmc.log(
                f"[Xtream] Invalid cache ignored: {type(error).__name__}",
                xbmc.LOGWARNING,
            )
            return None
        except Exception as error:
            xbmc.log(
                f"[Xtream] Cache read failed: {type(error).__name__}",
                xbmc.LOGERROR,
            )
            return None

    def set(self, key: str, data: Union[List, Dict]) -> bool:
        file_path = self._get_file_path(key)
        temporary_path = None
        try:
            descriptor, temporary_path = tempfile.mkstemp(
                prefix="cache.",
                suffix=".tmp",
                dir=self.cache_dir,
            )
            with os.fdopen(descriptor, "w", encoding="utf-8") as cache_handle:
                json.dump(data, cache_handle, ensure_ascii=False, separators=(",", ":"))
                cache_handle.flush()
                os.fsync(cache_handle.fileno())
            os.replace(temporary_path, file_path)
            return True
        except Exception as error:
            if temporary_path:
                try:
                    os.remove(temporary_path)
                except FileNotFoundError:
                    pass
            xbmc.log(
                f"[Xtream] Cache write failed: {type(error).__name__}",
                xbmc.LOGERROR,
            )
            return False

    def is_valid(self, key: str) -> bool:
        file_path = self._get_file_path(key)
        try:
            return (
                os.path.exists(file_path)
                and os.path.getsize(file_path) > 0
                and self._is_file_fresh(key, file_path)
            )
        except OSError:
            return False

    def acquire_job(self, job_name: str, stale_after: float = 900.0) -> bool:
        lock_path = self._get_job_lock_path(job_name)
        try:
            descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(descriptor)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock_path) > stale_after:
                    os.remove(lock_path)
                    descriptor = os.open(
                        lock_path,
                        os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                    )
                    os.close(descriptor)
                    return True
            except (FileExistsError, FileNotFoundError, OSError):
                pass
            return False

    def release_job(self, job_name: str) -> None:
        try:
            os.remove(self._get_job_lock_path(job_name))
        except FileNotFoundError:
            pass

    def clear(self, wait_timeout: float = 5.0) -> None:
        deadline = time.monotonic() + max(0.0, wait_timeout)
        owner_tokens = {}

        try:
            for key in sorted(CATALOG_KEYS):
                owner_token = self._acquire_catalog_lock(
                    key,
                    wait_timeout=max(0.0, deadline - time.monotonic()),
                )
                if owner_token is None:
                    raise TimeoutError("cache clear timed out")
                owner_tokens[key] = owner_token

            file_paths = glob.glob(os.path.join(self.cache_dir, "*.json"))
            file_paths.extend(
                self._get_catalog_retry_path(key) for key in CATALOG_KEYS
            )
            failed = False
            for file_path in file_paths:
                try:
                    os.remove(file_path)
                except FileNotFoundError:
                    pass
                except OSError as error:
                    failed = True
                    xbmc.log(
                        f"[Xtream] Cache clear failed: {type(error).__name__}",
                        xbmc.LOGWARNING,
                    )
            if failed:
                raise OSError("cache clear failed")
        finally:
            for key in reversed(sorted(owner_tokens)):
                self._release_catalog_lock(key, owner_tokens[key])
