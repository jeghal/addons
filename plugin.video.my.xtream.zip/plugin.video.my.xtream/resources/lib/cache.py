import os
import json
import time
import hashlib
import xbmc
import glob
from typing import Optional, Dict, Any, List, Union

class CacheManager:
    def __init__(self, profile_path: str):
        self.cache_dir = os.path.join(profile_path, 'cache')
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
        
        # 6 Hours in seconds (default)
        self.expiration = 6 * 60 * 60 

    def _get_file_path(self, key: str) -> str:
        """Generates a safe filename based on the key."""
        # Clean key for safety or just hash it. Hashing is safer for special chars.
        hashed_key = hashlib.md5(key.encode()).hexdigest()
        return os.path.join(self.cache_dir, f"{hashed_key}.json")

    def get(self, key: str) -> Optional[Union[List, Dict]]:
        """
        Retrieves data from cache if it exists and is not expired.
        """
        file_path = self._get_file_path(key)
        if not os.path.exists(file_path):
            return None
            
        try:
            # Check expiration
            mtime = os.path.getmtime(file_path)
            if time.time() - mtime > self.expiration:
                # xbmc.log(f"[Xtream] Cache expired for {key}", xbmc.LOGINFO)
                return None
                
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data
        except Exception as e:
            xbmc.log(f"[Xtream] Error reading cache {key}: {e}", xbmc.LOGERROR)
            return None

    def set(self, key: str, data: Union[List, Dict]) -> None:
        """
        Saves data to cache file.
        """
        file_path = self._get_file_path(key)
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            # xbmc.log(f"[Xtream] Cache updated for {key}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Xtream] Error writing cache {key}: {e}", xbmc.LOGERROR)

    def is_valid(self, key: str) -> bool:
        """
        Checks if valid cache exists without loading it.
        """
        file_path = self._get_file_path(key)
        if not os.path.exists(file_path):
            return False
        
        return (time.time() - os.path.getmtime(file_path)) < self.expiration

    def clear(self) -> None:
        """
        Clears all JSON files in the cache directory.
        """
        files = glob.glob(os.path.join(self.cache_dir, "*.json"))
        for f in files:
            try:
                os.remove(f)
                xbmc.log(f"[Xtream] Cache file removed: {f}", xbmc.LOGINFO)
            except OSError as e:
                # Retry once if file is locked (common on Windows)
                if e.errno == 13 or e.errno == 32: # Permission denied or Used by another process
                    try:
                        time.sleep(0.1)
                        os.remove(f)
                        xbmc.log(f"[Xtream] Cache file removed (retry): {f}", xbmc.LOGINFO)
                    except:
                        pass # Ignore provided it's just a cache file
                else:
                    xbmc.log(f"[Xtream] Error removing cache file {f}: {e}", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"[Xtream] Error removing cache file {f}: {e}", xbmc.LOGWARNING)
