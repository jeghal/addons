import os
import json
import time
import xbmc
from typing import Optional, Dict, Any, List

class CacheManager:
    def __init__(self, profile_path: str):
        self.cache_dir = os.path.join(profile_path, 'cache')
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
        
        self.cache_files = {
            "vod": os.path.join(self.cache_dir, "vod_streams.json"),
            "series": os.path.join(self.cache_dir, "series_list.json")
        }
        
        # 24 Hours in seconds
        self.expiration = 24 * 60 * 60 

    def get(self, key: str) -> Optional[List[Dict[str, Any]]]:
        """
        Retrieves data from cache if it exists and is not expired.
        """
        file_path = self.cache_files.get(key)
        if not file_path or not os.path.exists(file_path):
            return None
            
        try:
            # Check expiration
            mtime = os.path.getmtime(file_path)
            if time.time() - mtime > self.expiration:
                xbmc.log(f"[Xtream] Cache expired for {key}", xbmc.LOGINFO)
                return None
                
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data
        except Exception as e:
            xbmc.log(f"[Xtream] Error reading cache {key}: {e}", xbmc.LOGERROR)
            return None

    def set(self, key: str, data: List[Dict[str, Any]]) -> None:
        """
        Saves data to cache file.
        """
        file_path = self.cache_files.get(key)
        if not file_path: return
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            xbmc.log(f"[Xtream] Cache updated for {key}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Xtream] Error writing cache {key}: {e}", xbmc.LOGERROR)

    def is_valid(self, key: str) -> bool:
        """
        Checks if valid cache exists without loading it.
        """
        file_path = self.cache_files.get(key)
        if not file_path or not os.path.exists(file_path):
            return False
        
        return (time.time() - os.path.getmtime(file_path)) < self.expiration
