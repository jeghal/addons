import requests
import json
import threading

class XtreamCodesClient:
    def __init__(self, base_url, username, password):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.user_info = {}
        self.server_info = {}
        self.auth_data = None
        self._lock = threading.Lock()

    def _get(self, action, **kwargs):
        """
        Helper pour effectuer les requêtes API
        :param action: L'action à effectuer (ex: 'get_live_categories')
        :param kwargs: Paramètres supplémentaires
        :return: JSON response or None
        """
        params = {
            "username": self.username,
            "password": self.password,
            "action": action
        }
        params.update(kwargs)
        
        url = f"{self.base_url}/player_api.php"
        try:
            # Timeout raisonnable pour éviter le blocage de Kodi
            r = self.session.get(url, params=params, timeout=15)
            r.raise_for_status()
            try:
                return r.json()
            except json.JSONDecodeError:
                return None
        except requests.RequestException:
            return None

    def get_live_categories(self):
        return self._get("get_live_categories")

    def get_live_streams(self, category_id):
        return self._get("get_live_streams", category_id=category_id)

    def get_vod_categories(self):
        return self._get("get_vod_categories")

    def get_vod_streams(self, category_id=None):
        if category_id:
            return self._get("get_vod_streams", category_id=category_id)
        return self._get("get_vod_streams")

    def get_vod_info(self, vod_id):
        return self._get("get_vod_info", vod_id=vod_id)

    def get_series_categories(self):
        return self._get("get_series_categories")

    def get_series_list(self, category_id=None):
        if category_id:
            return self._get("get_series", category_id=category_id)
        return self._get("get_series")

    def get_series_info(self, series_id):
        return self._get("get_series_info", series_id=series_id)

    def get_general_info(self):
        """
        Récupère les infos du compte + serveur.
        Stocke le résultat en cache local pour usage ultérieur.
        """
        # Pas d'action spécifique, juste user/pass
        # L'API Xtream Codes retourne info user/server si pas d'action
        url = f"{self.base_url}/player_api.php"
        params = {
            "username": self.username,
            "password": self.password
        }
        try:
            r = self.session.get(url, params=params, timeout=10)
            r.raise_for_status()
            data = r.json()
            with self._lock:
                self.user_info = data.get("user_info", {})
                self.server_info = data.get("server_info", {})
                self.auth_data = data
            return data
        except:
            return None

    def get_live_url(self, stream_id, extension="ts"):
        return f"{self.base_url}/live/{self.username}/{self.password}/{stream_id}.{extension}"

    def get_vod_url(self, stream_id, extension="mp4"):
        return f"{self.base_url}/movie/{self.username}/{self.password}/{stream_id}.{extension}"

    def get_series_episode_url(self, episode_id, extension="mp4"):
        return f"{self.base_url}/series/{self.username}/{self.password}/{episode_id}.{extension}"
