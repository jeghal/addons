"""Central constants: identifiers, route names, window properties and limits.

Nothing here imports Kodi, so the module is safe to use from pure code.
"""

ADDON_ID = "plugin.video.my.xtream"
PLUGIN_BASE_URL = "plugin://{}/".format(ADDON_ID)

# Kodi stock icons
DEFAULT_VOD_ICON = "DefaultMovies.png"
DEFAULT_SERIES_ICON = "DefaultTVShows.png"
DEFAULT_FOLDER_ICON = "DefaultFolder.png"
DEFAULT_INFO_ICON = "DefaultInfo.png"

HOME_WINDOW_ID = 10000

# Behaviour limits
DEFAULT_RECENT_LIMIT = 50
SEARCH_MIN_QUERY_LENGTH = 2
SEARCH_RESULT_LIMIT = 50
GLOBAL_SEARCH_RESULT_LIMIT = 30
HISTORY_LIMIT = 20
EPISODE_RESUME_LIMIT = 500
RESUME_PROMPT_THRESHOLD_SECONDS = 60
NEXT_EPISODE_DELAY_SECONDS = 2.0

# TMDb read-only token shipped for backwards compatibility with existing
# installations. Users should set their own token in the add-on settings; this
# fallback is used only when that setting is empty.
TMDB_FALLBACK_TOKEN = (
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjNTdhMjEyOWVhM2I0ZDU0MGVmMTU5OWI2OWEyNzQxMSIsIm5iZiI6MTYxMjU2NTk4Ni43"
    "MDg5OTk5LCJzdWIiOiI2MDFkY2RlMmQyMGM4NzAwM2YwN2Y3ODkiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0."
    "5eXj9w-DTy2FjkiXb74nearYsrnRKMnZbbFFIhpK_-U"
)
TMDB_LANGUAGES = ("ar", "en-US")
DEFAULT_TMDB_LANGUAGE = "ar"


class MediaType:
    LIVE = "live"
    VOD = "vod"
    SERIES = "series"


class Mode:
    """Plugin route names (the ``mode`` query parameter). Values are stable
    because they appear in saved URLs, favourites and history entries."""

    HOME = None

    LIVE_CATEGORIES = "live_categories"
    LIVE_STREAMS = "live_streams"

    VOD_CATEGORIES = "vod_categories"
    VOD_STREAMS = "vod_streams"
    VOD_INFO = "vod_info"
    RECENT_VOD = "recent_vod"

    SERIES_CATEGORIES = "series_categories"
    SERIES_LIST = "series_list"
    SERIES_INFO = "series_info"
    SERIES_EPISODES = "series_episodes"
    RECENT_SERIES = "recent_series"

    SEARCH_GLOBAL = "search_global"
    SEARCH_VOD = "search_vod"
    SEARCH_SERIES = "search_series"

    HISTORY_VOD = "history_vod"
    HISTORY_SERIES = "history_series"
    CLEAR_HISTORY = "clear_history"
    REMOVE_HISTORY = "remove_history"

    ACCOUNT_INFO = "account_info"
    CLEAR_CACHE = "clear_cache"
    PLAY = "play_channel"

    CINEMA_HOME = "cinema_home"
    CINEMA_SECTIONS = "cinema_sections"
    CINEMA_FILTERS = "cinema_filters"
    CINEMA_LIST = "cinema_list"
    CINEMA_SEARCH = "cinema_search"
    CINEMA_PERSON_CREDITS = "cinema_person_credits"
    CINEMA_XTREAM_SEARCH = "cinema_xtream_search"


class Prop:
    """Home-window properties shared between the plugin and the service."""

    SESSION_ID = "xtream_session_id"
    NEXT_URL = "xtream_next_url"
    NEXT_SESSION = "xtream_next_session"
    MEDIA_TYPE = "xtream_media_type"
    MEDIA_ID = "xtream_media_id"
    ACCOUNT_FINGERPRINT = "xtream_account_fingerprint"
    PRECACHE_REQUEST = "xtream_precache_request"
