"""Per-request plugin context: parsed arguments plus lazily built services."""
import os
import sys
from functools import cached_property
from urllib.parse import parse_qsl

import xbmcaddon
import xbmcvfs

from resources.lib.core.settings import Settings, account_fingerprint


class PluginContext:
    """Everything a view needs, created on first use.

    Views receive the context and read ``handle``/``params`` plus services
    (``client``, ``cache``, ``catalogs``, ``history``, ``tmdb``,
    ``translator``). Nothing heavy is built unless a view asks for it.
    """

    def __init__(self, argv=None):
        argv = argv if argv is not None else sys.argv
        self.url = argv[0]
        self.handle = int(argv[1])
        query = argv[2][1:] if len(argv) > 2 else ""
        self.params = dict(parse_qsl(query))
        self.settings = Settings()

    # -- environment -----------------------------------------------------
    @cached_property
    def addon(self):
        return xbmcaddon.Addon()

    @cached_property
    def profile_path(self):
        return xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))

    @cached_property
    def img_dir(self):
        return xbmcvfs.translatePath(
            os.path.join(self.addon.getAddonInfo("path"), "resources", "img")
        )

    # -- account ---------------------------------------------------------
    @cached_property
    def credentials(self):
        return self.settings.credentials()

    @cached_property
    def client(self):
        """Xtream client, or None when the account is not configured."""
        if not self.credentials:
            return None
        from resources.lib.api.xtream_client import XtreamCodesClient
        return XtreamCodesClient(*self.credentials)

    # -- storage ---------------------------------------------------------
    @cached_property
    def cache(self):
        from resources.lib.storage.cache import CacheManager
        # Same namespace formula as earlier versions, so caches are reused.
        fingerprint = (
            self.credentials.fingerprint
            if self.credentials
            else account_fingerprint(None, None, None)
        )
        return CacheManager(self.profile_path, fingerprint)

    @cached_property
    def history(self):
        from resources.lib.storage.history import HistoryManager
        namespace = self.credentials.history_namespace if self.credentials else None
        return HistoryManager(self.profile_path, namespace=namespace)

    # -- services --------------------------------------------------------
    @cached_property
    def catalogs(self):
        from resources.lib.services.catalog_service import CatalogService
        return CatalogService(self.client, self.cache)

    @cached_property
    def translator(self):
        from resources.lib.services.translation import ArabicTranslator
        return ArabicTranslator(
            self.profile_path, enabled=lambda: self.settings.arabic_translation_enabled
        )

    @cached_property
    def tmdb(self):
        from resources.lib.api.tmdb_client import TmdbClient
        return TmdbClient(
            self.settings.tmdb_token,
            self.profile_path,
            language=self.settings.tmdb_language,
        )
