"""Logging helpers.

Policy: never log exception *messages* or request URLs. Provider URLs embed
the account username and password, so only the exception class name is
recorded.
"""
import xbmc

DEFAULT_TAG = "Xtream"


def log(message, level=xbmc.LOGINFO, tag=DEFAULT_TAG):
    xbmc.log("[{}] {}".format(tag, message), level)


def info(message, tag=DEFAULT_TAG):
    log(message, xbmc.LOGINFO, tag)


def warning(message, tag=DEFAULT_TAG):
    log(message, xbmc.LOGWARNING, tag)


def error(message, tag=DEFAULT_TAG):
    log(message, xbmc.LOGERROR, tag)


def log_exception(context, exc, level=xbmc.LOGWARNING, tag=DEFAULT_TAG):
    """Log ``context`` with only the exception type, never its message."""
    log("{}: {}".format(context, type(exc).__name__), level, tag)
