"""Typed access to the add-on settings.

A fresh ``xbmcaddon.Addon()`` is created on every read so long-lived
processes (the service) always see the user's latest values.
"""
import hashlib
from collections import namedtuple

import xbmcaddon

from resources.lib.core.constants import (
    DEFAULT_RECENT_LIMIT,
    DEFAULT_TMDB_LANGUAGE,
    TMDB_FALLBACK_TOKEN,
    TMDB_LANGUAGES,
)


class Credentials(namedtuple("Credentials", "base_url username password")):
    __slots__ = ()

    @property
    def fingerprint(self):
        """Stable hash used to namespace caches per account."""
        return account_fingerprint(self.base_url, self.username, self.password)

    @property
    def history_namespace(self):
        """Stable account identity that survives password changes."""
        return hashlib.sha256(
            "{}\0{}".format(self.base_url.rstrip("/"), self.username).encode("utf-8")
        ).hexdigest()


def account_fingerprint(base_url, username, password):
    return hashlib.sha256(
        "{}\0{}\0{}".format(base_url, username, password).encode("utf-8")
    ).hexdigest()


class Settings:
    @staticmethod
    def _addon():
        return xbmcaddon.Addon()

    def get(self, key):
        return self._addon().getSetting(key)

    def credentials(self):
        """Return ``Credentials`` or None when any field is missing."""
        addon = self._addon()
        base_url = addon.getSetting("server_url")
        username = addon.getSetting("username")
        password = addon.getSetting("password")
        if not base_url or not username or not password:
            return None
        return Credentials(base_url, username, password)

    @property
    def precache_enabled(self):
        return self.get("enable_background_precache") != "false"

    @property
    def arabic_translation_enabled(self):
        return self.get("enable_arabic_translation") != "false"

    @property
    def hide_original_plot(self):
        return self.get("hide_original_plot") != "false"

    @property
    def auto_resume(self):
        return self.get("auto_resume") == "true"

    @property
    def recent_limit(self):
        try:
            return int(self.get("recent_limit"))
        except (TypeError, ValueError):
            return DEFAULT_RECENT_LIMIT

    @property
    def tmdb_language(self):
        language = self.get("tmdb_language")
        return language if language in TMDB_LANGUAGES else DEFAULT_TMDB_LANGUAGE

    @property
    def tmdb_token(self):
        return (self.get("tmdb_read_access_token") or "").strip() or TMDB_FALLBACK_TOKEN
