"""Plugin URL construction."""
from urllib.parse import urlencode

from resources.lib.core.constants import PLUGIN_BASE_URL


def build_url(query):
    """Return a ``plugin://`` URL for the given query mapping."""
    return PLUGIN_BASE_URL + "?" + urlencode(query)
