"""Provider category grouping rules (pure data, no Kodi imports).

Icons starting with ``@img/`` point to files in ``resources/img`` and are
resolved at render time by ``ui.category_browser``.
"""

IMG_PREFIX = "@img/"

CATEGORY_GROUPS = [
    {
        'contains': ['BEIN', 'F1 / MOTOGP', 'MOTOGP', 'FIFA', 'WORLD CUP', 'WC 2026', 'EUROSPORT', 'RMCSPORT', "L'EQUIPE", 'EQUIPE', 'THAMANYH', 'THMANAYH', 'THAMANYA', 'ثمانية', 'SHAHID | SHASHA', 'SHAHID VIP SPORT', 'SHASHA SPORT', 'STARZPLAY SPORT', 'STRZPLAY', 'ALWAN SPORT', 'AD SPORTS', 'AL-KASS', 'AL KASS', 'ALKASS', 'AFC', 'ALRABIAA SPORT', 'TOD EVENTS', 'SKY SPORT', 'CANAL+ LIVE', 'CAMPEONES', 'HYPERMOTION', 'PRIMA FILA', 'رياضة'],
        'label': 'SPORT',
        'icon': 'https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/26bd.png',
    },
    {
        'contains': ['RAMADAN', 'RAMADANK', 'رمضان'],
        'label': 'Special Ramadan',
        'icon': '@img/icon_ramadan.png',
    },
    {
        'contains': ['24/7 SHAHID'],
        'prefix': ['ARABIC ', '|SERIES| ARABIC', '|SERIES|  ARABIC', '|SERIES| SUB ARABIC', '|SERIES|  SUB ARABIC', '|SERIES| DUBBED', '|SERIES| MOROCCO', '|SERIES| QESAT', '|SERIES| ا', '|PROGRAMS|', '|VOD| ARABIC', '|VOD| AR-', '|VOD| MASRAHIAT', '|VOD| RAMADAN', '|AR|', 'AR |', 'AR|', 'AR ‖', '┃AR┃', 'AR I ', 'AR I', 'AR┃'],
        'label': 'Arabe',
        'icon': 'https://flagcdn.com/h240/sa.png',
    },
    {
        'prefix': ['KU I ', '|KU|', 'KUR |', 'KU |'],
        'label': 'Kurde',
    },
    {
        'prefix': ['FRANCE ', '|VOD-FR|', '|SERIES| FRANCE', '|SERIES| QU', '|QC|', '|FR|', '|FR |', 'FR |', 'FR ‖', '┃FR┃', 'FR I '],
        'label': 'France',
        'icon': 'https://flagcdn.com/h240/fr.png',
    },
    {
        'prefix': ['EU BELGIUM', 'BE |', 'BE ‖', '┃BE┃', '|BE|', 'BE I '],
        'label': 'Belgique',
        'icon': 'https://flagcdn.com/h240/be.png',
    },
    {
        'prefix': ['EU SWITZERLAND', 'CH |', 'CH ‖', '┃CH┃', '|CH|', 'CH I '],
        'label': 'Suisse',
        'icon': 'https://flagcdn.com/h240/ch.png',
    },
    {
        'prefix': ['U.K ', 'EU UK ', 'USA ', 'US ', 'CANADA', '|VOD| ENGLISH', '|DOC| ENGLISH', '|SERIES| ENGLISH', 'QUEBEC', 'QUÉBEC', 'QUÃ‰BEC', '|ENG|', '|EN|', 'EN |', 'EN ‖', 'UK |', 'UK I ', 'UK  |', 'US |', 'US|', '┃USA┃', 'CA |', '┃CA┃', 'AU |'],
        'label': 'English / US / UK',
        'icon': 'https://flagcdn.com/h240/gb.png',
    },
    {
        'prefix': ['ESPANOL ', '|VOD-ES|', '|SERIES| SPANISH', '|ES|', 'ES |', 'ES ‖', 'ES I '],
        'label': 'Espagne / Latino',
        'icon': 'https://flagcdn.com/h240/es.png',
    },
    {
        'prefix': ['ITALIA ', '|VOD-IT|', '|SERIES| ITALIA', '|IT|', 'IT |', 'IT ‖', 'IT I', 'IT I '],
        'label': 'Italie',
        'icon': 'https://flagcdn.com/h240/it.png',
    },
    {
        'exact': ['DE'],
        'prefix': ['EU GERMANY', 'EU AUSTRIA', '|VOD-DE|', '|SERIES| GERMAN', '|DE|', 'DE |', 'DE ‖', 'AT |', 'DE I '],
        'label': 'Allemagne',
        'icon': 'https://flagcdn.com/h240/de.png',
    },
    {
        'prefix': ['EU TURKISH', '|SERIES| TURKISH', '|VOD| TURKISH', '|TR|', 'TR |', 'TR ‖', 'TR I '],
        'label': 'Turquie',
        'icon': 'https://flagcdn.com/h240/tr.png',
    },
    {
        'prefix': ['EU PORTUGAL', 'US BRAZIL', '|VOD-PT|', '|SERIES| PT', '|VOD| PORTUGAL', '|POR|', '|LEG.|', '|PT|', 'PT |', 'PT ‖', 'BR |', 'BR ‖', 'PT I '],
        'label': 'Portugal / Bresil',
        'icon': 'https://flagcdn.com/h240/pt.png',
    },
    {
        'prefix': ['EU NETHERLAND', '|VOD-NL|', '|NL|', 'NL |', 'NL ‖', 'NL I '],
        'label': 'Pays-Bas',
        'icon': 'https://flagcdn.com/h240/nl.png',
    },
    {
        'prefix': ['|VOD| SWEDEN', '|VOD|SWEDEN', 'SWEDEN', 'SWEDISH', '|SE|', 'SE |'],
        'label': 'Suède',
        'icon': 'https://flagcdn.com/h240/se.png',
    },
    {
        'prefix': ['EU ', 'EXYU ', '|SERIES| LATIN', '|SERIES│ALBANIA', '|VOD| EXYU', '|VOD| POLSKI', '|VOD| RUSSIA', '|VOD| SCANDINAVIA', '|VOD| ALBANIA', '|VOD│ALBANIA', '│VOD│ALBANIA', '|PL|', '┃SE┃', '┃DK┃', '┃NO┃', '┃SK┃', 'UKR |', '|RO|', 'EX-YU I ', 'EX-YU |', '|EX-YU|'],
        'label': "Europe de l'Est / Balkans",
        'icon': 'https://flagcdn.com/h240/eu.png',
    },
    {
        'prefix': ['AF ', '|VOD| SOMALIA', '|AF|', 'AF |', 'AF|'],
        'label': 'Afrique',
        'icon': 'https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/1f30d.png',
    },
    {
        'prefix': ['AS ', '|VOD| ASIAN', '|VOD| HINDI', '|VOD| INDIA', '|VOD| JAPANESE', '|VOD| KOREAN', '|VOD| CHINESE', '|SERIES| KOREAN', '|SERIES| HINDI', 'AS |', 'IND |', 'IS |'],
        'label': 'Asie',
        'icon': 'https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/1f30f.png',
    },
    {
        'prefix': ['ISRAEL', '|MULTI|', '|MOVIE|', '| DOCUMENTARY |', '|VOD-KIDS|', '|VOD| ANIMATION', '|VOD| CONCERTS', '|VOD| KARAOKE', '|SERIES| NETFLIX', '|SERIES| PRIME', '|SERIES| DISNEY', '|SERIES| HBO', '|SERIES| CRUNCHYROLL', '|SERIES| APPLE', '|SERIES| OSN', '|SERIES| HULU', '|SERIES| PARAMOUNT', '|SERIES| TOD', '|SERIES| STARZPLAY', '|SERIES| ANIME MULTI', 'MULTI |', 'INT |', 'INT ‖'],
        'label': 'International / Multi',
        'icon': 'https://flagcdn.com/h240/un.png',
    },
    {
        'contains': ['8K', '4K', 'UHD'],
        'prefix': ['|8K-MULTI|'],
        'label': 'Contenu 4K / 8K',
    },
]
