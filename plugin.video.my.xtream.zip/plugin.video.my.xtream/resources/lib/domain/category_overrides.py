"""Provider-specific category fix-ups kept apart from the generic rules."""

SWEDEN_LABEL = "Suède"
SWEDEN_CATEGORY_ID = "12274"
SWEDEN_CATEGORY_NAMES = ("|VOD| SWEDEN", "SWEDEN")


def pin_sweden_vod(categories, groups, orphans, rules):
    """Make sure the Swedish VOD category is never an orphan.

    The original category objects (and ids) are kept so navigation is
    unchanged. Returns ``(groups, orphans)`` with the Sweden group placed in
    the order configured in ``rules``.
    """
    sweden = [
        category for category in categories
        if str(category.get("category_id", "")).strip() == SWEDEN_CATEGORY_ID
        or str(category.get("category_name", "")).upper().strip() in SWEDEN_CATEGORY_NAMES
    ]
    if not sweden:
        return groups, orphans

    sweden_ids = {id(category) for category in sweden}
    cleaned = {}
    for label, items in groups.items():
        remaining = [category for category in items if id(category) not in sweden_ids]
        if remaining:
            cleaned[label] = remaining
    orphans = [category for category in orphans if id(category) not in sweden_ids]

    ordered = {}
    inserted = False
    for rule in rules:
        label = rule["label"]
        if label == SWEDEN_LABEL:
            ordered[label] = sweden
            inserted = True
        elif label in cleaned:
            ordered[label] = cleaned[label]
    if not inserted:
        ordered[SWEDEN_LABEL] = sweden
    return ordered, orphans
