"""Kodi-independent category grouping. Rules are supplied by the caller."""


def _as_list(value):
    return value if isinstance(value, list) else [value]


def _matches(rule, name):
    """Return True when ``name`` satisfies a rule (exact, contains, prefix)."""
    if "exact" in rule:
        if any(isinstance(k, str) and k and name == k.upper() for k in _as_list(rule["exact"])):
            return True
    if "contains" in rule:
        if any(isinstance(k, str) and k and k.upper() in name for k in _as_list(rule["contains"])):
            return True
    if "prefix" in rule:
        if any(isinstance(p, str) and p and name.startswith(p.upper()) for p in _as_list(rule["prefix"])):
            return True
    return False


def group_categories(categories, content_type=None, rules=None):
    """Group provider categories by the first matching rule.

    Returns ``(groups, orphans)``: ``groups`` maps a label to its categories
    (empty groups removed, rule order kept) and ``orphans`` lists categories
    no rule matched. Malformed rules are ignored.
    """
    groups = {}
    orphans = []
    valid_rules = []
    for rule in (rules or ()):
        if not isinstance(rule, dict) or not isinstance(rule.get("label"), str) or not rule["label"]:
            continue
        valid_rules.append(rule)
        groups.setdefault(rule["label"], [])

    for category in (categories or ()):
        if not isinstance(category, dict):
            orphans.append(category)
            continue
        name = str(category.get("category_name") or "").upper().strip()
        for rule in valid_rules:
            if content_type and "types" in rule and content_type not in (rule["types"] or ()):
                continue
            if _matches(rule, name):
                groups[rule["label"]].append(category)
                break
        else:
            orphans.append(category)

    return {label: items for label, items in groups.items() if items}, orphans
