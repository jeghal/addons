"""Episode metadata and play-route parameters (pure, no Kodi dependency).

Used by the season listing and by next-episode resolution so both build
identical titles, metadata and ``play_channel`` parameters.
"""
from resources.lib.core.constants import MediaType, Mode
from resources.lib.domain.metadata import get_duration, get_fanart, get_rating, get_year
from resources.lib.domain.meta_codec import encode_meta
from resources.lib.domain.subtitle_ids import enrich
from resources.lib.domain.text import get_safe_image, safe_float, safe_int, safe_text


class SeriesSummary:
    """Series-level fields shared by every episode of a series."""

    def __init__(self, series_info, default_icon):
        info = series_info if isinstance(series_info, dict) else {}
        self.info = info
        self.name = safe_text(info.get("name"))
        self.cover = get_safe_image(info.get("cover"), default_icon)
        self.fanart = get_fanart(info)
        self.plot = safe_text(info.get("plot"))
        self.year = get_year(info, safe_text(info.get("releaseDate") or info.get("releasedate")))


def _season_number(season_key):
    return int(season_key) if str(season_key).isdigit() else 0


def _fallback_title(series, season_key, number):
    try:
        return "{} S{:02d}E{:02d}".format(series.name, int(season_key), int(number))
    except (TypeError, ValueError):
        return "{} - Episode {}".format(series.name, number)


class EpisodeDetails:
    """Everything needed to list or chain-play one episode."""

    def __init__(self, episode, season_key, fallback_number, series):
        self.episode = episode
        self.series = series
        self.season_key = season_key
        self.id = episode.get("id")
        self.extension = episode.get("container_extension") or "mp4"
        info = episode.get("info", {})
        self.info = info if isinstance(info, dict) else {}

        number = safe_int(episode.get("episode_num"), fallback_number)
        self.number = number if number > 0 else fallback_number

        title = safe_text(episode.get("title"))
        self.title = title if title else _fallback_title(series, season_key, self.number)
        if series.name and series.name not in self.title:
            self.full_title = "{} - {}".format(series.name, self.title)
        else:
            self.full_title = self.title

        self.thumb = get_safe_image(self.info.get("movie_image"), series.cover)
        self.plot = safe_text(self.info.get("plot") or series.info.get("plot"))
        self.season = _season_number(season_key)

    def info_tag(self):
        """Video info for the listing item and for the current-episode meta."""
        tag = {
            "title": self.title,
            "plot": self.plot,
            "mediatype": "episode",
            "tvshowtitle": self.series.name,
            "season": self.season,
            "episode": self.number,
            "premiered": safe_text(self.info.get("releasedate")),
            "duration": safe_int(get_duration(self.info)),
            "rating": safe_float(get_rating(self.info)),
        }
        enrich(tag, self.info, self.episode, self.series.info)
        if not tag.get("year") and self.series.year:
            tag["year"] = self.series.year
        return tag

    def chained_meta(self, year=None):
        """Metadata carried by a next-episode URL (includes artwork)."""
        meta = {
            "title": self.title,
            "mediatype": "episode",
            "tvshowtitle": self.series.name,
            "thumb": self.thumb,
            "plot": self.plot,
            "duration": get_duration(self.info),
            "season": self.season,
            "episode": self.number,
            "premiered": safe_text(self.info.get("releasedate")),
            "rating": safe_float(get_rating(self.info)),
            "poster": self.series.cover,
            "fanart": self.series.fanart,
        }
        enrich(meta, self.info, self.episode, self.series.info)
        if year:
            meta["year"] = year
        return meta

    def play_params(self, series_id, meta, next_url=None):
        params = {
            "mode": Mode.PLAY,
            "title": self.full_title,
            "icon": self.thumb,
            "media_type": MediaType.SERIES,
            "media_id": self.id,
            "group_id": series_id,
            "extension": self.extension,
            "meta": encode_meta(meta),
        }
        if next_url is not None:
            params["next_url"] = next_url
        return params
