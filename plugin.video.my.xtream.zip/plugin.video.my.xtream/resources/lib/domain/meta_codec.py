"""Encode/decode the ``meta`` query parameter carried by playback URLs.

New URLs use compact JSON. Decoding still accepts the legacy ``str(dict)``
form so favourites, library entries and history created by older versions
keep working.
"""
import ast
import json


def encode_meta(meta):
    if not isinstance(meta, dict) or not meta:
        return ""
    return json.dumps(meta, ensure_ascii=False, separators=(",", ":"), default=str)


def decode_meta(value):
    if isinstance(value, dict):
        return value
    if not isinstance(value, str) or not value.strip():
        return {}
    try:
        data = json.loads(value)
    except ValueError:
        try:
            data = ast.literal_eval(value)
        except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
            return {}
    return data if isinstance(data, dict) else {}
