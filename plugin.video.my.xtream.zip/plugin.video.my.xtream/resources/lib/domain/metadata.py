"""Shared catalog-metadata extraction (pure, no Kodi dependency)."""
import datetime

from resources.lib.domain.text import get_safe_image, parse_duration, safe_float, safe_int, safe_text


def get_fanart(data):
    """First valid backdrop URL of a provider record, or None."""
    backdrop = data.get("backdrop_path")
    if isinstance(backdrop, list) and backdrop:
        return get_safe_image(backdrop[0], None)
    return get_safe_image(backdrop, None)


def first_backdrop(data):
    """First valid HTTP(S) backdrop entry, or None."""
    if not isinstance(data, dict):
        return None
    backdrop = data.get("backdrop_path")
    if isinstance(backdrop, list):
        return next((image for image in (get_safe_image(value, None) for value in backdrop) if image), None)
    return None


def get_year(data, release_date=""):
    year = safe_int(data.get("year"))
    if 1000 <= year <= 9999:
        return year
    if len(release_date) >= 4 and release_date[:4].isdigit():
        return int(release_date[:4])
    return 0


def release_year(data):
    """Year taken only from the release date fields (0 when unknown)."""
    if not isinstance(data, dict):
        return 0
    release_date = safe_text(data.get("releaseDate") or data.get("release_date"))
    return int(release_date[:4]) if len(release_date) >= 4 and release_date[:4].isdigit() else 0


def get_rating(data):
    """Rating on a 0-10 scale from ``rating`` or ``rating_5based``."""
    if not isinstance(data, dict):
        return 0.0
    rating = safe_float(data.get("rating"))
    if rating > 0:
        return min(rating, 10.0)
    rating_5based = safe_float(data.get("rating_5based"))
    return min(rating_5based * 2, 10.0) if rating_5based > 0 else 0.0


def get_duration(data):
    duration = safe_int(data.get("duration_secs"))
    if duration > 0:
        return duration
    duration = parse_duration(data.get("duration"))
    if duration > 0:
        return duration
    runtime_minutes = safe_int(data.get("episode_run_time"))
    return runtime_minutes * 60 if runtime_minutes > 0 else 0


def get_release_date(data, *keys):
    """First non-empty release date among ``keys``."""
    return safe_text(next((data.get(key) for key in keys if data.get(key)), None))


def parse_timestamp(value):
    """Convert a unix timestamp (str/int) to ``datetime`` or None."""
    if not value or not str(value).isdigit():
        return None
    try:
        return datetime.datetime.fromtimestamp(int(value))
    except (OverflowError, OSError, ValueError):
        return None
