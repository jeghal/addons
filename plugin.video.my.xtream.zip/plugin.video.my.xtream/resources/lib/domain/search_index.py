"""Offline catalog search (pure, no Kodi dependency)."""
import unicodedata

from resources.lib.domain.text import safe_text


def normalize_search_text(value):
    """Casefold and strip accents, Arabic diacritics and tatweel."""
    value = unicodedata.normalize("NFKD", safe_text(value)).casefold()
    return "".join(
        char for char in value
        if unicodedata.category(char) != "Mn" and char != "\u0640"
    )


def find_matches(items, query, limit, count_all=True):
    """Return ``(matches, total)`` for a title search.

    At most ``limit`` items are returned. With ``count_all`` every match is
    counted; otherwise scanning stops as soon as ``limit`` matches are found.
    """
    try:
        limit = int(limit)
    except (TypeError, ValueError, OverflowError):
        return [], 0
    if limit <= 0:
        return [], 0
    needle = normalize_search_text(query).strip()
    if not needle:
        return [], 0
    results = []
    count = 0
    for item in (items or ()):
        if not isinstance(item, dict):
            continue
        if needle in normalize_search_text(item.get("name") or item.get("title")):
            count += 1
            if len(results) < limit:
                results.append(item)
                if not count_all and len(results) >= limit:
                    break
    return results, count
