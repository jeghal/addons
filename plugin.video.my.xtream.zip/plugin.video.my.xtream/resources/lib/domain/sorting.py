"""Catalog ordering (newest first). Pure functions."""


def _numeric(value):
    text = str(value)
    return int(text) if text.isdigit() else 0


def _vod_key(item):
    return _numeric(item.get("added"))


def _series_key(item):
    return _numeric(item.get("last_modified") or item.get("series_id"))


def _sort_newest_first(data, key):
    try:
        if isinstance(data, list):
            data.sort(key=key, reverse=True)
            return data
        return sorted(data, key=key, reverse=True)
    except (TypeError, ValueError, AttributeError, OverflowError):
        return data


def sort_vod(data):
    """Order movies by ``added`` timestamp, newest first."""
    return _sort_newest_first(data, _vod_key)


def sort_series(data):
    """Order series by ``last_modified`` (or ``series_id``), newest first."""
    return _sort_newest_first(data, _series_key)
