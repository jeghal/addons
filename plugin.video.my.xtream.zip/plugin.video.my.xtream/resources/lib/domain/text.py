"""Pure value-coercion helpers (no Kodi dependency)."""
import math
from urllib.parse import urlsplit


def safe_text(value, default=""):
    """Return a stripped string, or ``default`` for None/containers/"null"."""
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return default
    text = str(value).strip()
    if not text or text.lower() == "null":
        return default
    return text


def safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def safe_float(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default


def get_safe_image(url, default):
    """Return a well-formed HTTP(S) URL, otherwise ``default``."""
    if not isinstance(url, str) or not url or url == "null":
        return default
    if any(character.isspace() or ord(character) < 32 for character in url):
        return default
    try:
        parsed = urlsplit(url)
    except ValueError:
        return default
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        return default
    return url


def parse_duration(value):
    """Parse seconds, ``HH:MM:SS``, ``MM:SS`` or ``"120 min"`` into seconds."""
    if not value:
        return 0
    text = str(value).strip()
    if text.isdigit():
        return int(text)
    try:
        if ":" in text:
            parts = [int(part) for part in text.split(":")]
            if len(parts) == 3:
                return parts[0] * 3600 + parts[1] * 60 + parts[2]
            if len(parts) == 2:
                return parts[0] * 60 + parts[1]
        elif "min" in text.lower():
            digits = "".join(filter(str.isdigit, text))
            return int(digits) * 60 if digits else 0
    except (TypeError, ValueError, OverflowError):
        return 0
    return 0


def split_names(value):
    """Split a comma separated provider string into a list of names."""
    if not isinstance(value, str):
        return []
    return [name.strip() for name in value.split(",")]
