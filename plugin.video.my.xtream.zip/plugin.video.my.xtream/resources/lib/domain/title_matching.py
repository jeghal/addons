"""Rank Xtream catalog entries against a TMDb title (pure, no Kodi)."""
import difflib
import heapq
import re
import unicodedata

MAX_MATCH_RESULTS = 20
MAX_TITLE_LENGTH = 240
QUALITY_TAG = re.compile(
    r"(?<!\w)(?:4k|uhd|fhd|hd|sd|full\s*hd|2160p?|1080p?|720p?|hdr10\+?|hdr|"
    r"dolby\s*vision|x26[45]|h\.?26[45]|hevc|avc|web[- .]?dl|webrip|"
    r"blu[- .]?ray|brrip|dvdrip)(?!\w)",
    re.IGNORECASE,
)
YEAR_PATTERN = re.compile(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)")
PROVIDER_PREFIX = re.compile(
    r"^\s*(?:\|+|\[)\s*(?:vod|series|fr|en|us|uk|multi|ar|it|es|pt|nl|de|"
    r"br|tr|exyu|sub-ar|sub-fr|dub-ar|4k|fhd|hd|uhd)\s*(?:\|+|\])\s*",
    re.IGNORECASE,
)
ARABIC_EQUIVALENTS = str.maketrans({
    "أ": "ا",
    "إ": "ا",
    "آ": "ا",
    "ٱ": "ا",
    "ى": "ي",
    "ة": "ه",
})


def _safe_text(value):
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return ""
    text = str(value).strip()
    return "" if not text or text.lower() == "null" else text


def normalize_title(value):
    text = _safe_text(value)[:MAX_TITLE_LENGTH]
    # Remove delimited catalog tags, never words within the actual title.
    while True:
        cleaned = PROVIDER_PREFIX.sub("", text, count=1)
        if cleaned == text:
            break
        text = cleaned
    without_quality = QUALITY_TAG.sub(" ", text)
    if any(character.isalnum() for character in without_quality):
        text = without_quality
    text = unicodedata.normalize("NFKD", text).casefold().translate(ARABIC_EQUIVALENTS)
    characters = []
    for character in text:
        category = unicodedata.category(character)
        if category.startswith("M") or character == "ـ":
            continue
        characters.append(character if category[0] in ("L", "N") else " ")
    return " ".join("".join(characters).split())


def _year_value(value):
    match = YEAR_PATTERN.search(_safe_text(value))
    return int(match.group(1)) if match else 0


def extract_year(item):
    if not isinstance(item, dict):
        return 0
    for key in ("year", "releaseDate", "release_date", "releasedate", "first_air_date"):
        year = _year_value(item.get(key))
        if year:
            return year
    name = _safe_text(item.get("name") or item.get("title"))
    dated = re.findall(r"\((19\d{2}|20\d{2})\)", name)
    return int(dated[-1]) if dated else _year_value(name)


def _tmdb_identifier(item):
    if not isinstance(item, dict):
        return ""
    for key in ("tmdb", "tmdb_id", "tmdbId"):
        value = _safe_text(item.get(key))
        if value.isdigit():
            return str(int(value))
    external_ids = item.get("external_ids")
    if isinstance(external_ids, dict):
        value = _safe_text(external_ids.get("tmdb_id"))
        if value.isdigit():
            return str(int(value))
    return ""


def _candidate_titles(item):
    titles = []
    for key in ("name", "title", "original_title", "original_name"):
        value = _safe_text(item.get(key))
        if value and value not in titles:
            titles.append(value)
    return titles


def _without_trailing_year(normalized, year):
    suffix = f" {year}" if year else ""
    if suffix and normalized.endswith(suffix) and len(normalized) > len(suffix):
        return normalized[:-len(suffix)].strip()
    return normalized


def _title_score(query, candidate, query_year, candidate_year):
    if not query or not candidate:
        return 0, ""
    if query == candidate:
        if query_year and candidate_year:
            return (900, "title_year") if query_year == candidate_year else (0, "")
        return 820, "title"

    query_tokens = set(query.split())
    candidate_tokens = set(candidate.split())
    if not query_tokens or not candidate_tokens:
        return 0, ""
    overlap = len(query_tokens & candidate_tokens) / max(len(query_tokens), len(candidate_tokens))
    if overlap < 0.5 and not (query_tokens <= candidate_tokens or candidate_tokens <= query_tokens):
        return 0, ""
    ratio = difflib.SequenceMatcher(None, query, candidate, autojunk=False).ratio()
    if query_year and candidate_year and query_year != candidate_year:
        return 0, ""
    if query_year and candidate_year == query_year and ratio >= 0.86:
        return 700 + int(ratio * 60), "similar_title_year"
    if (not query_year or not candidate_year) and ratio >= 0.92:
        return 640 + int(ratio * 60), "similar_title"
    return 0, ""


def rank_xtream_matches(items, title, year=None, tmdb_id=None, limit=MAX_MATCH_RESULTS, alternate_titles=None):
    queries = []
    for name in [title] + list(alternate_titles or ())[:3]:
        query = normalize_title(name)
        if query and query not in queries:
            queries.append(query)
    if not queries or not isinstance(items, list):
        return []
    query_year = _year_value(year)
    query_tmdb = _safe_text(tmdb_id)
    query_tmdb = str(int(query_tmdb)) if query_tmdb.isdigit() else ""
    try:
        result_limit = min(MAX_MATCH_RESULTS, max(1, int(limit)))
    except (TypeError, ValueError, OverflowError):
        result_limit = MAX_MATCH_RESULTS

    best = []
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        candidate_year = extract_year(item)
        candidate_tmdb = _tmdb_identifier(item)
        if query_tmdb and candidate_tmdb == query_tmdb:
            score = 1000
            if query_year and candidate_year:
                score += 20 if query_year == candidate_year else -40
            reason = "tmdb_id"
        else:
            score = 0
            reason = ""
            for candidate_title in _candidate_titles(item):
                normalized = _without_trailing_year(
                    normalize_title(candidate_title),
                    candidate_year,
                )
                for query in queries:
                    candidate_score, candidate_reason = _title_score(
                        query,
                        normalized,
                        query_year,
                        candidate_year,
                    )
                    if candidate_score > score:
                        score = candidate_score
                        reason = candidate_reason
                    # Providers may append a localized subtitle after a colon.
                    # Only accept its exact leading title with the same known year.
                    if query_year and query_year == candidate_year and ":" in candidate_title:
                        head = normalize_title(candidate_title.split(":", 1)[0])
                        if len(head) >= 3 and head == query and score < 760:
                            score, reason = 760, "subtitle_title_year"
        if score <= 0:
            continue
        result = {
            "item": item,
            "score": score,
            "reason": reason,
            "year": candidate_year,
        }
        entry = (score, -index, result)
        if len(best) < result_limit:
            heapq.heappush(best, entry)
        elif entry[:2] > best[0][:2]:
            heapq.heapreplace(best, entry)

    return [entry[2] for entry in sorted(best, key=lambda value: (-value[0], -value[1]))]
