import xbmcgui
import xbmc
from resources.lib.utils import build_url

def create_list_item(label, icon=None, thumb=None, poster=None, fanart=None, info=None, properties=None, path=None, is_folder=False):
    li = xbmcgui.ListItem(label=label)
    art = {}
    if icon: art["icon"] = icon
    if thumb: art["thumb"] = thumb
    if poster: art["poster"] = poster
    if fanart: art["fanart"] = fanart
    # Fallback/Default
    if icon and "thumb" not in art: art["thumb"] = icon
    if thumb and "icon" not in art: art["icon"] = thumb
    
    li.setArt(art)
    
    if info:
        # Extract specific complex types first
        video_info = info.get("video", {}) if "video" in info and isinstance(info["video"], dict) else info
        
        # 1. Cast (List)
        cast = video_info.pop("cast", None)
        if cast and isinstance(cast, list):
             try:
                 # Modern (Kodi 20+)
                 tag = li.getVideoInfoTag()
                 # setCast expects list of xbmc.Actor. We have list of strings.
                 # Actually setCast in Python API might accept list of dicts or strings depending on version.
                 # But safer: setCast expects xbmc.Actor objects usually or is readonly-ish in some versions.
                 # Fallback: setInfo('cast', ...) is deprecated/removed.
                 # Let's try Generic way:
                 # If strings list:
                 actors = []
                 for c in cast:
                     if isinstance(c, str):
                         a = xbmc.Actor(c)
                         actors.append(a)
                 tag.setCast(actors)
             except:
                 pass # API might vary

        # 2. UniqueIDs (Dict)
        unique_ids = video_info.pop("uniqueid", None)
        if unique_ids and isinstance(unique_ids, dict):
            try:
                # Modern
                tag = li.getVideoInfoTag()
                tag.setUniqueIDs(unique_ids)
            except:
                # Legacy
                try:
                    li.setUniqueIDs(unique_ids)
                except:
                    pass

        # 3. Clean remaining info for setInfo (Scalar types only)
        # remove keys that are definitely complex or unsupported in setInfo dictionary
        safe_info = {}
        # List of known invalid keys to skip for setInfo("video") in recent Kodi versions
        invalid_keys = ["tmdb_id", "code", "height", "width", "video_codec", "aspect", "audio_channels", "audio_codec", "duration_secs"]
        
        for k, v in video_info.items():
            if k in invalid_keys: continue 
            if isinstance(v, (str, int, float, bool)):
                safe_info[k] = v
            # 'dateadded' is tricky, needs specific format usually, but str is generally safe-ish
            
        li.setInfo("video", safe_info)
        
    if properties:
        for k, v in properties.items():
            li.setProperty(k, str(v))
            
    if path:
        li.setPath(path)
        
    return li

def show_notification(heading, message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=5000):
    xbmcgui.Dialog().notification(heading, message, icon, time_ms)

def show_yesno_dialog(heading, message):
    return xbmcgui.Dialog().yesno(heading, message)
