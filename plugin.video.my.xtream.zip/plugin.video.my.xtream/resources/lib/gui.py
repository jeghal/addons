import xbmcgui
import xbmc
from resources.lib.utils import build_url

def create_list_item(label, icon=None, thumb=None, poster=None, fanart=None, info=None, properties=None, path=None, is_folder=False):
    """
    Crée un ListItem Kodi avec l'API moderne InfoTagVideo (Kodi 20+)
    """
    li = xbmcgui.ListItem(label=label)
    
    # Art
    art = {}
    if icon: art["icon"] = icon
    if thumb: art["thumb"] = thumb
    if poster: art["poster"] = poster
    if fanart: art["fanart"] = fanart
    # Fallback/Default
    if icon and "thumb" not in art: art["thumb"] = icon
    if thumb and "icon" not in art: art["icon"] = thumb
    li.setArt(art)
    
    # Info via InfoTagVideo (Modern API)
    if info:
        video_info = info.get("video", {}) if "video" in info and isinstance(info["video"], dict) else info
        
        if video_info:
            try:
                tag = li.getVideoInfoTag()
                
                # Métadonnées de base
                if "title" in video_info and video_info["title"]:
                    tag.setTitle(str(video_info["title"]))
                
                if "originaltitle" in video_info and video_info["originaltitle"]:
                    tag.setOriginalTitle(str(video_info["originaltitle"]))
                
                if "plot" in video_info and video_info["plot"]:
                    tag.setPlot(str(video_info["plot"]))
                
                if "mediatype" in video_info and video_info["mediatype"]:
                    tag.setMediaType(str(video_info["mediatype"]))
                
                # Genre (peut être string ou list)
                if "genre" in video_info and video_info["genre"]:
                    genre = video_info["genre"]
                    if isinstance(genre, str):
                        tag.setGenres(genre.split(","))
                    elif isinstance(genre, list):
                        tag.setGenres(genre)
                
                # Année
                if "year" in video_info and video_info["year"]:
                    try:
                        tag.setYear(int(video_info["year"]))
                    except (ValueError, TypeError):
                        pass
                
                # Rating
                if "rating" in video_info and video_info["rating"]:
                    try:
                        tag.setRating(float(video_info["rating"]))
                    except (ValueError, TypeError):
                        pass
                
                # Director (peut être string ou list)
                if "director" in video_info and video_info["director"]:
                    director = video_info["director"]
                    if isinstance(director, str):
                        tag.setDirectors([director])
                    elif isinstance(director, list):
                        tag.setDirectors(director)
                
                # Duration (en secondes)
                if "duration" in video_info and video_info["duration"]:
                    try:
                        tag.setDuration(int(video_info["duration"]))
                    except (ValueError, TypeError):
                        pass
                
                # Premiered
                if "premiered" in video_info and video_info["premiered"]:
                    tag.setPremiered(str(video_info["premiered"]))
                
                # Date Added
                if "dateadded" in video_info and video_info["dateadded"]:
                    tag.setDateAdded(str(video_info["dateadded"]))
                
                # Trailer
                if "trailer" in video_info and video_info["trailer"]:
                    tag.setTrailer(str(video_info["trailer"]))
                
                # TV Show specific
                if "tvshowtitle" in video_info and video_info["tvshowtitle"]:
                    tag.setTvShowTitle(str(video_info["tvshowtitle"]))
                
                if "season" in video_info and video_info["season"]:
                    try:
                        tag.setSeason(int(video_info["season"]))
                    except (ValueError, TypeError):
                        pass
                
                if "episode" in video_info and video_info["episode"]:
                    try:
                        tag.setEpisode(int(video_info["episode"]))
                    except (ValueError, TypeError):
                        pass
                
                # Cast (filtrer les noms vides pour éviter les erreurs)
                if "cast" in video_info and isinstance(video_info["cast"], list):
                    actors = []
                    for c in video_info["cast"]:
                        if isinstance(c, str) and c.strip():  # Filtrer les chaînes vides
                            try:
                                actors.append(xbmc.Actor(c.strip()))
                            except:
                                pass
                    if actors:
                        tag.setCast(actors)
                
                # UniqueIDs
                if "uniqueid" in video_info and isinstance(video_info["uniqueid"], dict):
                    tag.setUniqueIDs(video_info["uniqueid"])
                
            except Exception as e:
                # Fallback vers setInfo si InfoTagVideo échoue (Kodi 19 ou erreur)
                xbmc.log(f"[Xtream] InfoTagVideo failed, using setInfo fallback: {e}", xbmc.LOGWARNING)
                
                # Nettoyer les clés non supportées par setInfo
                safe_info = {}
                invalid_keys = ["tmdb_id", "code", "height", "width", "video_codec", "aspect", 
                               "audio_channels", "audio_codec", "duration_secs", "cast", "uniqueid"]
                
                for k, v in video_info.items():
                    if k in invalid_keys: 
                        continue
                    if isinstance(v, (str, int, float, bool)):
                        safe_info[k] = v
                
                if safe_info:
                    li.setInfo("video", safe_info)
    
    # Properties
    if properties:
        for k, v in properties.items():
            li.setProperty(k, str(v))
    
    # Path
    if path:
        li.setPath(path)
    
    return li

def show_notification(heading, message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=5000):
    xbmcgui.Dialog().notification(heading, message, icon, time_ms)

def show_yesno_dialog(heading, message):
    return xbmcgui.Dialog().yesno(heading, message)
