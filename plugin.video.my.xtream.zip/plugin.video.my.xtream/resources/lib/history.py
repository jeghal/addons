import json
import os
import tempfile
import time
from contextlib import contextmanager


class HistoryManager:
    def __init__(self, profile_path):
        self.profile_path = profile_path
        os.makedirs(self.profile_path, exist_ok=True)
        self.history_file = os.path.join(self.profile_path, "history.json")
        self.lock_file = os.path.join(self.profile_path, "history.lock")
        self.limit = 20

    @staticmethod
    def _empty_history():
        return {"vod": [], "series": [], "episode_resume": {}}

    @contextmanager
    def _locked(self, timeout=5.0, stale_after=30.0):
        deadline = time.monotonic() + timeout
        acquired = False
        while not acquired:
            try:
                descriptor = os.open(
                    self.lock_file,
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                os.close(descriptor)
                acquired = True
            except FileExistsError:
                try:
                    if time.time() - os.path.getmtime(self.lock_file) > stale_after:
                        os.remove(self.lock_file)
                        continue
                except FileNotFoundError:
                    continue
                if time.monotonic() >= deadline:
                    raise TimeoutError("history lock timeout")
                time.sleep(0.05)

        try:
            yield
        finally:
            try:
                os.remove(self.lock_file)
            except FileNotFoundError:
                pass

    def _preserve_corrupted_file(self):
        if not os.path.exists(self.history_file):
            return
        suffix = f"{time.time_ns()}"
        backup_path = f"{self.history_file}.corrupt.{suffix}.json"
        os.replace(self.history_file, backup_path)

    def _load_unlocked(self):
        if not os.path.exists(self.history_file):
            return self._empty_history()

        try:
            with open(self.history_file, "r", encoding="utf-8") as history_handle:
                history = json.load(history_handle)
            if not isinstance(history, dict):
                raise ValueError("history root must be an object")
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
            self._preserve_corrupted_file()
            return self._empty_history()

        normalized = dict(history)
        for media_type in ("vod", "series"):
            if not isinstance(normalized.get(media_type), list):
                normalized[media_type] = []
        if not isinstance(normalized.get("episode_resume"), dict):
            normalized["episode_resume"] = {}
        return normalized

    def _save_unlocked(self, history):
        descriptor, temporary_path = tempfile.mkstemp(
            prefix="history.",
            suffix=".tmp",
            dir=self.profile_path,
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as history_handle:
                json.dump(history, history_handle, ensure_ascii=False, indent=2)
                history_handle.flush()
                os.fsync(history_handle.fileno())
            os.replace(temporary_path, self.history_file)
        except Exception:
            try:
                os.remove(temporary_path)
            except FileNotFoundError:
                pass
            raise

    def load_history(self):
        with self._locked():
            return self._load_unlocked()

    def save_history(self, history):
        with self._locked():
            self._save_unlocked(history)

    def add_item(self, media_type, item_data, group_id=None):
        with self._locked():
            history = self._load_unlocked()
            target_list = history.get(media_type, [])

            current_id = str(item_data.get("id"))
            key_id = str(group_id) if group_id else current_id

            # Keep the existing one-entry-per-series display behavior, but store
            # per-episode resume positions independently from that display list.
            resume_points = history.setdefault("episode_resume", {})
            existing_resume = resume_points.get(current_id, 0) if media_type == "series" else 0
            new_list = []
            for item in target_list:
                if not isinstance(item, dict):
                    continue
                item_group = item.get("group_id")
                item_id = str(item.get("id"))
                existing_key = str(item_group) if item_group else item_id

                if existing_key == key_id:
                    if item_id == current_id:
                        existing_resume = item.get("resume_time", 0) if media_type != "series" else existing_resume
                    elif media_type == "series":
                        # Migrate resume points from the legacy display entries.
                        old_resume = item.get("resume_time", 0)
                        if old_resume and item_id not in resume_points:
                            resume_points[item_id] = old_resume
                else:
                    new_list.append(item)

            if media_type == "series":
                # Older installations kept resume_time on the visible entry.
                for old_item in target_list:
                    if isinstance(old_item, dict) and str(old_item.get("id")) == current_id:
                        if current_id not in resume_points:
                            existing_resume = old_item.get("resume_time", 0)
                        break
            if existing_resume > 0:
                item_data["resume_time"] = existing_resume
            if group_id:
                item_data["group_id"] = group_id

            new_list.insert(0, item_data)
            history[media_type] = new_list[: self.limit]
            self._save_unlocked(history)

    def get_list(self, media_type):
        return self.load_history().get(media_type, [])

    def update_resume_time(self, media_type, media_id, time_sec):
        with self._locked():
            history = self._load_unlocked()
            items = history.get(media_type, [])
            if media_type == "series":
                history.setdefault("episode_resume", {})[str(media_id)] = time_sec
            changed = media_type == "series"
            for item in items:
                if isinstance(item, dict) and str(item.get("id")) == str(media_id):
                    item["resume_time"] = time_sec
                    changed = True
                    break
            if changed:
                self._save_unlocked(history)

    def clear_history(self, media_type):
        with self._locked():
            history = self._load_unlocked()
            history[media_type] = []
            if media_type == "series":
                history["episode_resume"] = {}
            self._save_unlocked(history)

    def remove_item(self, media_type, item_id):
        with self._locked():
            history = self._load_unlocked()
            items = history.get(media_type, [])
            new_items = [
                item
                for item in items
                if isinstance(item, dict) and str(item.get("id")) != str(item_id)
            ]
            changed = len(new_items) != len(items)
            if media_type == "series":
                resume_points = history.setdefault("episode_resume", {})
                if str(item_id) in resume_points:
                    del resume_points[str(item_id)]
                    changed = True
            if changed:
                history[media_type] = new_items
                self._save_unlocked(history)
