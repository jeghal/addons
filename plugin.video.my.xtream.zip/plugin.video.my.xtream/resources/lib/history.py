import os
import json
import time

class HistoryManager:
    def __init__(self, profile_path):
        self.profile_path = profile_path
        if not os.path.exists(self.profile_path):
            os.makedirs(self.profile_path)
        self.history_file = os.path.join(self.profile_path, 'history.json')
        self.limit = 20

    def load_history(self):
        if not os.path.exists(self.history_file):
            return {"vod": [], "series": []}
        try:
            with open(self.history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"vod": [], "series": []}

    def save_history(self, history):
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)

    def add_item(self, media_type, item_data, group_id=None):
        # media_type: "vod" or "series"
        history = self.load_history()
        target_list = history.get(media_type, [])
        
        # Deduplication Key: group_id if provided (for Series), else item_data["id"]
        current_id = str(item_data.get("id"))
        key_id = str(group_id) if group_id else current_id
        
        existing_resume = 0
        new_list = []
        for i in target_list:
            i_group = i.get("group_id")
            i_id = str(i.get("id"))
            existing_key = str(i_group) if i_group else i_id
            
            if existing_key == key_id:
                # Found existing entry for this series/movie
                # Only preserve resume_time if it's the SAME episode/movie ID
                if i_id == current_id:
                    existing_resume = i.get("resume_time", 0)
            else:
                new_list.append(i)
        
        # Preserve resume_time
        if existing_resume > 0:
            item_data["resume_time"] = existing_resume

        # Add group_id to data if present
        if group_id:
            item_data["group_id"] = group_id

        # Add to top
        new_list.insert(0, item_data)
        
        # Limit
        if len(new_list) > self.limit:
            new_list = new_list[:self.limit]
            
        history[media_type] = new_list
        self.save_history(history)
        
    def get_list(self, media_type):
        return self.load_history().get(media_type, [])

    def update_resume_time(self, media_type, media_id, time_sec):
        """
        Updates the resume time for a specific item.
        Used by service.py to update progress.
        """
        if not os.path.exists(self.history_file): return
        
        try:
            # We use load_history to get current state
            # But we want to modify it directly to avoid race conditions?
            # For this simple addon, just read-modify-write is fine.
            history = self.load_history()
            items = history.get(media_type, [])
            updated = False
            for item in items:
                if str(item.get("id")) == str(media_id):
                    item["resume_time"] = time_sec
                    updated = True
                    break
            
            if updated:
                self.save_history(history)
        except:
            pass

    def clear_history(self, media_type):
        history = self.load_history()
        history[media_type] = []
        self.save_history(history)

    def remove_item(self, media_type, item_id):
        history = self.load_history()
        items = history.get(media_type, [])
        
        new_items = [i for i in items if str(i.get("id")) != str(item_id)]
        
        if len(new_items) != len(items):
            history[media_type] = new_items
            self.save_history(history)
