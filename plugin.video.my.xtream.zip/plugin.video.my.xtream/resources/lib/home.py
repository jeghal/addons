import os

import xbmcaddon
import xbmcplugin

from resources.lib.gui import create_list_item
from resources.lib.utils import build_url


def main_menu(handle, img_path, precache_callback):
    # Menu Principal
    # Chemins absolus ou relatifs aux assets
    # Kodi gère bien les chemins relatifs à l'addon si on utilise special://home/addons/...
    # Ou juste le chemin relatif si on setIcon ? Non, il vaut mieux le chemin complet.
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    # img_path is now global and points to resources/img

    menus = [
        {"label": "[COLOR red]Recherche Globale[/COLOR]", "mode": "search_global", "icon": os.path.join(img_path, "search_pro.png")},
        {"label": "دليل السينما | TMDb", "mode": "cinema_home", "icon": "DefaultMovies.png"},
        {"label": "Télévision", "mode": "live_categories", "icon": os.path.join(img_path, "tv_pro.png")},
        {"label": "Films", "mode": "vod_categories", "icon": os.path.join(img_path, "movies_pro.png")},
        {"label": "Séries", "mode": "series_categories", "icon": os.path.join(img_path, "series_pro.png")},
        {"label": "Espace Client", "mode": "account_info", "icon": os.path.join(img_path, "account_pro.png")},
        {"label": "[COLOR yellow]Mettre à jour (Vider Cache)[/COLOR]", "mode": "clear_cache", "icon": "DefaultAddonService.png"}
    ]
    
    for item in menus:
        li = create_list_item(
             label=item["label"],
             icon=item.get("icon", "DefaultFolder.png"),
             thumb=item.get("icon", "DefaultFolder.png")
        )
        url = build_url({"mode": item["mode"]})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(handle)

    # Lancement du pré-chargement en arrière-plan
    precache_callback()
