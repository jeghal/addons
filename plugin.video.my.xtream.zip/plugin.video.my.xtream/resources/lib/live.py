import xbmcplugin

from resources.lib.catalog import CATEGORY_GROUPS, group_categories
from resources.lib.gui import create_list_item, directory_listing
from resources.lib.utils import build_url, safe_text


@directory_listing
def list_live_categories(handle, client, cache_manager, group_id=None):
    categories = cache_manager.get("live_categories")
    if categories is None:
        categories = client.get_live_categories()
        if categories is not None:
            cache_manager.set("live_categories", categories)
            
    if not isinstance(categories, list):
        return
    categories = [category for category in categories if isinstance(category, dict)]
    
    # Grouping Logic
    groups, orphans = group_categories(categories, "live")

    # 1. Si on est à la racine, on affiche les GROUPES + les ORPHELINS
    if not group_id:
        # Afficher les dossiers de groupe
        for label, cats in groups.items():
            count = len(cats)
            # On prend l'icone du premier groupe config qui matche ce label
            icon = "DefaultFolder.png"
            for g in CATEGORY_GROUPS:
                if g["label"] == label:
                    icon = g.get("icon", "DefaultFolder.png")
                    break
            
            li = create_list_item(label=f"{label} ({count})", icon=icon)
            url = build_url({"mode": "live_categories", "group_id": label})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
        # Afficher les orphelins (sous les groupes)
        if orphans:
             # Separator
            li_sep = create_list_item(label="[B]--- Autres ---[/B]", icon="DefaultSeparator.png")
            xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li_sep, isFolder=False)
            
            for cat in orphans:
                li = create_list_item(label=cat.get("category_name", "Unknown"))
                url = build_url({"mode": "live_streams", "category_id": cat.get("category_id")})
                xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    # 2. Si un groupe est sélectionné
    else:
        # On récupère les catégories du groupe demandé
        group_cats = groups.get(group_id, [])
        for cat in group_cats:
            li = create_list_item(label=cat.get("category_name", "Unknown"))
            url = build_url({"mode": "live_streams", "category_id": cat.get("category_id")})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

@directory_listing
def list_live_streams(handle, client, cache_manager, category_id):
    cache_key = f"live_streams_{category_id}"
    streams = cache_manager.get(cache_key)
    if streams is None:
        streams = client.get_live_streams(category_id)
        if streams is not None:
            cache_manager.set(cache_key, streams)
            
    if not isinstance(streams, list):
        return
    streams = [stream for stream in streams if isinstance(stream, dict)]

    items = []
    for stream in streams:
        name = safe_text(stream.get("name"), "Chaîne sans titre")
        stream_id = stream.get("stream_id")
        if stream_id is None:
            continue
        icon = stream.get("stream_icon")
        num = stream.get("num")
        epg_id = stream.get("epg_channel_id")
        
        # Format label with channel number if available
        label = f"{num} | {name}" if num else name

        plot_lines = [f"Numéro: {num}"]
        if epg_id:
            plot_lines.append(f"EPG ID: {epg_id}")
        if stream.get("tv_archive") not in (None, "", 0, "0", False):
            plot_lines.append("Replay disponible")
        
        info_tag = {
            "title": name,
            "mediatype": "video",
            "plot": "\n".join(plot_lines)
        }

        play_url = client.get_live_url(stream_id)
        
        li = create_list_item(
             label=label,
             icon=icon,
             thumb=icon,
             info={"video": info_tag},
             properties={'IsPlayable': 'true'}
        )
        
        url = build_url({"mode": "play_channel", "url": play_url, "title": name, "icon": icon})
        items.append((url, li, False))
        
    xbmcplugin.addDirectoryItems(handle, items)
