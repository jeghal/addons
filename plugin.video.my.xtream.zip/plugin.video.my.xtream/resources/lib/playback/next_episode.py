"""Resolve the episode that follows the one being played."""
from resources.lib.core import logger
from resources.lib.core.constants import DEFAULT_SERIES_ICON
from resources.lib.core.urls import build_url
from resources.lib.domain.episodes import EpisodeDetails, SeriesSummary


def _ordered_episodes(episodes_by_season):
    """Flatten ``{season: [episode, ...]}`` in season order.

    Yields ``(season_key, position_in_season, episode)``.
    """
    def season_order(value):
        text = str(value)
        return int(text) if text.isdigit() else 999

    for season_key in sorted(episodes_by_season, key=season_order):
        episodes = episodes_by_season.get(season_key)
        if not isinstance(episodes, list):
            continue
        position = 0
        for episode in episodes:
            if isinstance(episode, dict):
                position += 1
                yield season_key, position, episode


def find_next_episode_url(client, series_id, current_episode_id):
    """Return the play URL of the episode after ``current_episode_id``.

    Looks across seasons. Returns "" when none exists or the provider data
    cannot be used.
    """
    try:
        data = client.get_series_info(series_id)
        if not isinstance(data, dict):
            return ""
        episodes_by_season = data.get("episodes")
        if not isinstance(episodes_by_season, dict):
            return ""
        series = SeriesSummary(data.get("info"), DEFAULT_SERIES_ICON)

        entries = list(_ordered_episodes(episodes_by_season))
        for index, (_, _, episode) in enumerate(entries):
            if str(episode.get("id")) == str(current_episode_id):
                break
        else:
            return ""
        if index + 1 >= len(entries):
            return ""

        season_key, position, next_episode = entries[index + 1]
        details = EpisodeDetails(next_episode, season_key, position, series)
        if details.id is None:
            return ""
        meta = details.chained_meta(year=series.year or None)
        return build_url(details.play_params(series_id, meta))
    except Exception as error:  # provider data is untrusted; never block playback
        logger.log_exception("Next episode metadata rejected", error)
        return ""
