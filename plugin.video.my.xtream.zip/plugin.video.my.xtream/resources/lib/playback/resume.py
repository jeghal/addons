"""Resume-point prompt and application for a resolved list item."""
import time

import xbmcgui

from resources.lib.core import logger
from resources.lib.core.constants import RESUME_PROMPT_THRESHOLD_SECONDS
from resources.lib.domain.text import safe_float


def saved_resume_time(history, media_type, media_id):
    """Resume position (seconds) stored for the media item, or 0."""
    for entry in history.get(media_type, []):
        if isinstance(entry, dict) and str(entry.get("id")) == str(media_id):
            return safe_float(entry.get("resume_time"))
    return 0.0


def offer_resume(list_item, resume_time, total_seconds=None):
    """Ask the user whether to resume; apply the offset when accepted."""
    if resume_time <= RESUME_PROMPT_THRESHOLD_SECONDS:
        return False
    resume_text = time.strftime("%H:%M:%S", time.gmtime(resume_time))
    if not xbmcgui.Dialog().yesno("Reprendre la lecture", "Reprendre à {} ?".format(resume_text)):
        return False

    try:
        list_item.getVideoInfoTag().setResumePoint(float(resume_time))
    except Exception as error:  # Kodi < 20 lacks the API
        logger.log_exception("SetResumePoint failed", error)

    list_item.setProperty("StartOffset", str(float(resume_time)))
    total = safe_float(total_seconds)
    if total > 0:
        list_item.setProperty("StartPercent", str(float(resume_time) / total * 100))
    return True
