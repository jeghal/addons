"""Validation of ``play_channel`` routes before they are executed.

A route is only trusted when it targets this add-on, carries no raw stream
URL and does not embed the account credentials. Shared by the plugin (when it
stores a next-episode route) and the service (before it launches one).
"""
from urllib.parse import parse_qsl, urlsplit

from resources.lib.core.constants import Mode

_FORBIDDEN_CHARACTERS = ('"', "\n", "\r", "\x00")


def is_safe_play_route(route, addon_id, username="", password="",
                       media_type=None, stream_validator=None):
    """Return True when ``route`` is a safe ``play_channel`` plugin URL.

    ``media_type`` restricts the allowed media type; ``stream_validator`` is
    an optional callable receiving the route parameters (used by the plugin to
    check that a stream URL can actually be built).
    """
    if not isinstance(route, str) or any(char in route for char in _FORBIDDEN_CHARACTERS):
        return False
    parsed = urlsplit(route)
    if parsed.scheme != "plugin" or parsed.netloc != addon_id or parsed.path != "/":
        return False

    params = dict(parse_qsl(parsed.query))
    if params.get("mode") != Mode.PLAY or "url" in params or not params.get("media_id"):
        return False
    if media_type is not None and params.get("media_type") != media_type:
        return False

    decoded_values = "\n".join(params.values())
    for secret in (username, password):
        if secret and (secret in route or secret in decoded_values):
            return False

    return bool(stream_validator(params)) if stream_validator else True
