"""Background player: saves resume points and chains the next episode.

Runs inside ``service.py``. The plugin process describes the current playback
through home-window properties (see ``playback.session``).
"""
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.core import logger
from resources.lib.core.constants import ADDON_ID, NEXT_EPISODE_DELAY_SECONDS, MediaType, Prop
from resources.lib.core.settings import Settings
from resources.lib.playback.routes import is_safe_play_route
from resources.lib.playback.session import home_window
from resources.lib.services.precache import start_service_precache
from resources.lib.storage.history import HistoryManager


class XtreamPlayer(xbmc.Player):
    def __init__(self, history: HistoryManager, settings: Settings, profile_path=None):
        super().__init__()
        self._history = history
        self._profile_path = profile_path
        self._session_history = history
        self._settings = settings
        self.last_position = 0
        self._session_id = None
        self._playback_generation = 0
        self._pending_autoplay_session = None
        self._state_lock = threading.Lock()

    # -- helpers ---------------------------------------------------------
    def _is_safe_next_route(self, route):
        return is_safe_play_route(
            route,
            ADDON_ID,
            username=self._settings.get("username"),
            password=self._settings.get("password"),
            media_type=MediaType.SERIES,
        )

    def _clear_session(self, clear_next, expected_session_id=None):
        window = home_window()
        with self._state_lock:
            session_id = expected_session_id or self._session_id
            if not session_id or window.getProperty(Prop.SESSION_ID) != session_id:
                return
            if clear_next and window.getProperty(Prop.NEXT_SESSION) == session_id:
                window.clearProperty(Prop.NEXT_URL)
                window.clearProperty(Prop.NEXT_SESSION)
            window.clearProperty(Prop.MEDIA_TYPE)
            window.clearProperty(Prop.MEDIA_ID)
            window.clearProperty(Prop.ACCOUNT_FINGERPRINT)
            window.clearProperty(Prop.SESSION_ID)
            if self._session_id == session_id:
                self._session_id = None
                self._session_history = self._history

    def _cancel_pending_autoplay(self, session_id):
        with self._state_lock:
            if self._pending_autoplay_session == session_id:
                self._pending_autoplay_session = None

    def refresh_position(self):
        """Remember the current play time (called periodically by the service)."""
        try:
            self.last_position = self.getTime()
        except (RuntimeError, ValueError, TypeError):
            pass

    # -- xbmc.Player callbacks -------------------------------------------
    def onPlayBackStarted(self):
        window = home_window()
        account_fingerprint = window.getProperty(Prop.ACCOUNT_FINGERPRINT)
        session_history = (
            HistoryManager(self._profile_path, namespace=account_fingerprint)
            if self._profile_path and account_fingerprint
            else self._history
        )
        with self._state_lock:
            self.last_position = 0
            self._playback_generation += 1
            self._pending_autoplay_session = None
            self._session_id = window.getProperty(Prop.SESSION_ID) or None
            self._session_history = session_history

    def onPlayBackStopped(self):
        try:
            window = home_window()
            if window.getProperty(Prop.SESSION_ID) != self._session_id:
                return
            media_type = window.getProperty(Prop.MEDIA_TYPE)
            media_id = window.getProperty(Prop.MEDIA_ID)
            if media_type and media_id:
                self._session_history.update_resume_time(
                    media_type, media_id, self.last_position
                )
        except Exception as error:  # a callback must never raise into Kodi
            logger.log_exception("Saving resume point failed", error)
        finally:
            self._clear_session(clear_next=True)

    def onPlayBackError(self):
        self._clear_session(clear_next=True)

    def onPlayBackPaused(self):
        self.refresh_position()

    def onPlayBackEnded(self):
        next_url = ""
        session_id = None
        playback_generation = None
        try:
            window = home_window()
            with self._state_lock:
                session_id = self._session_id
                if not session_id or window.getProperty(Prop.SESSION_ID) != session_id:
                    return
                if self._pending_autoplay_session == session_id:
                    return
                self._pending_autoplay_session = session_id
                playback_generation = self._playback_generation

            media_type = window.getProperty(Prop.MEDIA_TYPE)
            media_id = window.getProperty(Prop.MEDIA_ID)
            if media_type and media_id:
                self._session_history.update_resume_time(media_type, media_id, 0)
            if window.getProperty(Prop.NEXT_SESSION) == session_id:
                next_url = window.getProperty(Prop.NEXT_URL)
        except Exception as error:  # a callback must never raise into Kodi
            logger.log_exception("Finishing playback failed", error)
        finally:
            self._clear_session(clear_next=True, expected_session_id=session_id)

        if not next_url:
            self._cancel_pending_autoplay(session_id)
            return
        self._autoplay(next_url, session_id, playback_generation)

    def _autoplay(self, next_url, session_id, playback_generation):
        monitor = xbmc.Monitor()
        if monitor.waitForAbort(NEXT_EPISODE_DELAY_SECONDS) or not self._is_safe_next_route(next_url):
            self._cancel_pending_autoplay(session_id)
            return

        window = home_window()
        with self._state_lock:
            can_autoplay = (
                self._pending_autoplay_session == session_id
                and self._playback_generation == playback_generation
                and not window.getProperty(Prop.SESSION_ID)
                and not self.isPlaying()
                and not monitor.abortRequested()
            )
            self._pending_autoplay_session = None
            if can_autoplay:
                xbmcgui.Dialog().notification(
                    "Xtream Codes",
                    "Lancement de l'épisode suivant...",
                    xbmcgui.NOTIFICATION_INFO,
                    3000,
                )
                # Go through Kodi's plugin resolver so the play route starts a
                # fresh session and history entry.
                xbmc.executebuiltin('PlayMedia("{}")'.format(next_url))


def run_service():
    """Service main loop: keep the play position fresh until Kodi exits."""
    profile_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    settings = Settings()
    player = XtreamPlayer(
        HistoryManager(profile_path),
        settings,
        profile_path=profile_path,
    )
    monitor = xbmc.Monitor()
    precache_thread = None  # Only an explicit refresh request may start catalog warming.
    window = home_window()
    try:
        while not monitor.abortRequested():
            if player.isPlaying():
                player.refresh_position()
            if window.getProperty(Prop.PRECACHE_REQUEST):
                window.clearProperty(Prop.PRECACHE_REQUEST)
                if precache_thread is None or not precache_thread.is_alive():
                    precache_thread = start_service_precache(
                        profile_path, settings, monitor, initial_delay=False
                    )
            if monitor.waitForAbort(1.0):
                break
    finally:
        if precache_thread is not None:
            precache_thread.join(timeout=1.0)
