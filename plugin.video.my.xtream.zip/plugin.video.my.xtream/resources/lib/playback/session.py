"""Playback session state shared through home-window properties.

The plugin process starts a session just before resolving a stream; the
background service reads it to save resume points and chain episodes.
"""
import uuid

import xbmcgui

from resources.lib.core.constants import HOME_WINDOW_ID, Prop


def home_window():
    return xbmcgui.Window(HOME_WINDOW_ID)


def begin(media_type, media_id, next_url=None, account_fingerprint=None):
    """Start a new session and return its id.

    ``next_url`` must already be validated by the caller.
    """
    window = home_window()
    session_id = uuid.uuid4().hex
    for key in (
        Prop.NEXT_URL,
        Prop.NEXT_SESSION,
        Prop.MEDIA_TYPE,
        Prop.MEDIA_ID,
        Prop.ACCOUNT_FINGERPRINT,
    ):
        window.clearProperty(key)
    window.setProperty(Prop.SESSION_ID, session_id)
    if next_url:
        window.setProperty(Prop.NEXT_URL, next_url)
        window.setProperty(Prop.NEXT_SESSION, session_id)
    if media_type and media_id:
        window.setProperty(Prop.MEDIA_TYPE, str(media_type))
        window.setProperty(Prop.MEDIA_ID, str(media_id))
    if account_fingerprint:
        window.setProperty(Prop.ACCOUNT_FINGERPRINT, str(account_fingerprint))
    return session_id
