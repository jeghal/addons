from resources.lib.routing.router import Router, router, route

__all__ = ["Router", "router", "route"]
