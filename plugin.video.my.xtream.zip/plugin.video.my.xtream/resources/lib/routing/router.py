"""Decorator based route registry for the plugin entry point."""
from resources.lib.core import logger


class Route:
    __slots__ = ("mode", "handler", "requires_account")

    def __init__(self, mode, handler, requires_account):
        self.mode = mode
        self.handler = handler
        self.requires_account = requires_account


class Router:
    def __init__(self):
        self._routes = {}

    def route(self, mode, requires_account=True):
        """Register ``handler(ctx, params)`` for ``mode``.

        Routes that need provider credentials use ``requires_account=True``;
        the dispatcher asks the user to configure the account first.
        """
        def decorator(handler):
            if mode in self._routes:
                raise ValueError("duplicate route: {!r}".format(mode))
            self._routes[mode] = Route(mode, handler, requires_account)
            return handler
        return decorator

    def modes(self):
        return set(self._routes)

    def resolve(self, mode):
        return self._routes.get(mode)

    def dispatch(self, ctx, on_missing_account):
        """Run the handler for the request, returning True when one ran."""
        route = self.resolve(ctx.params.get("mode"))
        if route is None:
            logger.warning("Unknown route requested")
            return False
        if route.requires_account and not ctx.credentials:
            on_missing_account(ctx)
            return False
        route.handler(ctx, ctx.params)
        return True


router = Router()
route = router.route
