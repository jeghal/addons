import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.gui import create_list_item, directory_listing
from resources.lib.utils import build_url, safe_float, safe_text, sort_series, sort_vod



def _find_matches(items, query, limit):
    """Count every match but retain only the first `limit` entries.

    Avoid creating a second list of the entire catalog or all matches.
    """
    results = []
    count = 0
    needle = query.lower()
    for item in items:
        if not isinstance(item, dict):
            continue
        if needle in safe_text(item.get("name")).lower():
            count += 1
            if len(results) < limit:
                results.append(item)
    return results, count

def _get_catalog_rating(data):
    rating = safe_float(data.get("rating"))
    if rating > 0:
        return min(rating, 10.0)
    rating_5based = safe_float(data.get("rating_5based"))
    return min(rating_5based * 2, 10.0) if rating_5based > 0 else 0.0


def _get_series_fanart(data):
    backdrop = data.get("backdrop_path")
    if isinstance(backdrop, list):
        return next((safe_text(image) for image in backdrop if safe_text(image)), None)
    return None


def _get_release_year(data):
    release_date = safe_text(data.get("releaseDate") or data.get("release_date"))
    return int(release_date[:4]) if len(release_date) >= 4 and release_date[:4].isdigit() else 0


def get_user_input(prompt):
    keyboard = xbmc.Keyboard("", prompt)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None


@directory_listing
def search_vod(handle, client, cache_manager, default_vod_icon):
    query = get_user_input("Rechercher un film :")
    if not query or len(query) < 2: return
    
    # 1. Tenter de lire le cache disque
    all_streams = cache_manager.get("vod")
    
    # 2. Si pas de cache, forcer le téléchargement maintenant
    if all_streams is None:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Recherche', 'Téléchargement de la liste des films...')
        
        all_streams = client.get_vod_streams()
        if all_streams is not None:
            # Tri et sauvegarde
            all_streams = sort_vod(all_streams)
            cache_manager.set("vod", all_streams)
        
        pDialog.close()
        
    if not isinstance(all_streams, list):
        xbmcgui.Dialog().notification("Info", "Aucun contenu trouvé", xbmcgui.NOTIFICATION_INFO)
        return
    # Un seul parcours, sans dupliquer la liste complète.
    results, match_count = _find_matches(all_streams, query, 50)
    del all_streams

    if not results:
        xbmcgui.Dialog().notification("Info", "Aucun résultat pour : " + query, xbmcgui.NOTIFICATION_INFO)
        return
    
    # Limiter à 50 résultats pour affichage plus rapide
    if match_count > 50:
        xbmcgui.Dialog().notification("Info", f"{match_count} trouvés. Affichage des 50 premiers.", xbmcgui.NOTIFICATION_INFO, 3000)
    
    # Affichage optimisé
    xbmcplugin.setContent(handle, 'movies')
    for stream in results:
        name = safe_text(stream.get("name"), "Sans titre")
        stream_id = stream.get("stream_id")
        if stream_id is None:
            continue
        icon = stream.get("stream_icon") or default_vod_icon
        info_tag = {
            "title": name,
            "rating": _get_catalog_rating(stream),
            "mediatype": "movie"
        }

        li = create_list_item(
             label=name,
             icon=icon,
             thumb=icon,
             poster=icon,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "vod_info", "vod_id": stream_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
@directory_listing
def search_global(handle, client, cache_manager, default_vod_icon, default_series_icon):
    query = get_user_input("Recherche Globale :")
    if not query or len(query) < 2: return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Recherche Globale', 'Chargement des données...')

    # --- 1. Recherche VOD ---
    pDialog.update(10, 'Recherche dans les films...')
    all_vod = cache_manager.get("vod")
    if all_vod is None:
        all_vod = client.get_vod_streams()
        if all_vod is not None:
            all_vod = sort_vod(all_vod)
            cache_manager.set("vod", all_vod)
    
    vod_results = []
    if isinstance(all_vod, list):
        vod_results, _ = _find_matches(all_vod, query, 30)
    # The result list holds only selected items; release the full VOD catalog
    # before loading the series catalog to lower peak memory usage on webOS.
    del all_vod

    # --- 2. Recherche Series ---
    pDialog.update(50, 'Recherche dans les séries...')
    all_series = cache_manager.get("series")
    if all_series is None:
        all_series = client.get_series_list()
        if all_series is not None:
            all_series = sort_series(all_series)
            cache_manager.set("series", all_series)

    series_results = []
    if isinstance(all_series, list):
        series_results, _ = _find_matches(all_series, query, 30)
    # Keep only selected series entries while rendering Kodi list items.
    del all_series

    pDialog.close()

    if not vod_results and not series_results:
        xbmcgui.Dialog().notification("Info", "Aucun résultat trouvé", xbmcgui.NOTIFICATION_INFO)
        return

    # Limites
    max_results = 30
    if len(vod_results) > max_results: vod_results = vod_results[:max_results]
    if len(series_results) > max_results: series_results = series_results[:max_results]

    xbmcplugin.setContent(handle, 'files') # Mixed content type for better compatibility

    # --- Affichage FILMS ---
    if vod_results:
        li_sep = create_list_item(label="[B][COLOR yellow]--- FILMS ---[/COLOR][/B]", icon="DefaultMovies.png")
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li_sep, isFolder=False)
        
        for stream in vod_results:
            name = safe_text(stream.get("name"), "Sans titre")
            stream_id = stream.get("stream_id")
            if stream_id is None:
                continue
            icon = stream.get("stream_icon") or default_vod_icon
            li = create_list_item(
                 label=name,
                 icon=icon,
                 thumb=icon,
                 poster=icon,
                 info={"video": {"title": name, "mediatype": "movie", "rating": _get_catalog_rating(stream)}}
            )
            url = build_url({"mode": "vod_info", "vod_id": stream_id})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    # --- Affichage SERIES ---
    if series_results:
        li_sep = create_list_item(label="[B][COLOR yellow]--- SERIES ---[/COLOR][/B]", icon="DefaultTVShows.png")
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li_sep, isFolder=False)

        for s in series_results:
            name = safe_text(s.get("name"), "Sans titre")
            series_id = s.get("series_id")
            if series_id is None:
                continue
            cover = s.get("cover") or default_series_icon
            fanart = _get_series_fanart(s)
            info_tag = {
                "title": name,
                "plot": safe_text(s.get("plot")),
                "mediatype": "tvshow",
                "genre": safe_text(s.get("genre")),
                "year": _get_release_year(s),
                "rating": _get_catalog_rating(s),
            }
            
            li = create_list_item(
                 label=name,
                 icon=cover,
                 thumb=cover,
                 poster=cover,
                 fanart=fanart,
                 info={"video": info_tag}
            )
            url = build_url({"mode": "series_info", "series_id": series_id})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
            
@directory_listing
def search_series(handle, client, cache_manager, default_series_icon):
    query = get_user_input("Rechercher une série :")
    if not query or len(query) < 2: return
    
    # 1. Tenter de lire le cache disque
    all_series = cache_manager.get("series")
    
    # 2. Si pas de cache, forcer le téléchargement
    if all_series is None:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Recherche', 'Téléchargement des séries...')
        
        all_series = client.get_series_list()
        if all_series is not None:
            all_series = sort_series(all_series)
            cache_manager.set("series", all_series)
            
        pDialog.close()
        
    if not isinstance(all_series, list):
        xbmcgui.Dialog().notification("Info", "Aucun contenu trouvé", xbmcgui.NOTIFICATION_INFO)
        return
    # Un seul parcours, sans dupliquer la liste complète.
    results, match_count = _find_matches(all_series, query, 50)
    del all_series

    if not results:
        xbmcgui.Dialog().notification("Info", "Aucun résultat pour : " + query, xbmcgui.NOTIFICATION_INFO)
        return

    # Limiter à 50 résultats pour affichage plus rapide
    if match_count > 50:
        xbmcgui.Dialog().notification("Info", f"{match_count} trouvés. Affichage des 50 premiers.", xbmcgui.NOTIFICATION_INFO, 3000)

    # Affichage optimisé
    xbmcplugin.setContent(handle, 'tvshows')
    for s in results:
        name = safe_text(s.get("name"), "Sans titre")
        series_id = s.get("series_id")
        if series_id is None:
            continue
        cover = s.get("cover") or default_series_icon
        fanart = _get_series_fanart(s)
        info_tag = {
            "title": name,
            "plot": safe_text(s.get("plot")),
            "mediatype": "tvshow",
            "genre": safe_text(s.get("genre")),
            "year": _get_release_year(s),
            "rating": _get_catalog_rating(s),
        }
        
        li = create_list_item(
             label=name,
             icon=cover,
             thumb=cover,
             poster=cover,
             fanart=fanart,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "series_info", "series_id": series_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
