import xbmcgui
import xbmcplugin

from resources.lib.catalog import CATEGORY_GROUPS, group_categories
from resources.lib.gui import create_list_item, directory_listing
from resources.lib.utils import (
    build_url,
    get_safe_image,
    safe_float,
    safe_int,
    safe_text,
    parse_duration,
    sort_series,
    translate_to_arabic,
)


def _get_fanart(data):
    backdrop = data.get("backdrop_path")
    if isinstance(backdrop, list) and backdrop:
        return get_safe_image(backdrop[0], None)
    return get_safe_image(backdrop, None)


def _get_year(data, release_date=""):
    year = safe_int(data.get("year"))
    if 1000 <= year <= 9999:
        return year
    if len(release_date) >= 4 and release_date[:4].isdigit():
        return int(release_date[:4])
    return 0


def _get_rating(data):
    rating = safe_float(data.get("rating"))
    if rating > 0:
        return min(rating, 10.0)
    rating_5based = safe_float(data.get("rating_5based"))
    return min(rating_5based * 2, 10.0) if rating_5based > 0 else 0.0


def _get_duration(data):
    duration = safe_int(data.get("duration_secs"))
    if duration > 0:
        return duration
    duration = parse_duration(data.get("duration"))
    if duration > 0:
        return duration
    runtime_minutes = safe_int(data.get("episode_run_time"))
    return runtime_minutes * 60 if runtime_minutes > 0 else 0


@directory_listing
def recent_series(handle, addon, client, cache_manager, default_series_icon):
    # 1. Lire le cache
    all_series = cache_manager.get("series")
    
    if not all_series:
        all_series = client.get_series_list()
        if all_series: 
            all_series = sort_series(all_series)
            cache_manager.set("series", all_series)

    if not isinstance(all_series, list):
        xbmcgui.Dialog().notification("Info", "Aucun contenu disponible", xbmcgui.NOTIFICATION_INFO)
        return
    all_series = [series for series in all_series if isinstance(series, dict)]

    # 2. Cache supposé déjà trié !
    
    # Récupérer la limite paramétrable
    limit = 50
    try:
        limit = int(addon.getSetting("recent_limit"))
    except:
        pass
        
    results = all_series[:limit]

    xbmcplugin.setContent(handle, 'tvshows')
    for s in results:
        name = safe_text(s.get("name"), "Série sans titre")
        series_id = s.get("series_id")
        if series_id is None:
            continue
        cover = get_safe_image(s.get("cover"), default_series_icon)
        fanart = _get_fanart(s)
        plot = safe_text(s.get("plot"))
        
        # Last Modified date format (souvent vide mais on essaie)
        last_mod = s.get("last_modified")
        date_str = ""
        date_added_iso = ""
        if last_mod and str(last_mod).isdigit():
             import datetime
             try:
                 dt = datetime.datetime.fromtimestamp(int(last_mod))
                 date_str = dt.strftime("%d/%m/%Y")
                 date_added_iso = dt.strftime("%Y-%m-%d")
             except: pass

        release_date = safe_text(s.get("releaseDate") or s.get("release_date"))
        if not plot and date_str:
            plot = f"Mis à jour : {date_str}"

        info_tag = {
            "title": name,
            "plot": plot,
            "mediatype": "tvshow",
            "genre": safe_text(s.get("genre")),
            "year": _get_year(s, release_date),
            "rating": _get_rating(s),
            "duration": _get_duration(s),
            "premiered": release_date,
            "dateadded": f"{date_added_iso} 00:00:00" if date_added_iso else None,
        }

        li = create_list_item(
             label=name,
             icon=cover,
             thumb=cover,
             poster=cover,
             fanart=fanart,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "series_info", "series_id": series_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
@directory_listing
def list_series_categories(handle, client, cache_manager, group_id=None):
    # Si aucun groupe sélectionné (Racine)
    if not group_id:
        # Ajout du bouton Recherche en premier
        li = create_list_item(label="[B][COLOR red]Rechercher une Série[/COLOR][/B]", icon="DefaultTVShows.png")
        url = build_url({"mode": "search_series"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
        # Ajout du bouton Derniers Ajouts
        li = create_list_item(label="[B][COLOR red]Derniers Ajouts[/COLOR][/B]", icon="DefaultAddonImages.png")
        url = build_url({"mode": "recent_series"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
        # Ajout du bouton Historique en deuxième
        li = create_list_item(label="[B][COLOR red]Continuer à regarder[/COLOR][/B]", icon="DefaultRecentlyAddedEpisodes.png")
        url = build_url({"mode": "history_series"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    categories = cache_manager.get("series_categories")
    if not categories:
        categories = client.get_series_categories()
        if categories:
            cache_manager.set("series_categories", categories)

    if not isinstance(categories, list):
        return
    categories = [category for category in categories if isinstance(category, dict)]
        
    # Grouping Logic
    groups, orphans = group_categories(categories, "series")

    # 1. Si on est à la racine, on affiche les GROUPES + les ORPHELINS
    if not group_id:
        # Afficher les dossiers de groupe
        for label, cats in groups.items():
            count = len(cats)
            # On prend l'icone du premier groupe config qui matche ce label
            icon = "DefaultFolder.png"
            for g in CATEGORY_GROUPS:
                if g["label"] == label:
                    icon = g.get("icon", "DefaultFolder.png")
                    break
            
            li = create_list_item(label=f"{label} ({count})", icon=icon)
            url = build_url({"mode": "series_categories", "group_id": label})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
        # Afficher les orphelins (sous les groupes)
        if orphans:
             # Separator
            li_sep = create_list_item(label="[B]--- Autres ---[/B]", icon="DefaultSeparator.png")
            xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li_sep, isFolder=False)
            
            for cat in orphans:
                li = create_list_item(label=cat.get("category_name", "Unknown"))
                url = build_url({"mode": "series_list", "category_id": cat.get("category_id")})
                xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    # 2. Si un groupe est sélectionné
    else:
        # On récupère les catégories du groupe demandé
        group_cats = groups.get(group_id, [])
        for cat in group_cats:
            li = create_list_item(label=cat.get("category_name", "Unknown"))
            url = build_url({"mode": "series_list", "category_id": cat.get("category_id")})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

@directory_listing
def list_series(handle, client, cache_manager, default_series_icon, category_id):
    xbmcplugin.setContent(handle, 'tvshows')
    
    cache_key = f"series_list_{category_id}"
    series = cache_manager.get(cache_key)
    if not series:
        series = client.get_series_list(category_id)
        if series:
            cache_manager.set(cache_key, series)

    if not isinstance(series, list):
        return
    series = [item for item in series if isinstance(item, dict)]

    items = []
    for s in series:
        name = safe_text(s.get("name"), "Série sans titre")
        series_id = s.get("series_id")
        if series_id is None:
            continue
        cover = get_safe_image(s.get("cover"), default_series_icon)
        
        # Metadata parsing
        plot = safe_text(s.get("plot"))
        cast = s.get("cast")
        director = s.get("director")
        genre = safe_text(s.get("genre"))
        release_date = safe_text(s.get("releaseDate") or s.get("release_date"))
        fanart = _get_fanart(s)

        info_tag = {
            "title": name,
            "plot": plot,
            "mediatype": "tvshow",
            "cast": [x.strip() for x in cast.split(",")] if isinstance(cast, str) else [],
            "director": director,
            "genre": genre,
            "year": _get_year(s, release_date),
            "premiered": release_date,
            "rating": _get_rating(s),
            "duration": _get_duration(s),
        }
        
        # TMDB
        tmdb_id = s.get("tmdb")
        if tmdb_id:
            info_tag["tmdb_id"] = tmdb_id
            info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

        li = create_list_item(
             label=name,
             icon=cover,
             thumb=cover,
             poster=cover,
             fanart=fanart,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "series_info", "series_id": series_id})
        items.append((url, li, True))

    xbmcplugin.addDirectoryItems(handle, items)
@directory_listing
def list_seasons(handle, client, default_series_icon, series_id):
    xbmcplugin.setContent(handle, 'seasons')
    data = client.get_series_info(series_id)
    if not isinstance(data, dict):
        return

    episodes_data = data.get("episodes")
    if not isinstance(episodes_data, dict):
        episodes_data = {}

    seasons_data = data.get("seasons")
    if not isinstance(seasons_data, list):
        seasons_data = []

    info = data.get("info", {})
    if not isinstance(info, dict):
        info = {}
    
    seasons_map = {}
    for s in seasons_data:
        if not isinstance(s, dict):
            continue
        s_num = s.get("season_number")
        if s_num is not None:
            seasons_map[str(s_num)] = s

    season_keys = sorted(
        (key for key, value in episodes_data.items() if isinstance(key, str) and isinstance(value, list)),
        key=lambda x: int(x) if x.isdigit() else 999
    )
    
    series_cover = get_safe_image(info.get("cover"), default_series_icon)
    
    series_fanart = _get_fanart(info)
    
    if not season_keys:
        xbmcgui.Dialog().notification("Info", "Aucune saison trouvée", xbmcgui.NOTIFICATION_INFO)
        return

    for season_num in season_keys:
        episode_list = episodes_data.get(season_num, [])
        episode_count = sum(1 for episode in episode_list if isinstance(episode, dict))
        
        s_info = seasons_map.get(str(season_num), {})
        
        s_name = safe_text(s_info.get("name"))
        if not s_name or s_name == "null":
            s_name = f"Saison {season_num}"
        
        label = f"{s_name} ({episode_count} épisodes)"
        
        s_cover = get_safe_image(s_info.get("cover"), series_cover)
            
        s_plot = safe_text(s_info.get("overview") or info.get("plot"))
        
        # Translate season plot to Arabic if enabled
        if s_plot:
            arabic_plot = translate_to_arabic(s_plot)
            if arabic_plot and arabic_plot != s_plot:
                # Show Arabic translation first, then original
                s_plot = f"[B][COLOR yellow]الترجمة العربية:[/COLOR][/B]\n{arabic_plot}\n\n[B]Original:[/B]\n{s_plot}"
        
        s_premiered = safe_text(s_info.get("air_date"))

        info_tag = {
            "title": s_name,
            "plot": s_plot,
            "mediatype": "season",
            "season": int(season_num) if str(season_num).isdigit() else 0,
            "premiered": s_premiered,
            "tvshowtitle": info.get("name")
        }

        li = create_list_item(
            label=label,
            icon=s_cover,
            thumb=s_cover,
            poster=s_cover,
            fanart=series_fanart,
            info={"video": info_tag}
        )
        
        url = build_url({"mode": "series_episodes", "series_id": series_id, "season_num": season_num})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
            
@directory_listing
def list_episodes(handle, plugin_url, client, default_series_icon, series_id, season_num):
    xbmcplugin.setContent(handle, 'episodes')
    data = client.get_series_info(series_id)
    if not isinstance(data, dict):
        return
    
    all_episodes = data.get("episodes")
    if not isinstance(all_episodes, dict):
        all_episodes = {}

    season_episodes = all_episodes.get(str(season_num), [])
    if not isinstance(season_episodes, list):
        season_episodes = []
    else:
        season_episodes = [episode for episode in season_episodes if isinstance(episode, dict)]
    
    series_info = data.get("info", {})
    if not isinstance(series_info, dict):
        series_info = {}
    series_name = safe_text(series_info.get("name"))
    series_cover = get_safe_image(series_info.get("cover"), default_series_icon)
    
    series_fanart = _get_fanart(series_info)

    count = len(season_episodes)
    for i in range(count):
        ep = season_episodes[i]
        
        title = safe_text(ep.get("title"))
        episode_num = safe_int(ep.get("episode_num"), i + 1)
        if episode_num <= 0:
            episode_num = i + 1
        
        # Fallback Title logic
        if not title or title.lower() == "null":
            # Format: Series Name SXXEXX
            try:
                s_num = int(season_num)
                e_num = int(episode_num)
                title = f"{series_name} S{s_num:02d}E{e_num:02d}"
            except:
                title = f"{series_name} - Episode {episode_num}"
        
        episode_id = ep.get("id")
        if episode_id is None:
            continue
        container_extension = ep.get("container_extension") or "mp4"
        play_url = client.get_series_episode_url(episode_id, container_extension)
        
        ep_info = ep.get("info", {})
        if not isinstance(ep_info, dict): ep_info = {}

        # Metadata extraction
        plot = safe_text(ep_info.get("plot") or series_info.get("plot"))
        
        rating = _get_rating(ep_info)
        releasedate = safe_text(ep_info.get("releasedate"))
        duration_secs = _get_duration(ep_info)
        
        thumb = get_safe_image(ep_info.get("movie_image"), series_cover)

        info_tag = {
            "title": title,
            "plot": plot,
            "mediatype": "episode",
            "tvshowtitle": series_name,
            "season": int(season_num) if str(season_num).isdigit() else 0,
            "episode": episode_num,
            "premiered": releasedate,
            "duration": safe_int(duration_secs),
            "rating": safe_float(rating)
        }
            
        li = create_list_item(
             label=title,
             icon=thumb,
             thumb=thumb,
             poster=series_cover,
             fanart=series_fanart,
             info={"video": info_tag},
             properties={'IsPlayable': 'true'}
        )
        
        # History Title
        full_title = f"{series_name} - {title}" if series_name and series_name not in title else title
        
        # Next Episode Logic
        next_url_param = ""
        if i + 1 < count:
            next_ep = season_episodes[i+1]
            next_id = next_ep.get("id")
            if next_id is not None:
                next_ext = next_ep.get("container_extension") or "mp4"
                next_play_url = client.get_series_episode_url(next_id, next_ext)

                next_title = safe_text(next_ep.get("title"))
                next_ep_num = int(next_ep.get("episode_num")) if "episode_num" in next_ep and str(next_ep.get("episode_num")).isdigit() else i + 2

                if not next_title:
                    try:
                        s_num = int(season_num)
                        next_title = f"{series_name} S{s_num:02d}E{next_ep_num:02d}"
                    except (TypeError, ValueError):
                        next_title = f"{series_name} - Episode {next_ep_num}"

                next_full_title = f"{series_name} - {next_title}" if series_name and series_name not in next_title else next_title

                next_ep_info = next_ep.get("info", {})
                if not isinstance(next_ep_info, dict):
                    next_ep_info = {}
                next_thumb = get_safe_image(next_ep_info.get("movie_image"), series_cover)

                next_meta = {
                    "title": next_title,
                    "mediatype": "episode",
                    "tvshowtitle": series_name,
                    "thumb": next_thumb,
                    "plot": safe_text(next_ep_info.get("plot") or series_info.get("plot")),
                    "duration": _get_duration(next_ep_info),
                    "season": info_tag["season"],
                    "episode": next_ep_num,
                }

                from urllib.parse import urlencode
                next_params = {
                    "mode": "play_channel",
                    "url": next_play_url,
                    "title": next_full_title,
                    "icon": next_thumb,
                    "media_type": "series",
                    "media_id": next_id,
                    "group_id": series_id,
                    "extension": next_ext,
                    "meta": str(next_meta),
                }
                next_url_param = f"{plugin_url}?{urlencode(next_params)}"

        url_params = {
            "mode": "play_channel", 
            "url": play_url, 
            "title": full_title, 
            "icon": thumb, 
            "media_type": "series", 
            "media_id": episode_id,
            "group_id": series_id,
            "extension": container_extension,
            "meta": str(info_tag),
            "next_url": next_url_param 
        }
        
        url = build_url(url_params)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
