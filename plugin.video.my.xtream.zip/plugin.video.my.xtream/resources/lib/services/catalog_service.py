"""Cache-aware access to provider catalogs (live / VOD / series).

Cache keys are unchanged from earlier versions so existing caches stay valid.
"""
from collections import namedtuple

from resources.lib.core.constants import MediaType
from resources.lib.domain.sorting import sort_series, sort_vod

CatalogKind = namedtuple(
    "CatalogKind",
    "categories_key categories_fetch streams_key streams_fetch catalog_key catalog_fetch sorter",
)

KINDS = {
    MediaType.LIVE: CatalogKind(
        "live_categories", "get_live_categories",
        "live_streams_{}", "get_live_streams",
        None, None, None,
    ),
    MediaType.VOD: CatalogKind(
        "vod_categories", "get_vod_categories",
        "vod_streams_{}", "get_vod_streams",
        "vod", "get_vod_streams", sort_vod,
    ),
    MediaType.SERIES: CatalogKind(
        "series_categories", "get_series_categories",
        "series_list_{}", "get_series_list",
        "series", "get_series_list", sort_series,
    ),
}


class CatalogService:
    def __init__(self, client, cache):
        self._client = client
        self._cache = cache

    def _cached_or_fetch(self, key, fetch, *args):
        data = self._cache.get(key)
        if data is None:
            generation = self._cache.generation()
            data = fetch(*args)
            if data is not None:
                self._cache.set(key, data, expected_generation=generation)
        return data

    def categories(self, kind):
        spec = KINDS[kind]
        return self._cached_or_fetch(spec.categories_key, getattr(self._client, spec.categories_fetch))

    def category_streams(self, kind, category_id):
        spec = KINDS[kind]
        return self._cached_or_fetch(
            spec.streams_key.format(category_id),
            getattr(self._client, spec.streams_fetch),
            category_id,
        )

    def cached_catalog(self, kind):
        """Full sorted catalog from disk cache only (None when absent/expired)."""
        return self._cache.get(KINDS[kind].catalog_key)

    def load_catalog(self, kind, wait_timeout=30.0):
        """Fetch (or wait for another worker to fetch) the full catalog."""
        spec = KINDS[kind]
        return self._cache.get_or_fetch_catalog(
            spec.catalog_key,
            getattr(self._client, spec.catalog_fetch),
            spec.sorter,
            wait_timeout=wait_timeout,
        )

    def catalog(self, kind, wait_timeout=30.0):
        """Full catalog from cache, downloading it when missing."""
        data = self.cached_catalog(kind)
        if data is None:
            data = self.load_catalog(kind, wait_timeout)
        return data

    def is_catalog_fresh(self, kind):
        return self._cache.is_valid(KINDS[kind].catalog_key)
