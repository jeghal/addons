"""Catalog pre-caching owned by Kodi's long-lived background service."""
import threading

import xbmcgui

from resources.lib.core import logger
from resources.lib.core.constants import HOME_WINDOW_ID, MediaType, Prop

JOB_NAME = "precache"
START_DELAY_SECONDS = 3


def start_background_precache(ctx):
    """Ask the background service to refresh catalogs without blocking UI."""
    if ctx.settings.precache_enabled and ctx.credentials:
        xbmcgui.Window(HOME_WINDOW_ID).setProperty(Prop.PRECACHE_REQUEST, "1")


def start_service_precache(profile_path, settings, monitor, initial_delay=True):
    """Start one service-owned cache worker and return its thread, if any."""
    if not settings.precache_enabled:
        return None
    credentials = settings.credentials()
    if not credentials:
        return None

    from resources.lib.api.xtream_client import XtreamCodesClient
    from resources.lib.services.catalog_service import CatalogService
    from resources.lib.storage.cache import CacheManager

    cache = CacheManager(profile_path, credentials.fingerprint)
    if not cache.acquire_job(JOB_NAME):
        return None
    try:
        client = XtreamCodesClient(*credentials)
        catalogs = CatalogService(client, cache)
    except Exception as error:
        cache.release_job(JOB_NAME)
        logger.log_exception("Background cache setup failed", error)
        return None

    def worker():
        try:
            if initial_delay and monitor.waitForAbort(START_DELAY_SECONDS):
                return
            for kind, label in ((MediaType.VOD, "VOD"), (MediaType.SERIES, "Series")):
                if monitor.abortRequested():
                    return
                if not catalogs.is_catalog_fresh(kind):
                    logger.info("Pre-caching {}...".format(label))
                    catalogs.load_catalog(kind)
        except Exception as error:
            logger.log_exception("Background cache refresh failed", error)
        finally:
            cache.release_job(JOB_NAME)

    try:
        thread = threading.Thread(target=worker, name="xtream-precache", daemon=True)
        thread.start()
    except Exception as error:
        cache.release_job(JOB_NAME)
        logger.log_exception("Background cache start failed", error)
        return None
    return thread
