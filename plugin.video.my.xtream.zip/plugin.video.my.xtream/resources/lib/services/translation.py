"""Arabic translation of plots with a bounded, persistent cache.

Uses the unofficial Google Translate endpoint. Failures are remembered for a
few minutes so a dead network does not slow every listing.
"""
import json
import os
import threading
import time
import urllib.parse
import urllib.request
from typing import Dict, Optional

from resources.lib.core import logger
from resources.lib.storage.atomic import write_atomic
from resources.lib.storage.file_lock import FileLock

MAX_CACHE_SIZE = 1000
CACHE_FILE = "translation_cache.json"
TRANSLATION_TIMEOUT = 5
FAILURE_RETRY_SECONDS = 300
MAX_TEXT_LENGTH = 5000
MAX_RESPONSE_BYTES = 256 * 1024
ENDPOINT = "https://translate.googleapis.com/translate_a/single"


class ArabicTranslator:
    def __init__(self, profile_path, enabled=lambda: True,
                 max_response_bytes=MAX_RESPONSE_BYTES):
        self._file_path = os.path.join(profile_path, CACHE_FILE) if profile_path else ""
        self._lock_path = self._file_path + ".lock" if self._file_path else ""
        self._enabled = enabled
        self._max_response_bytes = max(1, int(max_response_bytes))
        self._cache: Dict[str, str] = {}
        self._failures: Dict[str, float] = {}
        self._lock = threading.RLock()
        self._loaded = False

    # -- persistence -------------------------------------------------
    def _read_disk_cache(self):
        if not self._file_path or not os.path.exists(self._file_path):
            return {}
        try:
            with open(self._file_path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                return {
                    key: value
                    for key, value in list(loaded.items())[-MAX_CACHE_SIZE:]
                    if isinstance(key, str) and isinstance(value, str)
                }
        except (OSError, ValueError, UnicodeDecodeError):
            pass
        return {}

    def _load(self):
        with self._lock:
            if self._loaded:
                return
            self._cache = self._read_disk_cache()
            self._loaded = True

    def _save(self):
        """Persist the cache; caller must hold the lock."""
        if not self._file_path:
            return
        try:
            os.makedirs(os.path.dirname(self._file_path), exist_ok=True)
            write_atomic(
                self._file_path,
                lambda handle: json.dump(self._cache, handle, ensure_ascii=False),
                prefix="translation.",
            )
        except OSError:
            pass

    def _remember(self, text, translated):
        if not self._lock_path:
            with self._lock:
                self._cache[text] = translated
            return translated
        try:
            process_lock = FileLock(self._lock_path)
            process_lock.acquire()
        except (OSError, TimeoutError):
            with self._lock:
                self._cache[text] = translated
            return translated
        try:
            with self._lock:
                latest = self._read_disk_cache()
                merged = dict(self._cache)
                merged.update(latest)
                if text not in latest:
                    merged.pop(text, None)
                    merged[text] = translated
                while len(merged) > MAX_CACHE_SIZE:
                    del merged[next(iter(merged))]
                self._cache = merged
                self._failures.pop(text, None)
                self._save()
                return self._cache.get(text, translated)
        finally:
            process_lock.release()

    def _refresh_from_disk(self):
        if not self._lock_path:
            return
        try:
            with FileLock(self._lock_path):
                latest = self._read_disk_cache()
                with self._lock:
                    merged = dict(self._cache)
                    merged.update(latest)
                    self._cache = dict(list(merged.items())[-MAX_CACHE_SIZE:])
        except (OSError, TimeoutError):
            pass

    # -- public API --------------------------------------------------
    def cached(self, text: str) -> Optional[str]:
        """Return a cached translation without touching the network."""
        if not isinstance(text, str) or not text.strip() or not self._enabled():
            return None
        self._load()
        with self._lock:
            result = self._cache.get(text)
        if result is None:
            self._refresh_from_disk()
            with self._lock:
                result = self._cache.get(text)
        return result

    def translate(self, text: str) -> Optional[str]:
        """Translate ``text`` to Arabic.

        Returns None when translation is disabled and the original text when
        the service is unavailable.
        """
        if not isinstance(text, str) or not text.strip():
            return text
        if not self._enabled():
            return None

        cached = self.cached(text)
        if cached is not None:
            return cached
        with self._lock:
            last_failure = self._failures.get(text)
            if last_failure and time.monotonic() - last_failure < FAILURE_RETRY_SECONDS:
                return text

        try:
            translated = self._request(text[:MAX_TEXT_LENGTH])
        except Exception as error:  # network/parse errors must never break a listing
            with self._lock:
                self._failures[text] = time.monotonic()
            logger.log_exception("Translation failed", error)
            return text

        if translated:
            return self._remember(text, translated)
        return text

    def _request(self, text):
        query = urllib.parse.urlencode({"client": "gtx", "sl": "auto", "tl": "ar", "dt": "t", "q": text})
        request = urllib.request.Request(
            "{}?{}".format(ENDPOINT, query),
            headers={"User-Agent": "Mozilla/5.0"},
        )
        with urllib.request.urlopen(request, timeout=TRANSLATION_TIMEOUT) as response:
            chunks = []
            total = 0
            while True:
                remaining = self._max_response_bytes - total
                chunk = response.read(min(64 * 1024, remaining + 1))
                if not chunk:
                    break
                total += len(chunk)
                if total > self._max_response_bytes:
                    raise ValueError("translation response exceeds configured limit")
                chunks.append(chunk)
            data = json.loads(b"".join(chunks).decode("utf-8"))
        if data and isinstance(data, list):
            segments = data[0]
            if isinstance(segments, list):
                return "".join(
                    segment[0] for segment in segments
                    if isinstance(segment, list) and segment and isinstance(segment[0], str)
                )
        return ""
