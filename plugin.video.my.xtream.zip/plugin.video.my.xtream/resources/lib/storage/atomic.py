"""Crash-safe file replacement.

The payload is streamed through ``writer(handle)`` so very large catalogs are
never materialised as one extra in-memory string.
"""
import os
import tempfile


def write_atomic(path, writer, encoding="utf-8", prefix="tmp."):
    """Write via a temporary file in the same directory, fsync, then rename.

    On any failure the temporary file is removed and the error re-raised, so
    ``path`` always holds either the old or the new complete content.
    """
    directory = os.path.dirname(path) or "."
    descriptor, temporary_path = tempfile.mkstemp(prefix=prefix, suffix=".tmp", dir=directory)
    try:
        try:
            handle = os.fdopen(descriptor, "w", encoding=encoding)
        except BaseException:
            os.close(descriptor)
            raise
        with handle:
            writer(handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        try:
            os.remove(temporary_path)
        except OSError:
            pass
        raise
