import glob
import hashlib
import json
import os
import threading
import time
import uuid
from typing import Callable, Dict, List, Optional, Union

from resources.lib.core import logger
from resources.lib.storage.atomic import write_atomic
from resources.lib.storage.file_lock import FileLock


DEFAULT_CACHE_EXPIRATION = 6 * 60 * 60
CATALOG_CACHE_EXPIRATION = 24 * 60 * 60
CATALOG_RETRY_COOLDOWN = 5 * 60
CLOCK_SKEW_TOLERANCE = 5 * 60
CATALOG_KEYS = frozenset(("vod", "series"))


class CacheManager:
    def __init__(self, profile_path: str, namespace: str = "default"):
        namespace_hash = hashlib.sha256(str(namespace).encode("utf-8")).hexdigest()
        self.cache_dir = os.path.join(profile_path, "cache", namespace_hash)
        os.makedirs(self.cache_dir, exist_ok=True)
        self.expiration = DEFAULT_CACHE_EXPIRATION
        self._catalog_locks = {}
        self._catalog_locks_lock = threading.RLock()
        self._job_locks = {}
        self._job_locks_guard = threading.RLock()

    def _get_file_path(self, key: str) -> str:
        hashed_key = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{hashed_key}.json")

    def _get_job_lock_path(self, job_name: str) -> str:
        safe_name = hashlib.sha256(job_name.encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{safe_name}.lock")

    def _get_catalog_retry_path(self, key: str) -> str:
        safe_name = hashlib.sha256(f"catalog-retry:{key}".encode("utf-8")).hexdigest()
        return os.path.join(self.cache_dir, f"{safe_name}.retry")

    def _get_generation_path(self) -> str:
        return os.path.join(self.cache_dir, ".generation")

    def _get_write_lock_path(self) -> str:
        return os.path.join(self.cache_dir, ".write.lock")

    def generation(self) -> str:
        try:
            with open(self._get_generation_path(), "r", encoding="ascii") as handle:
                return handle.read().strip()
        except (OSError, UnicodeError):
            return ""

    def _get_expiration(self, key: str) -> float:
        if key in CATALOG_KEYS:
            return CATALOG_CACHE_EXPIRATION
        return self.expiration

    def _is_file_fresh(self, key: str, file_path: str) -> bool:
        age = time.time() - os.path.getmtime(file_path)
        return -CLOCK_SKEW_TOLERANCE <= age < self._get_expiration(key)

    def _get_catalog_data(self, key: str, allow_expired: bool = False) -> Optional[List]:
        data = self.get(key, allow_expired=allow_expired)
        if isinstance(data, list):
            return data
        if data is not None:
            logger.warning(f"Invalid {key} catalog cache type ignored")
        return None

    def _catalog_cooldown_active(self, key: str) -> bool:
        retry_path = self._get_catalog_retry_path(key)
        try:
            with open(retry_path, "r", encoding="ascii") as retry_handle:
                failed_at = float(retry_handle.read().strip())
            age = time.time() - failed_at
            if age < -CLOCK_SKEW_TOLERANCE:
                os.remove(retry_path)
                return False
            return age < CATALOG_RETRY_COOLDOWN
        except (FileNotFoundError, ValueError, UnicodeError):
            return False
        except OSError:
            return False

    def _record_catalog_failure(self, key: str) -> None:
        try:
            write_atomic(
                self._get_catalog_retry_path(key),
                lambda handle: handle.write(str(time.time())),
                encoding="ascii",
                prefix="retry.",
            )
        except OSError as error:
            logger.warning(f"Catalog retry state write failed: {type(error).__name__}")

    def _clear_catalog_failure(self, key: str) -> None:
        try:
            os.remove(self._get_catalog_retry_path(key))
        except FileNotFoundError:
            pass
        except OSError as error:
            logger.warning(f"Catalog retry state clear failed: {type(error).__name__}")

    def _acquire_catalog_lock(
        self,
        key: str,
        wait_timeout: float = 30.0,
        stale_after: float = 300.0,
        poll_interval: float = 0.1,
    ) -> Optional[str]:
        lock = FileLock(
            self._get_job_lock_path(f"catalog:{key}"),
            timeout=wait_timeout,
            stale_after=stale_after,
            poll_interval=poll_interval,
        )
        try:
            owner_token = lock.acquire()
        except TimeoutError:
            return None
        except OSError as error:
            logger.warning(f"Catalog lock unavailable: {type(error).__name__}")
            return None
        with self._catalog_locks_lock:
            self._catalog_locks[(key, owner_token)] = lock
        return owner_token

    def _assert_catalog_lock_owned(self, key: str, owner_token: str) -> None:
        with self._catalog_locks_lock:
            lock = self._catalog_locks.get((key, owner_token))
        if lock is None:
            raise RuntimeError("catalog lock is not registered")
        lock.assert_owned()

    def _release_catalog_lock(self, key: str, owner_token: str) -> None:
        with self._catalog_locks_lock:
            lock = self._catalog_locks.pop((key, owner_token), None)
        if lock is not None:
            lock.release()

    def get_or_fetch_catalog(
        self,
        key: str,
        fetcher: Callable[[], Optional[Union[List, Dict]]],
        transform: Optional[Callable[[List], List]] = None,
        wait_timeout: float = 30.0,
        stale_after: float = 300.0,
    ) -> Optional[Union[List, Dict]]:
        cached_data = self._get_catalog_data(key)
        if cached_data is not None:
            return cached_data

        stale_data = self._get_catalog_data(key, allow_expired=True)
        if self._catalog_cooldown_active(key):
            return stale_data

        owner_token = self._acquire_catalog_lock(
            key,
            wait_timeout=0.0 if stale_data is not None else wait_timeout,
            stale_after=stale_after,
        )
        if owner_token is None:
            if stale_data is None:
                logger.warning(f"Timed out waiting for {key} catalog cache")
                return self._get_catalog_data(key)
            return stale_data

        try:
            cached_data = self._get_catalog_data(key)
            if cached_data is not None:
                return cached_data

            if self._catalog_cooldown_active(key):
                return stale_data

            del stale_data
            catalog_data = None
            try:
                catalog_data = fetcher()
                if not isinstance(catalog_data, list):
                    raise ValueError("invalid catalog response")
                if transform is not None:
                    catalog_data = transform(catalog_data)
                if not isinstance(catalog_data, list):
                    raise ValueError("invalid transformed catalog")
                self._assert_catalog_lock_owned(key, owner_token)
                if not self.set(key, catalog_data):
                    raise OSError("catalog cache write failed")
            except Exception as error:
                self._record_catalog_failure(key)
                logger.warning(f"{key} catalog refresh failed: {type(error).__name__}")
                catalog_data = None  # release a partially built catalog
                return self._get_catalog_data(key, allow_expired=True)

            self._clear_catalog_failure(key)
            return catalog_data
        finally:
            self._release_catalog_lock(key, owner_token)

    def get(
        self,
        key: str,
        allow_expired: bool = False,
    ) -> Optional[Union[List, Dict]]:
        file_path = self._get_file_path(key)
        if not os.path.exists(file_path):
            return None

        try:
            if not allow_expired and not self._is_file_fresh(key, file_path):
                return None
            with open(file_path, "r", encoding="utf-8") as cache_handle:
                return json.load(cache_handle)
        except (ValueError, UnicodeError) as error:
            # Do not delete a cache file while another process may replace it.
            # A subsequent fetch will safely replace malformed data atomically.
            logger.warning(f"Invalid cache ignored: {type(error).__name__}")
            return None
        except OSError as error:
            logger.warning(f"Cache read unavailable: {type(error).__name__}")
            return None
        except Exception as error:
            logger.error(f"Cache read failed: {type(error).__name__}")
            return None

    def set(
        self,
        key: str,
        data: Union[List, Dict],
        expected_generation: Optional[str] = None,
    ) -> bool:
        try:
            with FileLock(self._get_write_lock_path()):
                if (
                    expected_generation is not None
                    and self.generation() != expected_generation
                ):
                    logger.info("Discarded cache data fetched before cache clear")
                    return False
                write_atomic(
                    self._get_file_path(key),
                    lambda handle: json.dump(
                        data,
                        handle,
                        ensure_ascii=False,
                        separators=(",", ":"),
                    ),
                    prefix="cache.",
                )
            return True
        except Exception as error:
            logger.error(f"Cache write failed: {type(error).__name__}")
            return False

    def is_valid(self, key: str) -> bool:
        file_path = self._get_file_path(key)
        try:
            return (
                os.path.exists(file_path)
                and os.path.getsize(file_path) > 0
                and self._is_file_fresh(key, file_path)
            )
        except OSError:
            return False

    def acquire_job(self, job_name: str, stale_after: float = 900.0) -> bool:
        """Acquire a cross-process job lock without stealing an active owner's lock."""
        with self._job_locks_guard:
            if job_name in self._job_locks:
                return False
            lock = FileLock(
                self._get_job_lock_path(job_name),
                timeout=0.0,
                stale_after=stale_after,
            )
            try:
                lock.acquire()
            except (OSError, TimeoutError):
                return False
            self._job_locks[job_name] = lock
            return True

    def release_job(self, job_name: str) -> None:
        with self._job_locks_guard:
            lock = self._job_locks.pop(job_name, None)
        if lock is not None:
            lock.release()

    def clear(self, wait_timeout: float = 5.0) -> None:
        deadline = time.monotonic() + max(0.0, wait_timeout)
        owner_tokens = {}

        try:
            for key in sorted(CATALOG_KEYS):
                owner_token = self._acquire_catalog_lock(
                    key,
                    wait_timeout=max(0.0, deadline - time.monotonic()),
                )
                if owner_token is None:
                    raise TimeoutError("cache clear timed out")
                owner_tokens[key] = owner_token

            with FileLock(self._get_write_lock_path()) as write_lock:
                file_paths = glob.glob(os.path.join(self.cache_dir, "*.json"))
                file_paths.extend(
                    self._get_catalog_retry_path(key) for key in CATALOG_KEYS
                )
                failed = False
                for file_path in file_paths:
                    try:
                        os.remove(file_path)
                    except FileNotFoundError:
                        pass
                    except OSError as error:
                        failed = True
                        logger.warning(f"Cache clear failed: {type(error).__name__}")
                write_lock.assert_owned()
                try:
                    write_atomic(
                        self._get_generation_path(),
                        lambda handle: handle.write(uuid.uuid4().hex),
                        encoding="ascii",
                        prefix="generation.",
                    )
                except OSError as error:
                    failed = True
                    logger.warning(f"Cache generation update failed: {type(error).__name__}")
                if failed:
                    raise OSError("cache clear failed")
        finally:
            for key in reversed(sorted(owner_tokens)):
                self._release_catalog_lock(key, owner_tokens[key])
