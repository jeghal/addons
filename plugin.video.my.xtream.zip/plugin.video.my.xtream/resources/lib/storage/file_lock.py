"""Small cross-process file lock with crash recovery and owner heartbeats."""
import ctypes
import json
import os
import threading
import time
import uuid


def _process_is_alive(process_id):
    if not isinstance(process_id, int) or process_id <= 0:
        return False
    if process_id == os.getpid():
        return True
    if os.name == "nt":
        process_query_limited_information = 0x1000
        still_active = 259
        handle = ctypes.windll.kernel32.OpenProcess(
            process_query_limited_information, False, process_id
        )
        if not handle:
            return False
        try:
            exit_code = ctypes.c_ulong()
            if not ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return True
            return exit_code.value == still_active
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    try:
        os.kill(process_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


class FileLock:
    """Exclusive lock represented by a token-owned file.

    The owning process refreshes the file timestamp while it is alive. A
    contender reclaims an expired lock only when the recorded process is no
    longer running (or the lock metadata is malformed).
    """

    def __init__(self, path, timeout=5.0, stale_after=30.0, poll_interval=0.05):
        self.path = path
        self.timeout = max(0.0, float(timeout))
        self.stale_after = max(0.1, float(stale_after))
        self.poll_interval = max(0.01, float(poll_interval))
        self.token = None
        self._heartbeat_stop = None
        self._heartbeat_thread = None

    @staticmethod
    def _read_metadata(path):
        try:
            with open(path, "r", encoding="utf-8") as lock_handle:
                data = json.load(lock_handle)
            return data if isinstance(data, dict) else {}
        except (FileNotFoundError, OSError, ValueError, UnicodeError):
            return {}

    @classmethod
    def token_at(cls, path):
        token = cls._read_metadata(path).get("token")
        return token if isinstance(token, str) and token else None

    def _write_new_lock(self, token):
        descriptor = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as lock_handle:
                json.dump(
                    {"token": token, "pid": os.getpid(), "created_at": time.time()},
                    lock_handle,
                    separators=(",", ":"),
                )
                lock_handle.flush()
                os.fsync(lock_handle.fileno())
        except BaseException:
            try:
                if self.token_at(self.path) in (None, token):
                    os.remove(self.path)
            except OSError:
                pass
            raise

    def _reap_if_abandoned(self):
        try:
            observed = os.stat(self.path)
            if time.time() - observed.st_mtime <= self.stale_after:
                return False
            metadata = self._read_metadata(self.path)
            if _process_is_alive(metadata.get("pid")):
                return False
            current = os.stat(self.path)
            if (
                current.st_mtime_ns != observed.st_mtime_ns
                or current.st_size != observed.st_size
                or self.token_at(self.path) != metadata.get("token")
            ):
                return False
            os.remove(self.path)
            return True
        except FileNotFoundError:
            return True
        except OSError:
            return False

    def _heartbeat(self):
        interval = min(5.0, max(0.05, self.stale_after / 3.0))
        while not self._heartbeat_stop.wait(interval):
            try:
                if self.token_at(self.path) != self.token:
                    return
                os.utime(self.path, None)
            except OSError:
                return

    def acquire(self):
        deadline = time.monotonic() + self.timeout
        while True:
            token = uuid.uuid4().hex
            try:
                self._write_new_lock(token)
                self.token = token
                self._heartbeat_stop = threading.Event()
                self._heartbeat_thread = threading.Thread(
                    target=self._heartbeat,
                    name="xtream-file-lock",
                    daemon=True,
                )
                self._heartbeat_thread.start()
                return token
            except FileExistsError:
                if self._reap_if_abandoned():
                    continue
            except PermissionError:
                if os.name != "nt":
                    raise
            if time.monotonic() >= deadline:
                raise TimeoutError("file lock timeout")
            time.sleep(min(self.poll_interval, max(0.0, deadline - time.monotonic())))

    def assert_owned(self):
        if not self.token or self.token_at(self.path) != self.token:
            raise RuntimeError("file lock ownership lost")

    def release(self):
        if self._heartbeat_stop is not None:
            self._heartbeat_stop.set()
        if self._heartbeat_thread is not None:
            self._heartbeat_thread.join(timeout=1.0)
        try:
            if self.token and self.token_at(self.path) == self.token:
                os.remove(self.path)
        except OSError:
            pass
        finally:
            self.token = None
            self._heartbeat_stop = None
            self._heartbeat_thread = None

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()
