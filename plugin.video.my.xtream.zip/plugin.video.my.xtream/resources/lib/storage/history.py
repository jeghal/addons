import hashlib
import json
import os
import tempfile
import time
from contextlib import contextmanager

from resources.lib.core.constants import EPISODE_RESUME_LIMIT, HISTORY_LIMIT
from resources.lib.domain.text import safe_float
from resources.lib.storage.atomic import write_atomic
from resources.lib.storage.file_lock import FileLock


class HistoryManager:
    """Watch history and resume points, stored in ``history.json``.

    Access is serialised across processes (plugin and service) with an
    owner-token lock file; writes are atomic.
    """

    def __init__(self, profile_path, namespace=None):
        self.profile_path = profile_path
        os.makedirs(self.profile_path, exist_ok=True)
        legacy_history_file = os.path.join(self.profile_path, "history.json")
        if namespace is None:
            self.history_file = legacy_history_file
            self.lock_file = os.path.join(self.profile_path, "history.lock")
        else:
            namespace_hash = hashlib.sha256(
                str(namespace).encode("utf-8")
            ).hexdigest()
            history_dir = os.path.join(self.profile_path, "history")
            os.makedirs(history_dir, exist_ok=True)
            self.history_file = os.path.join(history_dir, f"{namespace_hash}.json")
            self.lock_file = self.history_file + ".lock"
            self._migrate_legacy_history(
                legacy_history_file,
                namespace_hash,
                history_dir,
            )
        self.limit = HISTORY_LIMIT
        self.resume_limit = EPISODE_RESUME_LIMIT

    def _migrate_legacy_history(self, legacy_file, namespace_hash, history_dir):
        if os.path.exists(self.history_file) or not os.path.exists(legacy_file):
            return
        migration_lock = os.path.join(history_dir, ".migration.lock")
        owner_file = os.path.join(history_dir, ".legacy_owner")
        try:
            with FileLock(migration_lock):
                if os.path.exists(self.history_file):
                    return
                try:
                    with open(owner_file, "r", encoding="ascii") as owner_handle:
                        migration_owner = owner_handle.read().strip()
                except (OSError, UnicodeError):
                    migration_owner = ""
                if not migration_owner:
                    write_atomic(
                        owner_file,
                        lambda handle: handle.write(namespace_hash),
                        encoding="ascii",
                        prefix="history-owner.",
                    )
                    migration_owner = namespace_hash
                if migration_owner != namespace_hash:
                    return
                legacy_lock_file = os.path.join(self.profile_path, "history.lock")
                with FileLock(legacy_lock_file):
                    if not os.path.exists(legacy_file):
                        return
                    with open(legacy_file, "r", encoding="utf-8") as legacy_handle:
                        legacy_data = legacy_handle.read()
                    write_atomic(
                        self.history_file,
                        lambda handle: handle.write(legacy_data),
                        prefix="history-migration.",
                    )
        except (OSError, TimeoutError):
            return

    @staticmethod
    def _empty_history():
        return {"vod": [], "series": [], "episode_resume": {}}

    @contextmanager
    def _locked(self, timeout=5.0, stale_after=30.0):
        with FileLock(
            self.lock_file,
            timeout=timeout,
            stale_after=stale_after,
        ) as lock:
            yield lock.token

    def _read_lock_token(self):
        return FileLock.token_at(self.lock_file)

    def _assert_lock_owned(self, owner_token):
        if not owner_token or self._read_lock_token() != owner_token:
            raise RuntimeError("history lock ownership lost")

    def _normalize_resume_points(self, value):
        if not isinstance(value, dict):
            return {}
        valid = [
            (str(media_id), position)
            for media_id, position in value.items()
            if safe_float(position) > 0
        ]
        return dict(valid[-self.resume_limit:])

    def _touch_resume_point(self, resume_points, media_id, position):
        media_id = str(media_id)
        resume_points.pop(media_id, None)
        if safe_float(position) > 0:
            resume_points[media_id] = position
        while len(resume_points) > self.resume_limit:
            del resume_points[next(iter(resume_points))]

    def _preserve_corrupted_file(self, owner_token):
        if not os.path.exists(self.history_file):
            return
        self._assert_lock_owned(owner_token)
        suffix = f"{time.time_ns()}"
        backup_path = f"{self.history_file}.corrupt.{suffix}.json"
        os.replace(self.history_file, backup_path)

    def _load_unlocked(self, owner_token):
        if not os.path.exists(self.history_file):
            return self._empty_history()

        try:
            with open(self.history_file, "r", encoding="utf-8") as history_handle:
                history = json.load(history_handle)
            if not isinstance(history, dict):
                raise ValueError("history root must be an object")
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
            self._preserve_corrupted_file(owner_token)
            return self._empty_history()

        normalized = dict(history)
        for media_type in ("vod", "series"):
            entries = normalized.get(media_type)
            normalized[media_type] = (
                [entry for entry in entries if isinstance(entry, dict)]
                if isinstance(entries, list)
                else []
            )
        normalized["episode_resume"] = self._normalize_resume_points(
            normalized.get("episode_resume")
        )
        return normalized

    def _save_unlocked(self, history, owner_token):
        self._assert_lock_owned(owner_token)
        descriptor, temporary_path = tempfile.mkstemp(
            prefix="history.",
            suffix=".tmp",
            dir=self.profile_path,
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as history_handle:
                json.dump(history, history_handle, ensure_ascii=False, indent=2)
                history_handle.flush()
                os.fsync(history_handle.fileno())
            self._assert_lock_owned(owner_token)
            os.replace(temporary_path, self.history_file)
        except Exception:
            try:
                os.remove(temporary_path)
            except FileNotFoundError:
                pass
            raise

    def load_history(self):
        with self._locked() as owner_token:
            return self._load_unlocked(owner_token)

    def save_history(self, history):
        with self._locked() as owner_token:
            self._save_unlocked(history, owner_token)

    def add_item(self, media_type, item_data, group_id=None):
        with self._locked() as owner_token:
            history = self._load_unlocked(owner_token)
            target_list = history.get(media_type, [])

            current_id = str(item_data.get("id"))
            key_id = str(group_id) if group_id else current_id

            # Keep the existing one-entry-per-series display behavior, but store
            # per-episode resume positions independently from that display list.
            resume_points = history.setdefault("episode_resume", {})
            existing_resume = resume_points.get(current_id, 0) if media_type == "series" else 0
            new_list = []
            for item in target_list:
                if not isinstance(item, dict):
                    continue
                item_group = item.get("group_id")
                item_id = str(item.get("id"))
                existing_key = str(item_group) if item_group else item_id

                if existing_key == key_id:
                    if item_id == current_id:
                        existing_resume = item.get("resume_time", 0) if media_type != "series" else existing_resume
                    elif media_type == "series":
                        # Migrate resume points from the legacy display entries.
                        old_resume = item.get("resume_time", 0)
                        if old_resume and item_id not in resume_points:
                            self._touch_resume_point(resume_points, item_id, old_resume)
                else:
                    new_list.append(item)

            if media_type == "series":
                # Older installations kept resume_time on the visible entry.
                for old_item in target_list:
                    if isinstance(old_item, dict) and str(old_item.get("id")) == current_id:
                        if current_id not in resume_points:
                            existing_resume = old_item.get("resume_time", 0)
                        break
            if existing_resume > 0:
                item_data["resume_time"] = existing_resume
            if group_id:
                item_data["group_id"] = group_id

            new_list.insert(0, item_data)
            history[media_type] = new_list[: self.limit]
            self._save_unlocked(history, owner_token)

    def get_list(self, media_type):
        return self.load_history().get(media_type, [])

    def update_resume_time(self, media_type, media_id, time_sec):
        with self._locked() as owner_token:
            history = self._load_unlocked(owner_token)
            items = history.get(media_type, [])
            if media_type == "series":
                self._touch_resume_point(
                    history.setdefault("episode_resume", {}), media_id, time_sec
                )
            changed = media_type == "series"
            for item in items:
                if isinstance(item, dict) and str(item.get("id")) == str(media_id):
                    item["resume_time"] = time_sec
                    changed = True
                    break
            if changed:
                self._save_unlocked(history, owner_token)

    def clear_history(self, media_type):
        with self._locked() as owner_token:
            history = self._load_unlocked(owner_token)
            history[media_type] = []
            if media_type == "series":
                history["episode_resume"] = {}
            self._save_unlocked(history, owner_token)

    def remove_item(self, media_type, item_id):
        with self._locked() as owner_token:
            history = self._load_unlocked(owner_token)
            items = history.get(media_type, [])
            new_items = [
                item
                for item in items
                if isinstance(item, dict) and str(item.get("id")) != str(item_id)
            ]
            changed = len(new_items) != len(items)
            if media_type == "series":
                resume_points = history.setdefault("episode_resume", {})
                if str(item_id) in resume_points:
                    del resume_points[str(item_id)]
                    changed = True
            if changed:
                history[media_type] = new_items
                self._save_unlocked(history, owner_token)
