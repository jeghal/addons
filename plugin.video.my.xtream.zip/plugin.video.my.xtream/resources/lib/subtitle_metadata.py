"""Normalize Xtream identifiers for Kodi subtitle discovery (offline, no API calls)."""
import re


def identifiers(*sources):
    result = {}
    for source in sources:
        if not isinstance(source, dict):
            continue
        for key in ('imdb_id', 'imdb', 'imdbID'):
            value = str(source.get(key) or '').strip()
            if re.fullmatch(r'tt\d{5,12}', value, re.I):
                result.setdefault('imdb', value.lower())
        for key in ('tmdb_id', 'tmdb'):
            value = str(source.get(key) or '').strip()
            if value.isdigit() and int(value) > 0:
                result.setdefault('tmdb', str(int(value)))
    return result


def enrich(info_tag, *sources):
    ids = identifiers(*sources)
    if ids:
        existing = info_tag.get('uniqueid')
        merged = dict(existing) if isinstance(existing, dict) else {}
        merged.update(ids)
        info_tag['uniqueid'] = merged
    return info_tag
