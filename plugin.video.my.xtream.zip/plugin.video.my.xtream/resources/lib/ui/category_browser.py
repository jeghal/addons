"""Shared two-level category browser used by live, movies and series."""
import os

import xbmcplugin

from resources.lib.core.constants import DEFAULT_FOLDER_ICON
from resources.lib.core.urls import build_url
from resources.lib.domain.category_groups import CATEGORY_GROUPS, IMG_PREFIX
from resources.lib.domain.category_rules import group_categories
from resources.lib.ui.listitem import create_list_item

ORPHAN_SEPARATOR_LABEL = "[B]--- Autres ---[/B]"


def group_icon(label, img_dir):
    """Icon of the first configured group with this label."""
    for rule in CATEGORY_GROUPS:
        if rule["label"] == label:
            icon = rule.get("icon", DEFAULT_FOLDER_ICON)
            if icon.startswith(IMG_PREFIX):
                return os.path.join(img_dir, icon[len(IMG_PREFIX):])
            return icon
    return DEFAULT_FOLDER_ICON


def group_for(categories, content_type):
    return group_categories(categories, content_type, CATEGORY_GROUPS)


def _add_category(handle, category, leaf_mode):
    item = create_list_item(label=category.get("category_name", "Sans catégorie"))
    url = build_url({"mode": leaf_mode, "category_id": category.get("category_id")})
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=item, isFolder=True)


def render_groups(ctx, groups, orphans, group_id, browse_mode, leaf_mode):
    """Render group folders (root) or the categories of one group.

    Root shows each group as a folder followed by uncategorised entries;
    selecting a group lists only its categories.
    """
    handle = ctx.handle
    if group_id:
        for category in groups.get(group_id, []):
            _add_category(handle, category, leaf_mode)
        return

    for label, categories in groups.items():
        display_label = {"SPORT": "Sports", "English / US / UK": "Anglais — US, UK", "Portugal / Bresil": "Portugal — Brésil", "Special Ramadan": "Spécial Ramadan"}.get(label, label)
        count = len(categories)
        item = create_list_item(
            label="{} ({})".format(display_label, count),
            icon=group_icon(label, ctx.img_dir),
            properties={"MySkinGroupName": display_label, "MySkinCategoryCount": str(count),
                        "MySkinCategoryCountLabel": "{} {}".format(count, "catégorie" if count == 1 else "catégories")},
        )
        url = build_url({"mode": browse_mode, "group_id": label})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=item, isFolder=True)

    if orphans:
        separator = create_list_item(label=ORPHAN_SEPARATOR_LABEL, icon="DefaultSeparator.png")
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=separator, isFolder=False)
        for category in orphans:
            _add_category(handle, category, leaf_mode)


def add_root_shortcut(handle, label, icon, mode):
    """Highlighted shortcut shown above the groups (search, recent, history)."""
    item = create_list_item(label="[B][COLOR red]{}[/COLOR][/B]".format(label), icon=icon)
    xbmcplugin.addDirectoryItem(handle=handle, url=build_url({"mode": mode}), listitem=item, isFolder=True)
