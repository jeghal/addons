"""View decorators."""
from functools import wraps

import xbmc
import xbmcplugin

from resources.lib.core import logger


def add_sort_methods(handle, content_type="movies"):
    """Register native Kodi sort methods on a directory listing."""
    if not hasattr(xbmcplugin, "addSortMethod"):
        return

    # Categories in precedence order. First added is the default active sort in Kodi.
    if content_type in ("movies", "tvshows"):
        method_groups = (
            ("SORT_METHOD_UNSORTED", "SORT_METHOD_NONE"),
            ("SORT_METHOD_LABEL", "SORT_METHOD_LABEL_IGNORE_THE", "SORT_METHOD_TITLE"),
            ("SORT_METHOD_VIDEO_YEAR", "SORT_METHOD_YEAR"),
            ("SORT_METHOD_VIDEO_RATING",),
            ("SORT_METHOD_DATEADDED",),
            ("SORT_METHOD_DURATION",),
        )
    elif content_type in ("videos", "channels"):
        method_groups = (
            ("SORT_METHOD_UNSORTED", "SORT_METHOD_NONE"),
            ("SORT_METHOD_LABEL", "SORT_METHOD_LABEL_IGNORE_THE"),
        )
    else:
        method_groups = (
            ("SORT_METHOD_UNSORTED", "SORT_METHOD_NONE"),
            ("SORT_METHOD_LABEL",),
        )

    for candidates in method_groups:
        for name in candidates:
            method = getattr(xbmcplugin, name, None)
            if method is not None:
                try:
                    xbmcplugin.addSortMethod(handle, method)
                    break
                except Exception:
                    pass


def directory_listing(view):
    """Wrap ``view(ctx, params)`` so a failure never leaves Kodi hanging.

    The broad ``except`` is deliberate: this is the outermost boundary of a
    directory request, where the only safe outcome is to log the error type
    and always close the directory.
    """
    @wraps(view)
    def wrapper(ctx, params):
        try:
            return view(ctx, params)
        except Exception as error:
            logger.log_exception("Directory {} failed".format(view.__name__), error, xbmc.LOGERROR)
            return None
        finally:
            xbmcplugin.endOfDirectory(ctx.handle)

    return wrapper
