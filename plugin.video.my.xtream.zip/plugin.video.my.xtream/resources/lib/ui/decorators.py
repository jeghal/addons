"""View decorators."""
from functools import wraps

import xbmc
import xbmcplugin

from resources.lib.core import logger


def directory_listing(view):
    """Wrap ``view(ctx, params)`` so a failure never leaves Kodi hanging.

    The broad ``except`` is deliberate: this is the outermost boundary of a
    directory request, where the only safe outcome is to log the error type
    and always close the directory.
    """
    @wraps(view)
    def wrapper(ctx, params):
        try:
            return view(ctx, params)
        except Exception as error:
            logger.log_exception("Directory {} failed".format(view.__name__), error, xbmc.LOGERROR)
            return None
        finally:
            xbmcplugin.endOfDirectory(ctx.handle)

    return wrapper
