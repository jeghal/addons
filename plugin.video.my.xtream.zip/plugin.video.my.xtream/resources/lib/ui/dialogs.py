"""Thin wrappers around Kodi dialogs."""
from contextlib import contextmanager

import xbmc
import xbmcgui


def notify(heading, message, icon=xbmcgui.NOTIFICATION_INFO, time_ms=5000):
    xbmcgui.Dialog().notification(heading, message, icon, time_ms)


def confirm(heading, message):
    return xbmcgui.Dialog().yesno(heading, message)


def ask_text(prompt):
    """Show the on-screen keyboard; returns the text or None when cancelled."""
    keyboard = xbmc.Keyboard("", prompt)
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else None


@contextmanager
def progress(heading, message):
    """Progress dialog that is always closed, even when the body raises."""
    dialog = xbmcgui.DialogProgress()
    dialog.create(heading, message)
    try:
        yield dialog
    finally:
        dialog.close()
