"""Kodi ``ListItem`` factory using the modern InfoTagVideo API."""
import xbmc
import xbmcgui

from resources.lib.core import logger

# Keys the legacy ``setInfo`` call cannot accept.
_LEGACY_UNSUPPORTED = frozenset((
    "tmdb_id", "code", "height", "width", "video_codec", "aspect",
    "audio_channels", "audio_codec", "duration_secs", "cast", "uniqueid",
))


def _set_art(item, icon, thumb, poster, fanart):
    art = {}
    if icon:
        art["icon"] = icon
    if thumb:
        art["thumb"] = thumb
    if poster:
        art["poster"] = poster
    if fanart:
        art["fanart"] = fanart
    if icon and "thumb" not in art:
        art["thumb"] = icon
    if thumb and "icon" not in art:
        art["icon"] = thumb
    item.setArt(art)


def _set_number(setter, value, cast):
    try:
        setter(cast(value))
    except (ValueError, TypeError):
        pass


def _as_list(value, split=False):
    if isinstance(value, str):
        return value.split(",") if split else [value]
    return value if isinstance(value, list) else None


def _fill_video_tag(tag, info):
    def present(key):
        return key in info and info[key]

    for key, setter in (
        ("title", tag.setTitle),
        ("originaltitle", tag.setOriginalTitle),
        ("plot", tag.setPlot),
        ("mediatype", tag.setMediaType),
        ("premiered", tag.setPremiered),
        ("dateadded", tag.setDateAdded),
        ("trailer", tag.setTrailer),
        ("tvshowtitle", tag.setTvShowTitle),
    ):
        if present(key):
            setter(str(info[key]))

    if present("genre"):
        genres = _as_list(info["genre"], split=True)
        if genres is not None:
            tag.setGenres(genres)
    if present("director"):
        directors = _as_list(info["director"])
        if directors is not None:
            tag.setDirectors(directors)

    for key, setter, cast in (
        ("year", tag.setYear, int),
        ("rating", tag.setRating, float),
        ("duration", tag.setDuration, int),
        ("season", tag.setSeason, int),
        ("episode", tag.setEpisode, int),
    ):
        if present(key):
            _set_number(setter, info[key], cast)

    if isinstance(info.get("cast"), list):
        actors = []
        for name in info["cast"]:
            if isinstance(name, str) and name.strip():
                try:
                    actors.append(xbmc.Actor(name.strip()))
                except (TypeError, ValueError, RuntimeError):
                    pass
        if actors:
            tag.setCast(actors)

    if isinstance(info.get("uniqueid"), dict):
        tag.setUniqueIDs(info["uniqueid"])


def _set_video_info(item, video_info):
    try:
        _fill_video_tag(item.getVideoInfoTag(), video_info)
    except Exception as error:
        # Kodi 19 or an unexpected value: fall back to the legacy API.
        logger.log_exception("InfoTagVideo failed, using setInfo fallback", error)
        safe_info = {
            key: value for key, value in video_info.items()
            if key not in _LEGACY_UNSUPPORTED and isinstance(value, (str, int, float, bool))
        }
        if safe_info:
            item.setInfo("video", safe_info)


def create_list_item(label, icon=None, thumb=None, poster=None, fanart=None,
                     info=None, properties=None, path=None, is_folder=False):
    """Build a ``ListItem``.

    ``info`` is either ``{"video": {...}}`` or the bare video-info dict.
    """
    item = xbmcgui.ListItem(label=label)
    _set_art(item, icon, thumb, poster, fanart)

    if info:
        video_info = info["video"] if isinstance(info.get("video"), dict) else info
        if video_info:
            _set_video_info(item, video_info)

    for key, value in (properties or {}).items():
        item.setProperty(key, str(value))
    if path:
        item.setPath(path)
    return item
