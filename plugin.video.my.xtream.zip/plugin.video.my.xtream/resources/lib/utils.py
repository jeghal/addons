from urllib.parse import urlencode
import urllib.request
import urllib.parse
import json
import xbmc
import xbmcaddon
import xbmcvfs
import os
from typing import Dict, Optional

def build_url(query):
    return "plugin://plugin.video.my.xtream/?" + urlencode(query)

def parse_duration(duration_str):
    if not duration_str:
        return 0
    try:
        # Format HH:MM:SS
        if str(duration_str).isdigit():
            return int(duration_str) # Assume seconds if raw number
        
        # Handle string "XX min" or "HH:MM:SS"
        duration_str = str(duration_str).strip()
        if duration_str.isdigit():
             return int(duration_str)
             
        if ':' in duration_str:
            parts = list(map(int, duration_str.split(':')))
            if len(parts) == 3: return parts[0]*3600 + parts[1]*60 + parts[2]
            if len(parts) == 2: return parts[0]*60 + parts[1]
        elif 'min' in duration_str.lower():
            # "120 min"
            val = ''.join(filter(str.isdigit, duration_str))
            return int(val) * 60 if val else 0
    except:
        return 0
    return 0

# Persistent Cache Configuration
_translation_cache: Dict[str, str] = {}
MAX_CACHE_SIZE = 1000
CACHE_FILE = "translation_cache.json"
_cache_loaded = False

def _get_cache_file_path():
    try:
        addon = xbmcaddon.Addon()
        profile_path = xbmc.translatePath(addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdir(profile_path)
        return os.path.join(profile_path, CACHE_FILE)
    except:
        return ""

def _load_cache():
    global _translation_cache, _cache_loaded
    if _cache_loaded: return
    
    file_path = _get_cache_file_path()
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                _translation_cache = json.load(f)
        except:
            _translation_cache = {}
    _cache_loaded = True

def _save_cache():
    file_path = _get_cache_file_path()
    if file_path:
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(_translation_cache, f, ensure_ascii=False)
        except:
            pass

def translate_to_arabic(text: str) -> Optional[str]:
    """
    Traduit un texte en arabe en utilisant l'API Google Translate non officielle.
    Cache persistant sur disque (Max 1000 items).
    """
    if not text or not text.strip():
        return text
    
    # Ensure cache is loaded
    _load_cache()
    
    # 1. Check Cache
    if text in _translation_cache:
        return _translation_cache[text]
    
    # 2. Check Settings
    try:
        addon = xbmcaddon.Addon()
        if addon.getSetting('enable_arabic_translation') == 'false':
            return None
    except Exception:
        pass 
    
    # 3. Perform Translation
    try:
        # Limit text length
        text_to_translate = text[:5000]
        
        base_url = "https://translate.googleapis.com/translate_a/single"
        params = urllib.parse.urlencode({
            'client': 'gtx',
            'sl': 'auto', 
            'tl': 'ar',   
            'dt': 't',    
            'q': text_to_translate
        })
        
        req = urllib.request.Request(
            f"{base_url}?{params}", 
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode('utf-8'))
            
        # Parse Result
        if data and isinstance(data, list) and len(data) > 0:
            segments = data[0]
            if segments:
                translated_text = ''.join([seg[0] for seg in segments if seg and seg[0]])
                
                # Update Cache
                if len(_translation_cache) >= MAX_CACHE_SIZE:
                    # Remove the first inserted item (FIFO mostly since dicts are ordered in Python 3.7+)
                    # Note: iter(dict) gives keys in insertion order.
                    try:
                        oldest_key = next(iter(_translation_cache))
                        del _translation_cache[oldest_key]
                    except:
                        _translation_cache.clear() # Fallback safety
                        
                _translation_cache[text] = translated_text
                _save_cache()
                
                return translated_text
                
        return text

    except Exception as e:
        xbmc.log(f"[Xtream Codes] Translation error: {e}", xbmc.LOGWARNING)
        return text

