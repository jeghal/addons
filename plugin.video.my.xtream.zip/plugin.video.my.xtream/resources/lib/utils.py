from urllib.parse import urlencode
import urllib.request
import urllib.parse
import json
import xbmc
import xbmcaddon
import xbmcvfs
import os
import math
import tempfile
import threading
import time
from typing import Dict, Optional

def get_safe_image(url, default):
    """
    Retourne l'URL de l'image si valide, sinon retourne l'image par défaut.
    Gère les URLs vides, nulles, ou invalides.
    """
    if not url or url == "" or url == "null":
        return default
    # Vérifier si l'URL commence par http (basique mais efficace)
    if not str(url).startswith("http"):
        return default
    return url


def safe_text(value, default=""):
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return default
    text = str(value).strip()
    if not text or text.lower() == "null":
        return default
    return text


def safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def safe_float(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default

def sort_vod(data):
    try:
        if isinstance(data, list):
            data.sort(
                key=lambda x: int(x.get("added")) if x.get("added") and str(x.get("added")).isdigit() else 0,
                reverse=True,
            )
            return data
        return sorted(
            data,
            key=lambda x: int(x.get("added")) if x.get("added") and str(x.get("added")).isdigit() else 0,
            reverse=True,
        )
    except:
        return data

def sort_series(data):
    try:
        if isinstance(data, list):
            data.sort(
                key=lambda x: int(x.get("last_modified") or x.get("series_id")) if str(x.get("last_modified") or x.get("series_id")).isdigit() else 0,
                reverse=True,
            )
            return data
        return sorted(
            data,
            key=lambda x: int(x.get("last_modified") or x.get("series_id")) if str(x.get("last_modified") or x.get("series_id")).isdigit() else 0,
            reverse=True,
        )
    except:
        return data

def build_url(query):
    return "plugin://plugin.video.my.xtream/?" + urlencode(query)

def parse_duration(duration_str):
    if not duration_str:
        return 0
    try:
        # Format HH:MM:SS
        if str(duration_str).isdigit():
            return int(duration_str) # Assume seconds if raw number
        
        # Handle string "XX min" or "HH:MM:SS"
        duration_str = str(duration_str).strip()
        if duration_str.isdigit():
             return int(duration_str)
             
        if ':' in duration_str:
            parts = list(map(int, duration_str.split(':')))
            if len(parts) == 3: return parts[0]*3600 + parts[1]*60 + parts[2]
            if len(parts) == 2: return parts[0]*60 + parts[1]
        elif 'min' in duration_str.lower():
            # "120 min"
            val = ''.join(filter(str.isdigit, duration_str))
            return int(val) * 60 if val else 0
    except:
        return 0
    return 0

# Persistent Cache Configuration
_translation_cache: Dict[str, str] = {}
_translation_failures: Dict[str, float] = {}
_translation_lock = threading.RLock()
MAX_CACHE_SIZE = 1000
CACHE_FILE = "translation_cache.json"
TRANSLATION_TIMEOUT = 5
FAILURE_RETRY_SECONDS = 300
_cache_loaded = False

def _get_cache_file_path():
    try:
        addon = xbmcaddon.Addon()
        profile_path = xbmc.translatePath(addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdir(profile_path)
        return os.path.join(profile_path, CACHE_FILE)
    except:
        return ""

def _load_cache():
    global _translation_cache, _cache_loaded
    with _translation_lock:
        if _cache_loaded:
            return

        file_path = _get_cache_file_path()
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as cache_handle:
                    loaded_cache = json.load(cache_handle)
                if isinstance(loaded_cache, dict):
                    _translation_cache = loaded_cache
            except (OSError, json.JSONDecodeError, UnicodeDecodeError):
                _translation_cache = {}
        _cache_loaded = True

def _save_cache():
    file_path = _get_cache_file_path()
    if file_path:
        descriptor = None
        temporary_path = None
        try:
            descriptor, temporary_path = tempfile.mkstemp(
                prefix="translation.",
                suffix=".tmp",
                dir=os.path.dirname(file_path),
            )
            with os.fdopen(descriptor, 'w', encoding='utf-8') as cache_handle:
                descriptor = None
                json.dump(_translation_cache, cache_handle, ensure_ascii=False)
                cache_handle.flush()
                os.fsync(cache_handle.fileno())
            os.replace(temporary_path, file_path)
        except OSError:
            if descriptor is not None:
                os.close(descriptor)
            if temporary_path:
                try:
                    os.remove(temporary_path)
                except FileNotFoundError:
                    pass

def translate_to_arabic(text: str) -> Optional[str]:
    """
    Traduit un texte en arabe en utilisant l'API Google Translate non officielle.
    Cache persistant sur disque (Max 1000 items).
    """
    if not isinstance(text, str) or not text.strip():
        return text

    try:
        addon = xbmcaddon.Addon()
        if addon.getSetting('enable_arabic_translation') == 'false':
            return None
    except Exception:
        pass

    _load_cache()
    with _translation_lock:
        if text in _translation_cache:
            return _translation_cache[text]
        last_failure = _translation_failures.get(text)
        if last_failure and time.monotonic() - last_failure < FAILURE_RETRY_SECONDS:
            return text

    try:
        text_to_translate = text[:5000]

        base_url = "https://translate.googleapis.com/translate_a/single"
        params = urllib.parse.urlencode({
            'client': 'gtx',
            'sl': 'auto', 
            'tl': 'ar',   
            'dt': 't',    
            'q': text_to_translate
        })
        
        req = urllib.request.Request(
            f"{base_url}?{params}", 
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        
        with urllib.request.urlopen(req, timeout=TRANSLATION_TIMEOUT) as response:
            data = json.loads(response.read().decode('utf-8'))

        if data and isinstance(data, list) and len(data) > 0:
            segments = data[0]
            translated_text = ""
            if isinstance(segments, list):
                translated_text = ''.join(
                    segment[0]
                    for segment in segments
                    if isinstance(segment, list)
                    and segment
                    and isinstance(segment[0], str)
                )

            if translated_text:
                with _translation_lock:
                    _translation_failures.pop(text, None)
                if len(_translation_cache) >= MAX_CACHE_SIZE:
                    try:
                        oldest_key = next(iter(_translation_cache))
                        del _translation_cache[oldest_key]
                    except (StopIteration, RuntimeError):
                        _translation_cache.clear()

                _translation_cache[text] = translated_text
                _save_cache()
                return translated_text

        return text

    except Exception as error:
        with _translation_lock:
            _translation_failures[text] = time.monotonic()
        xbmc.log(
            f"[Xtream Codes] Translation failed: {type(error).__name__}",
            xbmc.LOGWARNING,
        )
        return text

