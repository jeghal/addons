from urllib.parse import urlencode
import urllib.request
import urllib.parse
import json
import xbmc
import xbmcaddon
from typing import Dict, Optional

def build_url(query):
    return "plugin://plugin.video.my.xtream/?" + urlencode(query)

def parse_duration(duration_str):
    if not duration_str:
        return 0
    try:
        # Format HH:MM:SS
        if str(duration_str).isdigit():
            return int(duration_str) # Assume seconds if raw number
        
        # Handle string "XX min" or "HH:MM:SS"
        duration_str = str(duration_str).strip()
        if duration_str.isdigit():
             return int(duration_str)
             
        if ':' in duration_str:
            parts = list(map(int, duration_str.split(':')))
            if len(parts) == 3: return parts[0]*3600 + parts[1]*60 + parts[2]
            if len(parts) == 2: return parts[0]*60 + parts[1]
        elif 'min' in duration_str.lower():
            # "120 min"
            val = ''.join(filter(str.isdigit, duration_str))
            return int(val) * 60 if val else 0
    except:
        return 0
    return 0

# Simple in-memory cache to avoid repeated requests in the same session
# Dictionary mapping: original_text -> translated_text
_translation_cache: Dict[str, str] = {}
MAX_CACHE_SIZE = 500

def translate_to_arabic(text: str) -> Optional[str]:
    """
    Traduit un texte en arabe en utilisant l'API Google Translate non officielle.
    
    Args:
        text: Texte à traduire
        
    Returns:
        Texte traduit en arabe ou None/Original en cas d'erreur
    """
    if not text or not text.strip():
        return text
    
    # 1. Check Cache
    if text in _translation_cache:
        return _translation_cache[text]
    
    # 2. Check Settings
    try:
        addon = xbmcaddon.Addon()
        if addon.getSetting('enable_arabic_translation') == 'false':
            return None
    except Exception:
        pass # Default to enabled if setting fails
    
    # 3. Perform Translation
    try:
        # Limit text length
        text_to_translate = text[:5000]
        
        base_url = "https://translate.googleapis.com/translate_a/single"
        params = urllib.parse.urlencode({
            'client': 'gtx',
            'sl': 'auto',  # Auto-detect source
            'tl': 'ar',    # Target Arabic
            'dt': 't',     # Return translation
            'q': text_to_translate
        })
        
        req = urllib.request.Request(
            f"{base_url}?{params}", 
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        
        # Log (truncated)
        # xbmc.log(f"[Xtream Codes] Translating... {text_to_translate[:30]}", xbmc.LOGDEBUG)
        
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode('utf-8'))
            
        # Parse Result
        if data and isinstance(data, list) and len(data) > 0:
            # Result[0] contains list of [translated, original] segments
            segments = data[0]
            if segments:
                translated_text = ''.join([seg[0] for seg in segments if seg and seg[0]])
                
                # Update Cache
                if len(_translation_cache) > MAX_CACHE_SIZE:
                    _translation_cache.clear()
                _translation_cache[text] = translated_text
                
                return translated_text
                
        return text

    except Exception as e:
        xbmc.log(f"[Xtream Codes] Translation error: {e}", xbmc.LOGWARNING)
        return text

