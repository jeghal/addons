"""Subscription information screen."""
import datetime

import xbmcgui
import xbmcplugin

from resources.lib.core.constants import Mode
from resources.lib.routing import route
from resources.lib.ui.decorators import directory_listing
from resources.lib.ui.dialogs import notify
from resources.lib.ui.listitem import create_list_item

_STATUS_LABELS = {
    "active": ("Actif", "green"),
    "expired": ("Expiré", "red"),
    "disabled": ("Désactivé", "red"),
    "banned": ("Bloqué", "red"),
    "inactive": ("Inactif", None),
}
_STATUS_DESCRIPTIONS = {
    "active": "Votre abonnement est actif.",
    "expired": "Votre abonnement a expiré.",
    "disabled": "Votre abonnement est désactivé.",
    "banned": "Votre abonnement est bloqué.",
    "inactive": "Votre abonnement est inactif.",
}
_UNKNOWN_STATUS_DESCRIPTION = "Le statut de votre abonnement n'est pas disponible."
_CALENDAR_ICON = "osd/fullscreen/buttons/calendar.png"


def format_timestamp(timestamp):
    if not timestamp:
        return "N/A"
    if str(timestamp).isdigit():
        try:
            return datetime.datetime.fromtimestamp(int(timestamp)).strftime("%d/%m/%Y")
        except (OverflowError, OSError, ValueError):
            pass
    return str(timestamp)


def format_status(value):
    """Return ``(display_label, normalized_key)`` for a provider status."""
    if not isinstance(value, (str, int, float, bool)):
        value = "Inconnu"
    status = str(value or "Inconnu")
    normalized = status.strip().lower()
    label, color = _STATUS_LABELS.get(normalized, (status, None))
    if color:
        label = "[COLOR {}]{}[/COLOR]".format(color, label)
    return label, normalized


def mask_username(value):
    """Hide all but the last four characters of the username."""
    if value is None or str(value).strip() == "":
        return "Non renseigné"
    username = str(value)
    return "****" if len(username) <= 4 else "****{}".format(username[-4:])


def format_connection_count(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return "N/A"


def build_account_rows(user_info, server_info):
    """Return ``[(label, icon, plot), ...]`` describing the subscription."""
    status_label, status_key = format_status(user_info.get("status", "Inconnu"))
    description = _STATUS_DESCRIPTIONS.get(status_key, _UNKNOWN_STATUS_DESCRIPTION)
    if user_info.get("is_trial") == "1":
        status_label += " (essai)"
        description += " Il s'agit d'un abonnement d'essai."

    active = format_connection_count(user_info.get("active_cons", "0"))
    maximum = format_connection_count(user_info.get("max_connections", "1"))
    server_label = "Configuré" if server_info.get("url") else "Non renseigné"
    server_details = "Protocole : {}\nPort : {}\nHeure du serveur : {}".format(
        server_info.get("server_protocol", "N/A"),
        server_info.get("port", "N/A"),
        server_info.get("time_now", "N/A"),
    )
    return [
        ("Statut de l'abonnement : {}".format(status_label),
         "icons/addonstatus/enabled-normal.png", description),
        ("Date d'expiration : {}".format(format_timestamp(user_info.get("exp_date"))),
         _CALENDAR_ICON, "Date de fin de l'abonnement."),
        ("Connexions actives / maximales : {} / {}".format(active, maximum),
         "DefaultNetwork.png", "Nombre de connexions utilisées et autorisées."),
        ("Serveur : {}".format(server_label), "DefaultAddonService.png", server_details),
        ("Nom d'utilisateur : {}".format(mask_username(user_info.get("username"))),
         "DefaultUser.png", "Le nom d'utilisateur est masqué pour protéger vos informations."),
        ("Date de création : {}".format(format_timestamp(user_info.get("created_at"))),
         _CALENDAR_ICON, "Date de création du compte."),
    ]


@route(Mode.ACCOUNT_INFO)
@directory_listing
def account_info(ctx, params):
    xbmcplugin.setPluginCategory(ctx.handle, "Mon abonnement")

    data = ctx.client.get_general_info()
    if not isinstance(data, dict) or not data:
        notify("Erreur", "Impossible de récupérer les informations du compte", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    user_info = data.get("user_info", {})
    server_info = data.get("server_info", {})
    user_info = user_info if isinstance(user_info, dict) else {}
    server_info = server_info if isinstance(server_info, dict) else {}

    for label, icon, plot in build_account_rows(user_info, server_info):
        item = create_list_item(label=label, icon=icon, thumb=icon, info={"video": {"plot": plot}})
        xbmcplugin.addDirectoryItem(handle=ctx.handle, url="", listitem=item, isFolder=False)
