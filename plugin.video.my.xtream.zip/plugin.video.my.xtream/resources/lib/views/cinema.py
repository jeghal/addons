"""TMDb cinema guide: browse, search and jump to the Xtream library."""
from datetime import date
import difflib
import unicodedata

import xbmcgui
import xbmcplugin

from resources.lib.api.tmdb_client import GENRE_IDS, TmdbError
from resources.lib.core.constants import Mode
from resources.lib.core.urls import build_url
from resources.lib.routing import route
from resources.lib.ui.decorators import directory_listing
from resources.lib.ui.listitem import create_list_item


ERROR_MESSAGES = {
    "missing_token": "أضف TMDb Read Access Token من إعدادات الإضافة.",
    "unauthorized": "رمز TMDb غير صالح أو لا يملك الصلاحية المطلوبة.",
    "not_found": "قائمة TMDb المطلوبة غير موجودة.",
    "rate_limited": "تم بلوغ حد طلبات TMDb. حاول لاحقًا.",
    "server_error": "خدمة TMDb غير متاحة مؤقتًا.",
    "timeout": "انتهت مهلة الاتصال بخدمة TMDb.",
    "network_error": "تعذر الاتصال بخدمة TMDb.",
    "invalid_json": "أعادت TMDb بيانات غير قابلة للقراءة.",
    "invalid_response": "أعادت TMDb استجابة غير متوقعة.",
    "request_busy": "يوجد طلب TMDb مماثل قيد التنفيذ.",
    "invalid_page": "رقم الصفحة غير صالح.",
    "invalid_media_type": "نوع محتوى TMDb غير صالح.",
    "invalid_section": "قسم TMDb غير صالح.",
    "invalid_filter": "مرشح TMDb غير صالح.",
    "invalid_query": "نص البحث غير صالح.",
    "invalid_person": "معرف الممثل غير صالح.",
    "http_error": "تعذر تحميل بيانات TMDb حاليًا.",
}

MAIN_SECTIONS = {
    "movie": (
        ("trending", "الرائجة"),
        ("new", "الجديدة"),
        ("popular", "الأكثر شعبية"),
        ("top_rated", "الأعلى تقييمًا"),
        ("box_office", "حسب الإيرادات في TMDb"),
        ("current", "المعروضة حاليًا"),
        ("upcoming", "قريبًا"),
    ),
    "tv": (
        ("trending", "الرائجة"),
        ("new", "الجديدة"),
        ("popular", "الأكثر شعبية"),
        ("top_rated", "الأعلى تقييمًا"),
    ),
}

GROUPS = (
    ("platforms", "المنصات والاستوديوهات"),
    ("smart", "المرشحات الذكية"),
    ("genres", "حسب النوع"),
    ("years", "حسب السنة"),
)

PLATFORM_SECTIONS = (
    ("netflix", "Netflix"),
    ("apple", "Apple TV+"),
    ("disney", "Disney+"),
    ("hbo", "HBO"),
)

SMART_SECTIONS = (
    ("mind_bending", "محتوى محير للعقل"),
    ("feel_good", "محتوى مبهج"),
    ("highly_rated", "عالية التقييم"),
    ("arabic", "سينما عربية"),
    ("marvel", "عالم Marvel"),
)

GENRE_LABELS = {
    "movie": {
        "action": "أكشن",
        "comedy": "كوميديا",
        "drama": "دراما",
        "horror": "رعب",
        "thriller": "إثارة",
        "scifi": "خيال علمي وفانتازيا",
        "crime": "جريمة",
        "documentary": "وثائقي",
        "family": "عائلي",
    },
    "tv": {
        "action_adventure": "أكشن ومغامرة",
        "comedy": "كوميديا",
        "drama": "دراما",
        "scifi_fantasy": "خيال علمي وفانتازيا",
        "crime": "جريمة",
        "documentary": "وثائقي",
        "family": "عائلي",
    },
}

ARABIC_SEARCH_EQUIVALENTS = str.maketrans({
    "أ": "ا",
    "إ": "ا",
    "آ": "ا",
    "ٱ": "ا",
    "ى": "ي",
    "ة": "ه",
})


def _add_information_item(handle, label):
    item = create_list_item(label=label, icon="DefaultInfo.png")
    xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=item, isFolder=False)


def _add_folder(handle, label, params, icon="DefaultFolder.png"):
    item = create_list_item(label=label, icon=icon, thumb=icon)
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(params),
        listitem=item,
        isFolder=True,
    )


def _is_valid_media_type(media_type):
    return media_type in ("movie", "tv")


def _normalize_search_text(value):
    text = unicodedata.normalize("NFKD", str(value or "")).casefold()
    text = text.translate(ARABIC_SEARCH_EQUIVALENTS)
    characters = []
    for character in text:
        category = unicodedata.category(character)
        if category.startswith("M") or character == "ـ":
            continue
        characters.append(character if category[0] in ("L", "N") else " ")
    return " ".join("".join(characters).split())


def _safe_number(value):
    try:
        return max(0.0, float(value or 0.0))
    except (TypeError, ValueError, OverflowError):
        return 0.0


def _search_relevance(item, query):
    media_type = str(item.get("media_type") or "")
    if media_type == "person":
        original = _normalize_search_text(item.get("name"))
        localized = original
    else:
        original = _normalize_search_text(item.get("original_title") or item.get("title"))
        localized = _normalize_search_text(item.get("localized_title") or item.get("title"))
    titles = [title for title in (original, localized) if title]
    if not titles:
        return 0, 0.0
    if original == query:
        return 5, 1.0
    if localized == query:
        return 4, 1.0
    if any(title.startswith(query) for title in titles):
        return 3, max(difflib.SequenceMatcher(None, query, title, autojunk=False).ratio() for title in titles)
    if any(query in title for title in titles):
        return 2, max(difflib.SequenceMatcher(None, query, title, autojunk=False).ratio() for title in titles)
    similarity = max(
        difflib.SequenceMatcher(None, query, title, autojunk=False).ratio()
        for title in titles
    )
    return (1, similarity) if similarity >= 0.45 else (0, similarity)


def rank_search_results(items, query):
    normalized_query = _normalize_search_text(query)
    if not normalized_query:
        return list(items)
    ranked = []
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        text_rank, similarity = _search_relevance(item, normalized_query)
        ranked.append((
            -text_rank,
            -similarity,
            -_safe_number(item.get("popularity")),
            -_safe_number(item.get("vote_count")),
            index,
            item,
        ))
    ranked.sort(key=lambda value: value[:-1])
    return [value[-1] for value in ranked]


def _show_tmdb_error(handle, error, fallback):
    message = ERROR_MESSAGES.get(error.code, fallback)
    xbmcgui.Dialog().notification(
        "دليل السينما | TMDb",
        message,
        xbmcgui.NOTIFICATION_WARNING,
        5000,
    )
    _add_information_item(handle, message)


def _add_media_result(handle, media, media_type=None, label_prefix=None):
    media_type = media_type or str(media.get("media_type") or "")
    if not _is_valid_media_type(media_type):
        return False
    try:
        tmdb_id = int(media.get("id"))
    except (TypeError, ValueError):
        return False
    if tmdb_id <= 0:
        return False
    release_date = str(media.get("release_date") or "")
    year = int(release_date[:4]) if release_date[:4].isdigit() else 0
    title = str(media.get("original_title") or media.get("title") or "بدون عنوان")
    label = f"{title} ({year})" if year else title
    if label_prefix:
        label = f"{label_prefix}: {label}"
    poster = str(media.get("poster_url") or "")
    backdrop = str(media.get("backdrop_url") or "")
    default_icon = "DefaultMovies.png" if media_type == "movie" else "DefaultTVShows.png"
    item = create_list_item(
        label=label,
        icon=poster or default_icon,
        thumb=poster or None,
        poster=poster or None,
        fanart=backdrop or None,
        info={
            "video": {
                "title": title,
                "originaltitle": str(media.get("original_title") or ""),
                "plot": str(media.get("overview") or "لا يتوفر وصف لهذا العمل."),
                "mediatype": "movie" if media_type == "movie" else "tvshow",
                "year": year,
                "rating": float(media.get("vote_average") or 0.0),
                "premiered": release_date,
                "uniqueid": {"tmdb": str(tmdb_id)},
            }
        },
    )
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url({
            "mode": Mode.CINEMA_XTREAM_SEARCH,
            "media_type": media_type,
            "title": title,
            "year": year,
            "tmdb_id": tmdb_id,
        }),
        listitem=item,
        isFolder=True,
    )
    return True


@route(Mode.CINEMA_HOME, requires_account=False)
@directory_listing
def cinema_home(ctx, params):
    handle = ctx.handle
    xbmcplugin.setPluginCategory(handle, "TMDb | دليل السينما")
    _add_folder(
        handle,
        "بحث في TMDb",
        {"mode": Mode.CINEMA_SEARCH},
        "DefaultAddonsSearch.png",
    )
    _add_folder(
        handle,
        "الأفلام",
        {"mode": Mode.CINEMA_SECTIONS, "media_type": "movie"},
        "DefaultMovies.png",
    )
    _add_folder(
        handle,
        "المسلسلات",
        {"mode": Mode.CINEMA_SECTIONS, "media_type": "tv"},
        "DefaultTVShows.png",
    )


@route(Mode.CINEMA_SECTIONS, requires_account=False)
@directory_listing
def cinema_sections(ctx, params):
    handle = ctx.handle
    media_type = params.get("media_type")
    if not _is_valid_media_type(media_type):
        _add_information_item(handle, "نوع دليل السينما غير صالح.")
        return
    xbmcplugin.setPluginCategory(
        handle,
        "أفلام TMDb" if media_type == "movie" else "مسلسلات TMDb",
    )
    for section, label in MAIN_SECTIONS[media_type]:
        _add_folder(handle, label, {
            "mode": Mode.CINEMA_LIST,
            "media_type": media_type,
            "section": section,
            "page": 1,
        })
    for group, label in GROUPS:
        _add_folder(handle, label, {
            "mode": Mode.CINEMA_FILTERS,
            "media_type": media_type,
            "group": group,
        })


@route(Mode.CINEMA_FILTERS, requires_account=False)
@directory_listing
def cinema_filters(ctx, params):
    handle = ctx.handle
    media_type = params.get("media_type")
    group = params.get("group")
    if not _is_valid_media_type(media_type) or group not in {item[0] for item in GROUPS}:
        _add_information_item(handle, "قائمة مرشحات TMDb غير صالحة.")
        return

    if group == "platforms":
        entries = PLATFORM_SECTIONS
        for section, label in entries:
            _add_folder(handle, label, {
                "mode": Mode.CINEMA_LIST,
                "media_type": media_type,
                "section": section,
                "page": 1,
            })
        return

    if group == "smart":
        for section, label in SMART_SECTIONS:
            _add_folder(handle, label, {
                "mode": Mode.CINEMA_LIST,
                "media_type": media_type,
                "section": section,
                "page": 1,
            })
        return

    if group == "genres":
        for genre_key in GENRE_IDS[media_type]:
            _add_folder(handle, GENRE_LABELS[media_type][genre_key], {
                "mode": Mode.CINEMA_LIST,
                "media_type": media_type,
                "section": "genre",
                "filter_value": genre_key,
                "page": 1,
            })
        return

    for year in range(date.today().year, 1999, -1):
        _add_folder(handle, str(year), {
            "mode": Mode.CINEMA_LIST,
            "media_type": media_type,
            "section": "year",
            "filter_value": year,
            "page": 1,
        })
    for value, label in (("1990s", "التسعينيات"), ("1980s", "الثمانينيات")):
        _add_folder(handle, label, {
            "mode": Mode.CINEMA_LIST,
            "media_type": media_type,
            "section": "year",
            "filter_value": value,
            "page": 1,
        })


def _pagination_params(media_type, section, page, filter_value):
    params = {
        "mode": Mode.CINEMA_LIST,
        "media_type": media_type,
        "section": section,
        "page": page,
    }
    if filter_value:
        params["filter_value"] = filter_value
    return params


def _search_pagination_params(query, page):
    return {
        "mode": Mode.CINEMA_SEARCH,
        "query": query,
        "page": page,
    }


@route(Mode.CINEMA_SEARCH, requires_account=False)
@directory_listing
def cinema_search(ctx, params):
    handle = ctx.handle
    client = ctx.tmdb
    query = params.get("query")
    page = params.get("page", 1)
    if query is None:
        query = xbmcgui.Dialog().input(
            "البحث في دليل السينما",
            type=xbmcgui.INPUT_ALPHANUM,
        )
    query = str(query or "").strip()
    if not query:
        return

    xbmcplugin.setPluginCategory(handle, f"نتائج البحث: {query}")
    xbmcplugin.setContent(handle, "videos")
    try:
        catalog = client.search_multi(query, page=page)
    except TmdbError as error:
        _show_tmdb_error(handle, error, "تعذر البحث في TMDb.")
        return

    results = catalog.get("results") if isinstance(catalog, dict) else None
    if not isinstance(results, list) or not results:
        _add_information_item(handle, "لا توجد نتائج لهذا البحث في TMDb.")
        return

    client.enrich_original_posters(results)
    current_page = int(catalog.get("page") or 1)
    total_pages = min(20, max(1, int(catalog.get("total_pages") or 1)))
    if current_page > 1:
        _add_folder(
            handle,
            "الصفحة السابقة",
            _search_pagination_params(query, current_page - 1),
        )

    groups = (
        ("movie", "فيلم"),
        ("tv", "مسلسل"),
        ("person", "ممثل"),
    )
    rendered = 0
    for media_type, label_prefix in groups:
        matches = [item for item in results if item.get("media_type") == media_type]
        if not matches:
            continue
        for media in rank_search_results(matches, query):
            if media_type == "person":
                name = str(media.get("name") or "").strip()
                person_id = media.get("id")
                if not name or person_id is None:
                    continue
                profile = str(media.get("profile_url") or "")
                item = create_list_item(
                    label=f"{label_prefix}: {name}",
                    icon=profile or "DefaultActor.png",
                    thumb=profile or None,
                    poster=profile or None,
                    info={"video": {
                        "title": name,
                        "plot": str(media.get("known_for_department") or ""),
                        "mediatype": "video",
                    }},
                )
                xbmcplugin.addDirectoryItem(
                    handle=handle,
                    url=build_url({
                        "mode": Mode.CINEMA_PERSON_CREDITS,
                        "person_id": person_id,
                        "name": name,
                    }),
                    listitem=item,
                    isFolder=True,
                )
                rendered += 1
            elif _add_media_result(
                handle,
                media,
                media_type=media_type,
                label_prefix=label_prefix,
            ):
                rendered += 1

    if not rendered:
        _add_information_item(handle, "لا توجد نتائج صالحة للعرض.")
    if current_page < total_pages:
        _add_folder(
            handle,
            "الصفحة التالية",
            _search_pagination_params(query, current_page + 1),
        )


@route(Mode.CINEMA_PERSON_CREDITS, requires_account=False)
@directory_listing
def cinema_person_credits(ctx, params):
    handle = ctx.handle
    client = ctx.tmdb
    person_id = params.get("person_id")
    name = params.get("name")
    person_name = str(name or "").strip() or "الممثل"
    xbmcplugin.setPluginCategory(handle, f"أعمال {person_name}")
    xbmcplugin.setContent(handle, "videos")
    try:
        catalog = client.get_person_credits(person_id)
    except TmdbError as error:
        _show_tmdb_error(handle, error, "تعذر تحميل أعمال الممثل.")
        return

    results = catalog.get("results") if isinstance(catalog, dict) else None
    if not isinstance(results, list) or not results:
        _add_information_item(handle, "لا توجد أعمال متاحة لهذا الممثل.")
        return

    client.enrich_original_posters(results)
    rendered = 0
    labels = {"movie": "فيلم", "tv": "مسلسل"}
    for media in results[:40]:
        media_type = str(media.get("media_type") or "")
        if _add_media_result(
            handle,
            media,
            media_type=media_type,
            label_prefix=labels.get(media_type),
        ):
            rendered += 1
    if not rendered:
        _add_information_item(handle, "لا توجد أعمال صالحة للعرض.")


@route(Mode.CINEMA_LIST, requires_account=False)
@directory_listing
def cinema_list(ctx, params):
    handle = ctx.handle
    client = ctx.tmdb
    media_type = params.get("media_type")
    section = params.get("section")
    page = params.get("page")
    filter_value = params.get("filter_value")
    xbmcplugin.setContent(handle, "movies" if media_type == "movie" else "tvshows")
    try:
        catalog = client.get_catalog(
            media_type,
            section,
            page=page,
            filter_value=filter_value,
        )
    except TmdbError as error:
        _show_tmdb_error(handle, error, "تعذر تحميل دليل السينما.")
        return

    results = catalog.get("results") if isinstance(catalog, dict) else None
    if not isinstance(results, list) or not results:
        _add_information_item(handle, "لا توجد نتائج متاحة حاليًا.")
        return

    client.enrich_original_posters(results)
    current_page = int(catalog.get("page") or 1)
    total_pages = min(20, max(1, int(catalog.get("total_pages") or 1)))
    if current_page > 1:
        _add_folder(
            handle,
            "الصفحة السابقة",
            _pagination_params(media_type, section, current_page - 1, filter_value),
        )

    for media in results[:20]:
        _add_media_result(handle, media, media_type=media_type)

    if current_page < total_pages:
        _add_folder(
            handle,
            "الصفحة التالية",
            _pagination_params(media_type, section, current_page + 1, filter_value),
        )
