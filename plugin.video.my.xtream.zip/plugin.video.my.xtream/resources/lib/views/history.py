"""Watch history ("Continuer à regarder") and its maintenance actions."""
import xbmc
import xbmcplugin

from resources.lib.core.constants import MediaType, Mode
from resources.lib.core.urls import build_url
from resources.lib.domain.meta_codec import encode_meta
from resources.lib.routing import route
from resources.lib.ui.decorators import directory_listing
from resources.lib.ui.dialogs import notify
from resources.lib.ui.listitem import create_list_item

_CONTENT = {MediaType.VOD: "movies", MediaType.SERIES: "tvshows"}
_HISTORY_TYPES = tuple(_CONTENT)


def _list_history(ctx, media_type):
    xbmcplugin.setContent(ctx.handle, _CONTENT[media_type])
    entries = ctx.history.get_list(media_type)
    if not entries:
        notify("Historique", "Votre historique est vide")
        return

    clear = create_list_item(label="[B][COLOR red]Tout Effacer[/COLOR][/B]", icon="DefaultClose.png")
    xbmcplugin.addDirectoryItem(
        handle=ctx.handle,
        url=build_url({"mode": Mode.CLEAR_HISTORY, "media_type": media_type}),
        listitem=clear,
        isFolder=False,
    )

    for entry in entries:
        name = entry.get("name")
        entry_id = entry.get("id")
        icon = entry.get("icon")
        meta = entry.get("meta", {})
        item = create_list_item(
            label=name, icon=icon, thumb=icon, poster=icon,
            info={"video": meta} if meta else None,
            properties={"IsPlayable": "true"},
        )
        remove_url = build_url({"mode": Mode.REMOVE_HISTORY, "media_type": media_type, "item_id": entry_id})
        item.addContextMenuItems([("Retirer de l'historique", "RunPlugin({})".format(remove_url))])

        # The next-episode link is not stored, so replaying from history does
        # not chain episodes; the play route rebuilds it for series.
        params = {
            "mode": Mode.PLAY,
            "title": name,
            "icon": icon,
            "media_type": media_type,
            "media_id": entry_id,
            "meta": encode_meta(meta),
            "extension": entry.get("extension") or "mp4",
        }
        if entry.get("group_id"):
            params["group_id"] = entry["group_id"]
        xbmcplugin.addDirectoryItem(
            handle=ctx.handle, url=build_url(params), listitem=item, isFolder=False
        )


@route(Mode.HISTORY_VOD)
@directory_listing
def history_vod(ctx, params):
    _list_history(ctx, MediaType.VOD)


@route(Mode.HISTORY_SERIES)
@directory_listing
def history_series(ctx, params):
    _list_history(ctx, MediaType.SERIES)


@route(Mode.CLEAR_HISTORY)
def clear_history(ctx, params):
    media_type = params.get("media_type")
    if media_type in _HISTORY_TYPES:
        ctx.history.clear_history(media_type)
        xbmc.executebuiltin("Container.Refresh")


@route(Mode.REMOVE_HISTORY)
def remove_history(ctx, params):
    media_type = params.get("media_type")
    if media_type in _HISTORY_TYPES:
        ctx.history.remove_item(media_type, params.get("item_id"))
        xbmc.executebuiltin("Container.Refresh")
