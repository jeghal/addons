"""Main menu."""
import os

import xbmcplugin

from resources.lib.core.constants import Mode
from resources.lib.core.urls import build_url
from resources.lib.routing import route
from resources.lib.services.precache import start_background_precache
from resources.lib.ui.listitem import create_list_item

IMG = "img:"  # icon located in resources/img

MENU = (
    ("[COLOR red]Recherche Globale[/COLOR]", Mode.SEARCH_GLOBAL, IMG + "search_pro.png"),
    ("دليل السينما | TMDb", Mode.CINEMA_HOME, "DefaultMovies.png"),
    ("Télévision", Mode.LIVE_CATEGORIES, IMG + "tv_pro.png"),
    ("Films", Mode.VOD_CATEGORIES, IMG + "movies_pro.png"),
    ("Séries", Mode.SERIES_CATEGORIES, IMG + "series_pro.png"),
    ("Espace Client", Mode.ACCOUNT_INFO, IMG + "account_pro.png"),
    ("[COLOR yellow]Mettre à jour (Vider Cache)[/COLOR]", Mode.CLEAR_CACHE, "DefaultAddonService.png"),
)


def _resolve_icon(spec, img_dir):
    return os.path.join(img_dir, spec[len(IMG):]) if spec.startswith(IMG) else spec


@route(Mode.HOME)
def main_menu(ctx, params):
    try:
        for label, mode, icon_spec in MENU:
            icon = _resolve_icon(icon_spec, ctx.img_dir)
            item = create_list_item(label=label, icon=icon, thumb=icon)
            xbmcplugin.addDirectoryItem(
                handle=ctx.handle, url=build_url({"mode": mode}), listitem=item, isFolder=True
            )
    finally:
        xbmcplugin.endOfDirectory(ctx.handle)
    # Only after the menu is on screen: warm the catalog cache in background.
    start_background_precache(ctx)
