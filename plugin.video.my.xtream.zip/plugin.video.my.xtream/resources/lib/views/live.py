"""Live TV: category groups and channel lists."""
import xbmcplugin

from resources.lib.core.constants import MediaType, Mode
from resources.lib.core.urls import build_url
from resources.lib.domain.text import get_safe_image, safe_text
from resources.lib.routing import route
from resources.lib.ui.category_browser import group_for, render_groups
from resources.lib.ui.decorators import directory_listing
from resources.lib.ui.listitem import create_list_item


@route(Mode.LIVE_CATEGORIES)
@directory_listing
def live_categories(ctx, params):
    categories = ctx.catalogs.categories(MediaType.LIVE)
    if not isinstance(categories, list):
        return
    categories = [category for category in categories if isinstance(category, dict)]
    groups, orphans = group_for(categories, MediaType.LIVE)
    render_groups(
        ctx, groups, orphans, params.get("group_id"),
        browse_mode=Mode.LIVE_CATEGORIES, leaf_mode=Mode.LIVE_STREAMS,
    )


def _channel_plot(stream, number):
    lines = []
    if number:
        lines.append("Numéro: {}".format(number))
    if stream.get("epg_channel_id"):
        lines.append("EPG ID: {}".format(stream["epg_channel_id"]))
    if stream.get("tv_archive") not in (None, "", 0, "0", False):
        lines.append("Replay disponible")
    return "\n".join(lines)


@route(Mode.LIVE_STREAMS)
@directory_listing
def live_streams(ctx, params):
    streams = ctx.catalogs.category_streams(MediaType.LIVE, params.get("category_id"))
    if not isinstance(streams, list):
        return

    items = []
    for stream in streams:
        if not isinstance(stream, dict) or stream.get("stream_id") is None:
            continue
        name = safe_text(stream.get("name"), "Chaîne sans titre")
        icon = get_safe_image(stream.get("stream_icon"), "DefaultVideo.png")
        number = stream.get("num")
        item = create_list_item(
            label="{} | {}".format(number, name) if number else name,
            icon=icon,
            thumb=icon,
            info={"video": {"title": name, "mediatype": "video", "plot": _channel_plot(stream, number)}},
            properties={"IsPlayable": "true"},
        )
        url = build_url({
            "mode": Mode.PLAY,
            "title": name,
            "icon": icon,
            "media_type": MediaType.LIVE,
            "media_id": stream["stream_id"],
            "extension": "ts",
        })
        items.append((url, item, False))
    xbmcplugin.addDirectoryItems(ctx.handle, items)
