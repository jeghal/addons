"""Maintenance actions."""
import xbmcgui

from resources.lib.core import logger
from resources.lib.core.constants import Mode
from resources.lib.routing import route
from resources.lib.services.precache import start_background_precache
from resources.lib.ui.dialogs import confirm, notify


@route(Mode.CLEAR_CACHE)
def clear_cache(ctx, params):
    if not confirm(
        "Vider le Cache",
        "Voulez-vous vraiment vider le cache et forcer le téléchargement des données ?",
    ):
        return
    try:
        ctx.cache.clear()
    except (OSError, TimeoutError) as error:
        logger.log_exception("Cache clear failed", error)
        notify("Xtream", "Impossible de vider le cache", xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    notify("Xtream", "Cache vidé avec succès", time_ms=3000)
    start_background_precache(ctx)
