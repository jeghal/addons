"""Playback entry point: resolve a stream and start a tracked session."""
import xbmcplugin

from resources.lib.core import logger
from resources.lib.core.constants import ADDON_ID, MediaType, Mode
from resources.lib.domain.meta_codec import decode_meta
from resources.lib.playback import session
from resources.lib.playback.next_episode import find_next_episode_url
from resources.lib.playback.resume import offer_resume, saved_resume_time
from resources.lib.playback.routes import is_safe_play_route
from resources.lib.routing import route
from resources.lib.ui.listitem import create_list_item

TRACKED_TYPES = (MediaType.VOD, MediaType.SERIES)


def _validated_next_url(ctx, next_url):
    """Return ``next_url`` only when the service may safely launch it."""
    client = ctx.client
    credentials = ctx.credentials

    def can_build_stream(route_params):
        return client.get_stream_url(
            route_params.get("media_type"),
            route_params.get("media_id"),
            route_params.get("extension"),
        )

    if is_safe_play_route(
        next_url, ADDON_ID,
        username=credentials.username, password=credentials.password,
        stream_validator=can_build_stream,
    ):
        return next_url
    logger.warning("Rejected unsafe next episode route")
    return None


def _record_history(ctx, media_type, media_id, title, icon, meta, extension, group_id):
    entry = {
        "id": media_id,
        "name": title,
        "icon": icon,
        "meta": meta,
        "extension": extension or "mp4",
    }
    try:
        ctx.history.add_item(media_type, entry, group_id=group_id)
    except Exception as error:  # history problems must never block playback
        logger.log_exception("History update failed", error)


def _resume_position(ctx, media_type, media_id):
    try:
        history = ctx.history.load_history()
    except Exception as error:  # history problems must never block playback
        logger.log_exception("History read failed", error)
        return 0.0
    return saved_resume_time(history, media_type, media_id)


@route(Mode.PLAY)
def play_channel(ctx, params):
    title = params.get("title")
    resolved = ctx.client.resolve_stream_url(
        params.get("media_type"),
        params.get("media_id"),
        params.get("extension"),
        legacy_url=params.get("url"),
    )
    if not resolved:
        logger.warning("Rejected invalid playback identity")
        xbmcplugin.setResolvedUrl(ctx.handle, False, listitem=create_list_item(label=title))
        return
    stream_url, media_type, media_id, extension = resolved

    icon = params.get("icon")
    group_id = params.get("group_id")
    meta = decode_meta(params.get("meta"))

    # Same InfoTagVideo path as manually selected directory entries.
    item = create_list_item(
        label=title,
        icon=icon,
        thumb=icon,
        poster=meta.get("poster") or meta.get("thumb") or icon,
        fanart=meta.get("fanart"),
        info={"video": meta} if meta else None,
        path=stream_url,
    )

    next_url = params.get("next_url")
    if media_type == MediaType.SERIES and not next_url and group_id and media_id:
        next_url = find_next_episode_url(ctx.client, group_id, media_id)
    if next_url:
        next_url = _validated_next_url(ctx, next_url)

    tracked = media_type in TRACKED_TYPES and bool(media_id)
    session.begin(
        media_type if tracked else None,
        media_id if tracked else None,
        next_url,
        account_fingerprint=ctx.credentials.history_namespace,
    )

    if tracked:
        _record_history(ctx, media_type, media_id, title, icon, meta, extension, group_id)
        offer_resume(
            item,
            _resume_position(ctx, media_type, media_id),
            meta.get("duration"),
            auto_resume=ctx.settings.auto_resume,
        )

    # Total duration is required for a correct resume bar.
    if meta.get("duration"):
        item.setProperty("TotalTime", str(meta["duration"]))

    xbmcplugin.setResolvedUrl(ctx.handle, True, listitem=item)
