"""Search: movies, series, global, and TMDb → Xtream lookups."""
import gc

import xbmc
import xbmcplugin

from resources.lib.core.constants import (
    DEFAULT_SERIES_ICON,
    DEFAULT_VOD_ICON,
    GLOBAL_SEARCH_RESULT_LIMIT,
    SEARCH_MIN_QUERY_LENGTH,
    SEARCH_RESULT_LIMIT,
    MediaType,
    Mode,
)
from resources.lib.core.urls import build_url
from resources.lib.domain.metadata import first_backdrop, get_rating, release_year
from resources.lib.domain.search_index import find_matches
from resources.lib.domain.text import get_safe_image, safe_text
from resources.lib.domain.title_matching import rank_xtream_matches
from resources.lib.routing import route
from resources.lib.ui.decorators import add_sort_methods, directory_listing
from resources.lib.ui.dialogs import ask_text, notify, progress
from resources.lib.ui.listitem import create_list_item


def _ask_query(prompt):
    query = ask_text(prompt)
    if not query or len(query) < SEARCH_MIN_QUERY_LENGTH:
        return None
    return query


def _info_entry(handle, message):
    item = create_list_item(label=message, icon="DefaultInfo.png")
    xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=item, isFolder=False)


def _movie_result(stream):
    stream_id = stream.get("stream_id")
    if stream_id is None:
        return None
    name = safe_text(stream.get("name"), "Sans titre")
    icon = get_safe_image(stream.get("stream_icon"), DEFAULT_VOD_ICON)
    item = create_list_item(
        label=name, icon=icon, thumb=icon, poster=icon,
        info={"video": {"title": name, "rating": get_rating(stream), "mediatype": "movie"}},
    )
    return build_url({"mode": Mode.VOD_INFO, "vod_id": stream_id}), item, True


def _series_result(series):
    series_id = series.get("series_id")
    if series_id is None:
        return None
    name = safe_text(series.get("name"), "Sans titre")
    cover = get_safe_image(series.get("cover"), DEFAULT_SERIES_ICON)
    item = create_list_item(
        label=name, icon=cover, thumb=cover, poster=cover,
        fanart=first_backdrop(series),
        info={"video": {
            "title": name,
            "plot": safe_text(series.get("plot")),
            "mediatype": "tvshow",
            "genre": safe_text(series.get("genre")),
            "year": release_year(series),
            "rating": get_rating(series),
        }},
    )
    return build_url({"mode": Mode.SERIES_INFO, "series_id": series_id}), item, True


def _add_entries(handle, entries):
    for url, item, is_folder in filter(None, entries):
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=item, isFolder=is_folder)


def _search_catalog(ctx, kind, prompt, download_message, content, build_result):
    """Shared flow of the single-type searches (movies / series)."""
    query = _ask_query(prompt)
    if not query:
        return

    catalog = ctx.catalogs.cached_catalog(kind)
    if catalog is None:
        with progress("Recherche", download_message):
            catalog = ctx.catalogs.load_catalog(kind)
    if not isinstance(catalog, list):
        notify("Info", "Aucun contenu trouvé")
        return

    results, match_count = find_matches(catalog, query, SEARCH_RESULT_LIMIT)
    del catalog
    if not results:
        notify("Info", "Aucun résultat pour : " + query)
        return
    if match_count > SEARCH_RESULT_LIMIT:
        notify("Info", "{} trouvés. Affichage des {} premiers.".format(match_count, SEARCH_RESULT_LIMIT), time_ms=3000)

    xbmcplugin.setContent(ctx.handle, content)
    add_sort_methods(ctx.handle, content)
    _add_entries(ctx.handle, (build_result(item) for item in results))


@route(Mode.SEARCH_VOD)
@directory_listing
def search_vod(ctx, params):
    _search_catalog(
        ctx, MediaType.VOD, "Rechercher un film :",
        "Téléchargement de la liste des films...", "movies", _movie_result,
    )


@route(Mode.SEARCH_SERIES)
@directory_listing
def search_series(ctx, params):
    _search_catalog(
        ctx, MediaType.SERIES, "Rechercher une série :",
        "Téléchargement des séries...", "tvshows", _series_result,
    )


def _matching_items(ctx, kind, query):
    catalog = ctx.catalogs.catalog(kind)
    results = []
    if isinstance(catalog, list):
        results, _ = find_matches(catalog, query, GLOBAL_SEARCH_RESULT_LIMIT, count_all=False)
    del catalog
    # Free the first catalog before the second one is loaded (low-memory devices).
    gc.collect()
    return results


@route(Mode.SEARCH_GLOBAL)
@directory_listing
def search_global(ctx, params):
    query = _ask_query("Recherche Globale :")
    if not query:
        return

    with progress("Recherche Globale", "Chargement des données...") as dialog:
        dialog.update(10, "Recherche dans les films...")
        movies = _matching_items(ctx, MediaType.VOD, query)
        dialog.update(50, "Recherche dans les séries...")
        series = _matching_items(ctx, MediaType.SERIES, query)

    if not movies and not series:
        notify("Info", "Aucun résultat trouvé")
        return

    handle = ctx.handle
    xbmcplugin.setContent(handle, "files")  # mixed content
    for label, icon, results, build_result in (
        ("FILMS", "DefaultMovies.png", movies, _movie_result),
        ("SERIES", "DefaultTVShows.png", series, _series_result),
    ):
        if not results:
            continue
        separator = create_list_item(label="[B][COLOR yellow]--- {} ---[/COLOR][/B]".format(label), icon=icon)
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=separator, isFolder=False)
        _add_entries(handle, (build_result(item) for item in results))


# -- TMDb title → Xtream library ------------------------------------------

def _xtream_match_entry(match, is_movie):
    candidate = match["item"]
    name = safe_text(candidate.get("name") or candidate.get("title"), "بدون عنوان")
    year = match["year"] or release_year(candidate)
    plot = safe_text(candidate.get("plot"))
    if match["reason"] != "tmdb_id":
        plot = "نتيجة محتملة" + ("\n\n{}".format(plot) if plot else "")

    if is_movie:
        content_id = candidate.get("stream_id")
        icon = get_safe_image(candidate.get("stream_icon") or candidate.get("movie_image"), DEFAULT_VOD_ICON)
        route_params = {"mode": Mode.VOD_INFO, "vod_id": content_id}
        media_tag, fanart = "movie", None
    else:
        content_id = candidate.get("series_id")
        icon = get_safe_image(candidate.get("cover"), DEFAULT_SERIES_ICON)
        route_params = {"mode": Mode.SERIES_INFO, "series_id": content_id}
        media_tag, fanart = "tvshow", first_backdrop(candidate)
    if content_id is None:
        return None

    item = create_list_item(
        label=name, icon=icon, thumb=icon, poster=icon, fanart=fanart,
        info={"video": {
            "title": name, "plot": plot, "mediatype": media_tag,
            "year": year, "rating": get_rating(candidate),
        }},
    )
    return build_url(route_params), item, True


@route(Mode.CINEMA_XTREAM_SEARCH, requires_account=False)
@directory_listing
def search_tmdb_xtream(ctx, params):
    handle = ctx.handle
    media_type = safe_text(params.get("media_type")).lower()
    title = safe_text(params.get("title"))[:240]
    if media_type not in ("movie", "tv") or not title:
        _info_entry(handle, "تعذر بدء البحث عن هذا المحتوى.")
        return
    if ctx.client is None:
        _info_entry(handle, "يرجى اختيار حساب Xtream أولًا.")
        return

    is_movie = media_type == "movie"
    kind = MediaType.VOD if is_movie else MediaType.SERIES
    catalog = ctx.catalogs.cached_catalog(kind)
    if catalog is None:
        if xbmc.Monitor().abortRequested():
            return
        catalog = ctx.catalogs.load_catalog(kind, wait_timeout=2.0)
    if not isinstance(catalog, list):
        _info_entry(handle, "تعذر البحث في Xtream حاليًا. حاول مرة أخرى.")
        return

    matches = rank_xtream_matches(
        catalog, title, year=params.get("year"), tmdb_id=params.get("tmdb_id"), limit=20,
    )
    del catalog
    gc.collect()
    if not matches:
        _info_entry(handle, "لم يُعثر على هذا المحتوى في مكتبة Xtream.")
        return

    xbmcplugin.setPluginCategory(handle, "نتائج Xtream — {}".format(title))
    xbmcplugin.setContent(handle, "movies" if is_movie else "tvshows")
    rendered = 0
    for match in matches:
        entry = _xtream_match_entry(match, is_movie)
        if entry:
            _add_entries(handle, [entry])
            rendered += 1
    if not rendered:
        _info_entry(handle, "لم يُعثر على هذا المحتوى في مكتبة Xtream.")
