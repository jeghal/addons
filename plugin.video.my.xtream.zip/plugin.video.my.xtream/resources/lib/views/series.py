"""TV series: categories, listings, seasons and episodes."""
import gc
import xbmcplugin

from resources.lib.core.constants import DEFAULT_SERIES_ICON, MediaType, Mode
from resources.lib.core.urls import build_url
from resources.lib.domain.episodes import EpisodeDetails, SeriesSummary
from resources.lib.domain.metadata import (
    get_duration, get_fanart, get_rating, get_release_date, get_year, parse_timestamp,
)
from resources.lib.domain.text import get_safe_image, safe_text, split_names
from resources.lib.routing import route
from resources.lib.ui.category_browser import add_root_shortcut, group_for, render_groups
from resources.lib.ui.decorators import add_sort_methods, directory_listing
from resources.lib.ui.dialogs import notify
from resources.lib.ui.listitem import create_list_item

ISO_DATE = "%Y-%m-%d"
DISPLAY_DATE = "%d/%m/%Y"


def _with_cast_and_director(plot, director, cast):
    meta_lines = []
    if director:
        meta_lines.append("[B]Réalisateur :[/B] {}".format(director))
    if cast:
        meta_lines.append("[B]Acteurs :[/B] {}".format(cast))
    if meta_lines:
        extra = "\n".join(meta_lines)
        return "{}\n\n{}".format(plot, extra) if plot else extra
    return plot


def _series_item(series, *, recent):
    """Build ``(url, list_item, is_folder)`` for one catalog series, or None.

    ``recent`` selects the "recent additions" presentation (update date in the
    plot and ``dateadded``); otherwise cast/director are shown.
    """
    series_id = series.get("series_id")
    if series_id is None:
        return None
    name = safe_text(series.get("name"), "Série sans titre")
    cover = get_safe_image(series.get("cover"), DEFAULT_SERIES_ICON)
    release_date = get_release_date(series, "releaseDate", "release_date")
    plot = safe_text(series.get("plot"))

    info_tag = {
        "title": name,
        "plot": plot,
        "mediatype": "tvshow",
        "genre": safe_text(series.get("genre")),
        "year": get_year(series, release_date),
        "rating": get_rating(series),
        "duration": get_duration(series),
        "premiered": release_date,
    }
    if recent:
        updated = parse_timestamp(series.get("last_modified"))
        if updated:
            if not plot:
                info_tag["plot"] = "Mis à jour : {}".format(updated.strftime(DISPLAY_DATE))
            info_tag["dateadded"] = "{} 00:00:00".format(updated.strftime(ISO_DATE))
        else:
            info_tag["dateadded"] = None
    else:
        info_tag["cast"] = split_names(series.get("cast"))
        info_tag["director"] = series.get("director")
        info_tag["plot"] = _with_cast_and_director(
            plot, safe_text(series.get("director")), safe_text(series.get("cast"))
        )
        if series.get("tmdb"):
            info_tag["tmdb_id"] = series["tmdb"]
            info_tag["uniqueid"] = {"tmdb": str(series["tmdb"])}

    item = create_list_item(
        label=name, icon=cover, thumb=cover, poster=cover,
        fanart=get_fanart(series), info={"video": info_tag},
    )
    return build_url({"mode": Mode.SERIES_INFO, "series_id": series_id}), item, True


@route(Mode.RECENT_SERIES)
@directory_listing
def recent_series(ctx, params):
    catalog = ctx.catalogs.catalog(MediaType.SERIES)
    if not isinstance(catalog, list):
        notify("Info", "Aucun contenu disponible")
        return

    limit = max(1, ctx.settings.recent_limit)
    latest = []
    for series in catalog:  # the cache is already sorted newest first
        if isinstance(series, dict):
            latest.append(series)
            if len(latest) >= limit:
                break
    del catalog
    gc.collect()

    xbmcplugin.setContent(ctx.handle, "tvshows")
    add_sort_methods(ctx.handle, "tvshows")
    entries = (_series_item(series, recent=True) for series in latest)
    xbmcplugin.addDirectoryItems(ctx.handle, [entry for entry in entries if entry])


@route(Mode.SERIES_CATEGORIES)
@directory_listing
def series_categories(ctx, params):
    group_id = params.get("group_id")
    if not group_id:
        add_root_shortcut(ctx.handle, "Rechercher une Série", "DefaultTVShows.png", Mode.SEARCH_SERIES)
        add_root_shortcut(ctx.handle, "Derniers Ajouts", "DefaultAddonImages.png", Mode.RECENT_SERIES)
        add_root_shortcut(ctx.handle, "Continuer à regarder", "DefaultRecentlyAddedEpisodes.png", Mode.HISTORY_SERIES)

    categories = ctx.catalogs.categories(MediaType.SERIES)
    if not isinstance(categories, list):
        return
    categories = [category for category in categories if isinstance(category, dict)]

    groups, orphans = group_for(categories, MediaType.SERIES)
    render_groups(
        ctx, groups, orphans, group_id,
        browse_mode=Mode.SERIES_CATEGORIES, leaf_mode=Mode.SERIES_LIST,
    )


@route(Mode.SERIES_LIST)
@directory_listing
def series_list(ctx, params):
    xbmcplugin.setContent(ctx.handle, "tvshows")
    add_sort_methods(ctx.handle, "tvshows")
    catalog = ctx.catalogs.category_streams(MediaType.SERIES, params.get("category_id"))
    if not isinstance(catalog, list):
        return
    entries = (_series_item(series, recent=False) for series in catalog if isinstance(series, dict))
    xbmcplugin.addDirectoryItems(ctx.handle, [entry for entry in entries if entry])


def _with_cached_arabic_plot(ctx, plot):
    if plot:
        arabic = ctx.translator.cached(plot)
        if arabic and arabic != plot:
            if ctx.settings.hide_original_plot:
                return "[B][COLOR yellow]الترجمة العربية:[/COLOR][/B]\n{}".format(arabic)
            return "[B][COLOR yellow]الترجمة العربية:[/COLOR][/B]\n{}\n\n[B]Original:[/B]\n{}".format(arabic, plot)
    return plot


@route(Mode.SERIES_INFO)
@directory_listing
def series_info(ctx, params):
    xbmcplugin.setContent(ctx.handle, "seasons")
    series_id = params.get("series_id")
    data = ctx.client.get_series_info(series_id)
    if not isinstance(data, dict):
        return

    episodes_data = data.get("episodes")
    episodes_data = episodes_data if isinstance(episodes_data, dict) else {}
    seasons_data = data.get("seasons")
    seasons_data = seasons_data if isinstance(seasons_data, list) else []
    info = data.get("info", {})
    info = info if isinstance(info, dict) else {}

    seasons_map = {
        str(season["season_number"]): season
        for season in seasons_data
        if isinstance(season, dict) and season.get("season_number") is not None
    }
    season_keys = sorted(
        (key for key, value in episodes_data.items() if isinstance(key, str) and isinstance(value, list)),
        key=lambda key: int(key) if key.isdigit() else 999,
    )
    if not season_keys:
        notify("Info", "Aucune saison trouvée")
        return

    series_cover = get_safe_image(info.get("cover"), DEFAULT_SERIES_ICON)
    series_fanart = get_fanart(info)

    for season_key in season_keys:
        episode_count = sum(1 for episode in episodes_data[season_key] if isinstance(episode, dict))
        season = seasons_map.get(season_key, {})

        name = safe_text(season.get("name"))
        if not name or name == "null":
            name = "Saison {}".format(season_key)
        cover = get_safe_image(season.get("cover"), series_cover)
        plot = _with_cached_arabic_plot(ctx, safe_text(season.get("overview") or info.get("plot")))
        plot = _with_cast_and_director(
            plot, safe_text(info.get("director")), safe_text(info.get("cast"))
        )

        info_tag = {
            "title": name,
            "plot": plot,
            "mediatype": "season",
            "season": int(season_key) if season_key.isdigit() else 0,
            "premiered": safe_text(season.get("air_date")),
            "tvshowtitle": info.get("name"),
        }
        item = create_list_item(
            label="{} ({} épisodes)".format(name, episode_count),
            icon=cover, thumb=cover, poster=cover, fanart=series_fanart,
            info={"video": info_tag},
        )
        url = build_url({"mode": Mode.SERIES_EPISODES, "series_id": series_id, "season_num": season_key})
        xbmcplugin.addDirectoryItem(handle=ctx.handle, url=url, listitem=item, isFolder=True)


@route(Mode.SERIES_EPISODES)
@directory_listing
def series_episodes(ctx, params):
    xbmcplugin.setContent(ctx.handle, "episodes")
    series_id = params.get("series_id")
    season_num = params.get("season_num")
    data = ctx.client.get_series_info(series_id)
    if not isinstance(data, dict):
        return

    all_episodes = data.get("episodes")
    all_episodes = all_episodes if isinstance(all_episodes, dict) else {}
    season_episodes = all_episodes.get(str(season_num), [])
    season_episodes = (
        [episode for episode in season_episodes if isinstance(episode, dict)]
        if isinstance(season_episodes, list) else []
    )
    series = SeriesSummary(data.get("info"), DEFAULT_SERIES_ICON)

    for index, episode in enumerate(season_episodes):
        details = EpisodeDetails(episode, season_num, index + 1, series)
        if details.id is None:
            continue
        info_tag = details.info_tag()
        item = create_list_item(
            label=details.title,
            icon=details.thumb, thumb=details.thumb,
            poster=series.cover, fanart=series.fanart,
            info={"video": info_tag},
            properties={"IsPlayable": "true"},
        )

        next_url = ""
        if index + 1 < len(season_episodes):
            following = EpisodeDetails(season_episodes[index + 1], season_num, index + 2, series)
            if following.id is not None:
                next_meta = following.chained_meta(year=info_tag.get("year"))
                next_url = build_url(following.play_params(series_id, next_meta))

        url = build_url(details.play_params(series_id, info_tag, next_url=next_url))
        xbmcplugin.addDirectoryItem(handle=ctx.handle, url=url, listitem=item, isFolder=False)
