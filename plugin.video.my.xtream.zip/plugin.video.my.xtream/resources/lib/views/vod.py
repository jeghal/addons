"""Movies: categories, listings, recent additions and movie details."""
import gc
import xbmcplugin

from resources.lib.core.constants import DEFAULT_VOD_ICON, MediaType, Mode
from resources.lib.core.urls import build_url
from resources.lib.domain.category_groups import CATEGORY_GROUPS
from resources.lib.domain.category_overrides import pin_sweden_vod
from resources.lib.domain.meta_codec import encode_meta
from resources.lib.domain.metadata import (
    get_duration, get_fanart, get_rating, get_release_date, get_year, parse_timestamp,
)
from resources.lib.domain.subtitle_ids import enrich as enrich_subtitle_metadata
from resources.lib.domain.text import get_safe_image, safe_text, split_names
from resources.lib.routing import route
from resources.lib.ui.category_browser import add_root_shortcut, group_for, render_groups
from resources.lib.ui.decorators import add_sort_methods, directory_listing
from resources.lib.ui.dialogs import notify
from resources.lib.ui.listitem import create_list_item

ISO_DATE = "%Y-%m-%d"
DISPLAY_DATE = "%d/%m/%Y"


def _catalog_entry(stream, plot_date_format, with_external_ids):
    """Build ``(url, list_item, is_folder)`` for one catalog movie, or None."""
    stream_id = stream.get("stream_id")
    if stream_id is None:
        return None
    name = safe_text(stream.get("name"), "Sans titre")
    icon = get_safe_image(stream.get("stream_icon") or stream.get("movie_image"), DEFAULT_VOD_ICON)

    added = parse_timestamp(stream.get("added"))
    added_iso = added.strftime(ISO_DATE) if added else ""
    release_date = get_release_date(stream, "releaseDate", "release_date", "releasedate")
    plot = safe_text(stream.get("plot") or stream.get("description"))
    if not plot and added:
        plot = "Ajouté le : {}".format(added.strftime(plot_date_format))

    info_tag = {
        "title": name,
        "plot": plot,
        "mediatype": "movie",
        "genre": safe_text(stream.get("genre")),
        "year": get_year(stream, release_date),
        "rating": get_rating(stream),
        "duration": get_duration(stream),
        "premiered": release_date,
        "dateadded": "{} 00:00:00".format(added_iso) if added_iso else None,
    }
    if with_external_ids and stream.get("tmdb"):
        tmdb_id = stream["tmdb"]
        info_tag["tmdb_id"] = tmdb_id
        info_tag["code"] = "tmdb:{}".format(tmdb_id)
        info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

    item = create_list_item(
        label=name, icon=icon, thumb=icon, poster=icon,
        fanart=get_fanart(stream), info={"video": info_tag},
    )
    return build_url({"mode": Mode.VOD_INFO, "vod_id": stream_id}), item, True


@route(Mode.RECENT_VOD)
@directory_listing
def recent_vod(ctx, params):
    catalog = ctx.catalogs.catalog(MediaType.VOD)
    if not isinstance(catalog, list):
        notify("Info", "Aucun contenu disponible")
        return

    limit = max(1, ctx.settings.recent_limit)
    latest = []
    for stream in catalog:  # the cache is already sorted newest first
        if isinstance(stream, dict):
            latest.append(stream)
            if len(latest) >= limit:
                break
    del catalog
    gc.collect()

    xbmcplugin.setContent(ctx.handle, "movies")
    add_sort_methods(ctx.handle, "movies")
    entries = (_catalog_entry(stream, DISPLAY_DATE, with_external_ids=False) for stream in latest)
    xbmcplugin.addDirectoryItems(ctx.handle, [entry for entry in entries if entry])


@route(Mode.VOD_CATEGORIES)
@directory_listing
def vod_categories(ctx, params):
    group_id = params.get("group_id")
    if not group_id:
        add_root_shortcut(ctx.handle, "Rechercher un Film", "DefaultMovies.png", Mode.SEARCH_VOD)
        add_root_shortcut(ctx.handle, "Derniers Ajouts", "DefaultAddonImages.png", Mode.RECENT_VOD)
        add_root_shortcut(ctx.handle, "Continuer à regarder", "DefaultRecentlyAddedMovies.png", Mode.HISTORY_VOD)

    categories = ctx.catalogs.categories(MediaType.VOD)
    if not isinstance(categories, list):
        return
    categories = [category for category in categories if isinstance(category, dict)]

    groups, orphans = group_for(categories, MediaType.VOD)
    groups, orphans = pin_sweden_vod(categories, groups, orphans, CATEGORY_GROUPS)
    render_groups(
        ctx, groups, orphans, group_id,
        browse_mode=Mode.VOD_CATEGORIES, leaf_mode=Mode.VOD_STREAMS,
    )


@route(Mode.VOD_STREAMS)
@directory_listing
def vod_streams(ctx, params):
    xbmcplugin.setContent(ctx.handle, "movies")
    add_sort_methods(ctx.handle, "movies")
    streams = ctx.catalogs.category_streams(MediaType.VOD, params.get("category_id"))
    if not isinstance(streams, list):
        return
    entries = (
        _catalog_entry(stream, ISO_DATE, with_external_ids=True)
        for stream in streams if isinstance(stream, dict)
    )
    xbmcplugin.addDirectoryItems(ctx.handle, [entry for entry in entries if entry])


def _with_arabic_plot(ctx, plot):
    """Prefix the original plot with its Arabic translation when available, or hide original if enabled."""
    if plot:
        arabic = ctx.translator.translate(plot)
        if arabic and arabic != plot:
            if ctx.settings.hide_original_plot:
                return "[B][COLOR yellow]Traduction arabe :[/COLOR][/B]\n{}".format(arabic)
            return "[B][COLOR yellow]Traduction arabe :[/COLOR][/B]\n{}\n\n[B]Original:[/B]\n{}".format(arabic, plot)
    return plot


def _with_cast_and_director(plot, director, cast):
    meta_lines = []
    if director:
        meta_lines.append("[B]Réalisateur :[/B] {}".format(director))
    if cast:
        meta_lines.append("[B]Acteurs :[/B] {}".format(cast))
    if meta_lines:
        extra = "\n".join(meta_lines)
        return "{}\n\n{}".format(plot, extra) if plot else extra
    return plot


@route(Mode.VOD_INFO)
@directory_listing
def vod_info(ctx, params):
    xbmcplugin.setContent(ctx.handle, "movies")
    data = ctx.client.get_vod_info(params.get("vod_id"))
    if not isinstance(data, dict):
        return

    info = data.get("info", {})
    info = info if isinstance(info, dict) else {}
    movie_data = data.get("movie_data", {})
    movie_data = movie_data if isinstance(movie_data, dict) else {}

    stream_id = movie_data.get("stream_id")
    if stream_id is None:
        return

    name = safe_text(info.get("name") or movie_data.get("name"), "Sans titre")
    extension = movie_data.get("container_extension") or info.get("container_extension") or "mp4"
    icon = get_safe_image(info.get("movie_image"), DEFAULT_VOD_ICON)
    release_date = get_release_date(info, "releasedate", "releaseDate", "release_date")

    plot = _with_arabic_plot(ctx, info.get("description") or info.get("plot"))
    plot = _with_cast_and_director(plot, safe_text(info.get("director")), safe_text(info.get("cast")))

    info_tag = {
        "title": name,
        "originaltitle": safe_text(info.get("o_name")),
        "plot": plot,
        "mediatype": "movie",
        "cast": split_names(info.get("cast")),
        "director": info.get("director"),
        "genre": safe_text(info.get("genre")),
        "year": get_year(info, release_date),
        "duration": get_duration(info),
        "premiered": release_date,
    }
    if info.get("rating") or info.get("rating_5based"):
        info_tag["rating"] = get_rating(info)
    if info.get("tmdb_id"):
        info_tag["tmdb_id"] = info["tmdb_id"]
        info_tag["uniqueid"] = {"tmdb": str(info["tmdb_id"])}
    enrich_subtitle_metadata(info_tag, info, movie_data)

    item = create_list_item(
        label=name, icon=icon, thumb=icon, poster=icon, fanart=get_fanart(info),
        info={"video": info_tag}, properties={"IsPlayable": "true"},
    )
    url = build_url({
        "mode": Mode.PLAY,
        "title": name,
        "icon": icon,
        "media_type": MediaType.VOD,
        "media_id": stream_id,
        "extension": extension,
        "meta": encode_meta(info_tag),
    })
    xbmcplugin.addDirectoryItem(handle=ctx.handle, url=url, listitem=item, isFolder=False)
