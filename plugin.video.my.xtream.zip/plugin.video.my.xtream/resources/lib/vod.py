import xbmcgui
import xbmcplugin

from resources.lib.catalog import CATEGORY_GROUPS, group_categories
from resources.lib.gui import create_list_item, directory_listing
from resources.lib.utils import (
    build_url,
    get_safe_image,
    safe_float,
    safe_int,
    safe_text,
    parse_duration,
    sort_vod,
    translate_to_arabic,
)


def _get_fanart(data):
    backdrop = data.get("backdrop_path")
    if isinstance(backdrop, list) and backdrop:
        return get_safe_image(backdrop[0], None)
    return get_safe_image(backdrop, None)


def _get_year(data, release_date=""):
    year = safe_int(data.get("year"))
    if 1000 <= year <= 9999:
        return year
    if len(release_date) >= 4 and release_date[:4].isdigit():
        return int(release_date[:4])
    return 0


def _get_rating(data):
    rating = safe_float(data.get("rating"))
    if rating > 0:
        return min(rating, 10.0)
    rating_5based = safe_float(data.get("rating_5based"))
    return min(rating_5based * 2, 10.0) if rating_5based > 0 else 0.0


def _get_duration(data):
    duration = safe_int(data.get("duration_secs"))
    if duration > 0:
        return duration
    duration = parse_duration(data.get("duration"))
    if duration > 0:
        return duration
    runtime_minutes = safe_int(data.get("episode_run_time"))
    return runtime_minutes * 60 if runtime_minutes > 0 else 0


@directory_listing
def recent_vod(handle, addon, client, cache_manager, default_vod_icon):
    # 1. Lire le cache
    all_streams = cache_manager.get("vod")
    
    if not all_streams:
       # Si pas de cache, on tente de le récupérer
       all_streams = client.get_vod_streams()
       if all_streams: 
           all_streams = sort_vod(all_streams)
           cache_manager.set("vod", all_streams)
    
    if not isinstance(all_streams, list):
        xbmcgui.Dialog().notification("Info", "Aucun contenu disponible", xbmcgui.NOTIFICATION_INFO)
        return
    all_streams = [stream for stream in all_streams if isinstance(stream, dict)]

    # 2. Cache supposé déjà trié ! (Optimisation)
    # Plus besoin de trier ici.
    
    # Récupérer la limite paramétrable
    limit = 50
    try:
        limit = int(addon.getSetting("recent_limit"))
    except:
        pass
        
    results = all_streams[:limit]

    xbmcplugin.setContent(handle, 'movies')
    for stream in results:
        name = safe_text(stream.get("name"), "Sans titre")
        stream_id = stream.get("stream_id")
        if stream_id is None:
            continue
        icon = get_safe_image(stream.get("stream_icon") or stream.get("movie_image"), default_vod_icon)
        fanart = _get_fanart(stream)
        added = stream.get("added")
        
        # Date added formatting
        date_added = ""
        date_added_iso = ""
        if added and str(added).isdigit():
            import datetime
            try:
                dt = datetime.datetime.fromtimestamp(int(added))
                date_added = dt.strftime("%d/%m/%Y")
                date_added_iso = dt.strftime("%Y-%m-%d")
            except: pass

        release_date = safe_text(
            stream.get("releaseDate") or stream.get("release_date") or stream.get("releasedate")
        )
        plot = safe_text(stream.get("plot") or stream.get("description"))
        if not plot and date_added:
            plot = f"Ajouté le : {date_added}"

        info_tag = {
            "title": name,
            "plot": plot,
            "mediatype": "movie",
            "genre": safe_text(stream.get("genre")),
            "year": _get_year(stream, release_date),
            "rating": _get_rating(stream),
            "duration": _get_duration(stream),
            "premiered": release_date,
            "dateadded": f"{date_added_iso} 00:00:00" if date_added_iso else None,
        }

        li = create_list_item(
             label=name,
             icon=icon,
             thumb=icon,
             poster=icon,
             fanart=fanart,
             info={"video": info_tag}
        )
        
        url = build_url({"mode": "vod_info", "vod_id": stream_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
@directory_listing
def list_vod_categories(handle, client, cache_manager, group_id=None):
    # Si aucun groupe sélectionné (Racine)
    if not group_id:
        # Ajout du bouton Recherche en premier
        li = create_list_item(label="[B][COLOR red]Rechercher un Film[/COLOR][/B]", icon="DefaultMovies.png")
        url = build_url({"mode": "search_vod"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        # Ajout du bouton Derniers Ajouts
        li = create_list_item(label="[B][COLOR red]Derniers Ajouts[/COLOR][/B]", icon="DefaultAddonImages.png")
        url = build_url({"mode": "recent_vod"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        # Ajout du bouton Historique en deuxième
        li = create_list_item(label="[B][COLOR red]Continuer à regarder[/COLOR][/B]", icon="DefaultRecentlyAddedMovies.png")
        url = build_url({"mode": "history_vod"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    categories = cache_manager.get("vod_categories")
    if not categories:
        categories = client.get_vod_categories()
        if categories:
            cache_manager.set("vod_categories", categories)

    if not isinstance(categories, list):
        return
    categories = [category for category in categories if isinstance(category, dict)]

    # Grouping Logic
    groups, orphans = group_categories(categories, "vod")

    # 1. Si on est à la racine, on affiche les GROUPES + les ORPHELINS
    if not group_id:
        # Afficher les dossiers de groupe
        for label, cats in groups.items():
            count = len(cats)
            # On prend l'icone du premier groupe config qui matche ce label
            icon = "DefaultFolder.png"
            for g in CATEGORY_GROUPS:
                if g["label"] == label:
                    icon = g.get("icon", "DefaultFolder.png")
                    break
            
            li = create_list_item(label=f"{label} ({count})", icon=icon)
            url = build_url({"mode": "vod_categories", "group_id": label})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        
        # Afficher les orphelins (ceux qui n'ont pas de préfixe connu)
        # On peut les mettre dans un dossier "Autres" ou les lister directement.
        # Ici on les liste directement en dessous pour plus de visibilité, ou dans un dossier "Autres" si trop nombreux ?
        # Listing direct pour l'instant:
        if orphans:
             # Separator
            li_sep = create_list_item(label="[B]--- Autres ---[/B]", icon="DefaultSeparator.png")
            xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li_sep, isFolder=False)
            
            for cat in orphans:
                li = create_list_item(label=cat.get("category_name", "Unknown"))
                url = build_url({"mode": "vod_streams", "category_id": cat.get("category_id")})
                xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    # 2. Si un groupe est sélectionné, on affiche SEULEMENT les catégories de ce groupe
    else:
        # On récupère les catégories du groupe demandé
        group_cats = groups.get(group_id, [])
        for cat in group_cats:
            li = create_list_item(label=cat.get("category_name", "Unknown"))
            url = build_url({"mode": "vod_streams", "category_id": cat.get("category_id")})
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

@directory_listing
def list_vod_streams(handle, client, cache_manager, default_vod_icon, category_id):
    xbmcplugin.setContent(handle, 'movies')
    
    cache_key = f"vod_streams_{category_id}"
    streams = cache_manager.get(cache_key)
    if not streams:
        streams = client.get_vod_streams(category_id)
        if streams:
            cache_manager.set(cache_key, streams)
            
    if not isinstance(streams, list):
        return
    streams = [stream for stream in streams if isinstance(stream, dict)]

    items = []
    for stream in streams:
        name = safe_text(stream.get("name"), "Sans titre")
        stream_id = stream.get("stream_id")
        if stream_id is None:
            continue
        # VOD streams list usually has basics. 
        # For 'vod_info' to work, we need to pass vod_id.
        # But 'vod_streams' endpoint gives us 'stream_id' which IS the 'vod_id' for get_vod_info.
        
        icon = get_safe_image(stream.get("stream_icon") or stream.get("movie_image"), default_vod_icon)
        fanart = _get_fanart(stream)
        
        added = stream.get("added")
        container_extension = stream.get("container_extension") or "mp4"
        
        # Date added formatting
        date_added = ""
        if added and str(added).isdigit():
            import datetime
            try:
                dt = datetime.datetime.fromtimestamp(int(added))
                date_added = dt.strftime("%Y-%m-%d")
            except: pass

        release_date = safe_text(
            stream.get("releaseDate") or stream.get("release_date") or stream.get("releasedate")
        )
        plot = safe_text(stream.get("plot") or stream.get("description"))
        if not plot and date_added:
            plot = f"Ajouté le : {date_added}"

        info_tag = {
            "title": name,
            "mediatype": "movie",
            "plot": plot,
            "genre": safe_text(stream.get("genre")),
            "year": _get_year(stream, release_date),
            "rating": _get_rating(stream),
            "duration": _get_duration(stream),
            "premiered": release_date,
            "dateadded": f"{date_added} 00:00:00" if date_added else None,
        }
        
        # Add TMDB ID if available for skins to scrape extra info
        tmdb_id = stream.get("tmdb")
        if tmdb_id:
            info_tag["tmdb_id"] = tmdb_id # Unofficial tag, but used by some fetchers
            info_tag["code"] = f"tmdb:{tmdb_id}"
            info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

        li = create_list_item(
            label=name,
            icon=icon,
            thumb=icon,
            poster=icon,
            fanart=fanart,
            info={"video": info_tag}
        )
        
        # Here we have a choice:
        # 1. Play directly (fastest)
        # 2. Open Info page (richer)
        # We'll use the Info page as intermediate.
        
        url = build_url({"mode": "vod_info", "vod_id": stream_id})
        items.append((url, li, True))
        
    xbmcplugin.addDirectoryItems(handle, items)
@directory_listing
def show_vod_info(handle, client, default_vod_icon, vod_id):
    xbmcplugin.setContent(handle, 'movies')
    data = client.get_vod_info(vod_id)
    if not isinstance(data, dict):
        return

    info = data.get("info", {})
    if not isinstance(info, dict):
        info = {}
    movie_data = data.get("movie_data", {})
    if not isinstance(movie_data, dict):
        movie_data = {}
    
    # Basic Info
    name = safe_text(info.get("name") or movie_data.get("name"), "Sans titre")
    original_title = safe_text(info.get("o_name"))
    stream_id = movie_data.get("stream_id")
    if stream_id is None:
        return
    # Check movie_data then info for extension
    container_extension = movie_data.get("container_extension") or info.get("container_extension") or "mp4"
    
    # Images
    icon = get_safe_image(info.get("movie_image"), default_vod_icon)
    
    fanart = _get_fanart(info)
    
    # Metadata
    plot = info.get("description") or info.get("plot")
    
    # Translate plot to Arabic if enabled
    if plot:
        arabic_plot = translate_to_arabic(plot)
        if arabic_plot and arabic_plot != plot:
            # Show Arabic translation first, then original
            plot = f"[B][COLOR yellow]الترجمة العربية:[/COLOR][/B]\n{arabic_plot}\n\n[B]Original:[/B]\n{plot}"
    
    cast = info.get("cast")
    director = info.get("director")
    genre = info.get("genre")
    release_date = safe_text(info.get("releasedate") or info.get("releaseDate") or info.get("release_date"))

    info_tag = {
        "title": name,
        "originaltitle": original_title,
        "plot": plot,
        "mediatype": "movie",
        "cast": [x.strip() for x in cast.split(",")] if isinstance(cast, str) else [],
        "director": director,
        "genre": safe_text(genre),
        "year": _get_year(info, release_date),
        "duration": _get_duration(info),
        "premiered": release_date
    }

    if info.get("rating") or info.get("rating_5based"):
        info_tag["rating"] = _get_rating(info)

    # TMDB
    tmdb_id = info.get("tmdb_id")
    if tmdb_id:
        info_tag["tmdb_id"] = tmdb_id
        info_tag["uniqueid"] = {"tmdb": str(tmdb_id)}

    li = create_list_item(
        label=name,
        icon=icon,
        thumb=icon,
        poster=icon,
        fanart=fanart,
        info={"video": info_tag},
        properties={'IsPlayable': 'true'}
    )
    
    # Play URL
    play_url = client.get_vod_url(stream_id, container_extension)

    url = build_url({
        "mode": "play_channel", 
        "url": play_url, 
        "title": name, 
        "icon": icon, 
        "media_type": "vod", 
        "media_id": stream_id, 
        "extension": container_extension,
        "meta": str(info_tag) # Pass full meta for player overlay
    })
    
    # Here we display the item as a single directory item that looks like the movie page
    # Kodi behavior: When you click this, it triggers play because IsPlayable=true and it is not a folder?
    # Actually show_vod_info is a directory listing of 1 item.
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
