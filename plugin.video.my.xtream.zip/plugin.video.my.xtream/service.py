import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys
from resources.lib.history import HistoryManager

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
# HISTORY_FILE is now managed by HistoryManager
history_manager = HistoryManager(PROFILE_PATH)

class XtreamMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = XtreamPlayer()

class XtreamPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._last_pos = 0

    def onPlayBackStarted(self):
        self._last_pos = 0
        
    def onPlayBackStopped(self):
        # Lire les propriétés définies par addon.py
        try:
            media_type = xbmcgui.Window(10000).getProperty('xtream_media_type')
            media_id = xbmcgui.Window(10000).getProperty('xtream_media_id')
            
            if media_type and media_id:
                # On a bien identifié ce qui jouait
                history_manager.update_resume_time(media_type, media_id, self._last_pos)
                
            # Clean properties
            xbmcgui.Window(10000).clearProperty('xtream_media_type')
            xbmcgui.Window(10000).clearProperty('xtream_media_id')
        except:
            pass
            
    def onPlayBackPaused(self):
        try:
            self._last_pos = self.getTime()
        except: pass
        
    def onPlayBackEnded(self):
        # 1. Update History (Finished)
        try:
             media_type = xbmcgui.Window(10000).getProperty('xtream_media_type')
             media_id = xbmcgui.Window(10000).getProperty('xtream_media_id')
             if media_type and media_id:
                history_manager.update_resume_time(media_type, media_id, 0)
        except: pass

        # 2. Check Auto-Play Next
        try:
            next_url = xbmcgui.Window(10000).getProperty('xtream_next_url')
            if next_url:
                # Clear it so it doesn't loop forever if next one fails or stops
                xbmcgui.Window(10000).clearProperty('xtream_next_url')
                
                # Wait a bit to let previous player cleanup (Avoids BusyDialog crash)
                xbmc.sleep(2000)
                
                # Notification
                xbmcgui.Dialog().notification("Xtream Codes", "Lancement de l'épisode suivant...", xbmcgui.NOTIFICATION_INFO, 3000)
                
                # Play
                xbmc.Player().play(next_url)
        except: pass



if __name__ == '__main__':
    monitor = XtreamMonitor()
    while not monitor.abortRequested():
        if monitor.player.isPlaying():
             try:
                 monitor.player._last_pos = monitor.player.getTime()
             except: pass
        xbmc.sleep(1000)
