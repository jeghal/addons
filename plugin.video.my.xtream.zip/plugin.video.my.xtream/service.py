import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys
from resources.lib.history import HistoryManager

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
# HISTORY_FILE is now managed by HistoryManager
history_manager = HistoryManager(PROFILE_PATH)

class XtreamMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = XtreamPlayer()

class XtreamPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._last_pos = 0
        self._session_id = None

    @staticmethod
    def _window():
        return xbmcgui.Window(10000)

    def _clear_session(self, clear_next):
        window = self._window()
        session_id = self._session_id
        if not session_id or window.getProperty('xtream_session_id') != session_id:
            return

        if clear_next and window.getProperty('xtream_next_session') == session_id:
            window.clearProperty('xtream_next_url')
            window.clearProperty('xtream_next_session')

        window.clearProperty('xtream_media_type')
        window.clearProperty('xtream_media_id')
        window.clearProperty('xtream_session_id')
        self._session_id = None

    def onPlayBackStarted(self):
        self._last_pos = 0
        self._session_id = self._window().getProperty('xtream_session_id') or None
        
    def onPlayBackStopped(self):
        try:
            window = self._window()
            if window.getProperty('xtream_session_id') != self._session_id:
                return
            media_type = window.getProperty('xtream_media_type')
            media_id = window.getProperty('xtream_media_id')
            if media_type and media_id:
                history_manager.update_resume_time(media_type, media_id, self._last_pos)
        except Exception:
            pass
        finally:
            self._clear_session(clear_next=True)

    def onPlayBackError(self):
        self._clear_session(clear_next=True)
            
    def onPlayBackPaused(self):
        try:
            self._last_pos = self.getTime()
        except: pass
        
    def onPlayBackEnded(self):
        next_url = ""
        try:
            window = self._window()
            session_id = self._session_id
            if not session_id or window.getProperty('xtream_session_id') != session_id:
                return

            media_type = window.getProperty('xtream_media_type')
            media_id = window.getProperty('xtream_media_id')
            if media_type and media_id:
                history_manager.update_resume_time(media_type, media_id, 0)
            if window.getProperty('xtream_next_session') == session_id:
                next_url = window.getProperty('xtream_next_url')
        except Exception:
            pass
        finally:
            self._clear_session(clear_next=True)

        if next_url:
            xbmc.sleep(2000)
            xbmcgui.Dialog().notification(
                "Xtream Codes",
                "Lancement de l'épisode suivant...",
                xbmcgui.NOTIFICATION_INFO,
                3000,
            )
            xbmc.Player().play(next_url)



if __name__ == '__main__':
    monitor = XtreamMonitor()
    while not monitor.abortRequested():
        if monitor.player.isPlaying():
             try:
                 monitor.player._last_pos = monitor.player.getTime()
             except: pass
        xbmc.sleep(1000)
