import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys
import threading
from urllib.parse import parse_qsl, urlsplit
from resources.lib.history import HistoryManager

ADDON = xbmcaddon.Addon()
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
# HISTORY_FILE is now managed by HistoryManager
history_manager = HistoryManager(PROFILE_PATH)


def is_safe_next_route(route):
    if not isinstance(route, str) or any(char in route for char in ('"', "\n", "\r", "\x00")):
        return False
    parsed = urlsplit(route)
    if parsed.scheme != "plugin" or parsed.netloc != "plugin.video.my.xtream" or parsed.path != "/":
        return False
    params = dict(parse_qsl(parsed.query))
    decoded_values = "\n".join(params.values())
    username = ADDON.getSetting("username")
    password = ADDON.getSetting("password")
    return (
        params.get("mode") == "play_channel"
        and params.get("media_type") == "series"
        and bool(params.get("media_id"))
        and "url" not in params
        and not (username and (username in route or username in decoded_values))
        and not (password and (password in route or password in decoded_values))
    )

class XtreamMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = XtreamPlayer()

class XtreamPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._last_pos = 0
        self._session_id = None
        self._playback_generation = 0
        self._pending_autoplay_session = None
        self._state_lock = threading.Lock()

    @staticmethod
    def _window():
        return xbmcgui.Window(10000)

    def _clear_session(self, clear_next, expected_session_id=None):
        window = self._window()
        with self._state_lock:
            session_id = expected_session_id or self._session_id
            if not session_id or window.getProperty('xtream_session_id') != session_id:
                return

            if clear_next and window.getProperty('xtream_next_session') == session_id:
                window.clearProperty('xtream_next_url')
                window.clearProperty('xtream_next_session')

            window.clearProperty('xtream_media_type')
            window.clearProperty('xtream_media_id')
            window.clearProperty('xtream_session_id')
            if self._session_id == session_id:
                self._session_id = None

    def _cancel_pending_autoplay(self, session_id):
        with self._state_lock:
            if self._pending_autoplay_session == session_id:
                self._pending_autoplay_session = None

    def onPlayBackStarted(self):
        with self._state_lock:
            self._last_pos = 0
            self._playback_generation += 1
            self._pending_autoplay_session = None
            self._session_id = self._window().getProperty('xtream_session_id') or None
        
    def onPlayBackStopped(self):
        try:
            window = self._window()
            if window.getProperty('xtream_session_id') != self._session_id:
                return
            media_type = window.getProperty('xtream_media_type')
            media_id = window.getProperty('xtream_media_id')
            if media_type and media_id:
                history_manager.update_resume_time(media_type, media_id, self._last_pos)
        except Exception:
            pass
        finally:
            self._clear_session(clear_next=True)

    def onPlayBackError(self):
        self._clear_session(clear_next=True)
            
    def onPlayBackPaused(self):
        try:
            self._last_pos = self.getTime()
        except: pass
        
    def onPlayBackEnded(self):
        next_url = ""
        session_id = None
        playback_generation = None
        try:
            window = self._window()
            with self._state_lock:
                session_id = self._session_id
                if not session_id or window.getProperty('xtream_session_id') != session_id:
                    return
                if self._pending_autoplay_session == session_id:
                    return
                self._pending_autoplay_session = session_id
                playback_generation = self._playback_generation

            media_type = window.getProperty('xtream_media_type')
            media_id = window.getProperty('xtream_media_id')
            if media_type and media_id:
                history_manager.update_resume_time(media_type, media_id, 0)
            if window.getProperty('xtream_next_session') == session_id:
                next_url = window.getProperty('xtream_next_url')
        except Exception:
            pass
        finally:
            self._clear_session(clear_next=True, expected_session_id=session_id)

        if not next_url:
            self._cancel_pending_autoplay(session_id)
            return

        xbmc.sleep(2000)
        monitor = xbmc.Monitor()
        if monitor.abortRequested() or not is_safe_next_route(next_url):
            self._cancel_pending_autoplay(session_id)
            return

        window = self._window()
        with self._state_lock:
            can_autoplay = (
                self._pending_autoplay_session == session_id
                and self._playback_generation == playback_generation
                and not window.getProperty('xtream_session_id')
                and not self.isPlaying()
                and not monitor.abortRequested()
            )
            if can_autoplay:
                self._pending_autoplay_session = None
                xbmcgui.Dialog().notification(
                    "Xtream Codes",
                    "Lancement de l'épisode suivant...",
                    xbmcgui.NOTIFICATION_INFO,
                    3000,
                )
                # Route through Kodi's plugin resolver, not a raw Player.play call.
                # The play_channel route initializes a new session and history entry.
                xbmc.executebuiltin('PlayMedia("{}")'.format(next_url))
            else:
                self._pending_autoplay_session = None



if __name__ == '__main__':
    monitor = XtreamMonitor()
    while not monitor.abortRequested():
        if monitor.player.isPlaying():
             try:
                 monitor.player._last_pos = monitor.player.getTime()
             except: pass
        xbmc.sleep(1000)
