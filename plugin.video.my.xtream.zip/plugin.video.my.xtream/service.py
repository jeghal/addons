"""Kodi background service: resume points and next-episode chaining."""
from resources.lib.playback.service_player import run_service

if __name__ == "__main__":
    run_service()
