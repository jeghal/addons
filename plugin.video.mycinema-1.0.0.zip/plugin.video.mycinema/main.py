# -*- coding: utf-8 -*-
"""
Kodi Addon Entry Point for MyCinema (plugin.video.mycinema)
Type: Video
"""
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib.helper import build_url, parse_query_params

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')

def list_root_categories(handle, base_url):
    """Render root category list in Kodi."""
    categories = [
        {'title': '🎬 أحدث الأفلام والمسلسلات', 'action': 'movies'},
        {'title': '📺 القنوات والبث المباشر', 'action': 'live'},
        {'title': '⚙️ إعدادات الإضافة', 'action': 'settings'}
    ]
    for cat in categories:
        list_item = xbmcgui.ListItem(label=cat['title'])
        list_item.setInfo('video', {'title': cat['title']})
        url = build_url(base_url, action=cat['action'])
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=(cat['action'] != 'settings'))
    xbmcplugin.endOfDirectory(handle)

def run():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
    base_url = sys.argv[0] if len(sys.argv) > 0 else f"plugin://plugin.video.mycinema/"
    params = parse_query_params(sys.argv[2] if len(sys.argv) > 2 else '')
    action = params.get('action')

    if not action:
        list_root_categories(handle, base_url)
    elif action == 'settings':
        ADDON.openSettings()
    else:
        xbmcgui.Dialog().notification(ADDON_NAME, f"تم اختيار: {action}", xbmcgui.NOTIFICATION_INFO, 3000)

if __name__ == '__main__':
    run()
