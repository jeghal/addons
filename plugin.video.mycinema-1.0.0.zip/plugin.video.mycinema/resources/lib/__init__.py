# Package initialization for plugin.video.mycinema
