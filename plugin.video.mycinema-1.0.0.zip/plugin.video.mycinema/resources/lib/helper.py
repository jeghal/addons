# -*- coding: utf-8 -*-
"""
Helper module for plugin.video.mycinema
"""
import sys
import urllib.parse

def build_url(base_url, **kwargs):
    """Safely build Kodi plugin URL with query parameters."""
    query = urllib.parse.urlencode(kwargs)
    return f"{base_url}?{query}"

def parse_query_params(param_string):
    """Parse query string into a key-value dictionary."""
    if not param_string:
        return {}
    if param_string.startswith('?'):
        param_string = param_string[1:]
    parsed = urllib.parse.parse_qs(param_string)
    return {k: v[0] if len(v) == 1 else v for k, v in parsed.items()}

def get_addon_info(addon_obj):
    """Extract standard metadata from Kodi addon object."""
    return {
        'id': addon_obj.getAddonInfo('id'),
        'name': addon_obj.getAddonInfo('name'),
        'version': addon_obj.getAddonInfo('version')
    }
