# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/),
et ce projet adhère au [Semantic Versioning](https://semver.org/lang/fr/).

## [2.1.0] - 2026-01-06

### 🎉 Ajouté - Améliorations basées sur l'analyse API réelle

- **Navigation hiérarchique complète pour Live TV**: Support complet de la structure parent_id complexe
  - Détection automatique des catégories avec sous-catégories
  - Icône 📁 pour les dossiers de catégories
  - Navigation fluide dans l'arborescence
- **Filtre parental**: Option pour masquer le contenu adulte (is_adult)
  - Paramètre configurable dans les settings
  - Filtrage automatique sur Live TV, VOD et Séries
  - Compteur de contenus filtrés dans les logs
- **Cache différencié par type de contenu**:
  - Catégories: 1 heure (changent rarement)
  - User info: 1 minute (vérification régulière)
  - Contenus: 5 minutes (défaut)
  - Paramètres configurables individuellement
- **Pagination**: Support pour affichage par lots (100 éléments par défaut)

### 🔒 Sécurité

- **HTTPS par défaut**: URL serveur configurée sur HTTPS:443
- **HTTPS obligatoire par défaut**: Option "Exiger HTTPS" activée

### ⚡ Performance

- **Optimisation du cache**: Durées adaptées au type de contenu
- **Lazy loading strict**: Évite le chargement de 16,262 chaînes ou 63,980 films d'un coup
- **Logs de cache améliorés**: Affichage de la durée de cache utilisée

### 🛠️ Amélioré

- **Routeur**: Support du paramètre parent_id pour navigation hiérarchique
- **Logs**: Messages plus détaillés pour le debugging
- **Settings**: Nouveaux paramètres pour personnalisation avancée

### 📊 Tests

- **Scripts de test API**: 3 scripts pour tester tous les endpoints
- **Analyse complète**: Documentation des réponses réelles du serveur
- **Recommandations**: Guide d'optimisation basé sur les données réelles

### 📝 Documentation

- **Guide de test API**: Instructions complètes pour tester l'API
- **Analyse API réelle**: Document détaillé avec statistiques et recommandations
- **Métriques de performance**: Temps de réponse mesurés pour chaque endpoint

## [2.0.0] - 2026-01-06

### 🎉 Ajouté

- **Architecture modulaire**: Refactorisation complète du code en modules spécialisés
  - `ui_live.py`: Gestion Live TV
  - `ui_vod.py`: Gestion VOD (Films)
  - `ui_series.py`: Gestion Séries TV
  - `ui_search.py`: Gestion Recherche
- **Cache LRU intelligent**: Implémentation d'un cache avec limite de taille configurable
- **Retry logic**: Tentatives automatiques avec backoff exponentiel pour les requêtes API
- **Validation HTTPS**: Option pour forcer l'utilisation de HTTPS
- **Paramètres de performance**: Configuration du timeout, durée du cache, et taille du cache
- **Fonction générique play_stream()**: Élimine la duplication de code
- **Documentation complète**: README détaillé avec guide d'installation et dépannage
- **Validation des réponses API**: Vérification de la validité des données reçues

### 🔒 Sécurité

- Masquage du mot de passe dans l'interface des paramètres
- Validation HTTPS optionnelle pour les connexions sécurisées
- Masquage des credentials dans tous les logs

### ⚡ Performance

- Cache LRU avec éviction automatique des entrées les plus anciennes
- Réduction de 75% de la taille du fichier ui.py (949 → ~230 lignes)
- Meilleure gestion de la mémoire avec limite configurable du cache
- Retry automatique pour améliorer la fiabilité

### 🛠️ Amélioré

- Gestion d'erreurs plus robuste avec retry logic
- Logs plus détaillés pour faciliter le débogage
- Validation des URLs de streaming
- Parsing amélioré des métadonnées (année, note, durée, casting)
- Code mieux organisé et plus maintenable

### 🐛 Corrigé

- Gestion correcte des réponses API vides ou malformées
- Meilleure gestion des timeouts réseau
- Correction de la gestion du cache (évite la croissance infinie)

### 📝 Documentation

- README.md complet avec instructions détaillées
- CHANGELOG.md pour suivre les versions
- Commentaires et docstrings améliorés dans le code

## [1.0.0] - 2025-XX-XX

### Ajouté

- Version initiale de l'addon
- Support Live TV
- Support VOD (Films)
- Support Séries TV
- Recherche de contenu
- Cache basique
- Informations utilisateur

---

## Légende

- 🎉 **Ajouté**: Nouvelles fonctionnalités
- 🔒 **Sécurité**: Améliorations de sécurité
- ⚡ **Performance**: Optimisations de performance
- 🛠️ **Amélioré**: Améliorations de fonctionnalités existantes
- 🐛 **Corrigé**: Corrections de bugs
- 📝 **Documentation**: Changements dans la documentation
- ⚠️ **Déprécié**: Fonctionnalités bientôt supprimées
- 🗑️ **Supprimé**: Fonctionnalités supprimées
