# Xtream Codes IPTV - Addon Kodi

[![Kodi Version](https://img.shields.io/badge/Kodi-19%2B-blue.svg)](https://kodi.tv/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/Version-2.0.0-orange.svg)](addon.xml)

Un addon Kodi moderne et performant pour accéder aux services IPTV via l'API Xtream Codes.

## ✨ Fonctionnalités

### 📺 Live TV

- Affichage des catégories et chaînes en direct
- Support EPG (Electronic Program Guide)
- Lecture de playlists complètes
- Ajout de chaînes à la liste de lecture Kodi

### 🎬 VOD (Films)

- Navigation par catégories hiérarchiques
- Films récemment ajoutés
- Métadonnées riches (année, note, durée, casting, synopsis)
- Artwork complet (posters, fanart)
- Recherche de films

### 📺 Séries TV

- Navigation par catégories
- Séries récemment ajoutées
- Affichage par saisons et épisodes
- Métadonnées détaillées pour chaque épisode
- Recherche de séries

### 🔍 Recherche

- Recherche de films
- Recherche de séries
- Historique de recherche

### ⚡ Performance

- Cache LRU intelligent avec limite de taille configurable
- Retry logic avec backoff exponentiel
- Timeout configurable
- Validation des réponses API

### 🔒 Sécurité

- Option HTTPS obligatoire
- Masquage des credentials dans les logs
- Validation des URLs de streaming

## 📋 Prérequis

- **Kodi** 19.x (Matrix) ou supérieur
- **Python** 3.x (inclus avec Kodi)
- Abonnement actif à un service Xtream Codes IPTV

## 🚀 Installation

### Méthode 1: Installation depuis un fichier ZIP

1. Téléchargez le fichier ZIP de l'addon
2. Dans Kodi, allez dans **Paramètres** → **Extensions**
3. Cliquez sur **Installer depuis un fichier zip**
4. Sélectionnez le fichier `plugin.video.xtream_codes_iptv-2.0.0.zip`
5. Attendez la notification de confirmation

### Méthode 2: Installation manuelle

1. Copiez le dossier `plugin.video.xtream_codes_iptv` dans:
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **Linux**: `~/.kodi/addons/`
   - **macOS**: `~/Library/Application Support/Kodi/addons/`
2. Redémarrez Kodi
3. Activez l'addon dans **Paramètres** → **Extensions** → **Mes extensions**

## ⚙️ Configuration

### Configuration initiale

1. Lancez l'addon pour la première fois
2. Allez dans **Paramètres de l'addon** (clic droit → Paramètres)
3. Configurez les paramètres suivants:

#### Onglet "Général"

- **URL du serveur**: L'URL de votre serveur Xtream Codes (ex: `http://example.com:8080`)
- **Nom d'utilisateur**: Votre nom d'utilisateur
- **Mot de passe**: Votre mot de passe
- **Exiger HTTPS**: Activez pour forcer l'utilisation de HTTPS (recommandé)

#### Onglet "Options d'affichage"

- **Nombre d'items récemment ajoutés**: Nombre de films/séries à afficher dans "Récemment ajoutés" (défaut: 100)

#### Onglet "Performance"

- **Timeout des requêtes**: Délai d'attente pour les requêtes API en secondes (défaut: 15)
- **Durée du cache**: Durée de conservation des données en cache en secondes (défaut: 300)
- **Nombre max d'entrées en cache**: Limite du cache LRU (défaut: 50)

### Paramètres recommandés

Pour une expérience optimale:

```
Timeout: 15-30 secondes (selon votre connexion)
Cache: 300-600 secondes (5-10 minutes)
Entrées cache: 50-100 (selon la RAM disponible)
```

## 📖 Utilisation

### Navigation

1. **Live TV**: Parcourez les catégories et sélectionnez une chaîne pour la regarder
2. **VOD**: Naviguez dans les catégories de films et sélectionnez un film
3. **Séries**: Choisissez une série, puis une saison, puis un épisode
4. **Recherche**: Utilisez la recherche pour trouver rapidement un contenu

### Fonctions avancées

#### Menu contextuel (clic droit)

- **Ajouter à la liste de lecture**: Ajoute le contenu à la playlist Kodi
- **Effacer le cache**: Force le rafraîchissement des données
- **Information**: Affiche les métadonnées détaillées (films/séries)

#### Playlists

- Utilisez "Lire toutes les chaînes" pour créer une playlist de toutes les chaînes d'une catégorie
- Ajoutez des contenus individuels à votre playlist via le menu contextuel

## 🔧 Dépannage

### Problèmes courants

#### "Veuillez configurer l'URL, l'utilisateur et le mot de passe"

- Vérifiez que tous les champs sont remplis dans les paramètres
- Assurez-vous qu'il n'y a pas d'espaces avant/après les valeurs

#### "Erreur de connexion"

- Vérifiez votre connexion Internet
- Vérifiez que l'URL du serveur est correcte
- Vérifiez que le serveur est accessible

#### "Erreur HTTP: 401"

- Vos identifiants sont incorrects
- Votre abonnement a peut-être expiré

#### "HTTPS est requis"

- Votre URL commence par `http://` mais vous avez activé "Exiger HTTPS"
- Changez l'URL pour `https://` ou désactivez l'option

#### Contenu ne se charge pas

- Effacez le cache via le menu principal
- Vérifiez les logs Kodi pour plus de détails

### Logs

Pour obtenir des logs détaillés:

1. Activez le debug dans Kodi: **Paramètres** → **Système** → **Journalisation** → **Activer la journalisation de débogage**
2. Reproduisez le problème
3. Consultez le fichier log:
   - **Windows**: `%APPDATA%\Kodi\kodi.log`
   - **Linux**: `~/.kodi/temp/kodi.log`
   - **macOS**: `~/Library/Logs/kodi.log`

Recherchez les lignes contenant `[Xtream Codes]`

## 🏗️ Architecture

Le code est organisé de manière modulaire:

```
plugin.video.xtream_codes_iptv/
├── addon.py                 # Point d'entrée et routeur
├── addon.xml                # Métadonnées de l'addon
├── resources/
│   ├── lib/
│   │   ├── api.py          # Gestion API avec cache LRU et retry logic
│   │   ├── utils.py        # Fonctions utilitaires
│   │   ├── ui.py           # UI core et coordination
│   │   ├── ui_live.py      # UI Live TV
│   │   ├── ui_vod.py       # UI VOD (Films)
│   │   ├── ui_series.py    # UI Séries
│   │   └── ui_search.py    # UI Recherche
│   ├── media/              # Icônes et artwork
│   └── settings.xml        # Configuration utilisateur
```

## 🤝 Contribution

Les contributions sont les bienvenues! Pour contribuer:

1. Forkez le projet
2. Créez une branche pour votre fonctionnalité (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Poussez vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

## 📝 Changelog

Voir [CHANGELOG.md](CHANGELOG.md) pour l'historique des versions.

## 📄 Licence

Ce projet est sous licence MIT - voir le fichier [LICENSE](LICENSE) pour plus de détails.

## 👤 Auteur

**Jeghal**

- GitHub: [@jeghal](https://github.com/jeghal)
- Website: [https://jeghal.github.io/addons/](https://jeghal.github.io/addons/)

## 🙏 Remerciements

- L'équipe Kodi pour leur excellent framework
- La communauté Xtream Codes
- Tous les contributeurs du projet

## ⚠️ Avertissement

Cet addon est un client pour les services Xtream Codes. Vous devez avoir un abonnement légitime à un service IPTV pour l'utiliser. L'auteur n'est pas responsable de l'utilisation que vous faites de cet addon.

---

**Note**: Cet addon nécessite un abonnement actif à un service IPTV compatible Xtream Codes.
