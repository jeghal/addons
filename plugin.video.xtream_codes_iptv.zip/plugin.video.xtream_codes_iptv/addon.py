import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.request import urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import parse_qsl, urlencode
import urllib.request
import urllib.parse
import json
from datetime import datetime

# Initialisation de l'addon et récupération des paramètres
addon = xbmcaddon.Addon()
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])
server_url = addon.getSetting('server_url').strip()
username = addon.getSetting('username').strip()
password = addon.getSetting('password').strip()

# Vérification des paramètres essentiels
if not server_url.startswith("http"):
    xbmcgui.Dialog().notification("Erreur", "L'URL du serveur est invalide.", xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()

if not server_url or not username or not password:
    xbmcgui.Dialog().notification("Xtream Codes IPTV",
                                  "Veuillez configurer l'URL du serveur, le nom d'utilisateur et le mot de passe dans les paramètres de l'addon.",
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()

# Définition des ressources graphiques
default_fanart = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/fanart.jpg'
live_icon      = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/live_icon.png'
vod_icon       = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/vod_icon.png'
series_icon    = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/series_icon.png'

# ==============================================================================
# Fonctions de base
# ==============================================================================

def notify(title, message, icon=xbmcgui.NOTIFICATION_INFO, display_time=3000):
    xbmcgui.Dialog().notification(title, message, icon, display_time)

def build_url(query):
    return __url__ + '?' + urlencode(query)

def fetch_data(endpoint):
    url = f"{server_url}/player_api.php?username={username}&password={password}&{endpoint}"
    try:
        with urlopen(url) as response:
            data = response.read().decode('utf-8')
            return json.loads(data)
    except HTTPError as e:
        notify("Xtream Codes IPTV", f"Erreur HTTP : {e.code} - {e.reason}", xbmcgui.NOTIFICATION_ERROR)
    except URLError as e:
        notify("Xtream Codes IPTV", f"Erreur de connexion : {e.reason}", xbmcgui.NOTIFICATION_ERROR)
    except json.JSONDecodeError as e:
        notify("Xtream Codes IPTV", f"Erreur de décodage JSON : {e}", xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        notify("Xtream Codes IPTV", f"Erreur : {e}", xbmcgui.NOTIFICATION_ERROR)
    return None

# ==============================================================================
# Fonctions pour le nettoyage du titre et récupération du synopsis via TMDB
# ==============================================================================

def contient_arabe(texte: str) -> bool:
    """Renvoie True si le texte contient des caractères arabes."""
    return bool(re.search(r'[\u0600-\u06FF]', texte))

def nettoie_titre(titre_brut: str) -> str:
    """
    Nettoie un titre brut en extrayant le titre principal et en ajoutant l'année si disponible.
    - Supprime les marqueurs de langue (ex: "|DE|").
    - Supprime les extensions de fichiers (ex: ".mkv").
    - Si plusieurs titres sont présents, conserve le plus pertinent.
    - Priorise les titres arabes s'ils existent.
    - Ajoute l'année entre parenthèses à la fin si elle est détectée.
    """
    if not titre_brut:
        return None

    # Remplacement des doubles `||` par un seul `|`
    titre_brut = re.sub(r'\|\|+', '|', titre_brut).strip('|').strip()

    # Suppression des marqueurs de langue au début (ex: "|DE|")
    titre_brut = re.sub(r'^\|+\s*[^\|]+\s*\|+', '', titre_brut)

    # Suppression de l'extension .mkv (insensible à la casse)
    titre_brut = re.sub(r'\.mkv$', '', titre_brut, flags=re.IGNORECASE)

    # Découpage en parties avec `|` comme séparateur
    champs = [champ.strip() for champ in titre_brut.split('|') if champ.strip()]
    if not champs:
        return None

    # Suppression de "Multi" s'il est présent
    champs = [champ for champ in champs if champ.lower() != "multi"]

    # Sauvegarde du premier élément avant suppression
    premier_element = champs[0] if champs else None

    # Suppression du premier titre s'il n'est pas en arabe et qu'il existe une alternative
    if len(champs) > 1 and not contient_arabe(champs[0]):
        champs.pop(0)

    # Vérification si après suppression il ne reste qu'une date
    if len(champs) == 1 and re.fullmatch(r'\d{4}(-\d{4})?', champs[0]) and premier_element:
        champs.insert(0, premier_element)

    titres_possibles = []
    date_year = None

    for champ in champs:
        if not champ:
            continue

        # Vérifier si le champ est une année (4 chiffres)
        if re.fullmatch(r'\d{4}', champ):
            if not date_year:
                date_year = champ
            continue

        # Ajouter aux titres possibles
        titres_possibles.append(champ)

    if not titres_possibles:
        return None

    # Filtrer les titres arabes en priorité
    titres_arabes = [t for t in titres_possibles if contient_arabe(t)]
    titre_selectionne = titres_arabes[0] if titres_arabes else titres_possibles[0]

    # Extraction et nettoyage de l’année entre parenthèses
    match_annee = re.search(r'(\d{4})', titre_selectionne)
    if match_annee and not date_year:
        date_year = match_annee.group(1)

    # Nettoyage du titre pour supprimer une éventuelle année entre parenthèses
    titre_selectionne = re.sub(r'\s*\(\d{4}\)$', '', titre_selectionne).strip()

    # Retourne le titre formaté
    return f"{titre_selectionne} ({date_year})" if date_year else titre_selectionne

def format_episode_title(series_title, episode_title):
    """
    Vérifie si le titre de l'épisode suit l'un des formats "SxxEyy", "Sxx-Epyy", "Sxx-epyy",
    "Sxx Eyy", "Sxx.Eyy" ou "SxxEyy" (sans séparateur).
    Si oui, ajoute le nom de la série devant.
    """
    episode_title = episode_title.strip()
    pattern = r"S\d{1,2}[\sE\-\.]?[eE]?[pP]?\d{1,3}"  # Prend en charge plusieurs variantes
    
    if re.fullmatch(pattern, episode_title, flags=re.IGNORECASE):
        return f"{series_title} {episode_title}"
    
    return episode_title



# ==============================================================================
# Fonctions de création d'items dans Kodi
# ==============================================================================

def add_directory_item(label, action, is_folder=True, icon=None, fanart=None, **kwargs):
    list_item = xbmcgui.ListItem(label=label)
    art = {}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        list_item.setArt(art)
    url = build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=is_folder)

# ==============================================================================
# MENU PRINCIPAL
# ==============================================================================

def show_main_menu():
    add_directory_item("Live", 'list_live_categories', icon=live_icon, fanart=default_fanart)
    add_directory_item("VOD", 'list_vod_categories', icon=vod_icon, fanart=default_fanart)
    add_directory_item("TVSHOWS", 'list_series_categories', icon=series_icon, fanart=default_fanart)
    add_directory_item("Rechercher un film", 'search_movies', icon=vod_icon, fanart=default_fanart)
    add_directory_item("Rechercher une série", 'search_series', icon=series_icon, fanart=default_fanart)
    add_directory_item("User Info", 'show_user_info', is_folder=False, icon='DefaultUser.png', fanart=default_fanart)
    xbmcplugin.endOfDirectory(__handle__)

# ==============================================================================
# LIVE
# ==============================================================================

def show_live_categories():
    categories = fetch_data('action=get_live_categories')
    if not categories:
        notify("Erreur", "Aucune catégorie Live trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return
    for category in categories:
        label = category.get('category_name', 'Inconnu')
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': live_icon, 'thumb': live_icon, 'fanart': default_fanart})
        url = build_url({'action': 'list_live_channels', 'category_id': category.get('category_id')})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_live_channels(category_id):
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return
    channels = fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        notify("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return
    # Option pour lire toutes les chaînes d'une catégorie
    list_item = xbmcgui.ListItem(label="[Lire toutes les chaînes]")
    list_item.setArt({'icon': live_icon, 'thumb': live_icon, 'fanart': default_fanart})
    url = build_url({'action': 'play_live_playlist', 'category_id': category_id})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)
    for channel in channels:
        label = channel.get('name', 'Inconnu')
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {'title': label})
        icon_channel = channel.get('stream_icon', live_icon)
        list_item.setArt({'thumb': icon_channel, 'poster': icon_channel, 'fanart': default_fanart})
        list_item.setProperty('IsPlayable', 'true')
        stream_url = f"{server_url}/live/{username}/{password}/{channel.get('stream_id')}.ts"
        url = build_url({'action': 'play_channel', 'stream_url': stream_url})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)

def play_channel(stream_url):
    if not stream_url:
        notify("Erreur", "URL de flux manquante.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)
    notify("Lecture", "Lecture de la chaîne démarrée.")

def play_live_playlist(category_id):
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return
    channels = fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        notify("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for channel in channels:
        label = channel.get('name', 'Inconnu')
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {'title': label})
        icon_channel = channel.get('stream_icon', live_icon)
        list_item.setArt({'thumb': icon_channel, 'poster': icon_channel, 'fanart': default_fanart})
        list_item.setProperty('IsPlayable', 'true')
        stream_url = f"{server_url}/live/{username}/{password}/{channel.get('stream_id')}.ts"
        playlist.add(stream_url, list_item)
    if playlist.size() > 0:
        xbmc.Player().play(playlist)
        notify("Lecture Playlist", "Lecture des chaînes démarrée.")
    else:
        notify("Erreur", "Aucune chaîne disponible.", xbmcgui.NOTIFICATION_ERROR)

# ==============================================================================
# VOD
# ==============================================================================

def show_vod_categories():
    categories = fetch_data("action=get_vod_categories")
    if not categories:
        notify("Erreur", "Aucune catégorie VOD trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return
    # Option : films récemment ajoutés
    list_item = xbmcgui.ListItem(label="Films récemment ajoutés")
    list_item.setArt({'icon': vod_icon, 'thumb': vod_icon, 'fanart': default_fanart})
    url = build_url({'action': 'list_recent_movies'})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    for category in categories:
        label = category.get('category_name', 'Inconnu')
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': vod_icon, 'thumb': vod_icon, 'fanart': default_fanart})
        url = build_url({'action': 'list_movies', 'category_id': category.get('category_id')})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_movies(category_id):
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return
    movies = fetch_data(f"action=get_vod_streams&category_id={category_id}")
    if not movies:
        notify("Erreur", "Aucun film disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return
    movies.sort(key=lambda x: int(x.get('added', 0)), reverse=True)
    add_movies_to_directory(movies)

def show_recent_movies():
    movies = fetch_data("action=get_vod_streams")
    if not movies:
        notify("Erreur", "Aucun film trouvé.", xbmcgui.NOTIFICATION_ERROR)
        return
    movies.sort(key=lambda x: int(x.get('added', 0)), reverse=True)
    movies = movies[:100]
    add_movies_to_directory(movies)

def add_movies_to_directory(movies):
    for movie in movies:
        label = movie.get('name', 'Inconnu')
        label=nettoie_titre(label)
        list_item = xbmcgui.ListItem(label=label)
        info = {
            'title': label,
            'genre': movie.get('genre', 'Inconnu'),
            'year': movie.get('year', 'Inconnu'),
            'rating': movie.get('rating', 'Inconnu'),
            'director': movie.get('director', 'Inconnu'),
            'cast': movie.get('cast', '').split(', ') if movie.get('cast') else []
        }
        list_item.setInfo('video', info)
        thumb = movie.get('stream_icon', vod_icon) or vod_icon
        list_item.setArt({
            'thumb': thumb,
            'poster': thumb,
            'fanart': movie.get('backdrop_path', default_fanart)
        })
        
        list_item.setProperty('IsPlayable', 'true')
        stream_url = f"{server_url}/movie/{username}/{password}/{movie.get('stream_id')}.{movie.get('container_extension')}"
        url = build_url({'action': 'play_movie', 'stream_url': stream_url})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)

def play_movie(stream_url):
    if not stream_url:
        notify("Erreur", "URL de flux manquante.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)
    notify("Lecture", "Lecture du film démarrée.")

def recherche_film():
    keyboard = xbmc.Keyboard("", "Entrez le titre du film")
    keyboard.doModal()
    if keyboard.isConfirmed():
        titre_film = keyboard.getText()
        films = fetch_data("action=get_vod_streams")
        if films:
            films_trouves = [film for film in films if titre_film.lower() in film.get('name', '').lower()]
            if films_trouves:
                add_movies_to_directory(films_trouves)
                notify("Recherche", f"{len(films_trouves)} film(s) trouvé(s).")
            else:
                notify("Résultat", "Aucun film trouvé.", xbmcgui.NOTIFICATION_ERROR)
        else:
            notify("Erreur", "Impossible de récupérer les films.", xbmcgui.NOTIFICATION_ERROR)
    else:
        notify("Recherche", "Recherche annulée.")

# ==============================================================================
# TVSHOWS
# ==============================================================================

def show_series_categories():
    categories = fetch_data("action=get_series_categories")
    if not categories:
        notify("Erreur", "Aucune catégorie de séries trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(label="Séries récemment ajoutées")
    list_item.setArt({'icon': series_icon, 'thumb': series_icon, 'fanart': default_fanart})
    url = build_url({'action': 'list_recent_series'})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    for category in categories:
        label = category.get('category_name', 'Inconnu')
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': series_icon, 'thumb': series_icon, 'fanart': default_fanart})
        url = build_url({'action': 'list_series', 'category_id': category.get('category_id')})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_recent_series():
    series = fetch_data("action=get_series")
    if not series:
        notify("Erreur", "Aucune série trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return
    series.sort(key=lambda x: int(x.get('last_modified', 0)), reverse=True)
    series = series[:100]
    add_series_to_directory(series)

def show_series(category_id):
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return
    series = fetch_data(f"action=get_series&category_id={category_id}")
    if not series:
        notify("Erreur", "Aucune série disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return
    series.sort(key=lambda x: int(x.get('last_modified', 0)), reverse=True)
    add_series_to_directory(series)

def add_series_to_directory(series):
    for serie in series:
        label = serie.get('name', 'Inconnu')
        label=nettoie_titre(label)
        list_item = xbmcgui.ListItem(label=label)
        info = {
            'title': label,
            'plot': serie.get('plot', 'Aucun synopsis'),
            'genre': serie.get('genre', 'Inconnu'),
            'year': serie.get('releaseDate', 'Inconnu'),
            'rating': serie.get('rating', 'Inconnu'),
            'cast': serie.get('cast', '').split(', ') if serie.get('cast') else []
        }
        list_item.setInfo('video', info)
        thumb = serie.get('cover', series_icon) or series_icon
        fanart = serie.get('backdrop_path', [default_fanart])
        list_item.setArt({
            'thumb': thumb,
            'poster': thumb,
            'fanart': fanart[0] if isinstance(fanart, list) and fanart else default_fanart
        })

        url = build_url({'action': 'list_seasons', 'series_id': serie.get('series_id')})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_seasons(series_id):
    series_info = fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        notify("Erreur", "Informations de la série introuvables.", xbmcgui.NOTIFICATION_ERROR)
        return
    seasons = series_info.get('seasons', [])
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    episodes = {int(k): v for k, v in episodes.items()}
    for season_number in sorted(episodes.keys()):
        list_item = xbmcgui.ListItem(f'Saison {season_number}')
        season_info = next((s for s in seasons if s.get('season_number') == season_number), None)
        if season_info:
            list_item.setInfo('video', {
                'title': f'Saison {season_number}',
                'plot': season_info.get('overview', 'Aucun synopsis'),
                'season': season_info.get('season_number', season_number),
                'episode': season_info.get('episode_count', 'Inconnu'),
                'rating': season_info.get('vote_average', 'Inconnu'),
                'premiered': season_info.get('air_date', 'Inconnu')
            })
            list_item.setArt({
                'thumb': season_info.get('cover', ''),
                'poster': season_info.get('cover', ''),
                'fanart': season_info.get('cover_big', default_fanart)
            })
        else:
            list_item.setInfo('video', {
                'title': f'Saison {season_number}',
                'plot': info.get('plot', 'Aucun synopsis'),
                'season': season_number
            })
            list_item.setArt({
                'thumb': info.get('cover', ''),
                'poster': info.get('cover', ''),
                'fanart': info.get('backdrop_path', [default_fanart])[0] if info.get('backdrop_path') else default_fanart
            })
        url = build_url({'action': 'list_episodes', 'series_id': series_id, 'season': season_number})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_episodes(series_id, season):
    series_info = fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        notify("Erreur", "Aucune information de série trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return
    episodes = series_info.get('episodes', {}).get(str(season), [])
    if not episodes:
        notify("Erreur", "Aucun épisode trouvé pour cette saison.", xbmcgui.NOTIFICATION_ERROR)
        return
    info = series_info.get('info', {})
    series_title = info.get('name')
    series_title=nettoie_titre(series_title)
    for episode in episodes:
        # On récupère le titre de l'épisode
        ep_title = episode.get('title', 'Inconnu')
        # Si le titre correspond à un format de type "SxxEyy" ou "Sxx-Epyy", on complète avec le nom de la série
        if series_title:
            ep_title = format_episode_title(series_title, ep_title)
        list_item = xbmcgui.ListItem(label=ep_title)
        list_item.setInfo('video', {
            'title': ep_title,
            'season': episode.get('season', 'Inconnu'),
            'episode': episode.get('episode_num', 'Inconnu'),
            'duration': episode.get('info', {}).get('duration', 'Inconnu'),
            'plot': episode.get('info', {}).get('plot', 'Aucun synopsis')
        })
        list_item.setArt({
            'thumb': episode.get('stream_icon', ''),
            'poster': info.get('cover', ''),
            'fanart': info.get('backdrop_path', [default_fanart])[0] if info.get('backdrop_path') else default_fanart
        })
        list_item.setProperty('IsPlayable', 'true')
        stream_url = f"{server_url}/series/{username}/{password}/{episode.get('id')}.{episode.get('container_extension')}"
        url = build_url({'action': 'play_episode', 'stream_url': stream_url})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)

def play_episode(stream_url):
    if not stream_url:
        notify("Erreur", "URL de flux manquante.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)
    notify("Lecture", "Lecture de l'épisode démarrée.")

def recherche_serie():
    keyboard = xbmc.Keyboard("", "Entrez le titre de la série")
    keyboard.doModal()
    if keyboard.isConfirmed():
        titre_serie = keyboard.getText()
        series = fetch_data("action=get_series")
        if series:
            series_trouvees = [s for s in series if titre_serie.lower() in s.get('name', '').lower()]
            if series_trouvees:
                add_series_to_directory(series_trouvees)
                notify("Recherche", f"{len(series_trouvees)} série(s) trouvée(s).")
            else:
                notify("Résultat", "Aucune série trouvée.", xbmcgui.NOTIFICATION_ERROR)
        else:
            notify("Erreur", "Impossible de récupérer les séries.", xbmcgui.NOTIFICATION_ERROR)
    else:
        notify("Recherche", "Recherche annulée.")

def show_user_info():
    user_info = fetch_data('action=user_info')
    if not user_info:
        notify("Erreur", "Impossible de récupérer les informations utilisateur.", xbmcgui.NOTIFICATION_ERROR)
        return
    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    exp_date = info.get('exp_date')
    if exp_date:
        exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
    message = (
        f"Nom d'utilisateur: {info.get('username', 'Inconnu')}\n"
        f"Statut: {info.get('status', 'Inconnu')}\n"
        f"Date d'expiration: {exp_date or 'Inconnu'}\n"
        f"Connexions actives: {info.get('active_cons', 'Inconnu')}\n"
        f"Connexions autorisées: {info.get('max_connections', 'Inconnu')}\n"
        f"Serveur: {server_info.get('url', 'Inconnu')}:{server_info.get('port', 'Inconnu')}\n"
        f"Protocole: {server_info.get('server_protocol', 'Inconnu')}\n"
        f"Fuseau horaire: {server_info.get('timezone', 'Inconnu')}\n"
        f"Heure actuelle: {server_info.get('time_now', 'Inconnu')}"
    )
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)

# ==============================================================================
# ROUTEUR
# ==============================================================================

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    actions = {
        None: show_main_menu,
        'list_live_categories': show_live_categories,
        'list_live_channels': lambda: show_live_channels(params.get('category_id')),
        'play_channel': lambda: play_channel(params.get('stream_url')),
        'play_live_playlist': lambda: play_live_playlist(params.get('category_id')),
        'list_vod_categories': show_vod_categories,
        'list_movies': lambda: show_movies(params.get('category_id')),
        'play_movie': lambda: play_movie(params.get('stream_url')),
        'list_recent_movies': show_recent_movies,
        'list_series_categories': show_series_categories,
        'list_series': lambda: show_series(params.get('category_id')),
        'list_recent_series': show_recent_series,
        'list_seasons': lambda: show_seasons(params.get('series_id')),
        'list_episodes': lambda: show_episodes(params.get('series_id'), params.get('season')),
        'play_episode': lambda: play_episode(params.get('stream_url')),
        'show_user_info': show_user_info,
        'search_movies': recherche_film,
        'search_series': recherche_serie
    }
    action_func = actions.get(action)
    if action_func:
        action_func()
    else:
        notify("Erreur", "Action inconnue.", xbmcgui.NOTIFICATION_ERROR)

if __name__ == "__main__":
    if len(sys.argv) > 2:
        router(sys.argv[2][1:])
    else:
        notify("Erreur", "Paramètres manquants.", xbmcgui.NOTIFICATION_ERROR)
