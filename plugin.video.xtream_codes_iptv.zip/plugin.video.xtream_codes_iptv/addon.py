import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import parse_qsl, urlencode
import json
from datetime import datetime
from time import time
import os

# Récupération des paramètres de l'addon
addon = xbmcaddon.Addon()
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])
server_url = addon.getSetting('server_url')
username = addon.getSetting('username')
password = addon.getSetting('password')

# Vérification des paramètres requis
if not server_url or not username or not password:
    xbmcgui.Dialog().notification("Xtream Codes IPTV", "Veuillez configurer l'URL du serveur, le nom d'utilisateur et le mot de passe dans les paramètres de l'addon.", xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()

def build_url(query):
    """Construire une URL compatible avec Kodi avec les paramètres donnés."""
    return __url__ + '?' + urlencode(query)

def fetch_data(endpoint):
    """Récupérer les données de l'API Xtream Codes en utilisant urllib."""
    try:
        url = f"{server_url}/player_api.php?username={username}&password={password}&{endpoint}"
        with urlopen(url) as response:
            data = response.read().decode('utf-8')
            json_data = json.loads(data)
            return json_data
    except HTTPError as e:
        xbmcgui.Dialog().notification("Xtream Codes IPTV", f"Erreur HTTP : {e.code} - {e.reason}", xbmcgui.NOTIFICATION_ERROR, 5000)
    except URLError as e:
        xbmcgui.Dialog().notification("Xtream Codes IPTV", f"Erreur de connexion : {e.reason}", xbmcgui.NOTIFICATION_ERROR, 5000)
    except json.JSONDecodeError as e:
        xbmcgui.Dialog().notification("Xtream Codes IPTV", f"Erreur de décodage JSON : {e}", xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception as e:
        xbmcgui.Dialog().notification("Xtream Codes IPTV", f"Erreur : {e}", xbmcgui.NOTIFICATION_ERROR, 5000)
    return []

def add_directory_item(label, action, is_folder=True, icon=None, fanart=None, **kwargs):
    """Ajouter un élément de répertoire à l'interface Kodi avec des icônes et des fanarts."""
    list_item = xbmcgui.ListItem(label=label)
    if icon:
        list_item.setArt({'icon': icon, 'thumb': icon})
    if fanart:
        list_item.setArt({'fanart': fanart})
    url = build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=is_folder)

def show_main_menu():
    """Afficher le menu principal avec des icônes et des fanarts."""
    add_directory_item("Live", 'list_live_categories', icon='DefaultTVShows.png', fanart='special://home/addons/plugin.video.xtream_codes_iptv/resources/media/fanart.jpg')
    add_directory_item("VOD", 'list_vod_categories', icon='DefaultMovies.png', fanart='special://home/addons/plugin.video.xtream_codes_iptv/resources/media/fanart.jpg')
    add_directory_item("TVSHOWS", 'list_series_categories', icon='DefaultTVShows.png', fanart='special://home/addons/plugin.video.xtream_codes_iptv/resources/media/fanart.jpg')
    add_directory_item("User Info", 'show_user_info', is_folder=False, icon='DefaultUser.png', fanart='special://home/addons/plugin.video.xtream_codes_iptv/resources/media/fanart.jpg')
    xbmcplugin.endOfDirectory(__handle__)

# ================================
#           LIVE
# ================================
def show_live_categories():
    """Afficher les catégories Live."""
    categories = fetch_data('action=get_live_categories')
    if not categories:
        return

    for category in categories:
        list_item = xbmcgui.ListItem(label=category['category_name'])
        list_item.setArt({'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'})
        url = build_url({'action': 'list_live_channels', 'category_id': category['category_id']})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_live_channels(category_id):
    """Afficher les chaînes d'une catégorie Live spécifique."""
    if not category_id:
        xbmcgui.Dialog().notification("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    channels = fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        return

    # Option : Lire toutes les chaînes en playlist
    list_item = xbmcgui.ListItem(label="[Lire toutes les chaînes]")
    list_item.setArt({'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'})
    url = build_url({'action': 'play_live_playlist', 'category_id': category_id})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)

    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setInfo('video', {'title': channel['name']})
        list_item.setArt({'thumb': channel.get('stream_icon', ''), 'poster': channel.get('stream_icon', '')})
        list_item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_channel', 'stream_url': f"{server_url}/live/{username}/{password}/{channel['stream_id']}.ts"})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(__handle__)

def play_channel(stream_url):
    """Lire une chaîne Live."""
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)

def play_live_playlist(category_id):
    """Lire toutes les chaînes Live d'une catégorie sous forme de playlist."""
    if not category_id:
        xbmcgui.Dialog().notification("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    channels = fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        xbmcgui.Dialog().notification("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setInfo('video', {'title': channel['name']})
        list_item.setArt({'thumb': channel.get('stream_icon', ''), 'poster': channel.get('stream_icon', '')})
        list_item.setProperty('IsPlayable', 'true')

        stream_url = f"{server_url}/live/{username}/{password}/{channel['stream_id']}.ts"
        playlist.add(stream_url, list_item)

    if playlist.size() > 0:
        player = xbmc.Player()
        player.play(playlist)
        xbmcgui.Dialog().notification("Lecture Playlist", "Lecture des chaînes démarrée.", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Erreur", "Aucune chaîne disponible.", xbmcgui.NOTIFICATION_ERROR, 3000)

# ================================
#           VOD
# ================================
def show_vod_categories():
    """Afficher les catégories VOD."""
    categories = fetch_data("action=get_vod_categories")
    
    # Option All Movies
    all_movies_item = xbmcgui.ListItem(label="All Movies")
    all_movies_item.setArt({'icon': 'DefaultMovies.png', 'thumb': 'DefaultMovies.png'})
    all_movies_url = build_url({'action': 'list_all_movies'})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=all_movies_url, listitem=all_movies_item, isFolder=True)
    
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['category_name'])
        list_item.setArt({'icon': 'DefaultMovies.png', 'thumb': 'DefaultMovies.png'})
        url = build_url({'action': 'list_movies', 'category_id': category['category_id']})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_movies(category_id):
    """Afficher les films d'une catégorie spécifique."""
    movies = fetch_data(f"action=get_vod_streams&category_id={category_id}")
    # Trier les films par date d'ajout (clé 'added') en ordre décroissant
    movies.sort(key=lambda x: int(x['added']), reverse=True)
    add_movies_to_directory(movies)

def show_all_movies():
    """Afficher tous les films."""
    movies = fetch_data("action=get_vod_streams")
    # Trier les films par date d'ajout (clé 'added') en ordre décroissant
    movies.sort(key=lambda x: int(x['added']), reverse=True)
    add_movies_to_directory(movies)

def add_movies_to_directory(movies):
    """Ajouter des films au répertoire Kodi avec des descriptions détaillées et une mise en page visuelle."""
    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie['name'])
        list_item.setInfo('video', {
            'title': movie['name'],
            'genre': movie.get('genre', 'Inconnu'),
            'year': movie.get('year', 'Inconnu'),
            'rating': movie.get('rating', 'Inconnu'),
            'director': movie.get('director', 'Inconnu'),
            'cast': movie.get('cast', [])
        })
        list_item.setArt({
            'thumb': movie.get('stream_icon', ''),
            'poster': movie.get('stream_icon', ''),
            'fanart': movie.get('backdrop_path', '')
        })
        list_item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play_movie', 'stream_url': f"{server_url}/movie/{username}/{password}/{movie['stream_id']}.{movie['container_extension']}"})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)

def play_movie(stream_url):
    """Lire un film."""
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)

# ================================
#           TVSHOWS
# ================================
def show_series_categories():
    """Afficher les catégories des séries."""
    categories = fetch_data("action=get_series_categories")
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['category_name'])
        list_item.setArt({'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'})
        url = build_url({'action': 'list_series', 'category_id': category['category_id']})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_series(category_id):
    """Afficher les séries pour une catégorie donnée."""
    series = fetch_data(f"action=get_series&category_id={category_id}")
    # Trier les series par date d'ajout (clé 'last_modified') en ordre décroissant
    series.sort(key=lambda x: int(x['last_modified']), reverse=True)
    add_series_to_directory(series)

def add_series_to_directory(series):
    """Ajouter des séries au répertoire Kodi avec des descriptions détaillées."""
    for serie in series:
        list_item = xbmcgui.ListItem(label=serie['name'])
        list_item.setInfo('video', {
            'title': serie['name'],
            'plot': serie.get('plot', 'Aucun synopsis'),
            'genre': serie.get('genre', 'Inconnu'),
            'year': serie.get('releaseDate', 'Inconnu'),
            'rating': serie.get('rating', 'Inconnu'),
            'cast': serie.get('cast', []).split(', ')if serie.get('cast') else []
        })
        list_item.setArt({
            'thumb': serie.get('cover', ''),
            'poster': serie.get('cover', ''),
            'fanart': serie.get('backdrop_path', [''])[0] if serie.get('backdrop_path') else ''
        })
        url = build_url({'action': 'list_seasons', 'series_id': serie['series_id']})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(__handle__)

def show_seasons(series_id):
    """Afficher les saisons pour une série donnée."""
    series_info = fetch_data(f"action=get_series_info&series_id={series_id}")
    seasons = series_info.get('seasons', {})
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    episodes = {int(k): v for k, v in episodes.items()}
    for season_number in episodes.keys():
        list_item = xbmcgui.ListItem(f'Saison {season_number}')
        season_info = next((season for season in seasons if season['season_number'] == season_number), None)
        
        if season_info:
            list_item.setInfo('video', {
                'title': f'Saison {season_number}',
                'plot': season_info.get('overview', 'Aucun synopsis'),
                'season': season_info.get('season_number', 'Inconnu'),
                'episode': season_info.get('episode_count', 'Inconnu'),
                'rating': season_info.get('vote_average', 'Inconnu'),
                'premiered': season_info.get('air_date', 'Inconnu')
            })
            list_item.setArt({
                'thumb': season_info.get('cover', ''),
                'poster': season_info.get('cover', ''),
                'fanart': season_info.get('cover_big', '')
            })
        else:
            list_item.setInfo('video', {
                'title': f'Saison {season_number}',
                'plot': info.get('plot', 'Aucun synopsis'),
                'season': season_number
            })
            list_item.setArt({
                'thumb': info.get('cover', ''),
                'poster': info.get('cover', ''),
                'fanart': info.get('backdrop_path', [''])[0] if info.get('backdrop_path') else ''
            })
        
        url = build_url({'action': 'list_episodes', 'series_id': series_id, 'season': season_number})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=True)
    
    xbmcplugin.endOfDirectory(__handle__)

def show_episodes(series_id, season):
    """Afficher les épisodes pour une saison donnée."""
    series_info = fetch_data(f"action=get_series_info&series_id={series_id}")
    episodes = series_info.get('episodes', {}).get(season, [])
    info = series_info.get('info', {})
    for episode in episodes:
        list_item = xbmcgui.ListItem(label=episode['title'])
        list_item.setInfo('video', {
            'title': episode['title'],
            'season': episode.get('season', 'Inconnu'),
            'episode': episode.get('episode_num', 'Inconnu'),
            'duration': episode['info'].get('duration', 'Inconnu'),
        })
        list_item.setArt({
            'thumb': episode.get('stream_icon', ''),
            'poster': info.get('cover', ''),
            'fanart': info.get('backdrop_path', [''])[0] if info.get('backdrop_path') else ''
        })
        list_item.setProperty('IsPlayable', 'true')
        stream_url = f"{server_url}/series/{username}/{password}/{episode['id']}.{episode['container_extension']}"
        url = build_url({'action': 'play_episode', 'stream_url': stream_url})
        xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)

def play_episode(stream_url):
    """Lire un épisode."""
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)

def show_user_info():
    """Afficher les informations de l'utilisateur."""
    user_info = fetch_data('action=user_info')
    if not user_info:
        return

    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    exp_date = info.get('exp_date')
    if exp_date:
        exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
    message = f"Nom d'utilisateur: {info.get('username')}\n" \
              f"Statut: {info.get('status')}\n" \
              f"Date d'expiration: {exp_date}\n" \
              f"Connexions actives: {info.get('active_cons')}\n" \
              f"Connexions autorisées: {info.get('max_connections')}\n" \
              f"Serveur: {server_info.get('url')}:{server_info.get('port')}\n" \
              f"Protocole: {server_info.get('server_protocol')}\n" \
              f"Fuseau horaire: {server_info.get('timezone')}\n" \
              f"Heure actuelle: {server_info.get('time_now')}"
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)

# ================================
#           ROUTEUR
# ================================
def router(paramstring):
    """Router les actions en fonction des paramètres."""
    params = dict(parse_qsl(paramstring))
    action = params.get('action')

    if action is None:
        show_main_menu()
    elif action == 'list_live_categories':
        show_live_categories()
    elif action == 'list_live_channels':
        category_id = params.get('category_id')
        show_live_channels(category_id)
    elif action == 'play_channel':
        stream_url = params.get('stream_url')
        play_channel(stream_url)
    elif action == 'play_live_playlist':
        category_id = params.get('category_id')
        play_live_playlist(category_id)
    elif action == 'list_vod_categories':
        show_vod_categories()
    elif action == 'list_movies':
        category_id = params.get('category_id')
        show_movies(category_id)
    elif action == 'play_movie':
        stream_url = params.get('stream_url')
        play_movie(stream_url)
    elif action == 'list_all_movies':
        show_all_movies()
    elif action == 'list_series_categories':
        show_series_categories()
    elif action == 'list_series':
        category_id = params.get('category_id')
        show_series(category_id)
    elif action == 'list_seasons':
        series_id = params.get('series_id')
        show_seasons(series_id)
    elif action == 'list_episodes':
        series_id = params.get('series_id')
        season = params.get('season')
        show_episodes(series_id, season)
    elif action == 'play_episode':
        stream_url = params.get('stream_url')
        play_episode(stream_url)
    elif action == 'show_user_info':
        show_user_info()

if __name__ == "__main__":
    router(sys.argv[2][1:])
