#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Addon Kodi pour Xtream Codes IPTV
Structure refactorisée avec gestion modulaire.
"""
import sys
import os
from urllib.parse import parse_qsl

# Ajout du chemin vers les modules
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

from resources.lib import utils
from resources.lib import api
from resources.lib import ui

def router(paramstring: str) -> None:
    """
    Route l'action en fonction des paramètres passés.
    
    Args:
        paramstring: Query string parameters from Kodi
    """
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    
    utils.log(f"Router called with action: {action}, params: {params}", utils.xbmc.LOGDEBUG)
    
    actions = {
        None: ui.show_main_menu,
        'list_live_categories': lambda: ui.show_live_categories(params.get('category_id', '0')),
        'list_live_channels': lambda: ui.show_live_channels(params.get('category_id', '')),
        'play_channel': lambda: ui.play_channel(params.get('stream_url', ''), params.get('title', ''), params.get('stream_id', ''), params.get('stream_icon', '')),
        'add_channel_to_playlist': lambda: ui.add_channel_to_playlist(params.get('stream_url', ''), params.get('label', '')),
        'play_live_playlist': lambda: ui.play_live_playlist(params.get('category_id', '')),
        'list_vod_categories': lambda: ui.show_vod_categories(params.get('category_id', '0')),
        'list_movies': lambda: ui.show_movies(params.get('category_id', '')),
        'play_movie': lambda: ui.play_movie(params.get('stream_url', ''), params.get('title', ''), params.get('stream_id', ''), params.get('stream_icon', ''), params.get('stream_fanart', ''), params.get('plot', ''), params.get('year', ''), params.get('duration', ''), params.get('rating', ''), params.get('resume_time', 0)),
        'show_movie_info': lambda: ui.show_movie_info(params.get('stream_id', '')),
        'movie_options': lambda: ui.show_movie_options(params.get('stream_url', ''), params.get('title', ''), params.get('stream_id', ''), params.get('stream_icon', ''), params.get('stream_fanart', ''), params.get('plot', ''), params.get('year', ''), params.get('duration', ''), params.get('rating', '')),
        'list_recent_movies': ui.show_recent_movies,
        'list_series_categories': ui.show_series_categories,
        'list_series': lambda: ui.show_series(params.get('category_id', '')),
        'list_recent_series': ui.show_recent_series,
        'list_seasons': lambda: ui.show_seasons(params.get('series_id', '')),
        'list_episodes': lambda: ui.show_episodes(params.get('series_id', ''), params.get('season', '')),
        'play_episode': lambda: ui.play_episode(params.get('stream_url', ''), params.get('title', ''), params.get('stream_id', ''), params.get('stream_icon', ''), params.get('stream_fanart', ''), params.get('series_id', ''), params.get('season', ''), params.get('episode_num', ''), params.get('plot', ''), params.get('duration', ''), params.get('premiered', ''), params.get('tvshowtitle', ''), params.get('resume_time', 0)),
        'show_series_info': lambda: ui.show_series_info(params.get('series_id', '')),
        'show_user_info': ui.show_user_info,
        'settings_menu': ui.show_settings_menu,
        'search_movies': ui.recherche_film,
        'search_series': ui.recherche_serie,
        'search_menu': ui.show_search_menu,
        'last_search': ui.last_search,
        'clear_cache': ui.confirm_clear_cache,
        'add_movie_to_playlist': lambda: ui.add_movie_to_playlist(params.get('stream_url', ''), params.get('label', '') or params.get('title', '')),
        'add_episode_to_playlist': lambda: ui.add_episode_to_playlist(params.get('stream_url', ''), params.get('label', '') or params.get('title', '')),
        'show_watch_history': ui.show_watch_history,
        'show_movie_history': ui.show_movie_history,
        'show_series_history': ui.show_series_history,
        'clear_history': ui.confirm_clear_history,
        'remove_from_history': lambda: ui.remove_from_history_ui(params.get('item_type', ''), params.get('item_id', '')),
        'continue_watching': ui.show_continue_watching,
        'show_continue_watching': ui.show_continue_watching, # Alias for consistency
        'play_next_from_continue': lambda: ui.play_next_from_continue(params.get('series_id', '')),
        'play_last_from_continue': lambda: ui.replay_last_from_continue(params.get('series_id', '')),
        'remove_from_continue': lambda: ui.remove_from_continue(params.get('series_id', '')),
        'clear_continue_watching': ui.confirm_clear_continue_watching
    }
    
    action_func = actions.get(action)
    if action_func:
        try:
            action_func()
        except Exception as e:
            utils.log(f"Error executing action '{action}': {e}", utils.xbmc.LOGERROR)
            utils.notify("Erreur", f"Erreur lors de l'exécution: {str(e)}", utils.xbmcgui.NOTIFICATION_ERROR)
            utils.xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
    else:
        utils.log(f"Unknown action requested: {action}", utils.xbmc.LOGWARNING)
        utils.notify("Erreur", "Action inconnue.", utils.xbmcgui.NOTIFICATION_ERROR)
        utils.xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)

def main() -> None:
    """
    Main entry point for the addon.
    Validates settings and routes to appropriate handler.
    """
    utils.log("Addon started", utils.xbmc.LOGINFO)
    
    # Validation des paramètres avant de commencer
    if not api.validate_settings():
        utils.log("Settings validation failed, prompting user configuration", utils.xbmc.LOGWARNING)
        # Ne pas quitter brutalement, mais ouvrir les paramètres
        api.ADDON.openSettings()
        # On continue pour afficher le menu (même vide/restreint) pour ne pas crasher Kodi


    if len(sys.argv) > 2:
        router(sys.argv[2][1:])
    else:
        ui.show_main_menu()

if __name__ == "__main__":
    main()