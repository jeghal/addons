#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Addon Kodi pour Xtream Codes IPTV - Version améliorée et unifiée.
Ce script gère l'affichage des menus (Live, VOD, TVshows) en utilisant une fonction
unique pour la création d'items de répertoire.
"""

import sys
import re
import json
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from urllib.request import urlopen, URLError, HTTPError
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon


# ==============================================================================
# Constantes et regex compilées
# ==============================================================================
REGEX_ARABE         = re.compile(r'[\u0600-\u06FF]')
REGEX_LANGUE        = re.compile(r'^\|+\s*[^\|]+\s*\|+')
REGEX_EXTENSION     = re.compile(r'\.mkv$', re.IGNORECASE)
REGEX_ANNEE_SIMPLE  = re.compile(r'^\d{4}$')
REGEX_ANNEE_RANGE   = re.compile(r'^\d{4}(-\d{4})?$')
REGEX_YEAR_IN_PAREN = re.compile(r'\s*\(\d{4}\)$')
REGEX_EPISODE       = re.compile(r"S\d{1,2}[\sE\-\.]?[eE]?[pP]?\d{1,3}", re.IGNORECASE)
TIMEOUT             = 10

# Ressources graphiques
DEFAULT_FANART = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/fanart.jpg'
LIVE_ICON      = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/live_icon.png'
VOD_ICON       = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/vod_icon.png'
SERIES_ICON    = 'special://home/addons/plugin.video.xtream_codes_iptv/resources/media/series_icon.png'

# ==============================================================================
# Initialisation de l'addon et récupération des paramètres
# ==============================================================================
addon = xbmcaddon.Addon()
__url__ = sys.argv[0]
try:
    __handle__ = int(sys.argv[1])
except (IndexError, ValueError):
    xbmcgui.Dialog().notification("Erreur", "Handle invalide.", xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()

server_url = addon.getSetting('server_url').strip()
username   = addon.getSetting('username').strip()
password   = addon.getSetting('password').strip()

if not server_url.startswith("http"):
    xbmcgui.Dialog().notification("Erreur", "L'URL du serveur est invalide.", xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()

if not server_url or not username or not password:
    xbmcgui.Dialog().notification("Xtream Codes IPTV",
                                  "Veuillez configurer l'URL du serveur, le nom d'utilisateur et le mot de passe dans les paramètres de l'addon.",
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
    sys.exit()

# ==============================================================================
# Fonctions utilitaires
# ==============================================================================

def notify(title: str, message: str, icon: str = xbmcgui.NOTIFICATION_INFO, display_time: int = 3000) -> None:
    """
    Affiche une notification dans Kodi et enregistre l'événement dans le log.
    """
    xbmcgui.Dialog().notification(title, message, icon, display_time)

def build_url(query: Dict[str, Any]) -> str:
    """
    Construit l'URL interne pour Kodi avec les paramètres donnés.
    """
    return f"{__url__}?{urlencode(query)}"

def fetch_data(endpoint: str) -> Optional[Dict[str, Any]]:
    """
    Récupère et décode les données JSON à partir de l'endpoint spécifié.
    """
    url = f"{server_url}/player_api.php?username={username}&password={password}&{endpoint}"
    try:
        with urlopen(url, timeout=TIMEOUT) as response:
            data = response.read().decode('utf-8')
            return json.loads(data)
    except HTTPError as e:
        error_msg = f"Erreur HTTP : {e.code} - {e.reason}"
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    except URLError as e:
        error_msg = f"Erreur de connexion : {e.reason}"
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    except json.JSONDecodeError as e:
        error_msg = f"Erreur de décodage JSON : {e}"
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        error_msg = f"Erreur : {e}"
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    return None

def contient_arabe(texte: str) -> bool:
    """
    Retourne True si le texte contient des caractères arabes.
    """
    return bool(REGEX_ARABE.search(texte))

def nettoie_titre(titre_brut: str) -> Optional[str]:
    """
    Nettoie et formate un titre brut pour obtenir un nom plus lisible.
    """
    if not titre_brut:
        return None

    # Réduire les doubles séparateurs et supprimer le marqueur de langue et l'extension .mkv
    titre_brut = re.sub(r'\|\|+', '|', titre_brut)
    pattern_combine = re.compile(r'(^\|+\s*[^\|]+\s*\|+)|(\.mkv$)', re.IGNORECASE)
    titre_brut = pattern_combine.sub('', titre_brut)
    titre_brut = titre_brut.strip('|').strip()

    champs = [champ.strip() for champ in titre_brut.split('|') if champ.strip()]
    if not champs:
        return None

    # Supprimer le marqueur "Multi"
    champs = [champ for champ in champs if champ.lower() != "multi"]
    premier_element = champs[0] if champs else None

    if len(champs) > 1 and not contient_arabe(champs[0]):
        del champs[0]

    if len(champs) == 1 and REGEX_ANNEE_RANGE.fullmatch(champs[0]) and premier_element:
        champs.insert(0, premier_element)

    titres_possibles: List[str] = []
    date_year: Optional[str] = None

    for champ in champs:
        if REGEX_ANNEE_SIMPLE.fullmatch(champ):
            if not date_year:
                date_year = champ
            continue
        titres_possibles.append(champ)

    if not titres_possibles:
        return None

    titres_arabes = (t for t in titres_possibles if contient_arabe(t))
    titre_selectionne = next(titres_arabes, titres_possibles[0])

    if not date_year:
        match_annee = REGEX_ANNEE_SIMPLE.search(titre_selectionne)
        if match_annee:
            date_year = match_annee.group()

    titre_selectionne = REGEX_YEAR_IN_PAREN.sub('', titre_selectionne).strip()

    return f"{titre_selectionne} ({date_year})" if date_year else titre_selectionne

def format_episode_title(series_title: str, episode_title: str) -> str:
    """
    Si le titre de l'épisode correspond à un format type "SxxEyy" ou similaire,
    renvoie le titre complété avec le nom de la série.
    """
    episode_title = episode_title.strip()
    if REGEX_EPISODE.fullmatch(episode_title):
        return f"{series_title} {episode_title}"
    return episode_title

# ==============================================================================
# Fonction unifiée pour ajouter un item de répertoire
# ==============================================================================

def add_directory_item(
    label: str,
    action: str,
    is_folder: bool = True,
    icon: Optional[str] = None,
    fanart: Optional[str] = None,
    info: Optional[Dict[str, Any]] = None,
    context_menu: Optional[List[Tuple[str, str]]] = None,
    is_playable: bool = False,
    **kwargs: Any
) -> None:
    """
    Ajoute un élément de répertoire générique pour tous les menus.
    
    Args:
        label (str): Le titre de l'élément.
        action (str): L'action à appeler (sera intégrée dans l'URL).
        is_folder (bool): Indique si l'élément est un dossier ou un item jouable.
        icon (Optional[str]): Chemin ou URL de l'icône de l'élément.
        fanart (Optional[str]): Chemin ou URL du fanart de l'élément.
        info (Optional[Dict[str, Any]]): Informations supplémentaires pour le mode vidéo.
        context_menu (Optional[List[Tuple[str, str]]]): Options de menu contextuel.
        is_playable (bool): Indique si l'élément est directement jouable.
        **kwargs: Paramètres supplémentaires pour la construction de l'URL.
    """
    list_item = xbmcgui.ListItem(label=label)
    art = {}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        list_item.setArt(art)
    if info:
        list_item.setInfo('video', info)
    if context_menu:
        list_item.addContextMenuItems(context_menu, replaceItems=True)
    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
    
    url = build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=__handle__, url=url, listitem=list_item, isFolder=is_folder)

# ==============================================================================
# Fonctions de navigation
# ==============================================================================

def show_main_menu() -> None:
    """
    Affiche le menu principal de l'addon.
    """
    add_directory_item("Live", 'list_live_categories', icon=LIVE_ICON, fanart=DEFAULT_FANART)
    add_directory_item("VOD", 'list_vod_categories', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("TVSHOWS", 'list_series_categories', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Rechercher un film", 'search_movies', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Rechercher une série", 'search_series', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("User Info", 'show_user_info', is_folder=False, icon='DefaultUser.png', fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(__handle__)

# --- Fonctions pour le Live ---

def show_live_categories() -> None:
    """
    Affiche les catégories Live.
    """
    categories = fetch_data('action=get_live_categories')
    if not categories:
        notify("Erreur", "Aucune catégorie Live trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return

    for category in categories:
        add_directory_item(
            label=category.get('category_name', 'Inconnu'),
            action='list_live_channels',
            is_folder=True,
            icon=LIVE_ICON,
            fanart=DEFAULT_FANART,
            category_id=category.get('category_id')
        )
    xbmcplugin.endOfDirectory(__handle__)

def show_live_channels(category_id: str) -> None:
    """
    Affiche les chaînes Live d'une catégorie donnée.
    """
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return

    channels = fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        notify("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return

    # Option : lire toutes les chaînes de la catégorie
    add_directory_item(
        label="[Lire toutes les chaînes]",
        action='play_live_playlist',
        is_folder=False,
        icon=LIVE_ICON,
        fanart=DEFAULT_FANART,
        category_id=category_id
    )

    for channel in channels:
        stream_url = f"{server_url}/live/{username}/{password}/{channel.get('stream_id')}.ts"
        add_directory_item(
            label=channel.get('name', 'Inconnu'),
            action='play_channel',
            is_folder=False,
            icon=channel.get('stream_icon', LIVE_ICON),
            fanart=DEFAULT_FANART,
            is_playable=True,
            stream_url=stream_url
        )
    xbmcplugin.endOfDirectory(__handle__)

def play_channel(stream_url: str) -> None:
    """
    Lance la lecture d'une chaîne Live.
    """
    if not stream_url:
        notify("Erreur", "URL de flux manquante.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)
    notify("Lecture", "Lecture de la chaîne démarrée.")

def play_live_playlist(category_id: str) -> None:
    """
    Lance la lecture d'une playlist regroupant toutes les chaînes d'une catégorie.
    """
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return

    channels = fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        notify("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for channel in channels:
        stream_url = f"{server_url}/live/{username}/{password}/{channel.get('stream_id')}.ts"
        li = xbmcgui.ListItem(label=channel.get('name', 'Inconnu'))
        li.setProperty('IsPlayable', 'true')
        playlist.add(stream_url, li)
    if playlist.size() > 0:
        xbmc.Player().play(playlist)
        notify("Lecture Playlist", "Lecture des chaînes démarrée.")
    else:
        notify("Erreur", "Aucune chaîne disponible.", xbmcgui.NOTIFICATION_ERROR)

# --- Fonctions pour le VOD ---

def show_vod_categories() -> None:
    """
    Affiche les catégories VOD.
    """
    categories = fetch_data("action=get_vod_categories")
    if not categories:
        notify("Erreur", "Aucune catégorie VOD trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return

    # Option : films récemment ajoutés
    add_directory_item(
        label="Films récemment ajoutés",
        action='list_recent_movies',
        is_folder=True,
        icon=VOD_ICON,
        fanart=DEFAULT_FANART
    )

    for category in categories:
        add_directory_item(
            label=category.get('category_name', 'Inconnu'),
            action='list_movies',
            is_folder=True,
            icon=VOD_ICON,
            fanart=DEFAULT_FANART,
            category_id=category.get('category_id')
        )
    xbmcplugin.endOfDirectory(__handle__)

def show_movies(category_id: str) -> None:
    """
    Affiche les films d'une catégorie donnée.
    """
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return

    movies = fetch_data(f"action=get_vod_streams&category_id={category_id}")
    if not movies:
        notify("Erreur", "Aucun film disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return

    for movie in movies:
        movie['added_int'] = int(movie.get('added', 0))
    movies.sort(key=lambda x: x['added_int'], reverse=True)
    add_movies_to_directory(movies)

def show_recent_movies() -> None:
    """
    Affiche les films récemment ajoutés.
    """
    movies = fetch_data("action=get_vod_streams")
    if not movies:
        notify("Erreur", "Aucun film trouvé.", xbmcgui.NOTIFICATION_ERROR)
        return

    for movie in movies:
        movie['added_int'] = int(movie.get('added', 0))
    movies.sort(key=lambda x: x['added_int'], reverse=True)
    movies = movies[:100]
    add_movies_to_directory(movies)

def add_movies_to_directory(movies: List[Dict[str, Any]]) -> None:
    """
    Ajoute les films à l'affichage.
    """
    for movie in movies:
        raw_label = movie.get('name', 'Inconnu')
        label = nettoie_titre(raw_label) or raw_label
        info = {
            'title': label,
            'genre': movie.get('genre', 'Inconnu'),
            'year': movie.get('year', 'Inconnu'),
            'rating': movie.get('rating', 'Inconnu'),
            'director': movie.get('director', 'Inconnu'),
            'cast': movie.get('cast', '').split(', ') if movie.get('cast') else []
        }
        thumb = movie.get('stream_icon', VOD_ICON) or VOD_ICON
        stream_url = f"{server_url}/movie/{username}/{password}/{movie.get('stream_id')}.{movie.get('container_extension')}"
        add_directory_item(
            label=label,
            action='play_movie',
            is_folder=False,
            icon=thumb,
            fanart=movie.get('backdrop_path', DEFAULT_FANART),
            info=info,
            is_playable=True,
            stream_url=stream_url
        )
    xbmcplugin.endOfDirectory(__handle__)

def play_movie(stream_url: str) -> None:
    """
    Lance la lecture d'un film.
    """
    if not stream_url:
        notify("Erreur", "URL de flux manquante.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)
    notify("Lecture", "Lecture du film démarrée.")

def recherche_film() -> None:
    """
    Recherche un film selon le titre entré par l'utilisateur.
    """
    keyboard = xbmc.Keyboard("", "Entrez le titre du film")
    keyboard.doModal()
    if keyboard.isConfirmed():
        titre_film = keyboard.getText().strip().lower()
        films = fetch_data("action=get_vod_streams")
        if films:
            films_trouves = [film for film in films if titre_film in film.get('name', '').lower()]
            if films_trouves:
                add_movies_to_directory(films_trouves)
                notify("Recherche", f"{len(films_trouves)} film(s) trouvé(s).")
            else:
                notify("Résultat", "Aucun film trouvé.", xbmcgui.NOTIFICATION_ERROR)
        else:
            notify("Erreur", "Impossible de récupérer les films.", xbmcgui.NOTIFICATION_ERROR)
    else:
        notify("Recherche", "Recherche annulée.")

# --- Fonctions pour les TVSHOWS ---

def show_series_categories() -> None:
    """
    Affiche les catégories de séries.
    """
    categories = fetch_data("action=get_series_categories")
    if not categories:
        notify("Erreur", "Aucune catégorie de séries trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return

    add_directory_item(
        label="Séries récemment ajoutées",
        action='list_recent_series',
        is_folder=True,
        icon=SERIES_ICON,
        fanart=DEFAULT_FANART
    )

    for category in categories:
        add_directory_item(
            label=category.get('category_name', 'Inconnu'),
            action='list_series',
            is_folder=True,
            icon=SERIES_ICON,
            fanart=DEFAULT_FANART,
            category_id=category.get('category_id')
        )
    xbmcplugin.endOfDirectory(__handle__)

def show_recent_series() -> None:
    """
    Affiche les séries récemment modifiées.
    """
    series = fetch_data("action=get_series")
    if not series:
        notify("Erreur", "Aucune série trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return

    for serie in series:
        serie['last_modified_int'] = int(serie.get('last_modified', 0))
    series.sort(key=lambda x: x['last_modified_int'], reverse=True)
    series = series[:100]
    add_series_to_directory(series)

def show_series(category_id: str) -> None:
    """
    Affiche les séries d'une catégorie donnée.
    """
    if not category_id:
        notify("Erreur", "ID de catégorie manquant.", xbmcgui.NOTIFICATION_ERROR)
        return

    series = fetch_data(f"action=get_series&category_id={category_id}")
    if not series:
        notify("Erreur", "Aucune série disponible dans cette catégorie.", xbmcgui.NOTIFICATION_ERROR)
        return

    for serie in series:
        serie['last_modified_int'] = int(serie.get('last_modified', 0))
    series.sort(key=lambda x: x['last_modified_int'], reverse=True)
    add_series_to_directory(series)

def add_series_to_directory(series: List[Dict[str, Any]]) -> None:
    """
    Ajoute les séries à l'affichage.
    """
    for serie in series:
        raw_label = serie.get('name', 'Inconnu')
        label = nettoie_titre(raw_label) or raw_label
        info = {
            'title': label,
            'plot': serie.get('plot', 'Aucun synopsis'),
            'genre': serie.get('genre', 'Inconnu'),
            'year': serie.get('releaseDate', 'Inconnu'),
            'rating': serie.get('rating', 'Inconnu'),
            'cast': serie.get('cast', '').split(', ') if serie.get('cast') else []
        }
        fanart = (serie.get('backdrop_path', [DEFAULT_FANART])[0]
                  if isinstance(serie.get('backdrop_path'), list) and serie.get('backdrop_path')
                  else DEFAULT_FANART)
        add_directory_item(
            label=label,
            action='list_seasons',
            is_folder=True,
            icon=serie.get('cover', SERIES_ICON) or SERIES_ICON,
            fanart=fanart,
            info=info,
            series_id=serie.get('series_id')
        )
    xbmcplugin.endOfDirectory(__handle__)

def show_seasons(series_id: str) -> None:
    # Affiche les saisons d'une série.
    
    series_info = fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        notify("Erreur", "Informations de la série introuvables.", xbmcgui.NOTIFICATION_ERROR)
        return

    seasons = series_info.get('seasons', [])
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})

    # Création d'un dictionnaire pour un accès rapide aux saisons
    saisons_dict = {s.get('season_number'): s for s in seasons}
    episodes = {int(k): v for k, v in episodes.items()}

    for season_number in sorted(episodes.keys()):
        # Pour chaque saison, créer un item de répertoire
        season_info = saisons_dict.get(season_number)
        if season_info:
            season_details = {
                'title': f'Saison {season_number}',
                'plot': season_info.get('overview', 'Aucun synopsis'),
                'season': season_info.get('season_number', season_number),
                'episode': season_info.get('episode_count', 'Inconnu'),
                'rating': season_info.get('vote_average', 'Inconnu'),
                'premiered': season_info.get('air_date', 'Inconnu')
            }
            art_icon = season_info.get('cover', '')
            art_fanart = season_info.get('cover_big', DEFAULT_FANART)
        else:
            season_details = {
                'title': f'Saison {season_number}',
                'plot': info.get('plot', 'Aucun synopsis'),
                'season': season_number
            }
            art_icon = info.get('cover', '')
            art_fanart = info.get('backdrop_path', [DEFAULT_FANART])[0] if info.get('backdrop_path') else DEFAULT_FANART

        add_directory_item(
            label=f'Saison {season_number}',
            action='list_episodes',
            is_folder=True,
            icon=art_icon,
            fanart=art_fanart,
            info=season_details,
            series_id=series_id,
            season=season_number
        )
    xbmcplugin.endOfDirectory(__handle__)

def show_episodes(series_id: str, season: str) -> None:
    """
    Affiche les épisodes d'une saison donnée pour une série.
    """
    series_info = fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        notify("Erreur", "Aucune information de série trouvée.", xbmcgui.NOTIFICATION_ERROR)
        return

    episodes = series_info.get('episodes', {}).get(str(season), [])
    if not episodes:
        notify("Erreur", "Aucun épisode trouvé pour cette saison.", xbmcgui.NOTIFICATION_ERROR)
        return

    info = series_info.get('info', {})
    series_title = nettoie_titre(info.get('name', 'Inconnu')) or info.get('name', 'Inconnu')

    for episode in episodes:
        ep_title = episode.get('title', 'Inconnu')
        # Compléter le titre de l'épisode si besoin
        ep_title = format_episode_title(series_title, ep_title)
        add_directory_item(
            label=ep_title,
            action='play_episode',
            is_folder=False,
            icon=info.get('cover', ''),
            fanart=info.get('backdrop_path', [DEFAULT_FANART])[0] if info.get('backdrop_path') else DEFAULT_FANART,
            info={
                'title': ep_title,
                'season': episode.get('season', 'Inconnu'),
                'episode': episode.get('episode_num', 'Inconnu'),
                'duration': episode.get('info', {}).get('duration', 'Inconnu'),
                'plot': episode.get('info', {}).get('plot', 'Aucun synopsis')
            },
            is_playable=True,
            stream_url=f"{server_url}/series/{username}/{password}/{episode.get('id')}.{episode.get('container_extension')}"
        )
    xbmcplugin.endOfDirectory(__handle__)

def play_episode(stream_url: str) -> None:
    """
    Lance la lecture d'un épisode.
    """
    if not stream_url:
        notify("Erreur", "URL de flux manquante.", xbmcgui.NOTIFICATION_ERROR)
        return
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(__handle__, True, list_item)
    notify("Lecture", "Lecture de l'épisode démarrée.")

def recherche_serie() -> None:
    """
    Recherche une série selon le titre entré par l'utilisateur.
    """
    keyboard = xbmc.Keyboard("", "Entrez le titre de la série")
    keyboard.doModal()
    if keyboard.isConfirmed():
        titre_serie = keyboard.getText().strip().lower()
        series = fetch_data("action=get_series")
        if series:
            series_trouvees = [s for s in series if titre_serie in s.get('name', '').lower()]
            if series_trouvees:
                add_series_to_directory(series_trouvees)
                notify("Recherche", f"{len(series_trouvees)} série(s) trouvée(s).")
            else:
                notify("Résultat", "Aucune série trouvée.", xbmcgui.NOTIFICATION_ERROR)
        else:
            notify("Erreur", "Impossible de récupérer les séries.", xbmcgui.NOTIFICATION_ERROR)
    else:
        notify("Recherche", "Recherche annulée.")

def show_user_info() -> None:
    """
    Affiche les informations utilisateur et du serveur.
    """
    user_info = fetch_data('action=user_info')
    if not user_info:
        notify("Erreur", "Impossible de récupérer les informations utilisateur.", xbmcgui.NOTIFICATION_ERROR)
        return

    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    exp_date = info.get('exp_date')
    if exp_date:
        exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
    message = (
        f"Nom d'utilisateur: {info.get('username', 'Inconnu')}\n"
        f"Statut: {info.get('status', 'Inconnu')}\n"
        f"Date d'expiration: {exp_date or 'Inconnu'}\n"
        f"Connexions actives: {info.get('active_cons', 'Inconnu')}\n"
        f"Connexions autorisées: {info.get('max_connections', 'Inconnu')}\n"
        f"Serveur: {server_info.get('url', 'Inconnu')}:{server_info.get('port', 'Inconnu')}\n"
        f"Protocole: {server_info.get('server_protocol', 'Inconnu')}\n"
        f"Fuseau horaire: {server_info.get('timezone', 'Inconnu')}\n"
        f"Heure actuelle: {server_info.get('time_now', 'Inconnu')}"
    )
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)

# ==============================================================================
# Router et Point d'entrée
# ==============================================================================

def router(paramstring: str) -> None:
    """
    Route l'action en fonction des paramètres passés.
    """
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    actions = {
        None: show_main_menu,
        'list_live_categories': show_live_categories,
        'list_live_channels': lambda: show_live_channels(params.get('category_id', '')),
        'play_channel': lambda: play_channel(params.get('stream_url', '')),
        'play_live_playlist': lambda: play_live_playlist(params.get('category_id', '')),
        'list_vod_categories': show_vod_categories,
        'list_movies': lambda: show_movies(params.get('category_id', '')),
        'play_movie': lambda: play_movie(params.get('stream_url', '')),
        'list_recent_movies': show_recent_movies,
        'list_series_categories': show_series_categories,
        'list_series': lambda: show_series(params.get('category_id', '')),
        'list_recent_series': show_recent_series,
        'list_seasons': lambda: show_seasons(params.get('series_id', '')),
        'list_episodes': lambda: show_episodes(params.get('series_id', ''), params.get('season', '')),
        'play_episode': lambda: play_episode(params.get('stream_url', '')),
        'show_user_info': show_user_info,
        'search_movies': recherche_film,
        'search_series': recherche_serie
    }
    action_func = actions.get(action)
    if action_func:
        action_func()
    else:
        notify("Erreur", "Action inconnue.", xbmcgui.NOTIFICATION_ERROR)

def main() -> None:
    """
    Point d'entrée principal de l'addon.
    """
    if len(sys.argv) > 2:
        router(sys.argv[2][1:])
    else:
        notify("Erreur", "Paramètres manquants.", xbmcgui.NOTIFICATION_ERROR)

if __name__ == "__main__":
    main()
