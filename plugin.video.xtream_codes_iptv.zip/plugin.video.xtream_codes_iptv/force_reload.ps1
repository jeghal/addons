#!/usr/bin/env pwsh
# Script pour forcer le rechargement de l'addon Kodi

Write-Host "=== Nettoyage et rechargement de l'addon Kodi ===" -ForegroundColor Cyan

# 1. Supprimer les fichiers cache Python
Write-Host "`n1. Suppression des fichiers cache Python (.pyc et __pycache__)..." -ForegroundColor Yellow
Get-ChildItem -Path "." -Include "*.pyc" -Recurse -Force | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem -Path "." -Include "__pycache__" -Directory -Recurse -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "   Cache Python nettoyé ✓" -ForegroundColor Green

# 2. Incrémenter la version de l'addon pour forcer le rechargement
Write-Host "`n2. Incrémentation de la version de l'addon..." -ForegroundColor Yellow
$addonXml = "addon.xml"
if (Test-Path $addonXml) {
    $content = Get-Content $addonXml -Raw
    if ($content -match 'version="(\d+)\.(\d+)\.(\d+)"') {
        $major = $matches[1]
        $minor = $matches[2]
        $patch = [int]$matches[3] + 1
        $newVersion = "$major.$minor.$patch"
        $content = $content -replace 'version="\d+\.\d+\.\d+"', "version=`"$newVersion`""
        Set-Content -Path $addonXml -Value $content -NoNewline
        Write-Host "   Version mise à jour: $newVersion ✓" -ForegroundColor Green
    }
} else {
    Write-Host "   addon.xml non trouvé !" -ForegroundColor Red
}

Write-Host "`n=== Terminé ===" -ForegroundColor Cyan
Write-Host "`nProchaines étapes:" -ForegroundColor Yellow
Write-Host "1. Fermez complètement Kodi (Alt+F4 ou Quitter)" -ForegroundColor White
Write-Host "2. Relancez Kodi" -ForegroundColor White
Write-Host "3. Allez dans l'addon et testez un épisode" -ForegroundColor White
Write-Host "`nAppuyez sur une touche pour continuer..."
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
