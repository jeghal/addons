
import sys
import os
import json
import unittest
from unittest.mock import MagicMock, patch

# Mock xbmc modules
sys.modules['xbmc'] = MagicMock()
sys.modules['xbmcaddon'] = MagicMock()
sys.modules['xbmcvfs'] = MagicMock()
sys.modules['xbmcgui'] = MagicMock()

# Setup mocks before importing local modules
import xbmc
import xbmcaddon
import xbmcvfs

# Mock Addon and Profile Path
mock_addon = MagicMock()
xbmcaddon.Addon.return_value = mock_addon
mock_addon.getAddonInfo.return_value = "."

# Mock File Operations
mock_files = {}

def mock_exists(path):
    return path in mock_files

def mock_mkdirs(path):
    pass

def mock_open(file, mode='r', *args, **kwargs):
    class MockFile:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self): return mock_files.get(file, "")
        def write(self, data): mock_files[file] = data
    return MockFile()

xbmcvfs.exists.side_effect = mock_exists
xbmcvfs.mkdirs.side_effect = mock_mkdirs
xbmcvfs.translatePath.side_effect = lambda x: x

# Check if continue_watching.py exists in the expected path
current_dir = os.getcwd()
sys.path.append(current_dir)

# Now import the module to test
# We need to manually point to the file location or ensure PYTHONPATH is set
# Assuming we are running this from the project root

from resources.lib import continue_watching

class TestContinueWatching(unittest.TestCase):
    
    def setUp(self):
        mock_files.clear()
        # Reset internal module state if necessary
        
    def test_save_and_load(self):
        # Test data
        data = {
            "series_123": {
                "series_id": "series_123",
                "series_name": "Test Series",
                "last_watched": {
                    "season": 1,
                    "episode": 1,
                    "timestamp": "2026-01-01T12:00:00"
                }
            }
        }
        
        # Save
        with patch('builtins.open', side_effect=mock_open):
            continue_watching.save_continue_watching(data)
            
        # Verify file content
        self.assertIn('continue_watching.json', mock_files)
        
        # Load
        with patch('builtins.open', side_effect=mock_open):
            loaded_data = continue_watching.load_continue_watching()
            
        self.assertEqual(loaded_data, data)

    def test_update_progress(self):
        # Initial empty state
        with patch('builtins.open', side_effect=mock_open):
             continue_watching.update_progress(
                series_id="123",
                series_name="My Series",
                season=1,
                episode=5,
                title="Episode 5",
                icon="icon.png"
            )
            
        # Verify
        with patch('builtins.open', side_effect=mock_open):
            data = continue_watching.load_continue_watching()
            
        self.assertIn("123", data)
        self.assertEqual(data["123"]["last_watched"]["episode"], 5)
        self.assertEqual(data["123"]["series_name"], "My Series")

if __name__ == '__main__':
    unittest.main()
