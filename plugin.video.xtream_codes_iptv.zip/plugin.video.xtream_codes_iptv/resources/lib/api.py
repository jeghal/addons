import json
import socket
import sqlite3
import os
import time
from urllib.request import urlopen, Request, URLError, HTTPError
from typing import Optional, Dict, Any, Union

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from resources.lib.utils import notify, log, mask_credentials

# Settings
ADDON = xbmcaddon.Addon()

class Settings:
    """
    Centralized settings management for the addon.
    """
    def __init__(self):
        self.addon = ADDON
        self.reload()

    def reload(self):
        """Reload settings from the addon configuration."""
        self.server_url = self.addon.getSetting('server_url').strip()
        self.username = self.addon.getSetting('username').strip()
        self.password = self.addon.getSetting('password').strip()
        
        self.timeout = self._get_int_setting('timeout', 15)
        self.cache_duration = self._get_int_setting('cache_duration', 300)
        self.cache_categories_duration = self._get_int_setting('cache_categories_duration', 3600)
        self.cache_user_info_duration = self._get_int_setting('cache_user_info_duration', 60)
        self.max_cache_entries = self._get_int_setting('max_cache_entries', 50)
        
        self.require_https = self.addon.getSetting('require_https') == 'true'
        self.hide_adult_content = self.addon.getSetting('hide_adult_content') == 'true'

    def _get_int_setting(self, setting_id: str, default: int) -> int:
        try:
            val = self.addon.getSetting(setting_id)
            return int(val) if val else default
        except (ValueError, TypeError):
            return default

    def validate(self) -> bool:
        """Validate critical settings."""
        if not self.server_url or not self.username or not self.password:
            log("Settings validaton failed: Missing credentials", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Xtream Codes IPTV",
                                          "Veuillez configurer l'URL, l'utilisateur et le mot de passe.",
                                          xbmcgui.NOTIFICATION_ERROR, 5000)
            return False

        if not self.server_url.startswith("http"):
             log(f"Settings validation failed: Invalid server URL: {self.server_url}", xbmc.LOGWARNING)
             xbmcgui.Dialog().notification("Erreur", "L'URL du serveur est invalide (doit commencer par http).", xbmcgui.NOTIFICATION_ERROR, 5000)
             return False
        
        if self.require_https and not self.server_url.startswith("https://"):
            log(f"Settings validation failed: HTTPS required but URL is HTTP: {self.server_url}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Erreur de sécurité", "HTTPS est requis dans les paramètres. Veuillez utiliser une URL HTTPS.", xbmcgui.NOTIFICATION_ERROR, 5000)
            return False
            
        return True

# Singleton instance
_settings = Settings()

# Backward compatibility / module level access if needed
SERVER_URL = _settings.server_url
USERNAME = _settings.username
PASSWORD = _settings.password
REQUIRE_HTTPS = _settings.require_https
HIDE_ADULT_CONTENT = _settings.hide_adult_content

def get_server_url(): return _settings.server_url
def get_username(): return _settings.username
def get_password(): return _settings.password


class PersistentCache:
    """
    Persistent cache using SQLite database.
    Stores data in addon profile directory to survive restarts.
    """
    def __init__(self):
        profile_path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdirs(profile_path)
        self.db_path = os.path.join(profile_path, 'cache.db')
        self._init_db()
    
    def _get_connection(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS cache (
                        key TEXT PRIMARY KEY,
                        value TEXT,
                        expires_at REAL
                    )
                ''')
                # Index for expiry cleanup
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)')
                conn.commit()
        except Exception as e:
            log(f"Cache DB Init Error: {e}", xbmc.LOGERROR)

    def get(self, key: str) -> Optional[Any]:
        """Get item from cache if not expired."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Clean expired first (lazy cleanup)
                now = time.time()
                cursor.execute('DELETE FROM cache WHERE expires_at < ?', (now,))
                
                cursor.execute('SELECT value FROM cache WHERE key = ?', (key,))
                row = cursor.fetchone()
                
                if row:
                    return json.loads(row[0])
            return None
        except Exception as e:
            log(f"Cache Get Error: {e}", xbmc.LOGERROR)
            return None
    
    def set(self, key: str, value: Any, duration: int) -> None:
        """Set item in cache with duration in seconds."""
        try:
            expires_at = time.time() + duration
            value_json = json.dumps(value)
            
            with self._get_connection() as conn:
                 conn.execute('REPLACE INTO cache (key, value, expires_at) VALUES (?, ?, ?)', 
                               (key, value_json, expires_at))
        except Exception as e:
            log(f"Cache Set Error: {e}", xbmc.LOGERROR)
    
    def clear(self) -> int:
        """Clear all cache entries."""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM cache')
                return cursor.rowcount
        except Exception as e:
            log(f"Cache Clear Error: {e}", xbmc.LOGERROR)
            return 0
    
    def __len__(self) -> int:
        try:
             with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT COUNT(*) FROM cache')
                row = cursor.fetchone()
                return row[0] if row else 0
        except Exception as e:
            log(f"Cache checking length Error: {e}", xbmc.LOGERROR)
            return 0

_data_cache = PersistentCache()

def validate_settings() -> bool:
    """
    Validate addon settings before making API calls.
    
    Returns:
        True if settings are valid, False otherwise
    """
    _settings.reload()
    # Update globals for compatibility
    global SERVER_URL, USERNAME, PASSWORD, REQUIRE_HTTPS, HIDE_ADULT_CONTENT
    SERVER_URL = _settings.server_url
    USERNAME = _settings.username
    PASSWORD = _settings.password
    REQUIRE_HTTPS = _settings.require_https
    HIDE_ADULT_CONTENT = _settings.hide_adult_content
    
    return _settings.validate()


def fetch_data(endpoint: str, use_cache: bool = True, max_retries: int = 3, cache_duration: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """
    Récupère et décode les données JSON à partir de l'endpoint spécifié.
    Utilise un cache LRU pour améliorer les performances.
    Implémente retry logic avec backoff exponentiel.
    
    Args:
        endpoint: API endpoint to fetch (e.g., "action=get_live_categories")
        use_cache: Whether to use cached data if available
        max_retries: Maximum number of retry attempts (default: 3)
        cache_duration: Custom cache duration in seconds (None = use default)
    
    Returns:
        Parsed JSON data or None if error occurs
    """
    global _data_cache
    
    # Determined cache duration
    if cache_duration is None:
        if 'categories' in endpoint:
            cache_duration = _settings.cache_categories_duration
        elif endpoint == '' or 'user_info' in endpoint:
            cache_duration = _settings.cache_user_info_duration
        elif 'get_vod_info' in endpoint or 'get_series_info' in endpoint:
            cache_duration = 7200  # 2 hours for detailed metadata
        else:
            cache_duration = _settings.cache_duration
    
    # Check cache
    if use_cache:
        cached_data = _data_cache.get(endpoint)
        if cached_data:
            log(f"Using cached data for endpoint: {endpoint} (persistent cache)", xbmc.LOGDEBUG)
            return cached_data
    
    # Prepare Request
    url = f"{_settings.server_url}/player_api.php?username={_settings.username}&password={_settings.password}&{endpoint}"
    masked_url = mask_credentials(url, _settings.username, _settings.password)
    
    headers = {'User-Agent': 'Kodi Xtream Codes Addon'}
    
    # Retry Loop
    for attempt in range(max_retries):
        try:
            log(f"Fetching data from: {masked_url} (attempt {attempt + 1}/{max_retries})", xbmc.LOGDEBUG)
            
            req = Request(url, headers=headers)
            with urlopen(req, timeout=_settings.timeout) as response:
                data = response.read().decode('utf-8')
                
                if not data or not data.strip():
                    raise ValueError("Empty response from server")
                
                result = json.loads(data)
                
                if not isinstance(result, (dict, list)):
                    raise ValueError(f"Invalid response type: {type(result)}")
                
                # Cache result
                if use_cache:
                    _data_cache.set(endpoint, result, cache_duration)
                    log(f"Data cached for endpoint: {endpoint} (duration: {cache_duration}s)", xbmc.LOGDEBUG)
                    
                log(f"Successfully fetched data for endpoint: {endpoint}", xbmc.LOGDEBUG)
                return result
                
        except (socket.gaierror, URLError) as e:
            # Handle DNS/URL errors
            is_dns = isinstance(e, socket.gaierror) or (isinstance(e, URLError) and isinstance(e.reason, socket.gaierror))
            
            if is_dns:
                log(f"DNS Error for {masked_url}: {e}", xbmc.LOGERROR)
                if attempt == max_retries - 1:
                    notify("Erreur de connexion", "Serveur introuvable. Vérifiez l'URL.", xbmcgui.NOTIFICATION_ERROR)
            else:
                log(f"Connection/URL Error for {masked_url}: {e}", xbmc.LOGERROR)
                if attempt == max_retries - 1:
                     # Check if it's a timeout wrapped in URLError
                     if isinstance(e, URLError) and isinstance(e.reason, (TimeoutError, socket.timeout)):
                         notify("Timeout", "Le serveur est trop lent à répondre.", xbmcgui.NOTIFICATION_ERROR)
                     else:
                         notify("Erreur de connexion", "Impossible de contacter le serveur.", xbmcgui.NOTIFICATION_ERROR)

        except (ConnectionRefusedError, ConnectionResetError) as e:
            log(f"Connection Error for {masked_url}: {e}", xbmc.LOGERROR)
            if attempt == max_retries - 1:
                 notify("Erreur de connexion", "Connexion refusée par le serveur.", xbmcgui.NOTIFICATION_ERROR)

        except (TimeoutError, socket.timeout) as e:
            log(f"Timeout Error for {masked_url}: {e}", xbmc.LOGERROR)
            if attempt == max_retries - 1:
                 notify("Timeout", "Le serveur est trop lent à répondre.", xbmcgui.NOTIFICATION_ERROR)

        except HTTPError as e:
            msg = f"Erreur HTTP : {e.code} - {e.reason}"
            log(f"HTTP Error for {masked_url}: {msg}", xbmc.LOGERROR)
            
            # Don't retry on 4xx
            if 400 <= e.code < 500:
                notify("Xtream Codes IPTV", msg, xbmcgui.NOTIFICATION_ERROR)
                return None
            
            if attempt == max_retries - 1:
                notify("Xtream Codes IPTV", msg, xbmcgui.NOTIFICATION_ERROR)
                
        except json.JSONDecodeError as e:
            log(f"JSON Decode Error for {masked_url}: {e}", xbmc.LOGERROR)
            return None # Don't retry
            
        except ValueError as e:
            log(f"Validation Error for {masked_url}: {e}", xbmc.LOGERROR)
            return None # Don't retry
            
        except Exception as e:
            log(f"Unexpected error for {masked_url}: {e}", xbmc.LOGERROR)
            if attempt == max_retries - 1:
                notify("Xtream Codes IPTV", f"Erreur : {e}", xbmcgui.NOTIFICATION_ERROR)
        
        # Exponential backoff if we are going to retry
        if attempt < max_retries - 1:
            wait_time = 2 ** attempt
            log(f"Retrying in {wait_time} seconds...", xbmc.LOGDEBUG)
            time.sleep(wait_time)
    
    return None

def filter_adult_content(items: list) -> list:
    """
    Filtre le contenu adulte si l'option est activée.
    
    Args:
        items: Liste d'éléments à filtrer
    
    Returns:
        Liste filtrée (sans contenu adulte si option activée)
    """
    if not _settings.hide_adult_content:
        return items
    
    filtered = [item for item in items if not item.get('is_adult', 0)]
    
    if len(filtered) < len(items):
        removed = len(items) - len(filtered)
        log(f"Filtered {removed} adult content items", xbmc.LOGDEBUG)
    
    return filtered

def clear_cache() -> None:
    """
    Vide le cache des données API.
    Utile pour forcer le rafraîchissement des données.
    """
    global _data_cache
    cache_size = len(_data_cache)
    _data_cache.clear()
    log(f"Cache cleared: {cache_size} entries removed", xbmc.LOGINFO)
    notify("Cache", "Cache vidé avec succès.")

def build_stream_url(stream_type: str, stream_id: Union[str, int], extension: Optional[str] = None) -> str:
    """
    Constructs a playable stream URL.
    
    Args:
        stream_type: 'live', 'movie', or 'series'
        stream_id: The ID of the stream
        extension: Optional file extension (e.g., 'ts', 'mp4', 'mkv'). 
                   If None, defaults based on type: 'live' -> 'ts', others -> 'mp4'
    """
    # Normalize types
    if stream_type == 'episode':
        stream_type = 'series'
        
    # Default extensions
    if not extension:
        extension = 'ts' if stream_type == 'live' else 'mp4'
        
    return f"{_settings.server_url}/{stream_type}/{_settings.username}/{_settings.password}/{stream_id}.{extension}"
