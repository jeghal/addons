import json
import sqlite3
import os
import xbmcgui
import xbmcaddon
import xbmcvfs
import xbmc
import time
from urllib.request import urlopen, Request, URLError, HTTPError
from datetime import datetime
from typing import Optional, Dict, Any, Tuple
from collections import OrderedDict

from resources.lib.utils import notify, log, mask_credentials

# Settings
ADDON = xbmcaddon.Addon()
SERVER_URL = ADDON.getSetting('server_url').strip()
USERNAME = ADDON.getSetting('username').strip()
PASSWORD = ADDON.getSetting('password').strip()

# Configurable settings with defaults
try:
    TIMEOUT = int(ADDON.getSetting('timeout')) if ADDON.getSetting('timeout') else 15
except (ValueError, TypeError):
    TIMEOUT = 15

try:
    CACHE_DURATION = int(ADDON.getSetting('cache_duration')) if ADDON.getSetting('cache_duration') else 300
except (ValueError, TypeError):
    CACHE_DURATION = 300  # 5 minutes

try:
    CACHE_CATEGORIES_DURATION = int(ADDON.getSetting('cache_categories_duration')) if ADDON.getSetting('cache_categories_duration') else 3600
except (ValueError, TypeError):
    CACHE_CATEGORIES_DURATION = 3600  # 1 hour

try:
    CACHE_USER_INFO_DURATION = int(ADDON.getSetting('cache_user_info_duration')) if ADDON.getSetting('cache_user_info_duration') else 60
except (ValueError, TypeError):
    CACHE_USER_INFO_DURATION = 60  # 1 minute

try:
    MAX_CACHE_ENTRIES = int(ADDON.getSetting('max_cache_entries')) if ADDON.getSetting('max_cache_entries') else 50
except (ValueError, TypeError):
    MAX_CACHE_ENTRIES = 50

REQUIRE_HTTPS = ADDON.getSetting('require_https') == 'true'
HIDE_ADULT_CONTENT = ADDON.getSetting('hide_adult_content') == 'true'

# Persistent Cache implementation using SQLite
class PersistentCache:
    """
    Persistent cache using SQLite database.
    Stores data in addon profile directory to survive restarts.
    """
    def __init__(self):
        profile_path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdirs(profile_path)
        self.db_path = os.path.join(profile_path, 'cache.db')
        self._init_db()
    
    def _init_db(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    expires_at REAL
                )
            ''')
            # Index for expiry cleanup
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)')
            conn.commit()
            conn.close()
        except Exception as e:
            log(f"Cache DB Init Error: {e}", xbmc.LOGERROR)

    def get(self, key: str) -> Optional[Any]:
        """Get item from cache if not expired."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Clean expired first (lazy cleanup)
            now = time.time()
            cursor.execute('DELETE FROM cache WHERE expires_at < ?', (now,))
            if cursor.rowcount > 0:
                conn.commit()
            
            cursor.execute('SELECT value FROM cache WHERE key = ?', (key,))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return json.loads(row[0])
            return None
        except Exception as e:
            log(f"Cache Get Error: {e}", xbmc.LOGERROR)
            return None
    
    def set(self, key: str, value: Any, duration: int) -> None:
        """Set item in cache with duration in seconds."""
        try:
            expires_at = time.time() + duration
            value_json = json.dumps(value)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('REPLACE INTO cache (key, value, expires_at) VALUES (?, ?, ?)', 
                           (key, value_json, expires_at))
            conn.commit()
            conn.close()
        except Exception as e:
            log(f"Cache Set Error: {e}", xbmc.LOGERROR)
    
    def clear(self) -> int:
        """Clear all cache entries."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('DELETE FROM cache')
            count = cursor.rowcount
            conn.commit()
            conn.close()
            return count
        except Exception as e:
            log(f"Cache Clear Error: {e}", xbmc.LOGERROR)
            return 0
    
    def __len__(self) -> int:
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM cache')
            row = cursor.fetchone()
            conn.close()
            return row[0] if row else 0
        except:
            return 0

_data_cache = PersistentCache()

def validate_settings() -> bool:
    """
    Validate addon settings before making API calls.
    
    Returns:
        True if settings are valid, False otherwise
    """
    if not SERVER_URL or not USERNAME or not PASSWORD:
        log("Settings validation failed: Missing credentials", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Xtream Codes IPTV",
                                      "Veuillez configurer l'URL, l'utilisateur et le mot de passe.",
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        return False
    
    if not SERVER_URL.startswith("http"):
        log(f"Settings validation failed: Invalid server URL: {SERVER_URL}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Erreur", "L'URL du serveur est invalide (doit commencer par http).", xbmcgui.NOTIFICATION_ERROR, 5000)
        return False
    
    # Validate HTTPS requirement
    if REQUIRE_HTTPS and not SERVER_URL.startswith("https://"):
        log(f"Settings validation failed: HTTPS required but URL is HTTP: {SERVER_URL}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Erreur de sécurité", "HTTPS est requis dans les paramètres. Veuillez utiliser une URL HTTPS.", xbmcgui.NOTIFICATION_ERROR, 5000)
        return False
    
    log("Settings validated successfully", xbmc.LOGDEBUG)
    return True

def get_server_url():
    return SERVER_URL

def get_username():
    return USERNAME

def get_password():
    return PASSWORD

def fetch_data(endpoint: str, use_cache: bool = True, max_retries: int = 3, cache_duration: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """
    Récupère et décode les données JSON à partir de l'endpoint spécifié.
    Utilise un cache LRU pour améliorer les performances.
    Implémente retry logic avec backoff exponentiel.
    
    Args:
        endpoint: API endpoint to fetch (e.g., "action=get_live_categories")
        use_cache: Whether to use cached data if available
        max_retries: Maximum number of retry attempts (default: 3)
        cache_duration: Custom cache duration in seconds (None = use default)
    
    Returns:
        Parsed JSON data or None if error occurs
    """
    global _data_cache
    
    # Determine cache duration based on endpoint type
    if cache_duration is None:
        if 'categories' in endpoint:
            cache_duration = CACHE_CATEGORIES_DURATION
        elif endpoint == '' or 'user_info' in endpoint:
            cache_duration = CACHE_USER_INFO_DURATION
        elif 'get_vod_info' in endpoint or 'get_series_info' in endpoint:
            cache_duration = 7200  # 2 hours for detailed metadata (rarely changes)
        else:
            cache_duration = CACHE_DURATION
    
    # Check cache
    if use_cache:
        cached_data = _data_cache.get(endpoint)
        if cached_data:
            log(f"Using cached data for endpoint: {endpoint} (persistent cache)", xbmc.LOGDEBUG)
            return cached_data
    
    url = f"{SERVER_URL}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    masked_url = mask_credentials(url, USERNAME, PASSWORD)
    
    headers = {'User-Agent': 'Kodi Xtream Codes Addon'}
    
    # Retry logic with exponential backoff
    for attempt in range(max_retries):
        try:
            log(f"Fetching data from: {masked_url} (attempt {attempt + 1}/{max_retries})", xbmc.LOGDEBUG)
            
            req = Request(url, headers=headers)
            with urlopen(req, timeout=TIMEOUT) as response:
                data = response.read().decode('utf-8')
                
                # Validate JSON before parsing
                if not data or not data.strip():
                    raise ValueError("Empty response from server")
                
                result = json.loads(data)
                
                # Basic validation: ensure result is a dict or list
                if not isinstance(result, (dict, list)):
                    raise ValueError(f"Invalid response type: {type(result)}")
                
                # Cache result
                if use_cache:
                    _data_cache.set(endpoint, result, cache_duration)
                    log(f"Data cached for endpoint: {endpoint} (duration: {cache_duration}s)", xbmc.LOGDEBUG)
                    
                log(f"Successfully fetched data for endpoint: {endpoint}", xbmc.LOGDEBUG)
                return result
                
        except HTTPError as e:
            error_msg = f"Erreur HTTP : {e.code} - {e.reason}"
            log(f"HTTP Error for {masked_url}: {e.code} - {e.reason} (attempt {attempt + 1}/{max_retries})", xbmc.LOGERROR)
            
            # Don't retry on 4xx errors (client errors)
            if 400 <= e.code < 500:
                notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
                return None
            
            # Retry on 5xx errors (server errors)
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff: 1s, 2s, 4s
                log(f"Retrying in {wait_time} seconds...", xbmc.LOGDEBUG)
                time.sleep(wait_time)
            else:
                notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
                
        except URLError as e:
            error_msg = f"Erreur de connexion : {e.reason}"
            log(f"URL Error for {masked_url}: {e.reason} (attempt {attempt + 1}/{max_retries})", xbmc.LOGERROR)
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                log(f"Retrying in {wait_time} seconds...", xbmc.LOGDEBUG)
                time.sleep(wait_time)
            else:
                notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
                
        except json.JSONDecodeError as e:
            error_msg = f"Erreur de décodage JSON : {e}"
            log(f"JSON Decode Error for {masked_url}: {e} (attempt {attempt + 1}/{max_retries})", xbmc.LOGERROR)
            
            # Don't retry on JSON errors
            return None
            
        except ValueError as e:
            error_msg = f"Erreur de validation : {e}"
            log(f"Validation Error for {masked_url}: {e} (attempt {attempt + 1}/{max_retries})", xbmc.LOGERROR)
            
            # Don't retry on validation errors
            return None
            
        except Exception as e:
            error_msg = f"Erreur : {e}"
            log(f"Unexpected error for {masked_url}: {e} (attempt {attempt + 1}/{max_retries})", xbmc.LOGERROR)
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                log(f"Retrying in {wait_time} seconds...", xbmc.LOGDEBUG)
                time.sleep(wait_time)
            else:
                notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    
    return None

def filter_adult_content(items: list) -> list:
    """
    Filtre le contenu adulte si l'option est activée.
    
    Args:
        items: Liste d'éléments à filtrer
    
    Returns:
        Liste filtrée (sans contenu adulte si option activée)
    """
    if not HIDE_ADULT_CONTENT:
        return items
    
    filtered = [item for item in items if not item.get('is_adult', 0)]
    
    if len(filtered) < len(items):
        removed = len(items) - len(filtered)
        log(f"Filtered {removed} adult content items", xbmc.LOGDEBUG)
    
    return filtered

def clear_cache() -> None:
    """
    Vide le cache des données API.
    Utile pour forcer le rafraîchissement des données.
    """
    global _data_cache
    cache_size = len(_data_cache)
    _data_cache.clear()
    log(f"Cache cleared: {cache_size} entries removed", xbmc.LOGINFO)
    notify("Cache", "Cache vidé avec succès.")
