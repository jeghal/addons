import json
import xbmcgui
import xbmcaddon
import xbmc
from urllib.request import urlopen, Request, URLError, HTTPError
from datetime import datetime
from typing import Optional, Dict, Any

from resources.lib.utils import notify, log, mask_credentials

# Settings
ADDON = xbmcaddon.Addon()
SERVER_URL = ADDON.getSetting('server_url').strip()
USERNAME = ADDON.getSetting('username').strip()
PASSWORD = ADDON.getSetting('password').strip()

# Configurable settings with defaults
try:
    TIMEOUT = int(ADDON.getSetting('timeout')) if ADDON.getSetting('timeout') else 15
except (ValueError, TypeError):
    TIMEOUT = 15

try:
    CACHE_DURATION = int(ADDON.getSetting('cache_duration')) if ADDON.getSetting('cache_duration') else 300
except (ValueError, TypeError):
    CACHE_DURATION = 300  # 5 minutes

_data_cache = {}

def validate_settings() -> bool:
    """
    Validate addon settings before making API calls.
    
    Returns:
        True if settings are valid, False otherwise
    """
    if not SERVER_URL or not USERNAME or not PASSWORD:
        log("Settings validation failed: Missing credentials", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Xtream Codes IPTV",
                                      "Veuillez configurer l'URL, l'utilisateur et le mot de passe.",
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        return False
    
    if not SERVER_URL.startswith("http"):
        log(f"Settings validation failed: Invalid server URL: {SERVER_URL}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Erreur", "L'URL du serveur est invalide (doit commencer par http).", xbmcgui.NOTIFICATION_ERROR, 5000)
        return False
    
    log("Settings validated successfully", xbmc.LOGDEBUG)
    return True

def get_server_url():
    return SERVER_URL

def get_username():
    return USERNAME

def get_password():
    return PASSWORD

def fetch_data(endpoint: str, use_cache: bool = True) -> Optional[Dict[str, Any]]:
    """
    Récupère et décode les données JSON à partir de l'endpoint spécifié.
    Utilise un cache pour améliorer les performances.
    
    Args:
        endpoint: API endpoint to fetch (e.g., "action=get_live_categories")
        use_cache: Whether to use cached data if available
    
    Returns:
        Parsed JSON data or None if error occurs
    """
    global _data_cache
    
    # Check cache
    if use_cache and endpoint in _data_cache:
        cached_data, timestamp = _data_cache[endpoint]
        if (datetime.now().timestamp() - timestamp) < CACHE_DURATION:
            log(f"Using cached data for endpoint: {endpoint}", xbmc.LOGDEBUG)
            return cached_data
    
    url = f"{SERVER_URL}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    masked_url = mask_credentials(url, USERNAME, PASSWORD)
    log(f"Fetching data from: {masked_url}", xbmc.LOGDEBUG)
    
    headers = {'User-Agent': 'Kodi Xtream Codes Addon'}
    
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=TIMEOUT) as response:
            data = response.read().decode('utf-8')
            result = json.loads(data)
            
            # Cache result
            if use_cache:
                _data_cache[endpoint] = (result, datetime.now().timestamp())
                log(f"Data cached for endpoint: {endpoint}", xbmc.LOGDEBUG)
                
            log(f"Successfully fetched data for endpoint: {endpoint}", xbmc.LOGDEBUG)
            return result
            
    except HTTPError as e:
        error_msg = f"Erreur HTTP : {e.code} - {e.reason}"
        log(f"HTTP Error for {masked_url}: {e.code} - {e.reason}", xbmc.LOGERROR)
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    except URLError as e:
        error_msg = f"Erreur de connexion : {e.reason}"
        log(f"URL Error for {masked_url}: {e.reason}", xbmc.LOGERROR)
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    except json.JSONDecodeError as e:
        error_msg = f"Erreur de décodage JSON : {e}"
        log(f"JSON Decode Error for {masked_url}: {e}", xbmc.LOGERROR)
        # Silent error - don't notify user for JSON errors
    except Exception as e:
        error_msg = f"Erreur : {e}"
        log(f"Unexpected error for {masked_url}: {e}", xbmc.LOGERROR)
        notify("Xtream Codes IPTV", error_msg, xbmcgui.NOTIFICATION_ERROR)
    
    return None

def clear_cache() -> None:
    """
    Vide le cache des données API.
    Utile pour forcer le rafraîchissement des données.
    """
    global _data_cache
    cache_size = len(_data_cache)
    _data_cache = {}
    log(f"Cache cleared: {cache_size} entries removed", xbmc.LOGINFO)
    notify("Cache", "Cache vidé avec succès.")
