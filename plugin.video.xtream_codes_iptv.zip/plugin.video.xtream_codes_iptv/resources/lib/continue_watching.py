#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Module pour gérer la fonctionnalité "Continuer à regarder"
Stocke et gère les séries en cours de visionnage
"""
import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_DATA_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CONTINUE_WATCHING_FILE = os.path.join(ADDON_DATA_PATH, 'continue_watching.json')
MAX_CONTINUE_ITEMS = 20


def ensure_data_dir():
    """Créer le dossier de données si nécessaire."""
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        xbmcvfs.mkdirs(ADDON_DATA_PATH)


def load_continue_watching() -> Dict[str, Any]:
    """
    Charge les données "Continue Watching" depuis le fichier JSON.
    
    Returns:
        Dictionnaire des séries en cours {series_id: data}
    """
    ensure_data_dir()
    
    if not xbmcvfs.exists(CONTINUE_WATCHING_FILE):
        return {}
    
    try:
        with open(CONTINUE_WATCHING_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error loading continue watching: {e}", xbmc.LOGERROR)
        return {}


def save_continue_watching(data: Dict[str, Any]) -> None:
    """
    Sauvegarde les données "Continue Watching" dans le fichier JSON.
    
    Args:
        data: Dictionnaire des séries en cours
    """
    ensure_data_dir()
    
    try:
        with open(CONTINUE_WATCHING_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        xbmc.log(f"[Xtream Codes] Continue watching saved: {len(data)} series", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error saving continue watching: {e}", xbmc.LOGERROR)


def update_progress(series_id: str, series_name: str, season: int, episode: int, 
                    title: str, icon: str = '', fanart: str = '', 
                    next_season: Optional[int] = None, next_episode: Optional[int] = None) -> None:
    """
    Met à jour la progression d'une série.
    
    Args:
        series_id: ID de la série
        series_name: Nom de la série
        season: Numéro de saison
        episode: Numéro d'épisode
        title: Titre de l'épisode
        icon: URL de l'icône
        fanart: URL du fanart
        next_season: Numéro de la prochaine saison (optionnel)
        next_episode: Numéro du prochain épisode (optionnel)
    """
    # Validation des paramètres
    if not series_id or not series_name:
        xbmc.log("[Xtream Codes] Invalid parameters for update_progress: missing series_id or series_name", xbmc.LOGWARNING)
        return
    
    if season < 1 or episode < 1:
        xbmc.log(f"[Xtream Codes] Invalid season/episode: S{season}E{episode}", xbmc.LOGWARNING)
        return
    
    data = load_continue_watching()
    
    # Créer ou mettre à jour l'entrée
    entry = {
        'series_id': series_id,
        'series_name': series_name,
        'last_watched': {
            'season': season,
            'episode': episode,
            'title': title,
            'timestamp': datetime.now().isoformat()
        },
        'icon': icon,
        'fanart': fanart
    }
    
    # Ajouter les infos du prochain épisode si disponibles
    if next_season is not None and next_episode is not None:
        entry['next_episode'] = {
            'season': next_season,
            'episode': next_episode
        }
    
    data[series_id] = entry
    
    # Limiter le nombre d'entrées
    if len(data) > MAX_CONTINUE_ITEMS:
        # Trier par timestamp et garder les plus récents
        sorted_items = sorted(
            data.items(),
            key=lambda x: x[1]['last_watched']['timestamp'],
            reverse=True
        )
        data = dict(sorted_items[:MAX_CONTINUE_ITEMS])
    
    save_continue_watching(data)
    xbmc.log(f"[Xtream Codes] Updated continue watching: {series_name} S{season}E{episode}", xbmc.LOGINFO)


def get_continue_watching_list() -> List[Dict[str, Any]]:
    """
    Récupère la liste des séries en cours, triée par date.
    
    Returns:
        Liste des séries en cours, triée par date de dernier visionnage
    """
    data = load_continue_watching()
    
    # Convertir en liste et trier par timestamp
    series_list = list(data.values())
    series_list.sort(
        key=lambda x: x['last_watched']['timestamp'],
        reverse=True
    )
    
    return series_list


def remove_from_continue_watching(series_id: str) -> None:
    """
    Supprime une série de la liste "Continue Watching".
    
    Args:
        series_id: ID de la série à supprimer
    """
    data = load_continue_watching()
    
    if series_id in data:
        series_name = data[series_id]['series_name']
        del data[series_id]
        save_continue_watching(data)
        xbmc.log(f"[Xtream Codes] Removed from continue watching: {series_name}", xbmc.LOGINFO)


def clear_continue_watching() -> None:
    """Efface toute la liste "Continue Watching"."""
    ensure_data_dir()
    
    try:
        if xbmcvfs.exists(CONTINUE_WATCHING_FILE):
            xbmcvfs.delete(CONTINUE_WATCHING_FILE)
        xbmc.log("[Xtream Codes] Continue watching cleared", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error clearing continue watching: {e}", xbmc.LOGERROR)


def get_series_info(series_id: str) -> Optional[Dict[str, Any]]:
    """
    Récupère les informations d'une série depuis "Continue Watching".
    
    Args:
        series_id: ID de la série
        
    Returns:
        Informations de la série ou None si non trouvée
    """
    data = load_continue_watching()
    return data.get(series_id)
