"""
Module pour gérer l'historique de lecture
Stocke les 20 derniers contenus regardés
"""
import json
import os
from datetime import datetime
from typing import List, Dict, Any

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_DATA_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HISTORY_FILE = os.path.join(ADDON_DATA_PATH, 'watch_history.json')
MAX_HISTORY_ITEMS = 20

def ensure_data_dir():
    """Créer le dossier de données si nécessaire."""
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        xbmcvfs.mkdirs(ADDON_DATA_PATH)

def load_history() -> List[Dict[str, Any]]:
    """
    Charge l'historique depuis le fichier JSON.
    
    Returns:
        Liste des éléments de l'historique (max 20)
    """
    ensure_data_dir()
    
    if not xbmcvfs.exists(HISTORY_FILE):
        return []
    
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
            history = json.load(f)
            return history[:MAX_HISTORY_ITEMS]
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error loading history: {e}", xbmc.LOGERROR)
        return []

def save_history(history: List[Dict[str, Any]]) -> None:
    """
    Sauvegarde l'historique dans le fichier JSON.
    
    Args:
        history: Liste des éléments à sauvegarder
    """
    ensure_data_dir()
    
    try:
        # Limiter à MAX_HISTORY_ITEMS
        history = history[:MAX_HISTORY_ITEMS]
        
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2, ensure_ascii=False)
        
        xbmc.log(f"[Xtream Codes] History saved: {len(history)} items", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error saving history: {e}", xbmc.LOGERROR)

def add_to_history(item_type: str, item_id: str, title: str, stream_url: str, 
                   icon: str = '', fanart: str = '', series_id: str = '', 
                   season: str = '', episode_num: str = '') -> None:
    """
    Ajoute un élément à l'historique.
    
    Args:
        item_type: Type ('live', 'movie', 'episode')
        item_id: ID du contenu
        title: Titre affiché
        stream_url: URL de streaming
        icon: URL de l'icône
        fanart: URL du fanart
        series_id: ID de la série (pour épisodes uniquement)
        season: Numéro de saison (pour épisodes uniquement)
        episode_num: Numéro d'épisode (pour épisodes uniquement)
    """
    history = load_history()
    
    # Créer l'entrée
    entry = {
        'type': item_type,
        'id': item_id,
        'title': title,
        'stream_url': stream_url,
        'icon': icon,
        'fanart': fanart,
        'timestamp': datetime.now().isoformat(),
        'date': datetime.now().strftime('%Y-%m-%d %H:%M')
    }
    
    # Ajouter les métadonnées d'épisode si disponibles
    if item_type == 'episode' and series_id and season and episode_num:
        entry['series_id'] = series_id
        entry['season'] = season
        entry['episode_num'] = episode_num
    
    # Deduplication logic (Cleaned)
    if item_type == 'episode' and series_id:
        # For episodes, remove ANY previous episode of the same series
        # We only want to see the latest watched episode of a series in the history
        # Force string comparison to avoid int/str mismatches from JSON
        history = [h for h in history if not (h.get('type') == 'episode' and str(h.get('series_id', '')) == str(series_id))]
    else:
        # For everything else, strictly deduplicate by ID and Type
        history = [h for h in history if not (str(h.get('id', '')) == str(item_id) and h.get('type') == item_type)]
    
    # Ajouter en première position
    history.insert(0, entry)
    
    # Sauvegarder
    save_history(history)
    
    xbmc.log(f"[Xtream Codes] Added to history: {title} ({item_type})", xbmc.LOGDEBUG)

def get_history() -> List[Dict[str, Any]]:
    """
    Récupère l'historique complet.
    
    Returns:
        Liste des éléments de l'historique
    """
    return load_history()

def clear_history() -> None:
    """Efface tout l'historique."""
    ensure_data_dir()
    
    try:
        if xbmcvfs.exists(HISTORY_FILE):
            xbmcvfs.delete(HISTORY_FILE)
        xbmc.log("[Xtream Codes] History cleared", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error clearing history: {e}", xbmc.LOGERROR)

def remove_from_history(item_type: str, item_id: str) -> None:
    """
    Supprime un élément spécifique de l'historique.
    
    Args:
        item_type: Type de l'élément
        item_id: ID de l'élément
    """
    history = load_history()
    history = [h for h in history if not (h.get('id') == item_id and h.get('type') == item_type)]
    save_history(history)
    xbmc.log(f"[Xtream Codes] Removed from history: {item_id} ({item_type})", xbmc.LOGDEBUG)
