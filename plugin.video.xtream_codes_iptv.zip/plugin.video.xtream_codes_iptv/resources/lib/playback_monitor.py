#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Playback Monitor for Auto-Play Next Episode
Monitors episode playback and automatically plays the next episode.
"""
import xbmc
import xbmcgui
import xbmcaddon
from typing import Optional, Dict, Any

from resources.lib import api
from resources.lib import utils


class PlaybackMonitor(xbmc.Player):
    """
    Monitor for automatic next episode playback.
    Detects when an episode ends and automatically plays the next one.
    """
    
    def __init__(self):
        """Initialize the playback monitor."""
        super(PlaybackMonitor, self).__init__()
        self.addon = xbmcaddon.Addon()
        self.is_playing_episode = False
        self.episode_metadata = {}
        self.countdown_dialog = None
        self.cancelled = False
        self.has_ended = False
        
        utils.log("PlaybackMonitor initialized", xbmc.LOGINFO)
    
    def start_monitoring(self, series_id: str, season: int, episode_num: int, title: str) -> None:
        """
        Start monitoring playback for auto-play next episode.
        
        Args:
            series_id: ID of the series
            season: Season number
            episode_num: Episode number
            title: Episode title
        """
        self.is_playing_episode = True
        self.episode_metadata = {
            'series_id': series_id,
            'season': season,
            'episode_num': episode_num,
            'title': title
        }
        self.cancelled = False
        self.has_ended = False
        
        utils.log(f"Started monitoring episode: S{season}E{episode_num} - {title}", xbmc.LOGINFO)
    
    def stop_monitoring(self) -> None:
        """Stop monitoring playback."""
        self.is_playing_episode = False
        self.episode_metadata = {}
        self.cancelled = False
        self.has_ended = False
        
        if self.countdown_dialog:
            try:
                self.countdown_dialog.close()
            except:
                pass
            self.countdown_dialog = None
        
        utils.log("Stopped monitoring episode", xbmc.LOGDEBUG)
    
    def onPlayBackStarted(self) -> None:
        """Called when playback starts."""
        utils.log("Playback started - checking for episode metadata", xbmc.LOGINFO)
        
        # Check if this is an episode by reading window properties
        try:
            window = xbmcgui.Window(10000)
            series_id = window.getProperty('xtream.episode.series_id')
            season_str = window.getProperty('xtream.episode.season')
            episode_num_str = window.getProperty('xtream.episode.episode_num')
            title = window.getProperty('xtream.episode.title')
            
            if series_id and season_str and episode_num_str:
                # Convert to integers
                season = int(season_str)
                episode_num = int(episode_num_str)
                
                # Start monitoring this episode
                self.is_playing_episode = True
                self.episode_metadata = {
                    'series_id': series_id,
                    'season': season,
                    'episode_num': episode_num,
                    'title': title
                }
                self.cancelled = False
                self.has_ended = False
                
                utils.log(f"Auto-play monitoring started for S{season}E{episode_num} - {title}", xbmc.LOGINFO)
            else:
                utils.log("No episode metadata found - not monitoring for auto-play", xbmc.LOGINFO)
                self.is_playing_episode = False
        except Exception as e:
            utils.log(f"Error reading episode metadata: {e}", xbmc.LOGWARNING)
            self.is_playing_episode = False
    
    def onPlayBackEnded(self) -> None:
        """Called when playback ends normally."""
        utils.log(f"Playback ended - is_playing_episode={self.is_playing_episode}", xbmc.LOGINFO)
        if self.is_playing_episode:
            self.has_ended = True
            self._update_continue_watching(finished=True)
            self._handle_episode_end()
    
    def onPlayBackStopped(self) -> None:
        """Called when playback is stopped by the user."""
        utils.log("Playback stopped - is_playing_episode={}".format(self.is_playing_episode), xbmc.LOGINFO)
        
        # If we already handled the end of the episode (has_ended=True), don't treat this as a manual stop
        if self.has_ended:
            self.stop_monitoring()
            return

        # Update Continue Watching even if stopped manually
        if self.is_playing_episode and self.episode_metadata:
            self._update_continue_watching(finished=False)
        
        self.stop_monitoring()
    
    def onPlayBackError(self) -> None:
        """Called when playback error occurs."""
        utils.log("Playback error", xbmc.LOGERROR)
        self.stop_monitoring()
    
    def _update_continue_watching(self, finished: bool = False) -> None:
        """
        Update Continue Watching with current episode progress.
        Called when episode ends or is stopped manually.
        
        Args:
            finished: True if playback completed naturally, False if stopped manually
        """
        if not self.episode_metadata:
            return
        
        series_id = self.episode_metadata.get('series_id')
        season = self.episode_metadata.get('season')
        episode_num = self.episode_metadata.get('episode_num')
        title = self.episode_metadata.get('title', '')
        
        if not series_id or not season or not episode_num:
            utils.log("Missing episode metadata for continue watching", xbmc.LOGWARNING)
            return
        
        try:
            from resources.lib import continue_watching
            from resources.lib import api
            
            # Get series info for name and artwork
            series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
            if series_info:
                info = series_info.get('info', {})
                series_name = info.get('name', 'Unknown Series')
                icon = info.get('cover', '')
                fanart = info.get('backdrop_path', [''])[0] if isinstance(info.get('backdrop_path'), list) else info.get('backdrop_path', '')
                
                # Calculate next episode
                if finished:
                    # If finished, point to next episode
                    next_season, next_episode = self._calculate_next_from_info(series_info, season, episode_num)
                else:
                    # If not finished, stay on current episode (resume)
                    next_season, next_episode = season, episode_num
                
                continue_watching.update_progress(
                    series_id=series_id,
                    series_name=series_name,
                    season=season,
                    episode=episode_num,
                    title=title,
                    icon=icon,
                    fanart=fanart,
                    next_season=next_season,
                    next_episode=next_episode
                )
        except Exception as e:
            utils.log(f"Error updating continue watching: {e}", xbmc.LOGWARNING)
    
    def _calculate_next_from_info(self, series_info: Dict[str, Any], current_season: int, current_episode: int):
        """
        Calculate next episode from series info.
        
        Returns:
            Tuple (next_season, next_episode) or (None, None) if no next episode
        """
        try:
            episodes = series_info.get('episodes', {})
            
            # Check if next episode exists in same season
            season_episodes = episodes.get(str(current_season), [])
            
            for ep in season_episodes:
                ep_num = int(ep.get('episode_num', 0))
                if ep_num == current_episode + 1:
                    return current_season, current_episode + 1
            
            # Check first episode of next season
            next_season = current_season + 1
            if str(next_season) in episodes:
                next_season_episodes = episodes[str(next_season)]
                if next_season_episodes:
                    # Obtenir le numéro du premier épisode (peut être 0, 1, 101...)
                    first_ep = next_season_episodes[0]
                    first_ep_num = int(first_ep.get('episode_num', 1)) 
                    return next_season, first_ep_num
            
            return None, None
        except Exception as e:
            utils.log(f"Error calculating next episode: {e}", xbmc.LOGWARNING)
            return None, None
    
    def _handle_episode_end(self) -> None:
        """
        Handle the end of an episode playback.
        Determine next episode and show countdown.
        """
        if not self.is_playing_episode or not self.episode_metadata:
            return
        
        utils.log("Playback ended - is_playing_episode=True", xbmc.LOGINFO)
        
        series_id = self.episode_metadata.get('series_id')
        season = self.episode_metadata.get('season')
        episode_num = self.episode_metadata.get('episode_num')
        
        if not series_id or not season or not episode_num:
            utils.log("Missing episode metadata for auto-play", xbmc.LOGWARNING)
            return
        
        # Check if auto-play is enabled
        autoplay_enabled = self.addon.getSetting('autoplay_next_episode') == 'true'
        if not autoplay_enabled:
            utils.log("Auto-play is disabled", xbmc.LOGDEBUG)
            self.stop_monitoring()
            return
        
        # Get next episode
        next_episode = self._get_next_episode(series_id, season, episode_num)
        
        if next_episode:
            # Show countdown and play next episode
            self._show_countdown_and_play(next_episode)
        else:
            # End of series
            utils.notify("Auto-Play", "Fin de la série: Vous avez terminé cette série", xbmcgui.NOTIFICATION_INFO)
            utils.log("End of series reached", xbmc.LOGINFO)
    
    def _get_next_episode(self, series_id: str, current_season: int, current_episode: int) -> Optional[Dict[str, Any]]:
        """
        Get information about the next episode.
        
        Returns:
            Dictionary with next episode info or None if no next episode
        """
        series_id = self.episode_metadata.get('series_id')
        current_season = self.episode_metadata.get('season')
        current_episode = self.episode_metadata.get('episode_num')
        
        if not all([series_id, current_season is not None, current_episode is not None]):
            return None
        
        # Fetch series info
        series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
        if not series_info:
            utils.log(f"Failed to fetch series info for series_id={series_id}", xbmc.LOGWARNING)
            return None
        
        episodes = series_info.get('episodes', {})
        episodes_map = {int(k): v for k, v in episodes.items()}
        
        # Try to find next episode in current season
        current_season_episodes = episodes_map.get(current_season, [])
        
        # Find current episode index
        current_index = None
        for idx, ep in enumerate(current_season_episodes):
            if ep.get('episode_num') == current_episode:
                current_index = idx
                break
        
        if current_index is not None and current_index + 1 < len(current_season_episodes):
            # Next episode in same season
            next_ep = current_season_episodes[current_index + 1]
            return self._format_episode_info(next_ep, current_season, series_id)
        
        # Check if we should continue to next season
        autoplay_next_season = self.addon.getSetting('autoplay_next_season') == 'true'
        if not autoplay_next_season:
            utils.notify("Fin de la saison", "Dernière épisode de la saison", xbmcgui.NOTIFICATION_INFO)
            return None
        
        # Try next season
        next_season = current_season + 1
        next_season_episodes = episodes_map.get(next_season, [])
        
        if next_season_episodes:
            # First episode of next season
            next_ep = next_season_episodes[0]
            return self._format_episode_info(next_ep, next_season, series_id)
        
        # No more episodes
        utils.notify("Fin de la série", "Vous avez terminé cette série", xbmcgui.NOTIFICATION_INFO)
        return None
    
    def _format_episode_info(self, episode: Dict[str, Any], season: int, series_id: str) -> Dict[str, Any]:
        """
        Format episode information for playback.
        
        Args:
            episode: Episode data from API
            season: Season number
            series_id: Series ID
            
        Returns:
            Formatted episode info
        """
        server = api.get_server_url()
        user = api.get_username()
        pwd = api.get_password()
        
        ep_id = episode.get('id', '')
        container_extension = episode.get('container_extension', 'ts')
        ep_title = episode.get('title', 'Inconnu')
        ep_num = episode.get('episode_num', 0)
        
        # Get episode thumbnail
        ep_data = episode.get('info', {})
        if isinstance(ep_data, list):
            ep_data = ep_data[0] if ep_data else {}
        
        ep_thumb = ''
        ep_fanart = ''
        if isinstance(ep_data, dict):
            ep_thumb = ep_data.get('movie_image', '')
        
        stream_url = f"{server}/series/{user}/{pwd}/{ep_id}.{container_extension}"
        
        return {
            'series_id': series_id,
            'season': season,
            'episode_num': ep_num,
            'stream_url': stream_url,
            'title': ep_title,
            'stream_id': str(ep_id),
            'icon': ep_thumb,
            'fanart': ep_fanart
        }
    
    def _show_countdown_and_play(self, next_episode: Dict[str, Any]) -> None:
        """
        Show countdown dialog and play next episode if not cancelled.
        
        Args:
            next_episode: Next episode information
        """
        try:
            countdown_seconds = int(self.addon.getSetting('autoplay_countdown'))
        except (ValueError, TypeError):
            countdown_seconds = 10
        
        # Ensure countdown is within valid range
        countdown_seconds = max(3, min(30, countdown_seconds))
        
        season = next_episode.get('season', 0)
        episode_num = next_episode.get('episode_num', 0)
        title = next_episode.get('title', 'Inconnu')
        
        utils.log(f"Starting countdown for next episode: S{season}E{episode_num} - {title}", xbmc.LOGINFO)
        
        # Show countdown notification
        for remaining in range(countdown_seconds, 0, -1):
            if xbmc.Monitor().abortRequested():
                self.cancelled = True
                break
            
            # Check if user pressed back/escape
            if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                self.cancelled = True
                break
            
            message = f"Lecture dans {remaining}s: S{season:02d}E{episode_num:02d} - {title}"
            
            # Use a progress dialog for better visibility
            if remaining == countdown_seconds:
                self.countdown_dialog = xbmcgui.DialogProgress()
                self.countdown_dialog.create("Épisode suivant", message)
            
            if self.countdown_dialog:
                progress = int((countdown_seconds - remaining) * 100 / countdown_seconds)
                self.countdown_dialog.update(progress, message)
                
                # Check if user cancelled
                if self.countdown_dialog.iscanceled():
                    self.cancelled = True
                    break
            
            xbmc.sleep(1000)
        
        # Close dialog
        if self.countdown_dialog:
            self.countdown_dialog.close()
            self.countdown_dialog = None
        
        # Play next episode if not cancelled
        if not self.cancelled:
            utils.log(f"Playing next episode: {next_episode.get('title')}", xbmc.LOGINFO)
            self._play_next_episode(next_episode)
        else:
            utils.log("Auto-play cancelled by user", xbmc.LOGDEBUG)
        
        self.stop_monitoring()
    
    def _play_next_episode(self, episode_info: Dict[str, Any]) -> None:
        """
        Play the next episode.
        
        Args:
            episode_info: Episode information
        """
        stream_url = episode_info.get('stream_url', '')
        title = episode_info.get('title', '')
        stream_id = episode_info.get('stream_id', '')
        icon = episode_info.get('icon', '')
        fanart = episode_info.get('fanart', '')
        
        # Create list item
        list_item = xbmcgui.ListItem(label=title, path=stream_url)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # Set info
        # Set info
        # Kodi Matrix/Nexus+ (version 19+) - Utilisation de InfoTagVideo
        if hasattr(list_item, 'getVideoInfoTag'):
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(title)
            video_info.setSeason(int(episode_info.get('season', 0)))
            video_info.setEpisode(int(episode_info.get('episode_num', 0)))
            video_info.setMediaType('episode')
        else:
            list_item.setInfo('video', {
                'title': title,
                'season': episode_info.get('season', 0),
                'episode': episode_info.get('episode_num', 0),
                'mediatype': 'episode'
            })
        
        # Set art
        if icon:
            list_item.setArt({'thumb': icon, 'icon': icon})
        if fanart:
            list_item.setArt({'fanart': fanart})
            
        # Update window properties for the new episode so onPlayBackStarted picks it up
        try:
            window = xbmcgui.Window(10000)
            window.setProperty('xtream.episode.series_id', str(episode_info.get('series_id', '')))
            window.setProperty('xtream.episode.season', str(episode_info.get('season', '')))
            window.setProperty('xtream.episode.episode_num', str(episode_info.get('episode_num', '')))
            window.setProperty('xtream.episode.title', title)
            utils.log(f"Updated window properties for auto-play: {title}", xbmc.LOGDEBUG)
        except Exception as e:
            utils.log(f"Error updating window properties: {e}", xbmc.LOGWARNING)
        
        # Play the episode
        self.play(stream_url, list_item)
        
        # Start monitoring the new episode
        self.start_monitoring(
            series_id=episode_info.get('series_id', ''),
            season=episode_info.get('season', 0),
            episode_num=episode_info.get('episode_num', 0),
            title=title
        )
        
        # Add to history
        try:
            from resources.lib import history
            history.add_to_history(
                item_type='episode',
                item_id=stream_id,
                title=title,
                stream_url=stream_url,
                icon=icon,
                fanart=fanart,
                series_id=episode_info.get('series_id', ''),
                season=str(episode_info.get('season', '')),
                episode_num=str(episode_info.get('episode_num', ''))
            )
        except Exception as e:
            utils.log(f"Error adding to history: {e}", xbmc.LOGWARNING)


# Global instance
_monitor_instance = None


def get_monitor() -> PlaybackMonitor:
    """
    Get the global playback monitor instance.
    
    Returns:
        PlaybackMonitor instance
    """
    global _monitor_instance
    if _monitor_instance is None:
        _monitor_instance = PlaybackMonitor()
    return _monitor_instance


def start_monitoring_episode(series_id: str, season: int, episode_num: int, title: str) -> None:
    """
    Start monitoring an episode for auto-play.
    
    Args:
        series_id: Series ID
        season: Season number
        episode_num: Episode number
        title: Episode title
    """
    monitor = get_monitor()
    monitor.start_monitoring(series_id, season, episode_num, title)
