#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Playback Monitor for Auto-Play Next Episode
Monitors episode playback and automatically plays the next episode.
"""
import xbmc
import xbmcgui
import xbmcaddon
import os
import json
from typing import Optional, Dict, Any

from resources.lib import api
from resources.lib import utils


class PlaybackMonitor(xbmc.Player):
    """
    Monitor for automatic next episode playback.
    Detects when an episode ends and automatically plays the next one.
    """
    
    def __init__(self):
        """Initialize the playback monitor."""
        super(PlaybackMonitor, self).__init__()
        self.addon = xbmcaddon.Addon()
        self.is_playing_episode = False
        self.episode_metadata = {}
        self.countdown_dialog = None
        self.cancelled = False
        self.has_ended = False
        
        utils.log("PlaybackMonitor initialized", xbmc.LOGINFO)

    def load_playback_state(self):
        """Loads metadata from the stash file."""
        state_file = os.path.join(utils.userdata_path, 'playback_state.json')
        if os.path.exists(state_file):
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                utils.log(f"DEBUG: Loaded Playback State: {data}", xbmc.LOGINFO)
                return data
            except Exception as e:
                utils.log(f"Error loading playback state: {e}", xbmc.LOGERROR)
        return {}
    
    def start_monitoring(self, series_id: str, season: int, episode_num: int, title: str) -> None:
        """
        Start monitoring playback for auto-play next episode.
        """
        self.is_playing_episode = True
        self.episode_metadata = {
            'series_id': series_id,
            'season': season,
            'episode_num': episode_num,
            'title': title
        }
        self.cancelled = False
        self.has_ended = False
        
        utils.log(f"Started monitoring episode: S{season}E{episode_num} - {title}", xbmc.LOGINFO)
    
    def stop_monitoring(self) -> None:
        """Stop monitoring playback."""
        self.is_playing_episode = False
        self.episode_metadata = {}
        self.cancelled = False
        self.has_ended = False
        
        if self.countdown_dialog:
            try: self.countdown_dialog.close()
            except: pass
            self.countdown_dialog = None
        
        utils.log("Stopped monitoring episode", xbmc.LOGDEBUG)
    
    def onPlayBackStarted(self) -> None:
        """Called when playback starts."""
        utils.log("Playback started - checking for metadata", xbmc.LOGINFO)
        # Load state from file (more reliable than Window Properties)
        state = self.load_playback_state()
        
        if state.get('is_episode'):
            # It's an episode
            self.is_playing_episode = True
            self.episode_metadata = {
                'series_id': state.get('series_id'),
                'season': state.get('season'),
                'episode_num': state.get('episode_num'),
                'title': state.get('title')
            }
            self.cancelled = False
            self.has_ended = False
            utils.log(f"Auto-play monitoring started for S{state.get('season')}E{state.get('episode_num')}", xbmc.LOGINFO)
        else:
            # Generic Stream / Movie
            self.is_playing_episode = False
            self.stream_id = state.get('stream_id')
            self.stream_type = state.get('stream_type')
            utils.log(f"Monitoring Generic Stream: ID={self.stream_id}, Type={self.stream_type}", xbmc.LOGINFO)

    
    def onPlayBackEnded(self) -> None:
        """Called when playback ends normally."""
        utils.log(f"Playback ended - is_playing_episode={self.is_playing_episode}", xbmc.LOGINFO)
        if self.is_playing_episode:
            self.has_ended = True
            self._update_continue_watching(finished=True)
            self._handle_episode_end()
    
    def onPlayBackStopped(self) -> None:
        """Called when playback is stopped by the user."""
        utils.log("Playback stopped", xbmc.LOGINFO)
        
        if self.has_ended:
            self.stop_monitoring()
            return

        # Update Continue Watching even if stopped manually
        if self.is_playing_episode and self.episode_metadata:
            self._update_continue_watching(finished=False)
        
        self.stop_monitoring()
    
    def onPlayBackError(self) -> None:
        """Called when playback error occurs."""
        utils.log("Playback error", xbmc.LOGERROR)
        self.stop_monitoring()
    
    def _update_continue_watching(self, finished: bool = False) -> None:
        """Update Continue Watching with current episode progress."""
        # 1. Gestion des Épisodes (Smart Queue)
        if self.is_playing_episode and self.episode_metadata:
             self._update_continue_watching_episode(finished)

        # 2. Gestion des Films/Générique (Historique Resume)
        try:
            if hasattr(self, 'stream_id') and hasattr(self, 'stream_type') and self.stream_id and self.stream_type:
                # Récupérer la position actuelle
                try:
                    time = self.getTime()
                    total = self.getTotalTime()
                except:
                    time = 0
                    total = 0
                
                if finished: time = 0
                
                if total > 0:
                    percent = (time / total) * 100
                    from resources.lib import history
                    if not finished and time > 180 and percent < 95:
                        history.update_resume_point(self.stream_id, self.stream_type, time, total)
                    elif finished or percent >= 95:
                        history.update_resume_point(self.stream_id, self.stream_type, 0, total)
        except Exception as e:
            utils.log(f"Error updating resume point: {e}", xbmc.LOGWARNING)

    def _update_continue_watching_episode(self, finished: bool = False) -> None:
        """Logic specific to Episodes (Continue Watching / Next Episode calculation)"""
        if not self.episode_metadata: return
        
        series_id = self.episode_metadata.get('series_id')
        season = self.episode_metadata.get('season')
        episode_num = self.episode_metadata.get('episode_num')
        title = self.episode_metadata.get('title', '')
        
        if not series_id or not season or not episode_num: return
        
        try:
            from resources.lib import continue_watching
            from resources.lib import api
            
            # Get series info for name and artwork
            series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
            
            if series_info:
                info = series_info.get('info', {})
                series_name = info.get('name', 'Unknown Series')
                icon = info.get('cover', '')
                fanart = info.get('backdrop_path', [''])[0] if isinstance(info.get('backdrop_path'), list) else info.get('backdrop_path', '')

                # Calculate next episode
                total_time = 0
                
                if finished:
                    # If finished, point to next episode
                    next_season, next_episode = self._calculate_next_from_info(series_info, season, episode_num)
                    resume_time = 0
                else:
                    # If not finished, stay on current episode (resume)
                    next_season, next_episode = season, episode_num
                    try:
                        resume_time = self.getTime()
                        total_time = self.getTotalTime()
                        
                        if total_time > 0:
                            percent = (resume_time / total_time) * 100
                            if resume_time < 180 or percent >= 95:
                                resume_time = 0
                    except:
                        resume_time = 0
                        total_time = 0
                
                continue_watching.update_progress(
                    series_id=series_id,
                    series_name=series_name,
                    season=season,
                    episode=episode_num,
                    title=title,
                    icon=icon,
                    fanart=fanart,
                    next_season=next_season,
                    next_episode=next_episode,
                    resume_time=resume_time,
                    total_time=total_time
                )
        except Exception as e:
            utils.log(f"Error updating continue watching: {e}", xbmc.LOGWARNING)
    
    def _calculate_next_from_info(self, series_info: Dict[str, Any], current_season: int, current_episode: int):
        """Calculate next episode from series info."""
        try:
            episodes = series_info.get('episodes', {})
            season_episodes = episodes.get(str(current_season), [])
            
            for ep in season_episodes:
                if int(ep.get('episode_num', 0)) == current_episode + 1:
                    return current_season, current_episode + 1
            
            # Check first episode of next season
            next_season = current_season + 1
            if str(next_season) in episodes:
                next_season_episodes = episodes[str(next_season)]
                if next_season_episodes:
                    first_ep_num = int(next_season_episodes[0].get('episode_num', 1))
                    return next_season, first_ep_num
            
            return None, None
        except Exception as e:
            utils.log(f"Error calculating next episode: {e}", xbmc.LOGWARNING)
            return None, None
    
    def _handle_episode_end(self) -> None:
        """Handle the end of an episode playback."""
        if not self.is_playing_episode or not self.episode_metadata: return
        
        series_id = self.episode_metadata.get('series_id')
        season = self.episode_metadata.get('season')
        episode_num = self.episode_metadata.get('episode_num')
        
        if not series_id: return
        
        # Check if auto-play is enabled
        if self.addon.getSetting('autoplay_next_episode') != 'true':
            self.stop_monitoring()
            return
        
        # Get next episode
        next_episode = self._get_next_episode(series_id, season, episode_num)
        
        if next_episode:
            self._show_countdown_and_play(next_episode)
        else:
            utils.notify("Auto-Play", "Fin de la série.", xbmcgui.NOTIFICATION_INFO)
    
    def _get_next_episode(self, series_id: str, current_season: int, current_episode: int) -> Optional[Dict[str, Any]]:
        """Get information about the next episode."""
        if not all([series_id, current_season is not None, current_episode is not None]): return None
        
        series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
        if not series_info: return None
        
        episodes = series_info.get('episodes', {})
        episodes_map = {int(k): v for k, v in episodes.items()}
        
        # Try to find next episode in current season
        current_season_episodes = episodes_map.get(current_season, [])
        for idx, ep in enumerate(current_season_episodes):
            if ep.get('episode_num') == current_episode:
                if idx + 1 < len(current_season_episodes):
                    return self._format_episode_info(current_season_episodes[idx + 1], current_season, series_id)
                break
        
        # Check next season
        if self.addon.getSetting('autoplay_next_season') == 'true':
            next_season = current_season + 1
            next_season_episodes = episodes_map.get(next_season, [])
            if next_season_episodes:
                return self._format_episode_info(next_season_episodes[0], next_season, series_id)
        
        return None
    
    def _format_episode_info(self, episode: Dict[str, Any], season: int, series_id: str) -> Dict[str, Any]:
        """Format episode information using api helpers."""
        ep_id = episode.get('id', '')
        ext = episode.get('container_extension', 'ts')
        
        # Use centralized URL builder
        stream_url = api.build_stream_url('series', ep_id, ext)
        
        ep_data = {}
        if isinstance(episode.get('info'), list) and episode['info']:
             ep_data = episode['info'][0]
        elif isinstance(episode.get('info'), dict):
             ep_data = episode['info']
             
        return {
            'series_id': series_id,
            'season': season,
            'episode_num': episode.get('episode_num', 0),
            'stream_url': stream_url,
            'title': episode.get('title', 'Inconnu'),
            'stream_id': str(ep_id),
            'icon': ep_data.get('movie_image', ''),
            'fanart': '' # Can fetch from series info if really needed
        }
    
    def _show_countdown_and_play(self, next_episode: Dict[str, Any]) -> None:
        """Show countdown dialog and play next episode if not cancelled."""
        try: countdown_seconds = int(self.addon.getSetting('autoplay_countdown'))
        except: countdown_seconds = 10
        countdown_seconds = max(3, min(30, countdown_seconds))
        
        season = next_episode.get('season', 0)
        episode_num = next_episode.get('episode_num', 0)
        title = next_episode.get('title', 'Inconnu')
        
        for remaining in range(countdown_seconds, 0, -1):
            if xbmc.Monitor().abortRequested() or xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                self.cancelled = True
                break
            
            message = f"Lecture dans {remaining}s: S{season:02d}E{episode_num:02d} - {title}"
            
            if remaining == countdown_seconds:
                self.countdown_dialog = xbmcgui.DialogProgress()
                self.countdown_dialog.create("Épisode suivant", message)
            
            if self.countdown_dialog:
                self.countdown_dialog.update(int((countdown_seconds - remaining) * 100 / countdown_seconds), message)
                if self.countdown_dialog.iscanceled():
                    self.cancelled = True
                    break
            
            xbmc.sleep(1000)
        
        if self.countdown_dialog:
            self.countdown_dialog.close()
            self.countdown_dialog = None
        
        if not self.cancelled:
            self._play_next_episode(next_episode)
        
        self.stop_monitoring()
    
    def _play_next_episode(self, episode_info: Dict[str, Any]) -> None:
        """Play the next episode."""
        title = episode_info.get('title', '')
        stream_url = episode_info.get('stream_url', '')
        
        list_item = xbmcgui.ListItem(label=title, path=stream_url)
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # Use Utils for metadata setting
        meta = {
            'title': title,
            'mediatype': 'episode',
            'season': episode_info.get('season', 0),
            'episode': episode_info.get('episode_num', 0)
        }
        utils._set_list_item_metadata(list_item, title, meta)
        
        if episode_info.get('icon'):
            list_item.setArt({'thumb': episode_info['icon'], 'icon': episode_info['icon']})
            
        # Update window properties so onPlayBackStarted picks it up
        try:
            window = xbmcgui.Window(10000)
            window.setProperty('xtream.episode.series_id', str(episode_info.get('series_id', '')))
            window.setProperty('xtream.episode.season', str(episode_info.get('season', '')))
            window.setProperty('xtream.episode.episode_num', str(episode_info.get('episode_num', '')))
            window.setProperty('xtream.episode.title', title)
        except: pass
        
        # We must trigger Play
        self.play(stream_url, list_item)
        
        # Start monitoring immediately
        self.start_monitoring(
            series_id=episode_info.get('series_id', ''),
            season=episode_info.get('season', 0),
            episode_num=episode_info.get('episode_num', 0),
            title=title
        )
        
        # Add to history
        try:
            from resources.lib import history
            history.add_to_history(
                item_type='episode',
                item_id=episode_info.get('stream_id', ''),
                title=title,
                stream_url=stream_url,
                icon=episode_info.get('icon', ''),
                fanart='',
                series_id=episode_info.get('series_id', ''),
                season=str(episode_info.get('season', '')),
                episode_num=str(episode_info.get('episode_num', ''))
            )
        except Exception as e:
            utils.log(f"Error adding history: {e}", xbmc.LOGWARNING)


# Global instance
_monitor_instance = None


def get_monitor() -> PlaybackMonitor:
    """Get the global playback monitor instance."""
    global _monitor_instance
    if _monitor_instance is None:
        _monitor_instance = PlaybackMonitor()
    return _monitor_instance


def start_monitoring_episode(series_id: str, season: int, episode_num: int, title: str) -> None:
    """Start monitoring an episode for auto-play."""
    monitor = get_monitor()
    monitor.start_monitoring(series_id, season, episode_num, title)
