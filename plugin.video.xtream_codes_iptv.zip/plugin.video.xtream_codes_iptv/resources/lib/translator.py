#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Module de traduction pour l'addon Kodi
Traduit les synopsis en arabe en utilisant l'API Google Translate
"""
import json
import xbmc

try:
    # Python 3
    import urllib.parse
    import urllib.request
except ImportError:
    # Python 2 (Kodi 18)
    import urllib
    import urllib2


def translate_to_arabic(text):
    """
    Traduit un texte en arabe en utilisant l'API Google Translate non officielle.
    
    Args:
        text: Texte à traduire
        
    Returns:
        Texte traduit en arabe ou texte original en cas d'erreur
    """
    if not text or len(text) == 0:
        return text
    
    # Vérifier si la traduction est activée
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon()
        if addon.getSetting('enable_arabic_translation') != 'true':
            return None  # Retourner None si désactivé
    except:
        pass
    
    try:
        # Limiter la longueur pour éviter les erreurs
        if len(text) > 5000:
            text = text[:5000]
        
        xbmc.log(f"[Xtream Codes] Translating to Arabic: {text[:50]}...", xbmc.LOGDEBUG)
        
        # URL de l'API Google Translate (non officielle)
        base_url = "https://translate.googleapis.com/translate_a/single"
        
        try:
            # Python 3
            params = urllib.parse.urlencode({
                'client': 'gtx',
                'sl': 'auto',  # Détection automatique
                'tl': 'ar',    # Arabe
                'dt': 't',
                'q': text.encode('utf-8')
            })
            url = f"{base_url}?{params}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
        except:
            # Python 2 fallback
            params = urllib.urlencode({
                'client': 'gtx',
                'sl': 'auto',
                'tl': 'ar',
                'dt': 't',
                'q': text.encode('utf-8')
            })
            url = base_url + '?' + params
            req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            response = urllib2.urlopen(req, timeout=10)
            result = json.loads(response.read().decode('utf-8'))
            response.close()
        
        # Extraire la traduction
        if result and len(result) > 0 and result[0]:
            translated = ''.join([item[0] for item in result[0] if item[0]])
            xbmc.log(f"[Xtream Codes] Translation successful: {translated[:50]}...", xbmc.LOGDEBUG)
            return translated
        
        return text
        
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Translation error: {e}", xbmc.LOGWARNING)
        return text  # Retourner le texte original en cas d'erreur


def format_bilingual_text(original, translated, title="Synopsis"):
    """
    Formate un texte bilingue pour l'affichage dans Kodi.
    
    Args:
        original: Texte original
        translated: Texte traduit en arabe
        title: Titre de la section
        
    Returns:
        Texte formaté avec les deux versions
    """
    if not translated:
        return f"\n{title}:\n{original}\n"
    
    return f"""
{title} (Original):
{original}

الملخص (بالعربية):
{translated}
"""
