"""
Module UI principal - Core functions
Coordonne les modules UI spécialisés.
"""
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

from resources.lib import api
from resources.lib import utils
from resources.lib import ui_live
from resources.lib import ui_vod
from resources.lib import ui_series
from resources.lib import ui_search
from resources.lib import ui_history

# Initialisation des ressources
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# Icons & Fanart
DEFAULT_FANART = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/fanart.jpg')
LIVE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/live_icon.png')
VOD_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/vod_icon.png')
SERIES_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/series_icon.png')
SEARCH_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/search_icon.png')
USER_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/user_info_icon.png')
CACHE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/cache_icon.png')

# Settings UI
try:
    RECENT_ITEMS_COUNT = int(ADDON.getSetting('recent_items_count'))
except ValueError:
    RECENT_ITEMS_COUNT = 100

# Initialize sub-modules
ui_live.init_resources(LIVE_ICON, DEFAULT_FANART)
ui_vod.init_resources(VOD_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT)
ui_series.init_resources(SERIES_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT)
ui_search.init_resources(SEARCH_ICON, VOD_ICON, SERIES_ICON, DEFAULT_FANART)
ui_history.init_resources(LIVE_ICON, DEFAULT_FANART)  # Use LIVE_ICON as fallback

def add_directory_item(
    label: str,
    action: str,
    is_folder: bool = True,
    icon: Optional[str] = None,
    fanart: Optional[str] = None,
    info: Optional[Dict[str, Any]] = None,
    context_menu: Optional[List[Tuple[str, str]]] = None,
    is_playable: bool = False,
    **kwargs: Any
) -> None:
    """
    Ajoute un élément de répertoire générique.
    """
    list_item = xbmcgui.ListItem(label=label)
    
    # Artwork
    art = {}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        list_item.setArt(art)
    
    # Info
    if info:
        list_item.setInfo('video', info)
    
    # Context Menu
    if context_menu:
        list_item.addContextMenuItems(context_menu, replaceItems=True)
    
    # Playable
    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
    
    # URL
    url = utils.build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=utils.get_handle(), url=url, listitem=list_item, isFolder=is_folder)

# ---------------------------
# MAIN MENU
# ---------------------------
def show_main_menu() -> None:
    """Display main menu."""
    add_directory_item("Live TV", 'list_live_categories', icon=LIVE_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Films", 'list_vod_categories', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Series", 'list_series_categories', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Recherche", 'search_menu', is_folder=True, icon=SEARCH_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Historique", 'show_watch_history', is_folder=True, icon=LIVE_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Informations Compte", 'show_user_info', is_folder=False, icon=USER_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Effacer le Cache", 'clear_cache', is_folder=False, icon=CACHE_ICON, fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_user_info() -> None:
    """Display user information."""
    user_info = api.fetch_data('action=user_info')
    if not user_info:
        return

    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    
    exp_date = info.get('exp_date')
    if exp_date and exp_date != '0':
        try:
            exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            exp_date = 'Inconnu'
    else:
        exp_date = 'Illimité'
        
    message = (
        f"Nom d'utilisateur: {info.get('username', 'Inconnu')}\n"
        f"Statut: {info.get('status', 'Inconnu')}\n"
        f"Date d'expiration: {exp_date}\n"
        f"Connexions actives: {info.get('active_cons', 'Inconnu')}\n"
        f"Connexions autorisées: {info.get('max_connections', 'Inconnu')}\n"
        f"Serveur: {server_info.get('url', 'Inconnu')}:{server_info.get('port', 'Inconnu')}\n"
        f"Protocole: {server_info.get('server_protocol', 'Inconnu')}\n"
        f"Fuseau horaire: {server_info.get('timezone', 'Inconnu')}\n"
        f"Heure actuelle: {server_info.get('time_now', 'Inconnu')}"
    )
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)

def confirm_clear_cache() -> None:
    """Prompt user before clearing cache."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer le cache local ?"):
        api.clear_cache()

# ---------------------------
# DELEGATED FUNCTIONS TO SUB-MODULES
# ---------------------------

# Live TV
def show_live_categories(parent_id: str = "0") -> None:
    ui_live.show_live_categories(add_directory_item, parent_id)

def show_live_channels(category_id: str) -> None:
    ui_live.show_live_channels(add_directory_item, category_id)

def play_channel(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "") -> None:
    ui_live.play_channel(stream_url, title, stream_id, stream_icon)

def add_channel_to_playlist(stream_url: str, label: str) -> None:
    ui_live.add_channel_to_playlist(stream_url, label)

def play_live_playlist(category_id: str) -> None:
    ui_live.play_live_playlist(category_id)

# VOD (Movies)
def show_vod_categories(parent_id: str = "0") -> None:
    ui_vod.show_vod_categories(add_directory_item, parent_id)

def show_movies(category_id: str) -> None:
    ui_vod.show_movies(add_directory_item, category_id)

def show_recent_movies() -> None:
    ui_vod.show_recent_movies(add_directory_item)

def play_movie(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "") -> None:
    ui_vod.play_movie(stream_url, title, stream_id, stream_icon, stream_fanart)

def add_movie_to_playlist(stream_url: str, label: str) -> None:
    ui_vod.add_movie_to_playlist(stream_url, label)

def show_movie_info(stream_id: str) -> None:
    ui_vod.show_movie_info(stream_id)

# Series (TV Shows)
def show_series_categories() -> None:
    ui_series.show_series_categories(add_directory_item)

def show_series(category_id: str) -> None:
    ui_series.show_series(add_directory_item, category_id)

def show_recent_series() -> None:
    ui_series.show_recent_series(add_directory_item)

def show_seasons(series_id: str) -> None:
    ui_series.show_seasons(add_directory_item, series_id)

def show_episodes(series_id: str, season: str) -> None:
    ui_series.show_episodes(add_directory_item, series_id, season)

def play_episode(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "") -> None:
    ui_series.play_episode(stream_url, title, stream_id, stream_icon, stream_fanart)

def add_episode_to_playlist(stream_url: str, label: str) -> None:
    ui_series.add_episode_to_playlist(stream_url, label)

# Search
def show_search_menu() -> None:
    ui_search.show_search_menu(add_directory_item)

def last_search() -> None:
    ui_search.last_search(
        lambda movies: ui_vod.add_movies_to_directory(add_directory_item, movies),
        lambda series: ui_series.add_series_to_directory(add_directory_item, series)
    )

def recherche_film(query: str = "") -> None:
    ui_search.recherche_film(
        lambda movies: ui_vod.add_movies_to_directory(add_directory_item, movies),
        query
    )

def recherche_serie(query: str = "") -> None:
    ui_search.recherche_serie(
        lambda series: ui_series.add_series_to_directory(add_directory_item, series),
        query
    )

# History
def show_watch_history() -> None:
    ui_history.show_watch_history(add_directory_item)

def confirm_clear_history() -> None:
    ui_history.confirm_clear_history()

def remove_from_history_ui(item_type: str, item_id: str) -> None:
    ui_history.remove_from_history_ui(item_type, item_id)
