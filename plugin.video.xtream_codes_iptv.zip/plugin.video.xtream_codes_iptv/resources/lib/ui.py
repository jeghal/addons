"""
Module UI principal - Core functions
Coordonne les modules UI spécialisés.
"""
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

from resources.lib import api
from resources.lib import utils
from resources.lib import ui_live
from resources.lib import ui_vod
from resources.lib import ui_series
from resources.lib import ui_search
from resources.lib import ui_history
from resources.lib import ui_continue

# Initialisation des ressources
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# Icons & Fanart
DEFAULT_FANART = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/fanart.jpg')
LIVE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/live_icon.png')
VOD_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/vod_icon.png')
SERIES_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/series_icon.png')
SEARCH_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/search_icon.png')
USER_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/user_info_icon.png')
CACHE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/cache_icon.png')

# Settings UI
try:
    RECENT_ITEMS_COUNT = int(ADDON.getSetting('recent_items_count'))
except ValueError:
    RECENT_ITEMS_COUNT = 100

# Initialize sub-modules
ui_live.init_resources(LIVE_ICON, DEFAULT_FANART)
ui_vod.init_resources(VOD_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT, search_icon=SEARCH_ICON, series_icon=SERIES_ICON)
ui_series.init_resources(SERIES_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT, search_icon=SEARCH_ICON)
ui_search.init_resources(SEARCH_ICON, VOD_ICON, SERIES_ICON, DEFAULT_FANART)
ui_history.init_resources(LIVE_ICON, DEFAULT_FANART)  # Use LIVE_ICON as fallback
ui_continue.init_resources(SERIES_ICON, DEFAULT_FANART)  # Use SERIES_ICON for continue watching

# Initialize playback monitor for auto-play next episode
try:
    from resources.lib import playback_monitor
    _playback_monitor = playback_monitor.get_monitor()
    xbmc.log("[Xtream Codes] PlaybackMonitor initialized and ready", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Xtream Codes] Failed to initialize PlaybackMonitor: {e}", xbmc.LOGWARNING)

def add_directory_item(
    label: str,
    action: str,
    is_folder: bool = True,
    icon: Optional[str] = None,
    fanart: Optional[str] = None,
    info: Optional[Dict[str, Any]] = None,
    context_menu: Optional[List[Tuple[str, str]]] = None,
    is_playable: bool = False,
    **kwargs: Any
) -> None:
    """
    Ajoute un élément de répertoire générique.
    """
    list_item = xbmcgui.ListItem(label=label)
    
    # Artwork
    art = {}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        list_item.setArt(art)
    
    # Info
    if info:
        # Kodi Matrix/Nexus+ (version 19+) - Utilisation de InfoTagVideo
        if hasattr(list_item, 'getVideoInfoTag'):
            video_info = list_item.getVideoInfoTag()
            
            # Mappage des champs standard
            if 'title' in info: video_info.setTitle(info['title'])
            if 'plot' in info: video_info.setPlot(info['plot'])
            if 'year' in info and info['year']:
                try: video_info.setYear(int(info['year']))
                except (ValueError, TypeError): pass
            if 'duration' in info and info['duration']:
                try: video_info.setDuration(int(info['duration']))
                except (ValueError, TypeError): pass
            if 'rating' in info and info['rating']:
                try: video_info.setRating(float(info['rating']))
                except (ValueError, TypeError): pass
            
            # Listes (genre, cast, director)
            if 'genre' in info:
                # Peut être une string ou une liste
                genres = info['genre']
                if isinstance(genres, str):
                    genres = [g.strip() for g in genres.split(',')]
                video_info.setGenres(genres)
                
            if 'director' in info:
                directors = info['director']
                if isinstance(directors, str):
                    directors = [d.strip() for d in directors.split(',')]
                elif not isinstance(directors, list):
                    directors = [str(directors)]
                video_info.setDirectors(directors)
                
            if 'cast' in info:
                cast_list = info['cast']
                actors = []
                
                # Normalize to list of strings if string provided
                if isinstance(cast_list, str):
                    cast_list = [c.strip() for c in cast_list.split(',')]
                
                # Process list
                if isinstance(cast_list, list):
                    for c in cast_list:
                        if isinstance(c, str) and c:
                            # Simple name string
                            if hasattr(xbmc, 'Actor'):
                                actors.append(xbmc.Actor(name=c))
                        elif isinstance(c, dict):
                            # Dictionary with details
                            name = c.get('name', '')
                            if name and hasattr(xbmc, 'Actor'):
                                role = c.get('role', '')
                                thumb = c.get('thumbnail', '')
                                actors.append(xbmc.Actor(name=name, role=role, thumbnail=thumb))
                
                if actors:
                    video_info.setCast(actors)

            # Champs supplémentaires
            if 'premiered' in info: video_info.setPremiered(info['premiered'])
            if 'studio' in info: video_info.setStudios([info['studio']])
            if 'tagline' in info: 
                # Try multiple variations or skip if missing (Kodi API varies)
                if hasattr(video_info, 'setTagLine'): video_info.setTagLine(info['tagline'])
                elif hasattr(video_info, 'setTagline'): video_info.setTagline(info['tagline'])
            
            if 'mediatype' in info: video_info.setMediaType(info['mediatype'])
            if 'country' in info: video_info.setCountries([info['country']])
            
        # Fallback ancienne API (Kodi 18 et antérieurs) ou complément
        else:
            list_item.setInfo('video', info)
    
    # Context Menu
    if context_menu:
        list_item.addContextMenuItems(context_menu, replaceItems=True)
    
    # Playable
    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # For episodes, store metadata in window properties for auto-play
        # This is necessary because Kodi doesn't recall the addon for playable items
        if action == 'play_episode' and 'series_id' in kwargs and 'season' in kwargs and 'episode_num' in kwargs:
            try:
                window = xbmcgui.Window(10000)
                window.setProperty('xtream.episode.series_id', kwargs.get('series_id', ''))
                window.setProperty('xtream.episode.season', kwargs.get('season', ''))
                window.setProperty('xtream.episode.episode_num', kwargs.get('episode_num', ''))
                window.setProperty('xtream.episode.title', kwargs.get('title', label))
                xbmc.log(f"[Xtream Codes] Stored episode metadata: S{kwargs.get('season')}E{kwargs.get('episode_num')} - {kwargs.get('title', label)}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Xtream Codes] Error storing episode metadata: {e}", xbmc.LOGWARNING)
    
    # Resume Points
    if 'resume_time' in kwargs:
        list_item.setProperty('ResumeTime', str(kwargs['resume_time']))
        list_item.setProperty('TotalTime', str(kwargs.get('total_time', '')))
    
    # URL
    url = utils.build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=utils.get_handle(), url=url, listitem=list_item, isFolder=is_folder)

# ---------------------------
# MAIN MENU
# ---------------------------
def show_main_menu() -> None:
    """Display main menu."""
    # 1. Live TV (Direct)
    add_directory_item("Direct (Live TV)", 'list_live_categories', icon=LIVE_ICON, fanart=DEFAULT_FANART)
    
    # 2. Films (VOD)
    add_directory_item("Films (VOD)", 'list_vod_categories', icon=VOD_ICON, fanart=DEFAULT_FANART)
    
    # 3. Séries
    add_directory_item("Séries", 'list_series_categories', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    
    # 4. Mon Compte
    add_directory_item("Mon Compte", 'show_user_info', is_folder=False, icon=USER_ICON, fanart=DEFAULT_FANART)
    
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_settings_menu() -> None:
    """Display settings and tools menu."""
    # User Account Info
    add_directory_item("Informations Compte", 'show_user_info', is_folder=False, icon=USER_ICON, fanart=DEFAULT_FANART)
    
    # Maintenance
    add_directory_item("Effacer le Cache", 'clear_cache', is_folder=False, icon=CACHE_ICON, fanart=DEFAULT_FANART)
    
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_user_info() -> None:
    """Display user information."""
    user_info = api.fetch_data('action=user_info')
    if not user_info:
        return

    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    
    exp_date = info.get('exp_date')
    if exp_date and exp_date != '0':
        try:
            exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            exp_date = 'Inconnu'
    else:
        exp_date = 'Illimité'
        
    message = (
        f"Nom d'utilisateur: {info.get('username', 'Inconnu')}\n"
        f"Statut: {info.get('status', 'Inconnu')}\n"
        f"Date d'expiration: {exp_date}\n"
        f"Connexions actives: {info.get('active_cons', 'Inconnu')}\n"
        f"Connexions autorisées: {info.get('max_connections', 'Inconnu')}\n"
        f"Serveur: {server_info.get('url', 'Inconnu')}:{server_info.get('port', 'Inconnu')}\n"
        f"Protocole: {server_info.get('server_protocol', 'Inconnu')}\n"
        f"Fuseau horaire: {server_info.get('timezone', 'Inconnu')}\n"
        f"Heure actuelle: {server_info.get('time_now', 'Inconnu')}"
    )
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)

def confirm_clear_cache() -> None:
    """Prompt user before clearing cache."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer le cache local ?"):
        api.clear_cache()

# ---------------------------
# DELEGATED FUNCTIONS TO SUB-MODULES
# ---------------------------

# Live TV
def show_live_categories(parent_id: str = "0") -> None:
    ui_live.show_live_categories(add_directory_item, parent_id)

def show_live_channels(category_id: str) -> None:
    ui_live.show_live_channels(add_directory_item, category_id)

def play_channel(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "") -> None:
    ui_live.play_channel(stream_url, title, stream_id, stream_icon)

def add_channel_to_playlist(stream_url: str, label: str) -> None:
    ui_live.add_channel_to_playlist(stream_url, label)

def play_live_playlist(category_id: str) -> None:
    ui_live.play_live_playlist(category_id)

# VOD (Movies)
def show_vod_categories(parent_id: str = "0") -> None:
    ui_vod.show_vod_categories(add_directory_item, parent_id)

def show_movies(category_id: str) -> None:
    ui_vod.show_movies(add_directory_item, category_id)

def show_recent_movies() -> None:
    ui_vod.show_recent_movies(add_directory_item)

def play_movie(stream_url, title, stream_id, icon, fanart, plot, year, duration, rating, resume_time=0) -> None:
    """Play a movie."""
    meta = {
        'plot': plot,
        'year': year,
        'duration': duration,
        'rating': rating,
        'mediatype': 'movie'
    }
    utils.play_stream(stream_url, 'movie', title, stream_id, icon, fanart, meta=meta, resume_time=resume_time)

def add_movie_to_playlist(stream_url: str, label: str) -> None:
    ui_vod.add_movie_to_playlist(stream_url, label)

def show_movie_options(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "", 
                       plot: str = "", year: str = "", duration: str = "", rating: str = "") -> None:
    ui_vod.show_movie_options_menu(add_directory_item, stream_url, title, stream_id, stream_icon, stream_fanart, plot, year, duration, rating)

def show_movie_info(stream_id: str) -> None:
    ui_vod.show_movie_info(stream_id)

# Series (TV Shows)
def show_series_categories() -> None:
    ui_series.show_series_categories(add_directory_item)

def show_series(category_id: str) -> None:
    ui_series.show_series(add_directory_item, category_id)

def show_recent_series() -> None:
    ui_series.show_recent_series(add_directory_item)

def show_seasons(series_id: str) -> None:
    ui_series.show_seasons(add_directory_item, series_id)

def show_episodes(series_id: str, season: str) -> None:
    ui_series.show_episodes(add_directory_item, series_id, season)

def play_episode(stream_url, title, stream_id, icon, fanart, series_id, season, episode_num, plot, duration, premiered, tvshowtitle, resume_time=0) -> None:
    """Play an episode."""
    meta = {
        'plot': plot,
        'duration': duration,
        'premiered': premiered,
        'tvshowtitle': tvshowtitle,
        'mediatype': 'episode',
        'season': season,
        'episode': episode_num
    }
    utils.play_stream(stream_url, 'episode', title, stream_id, icon, fanart, series_id, season, episode_num, meta, resume_time=resume_time)

def add_episode_to_playlist(stream_url: str, label: str) -> None:
    ui_series.add_episode_to_playlist(stream_url, label)

def show_series_info(series_id: str) -> None:
    ui_series.show_series_info(series_id)

# Search
def show_search_menu() -> None:
    ui_search.show_search_menu(add_directory_item)

def last_search() -> None:
    ui_search.last_search(
        lambda movies: ui_vod.add_movies_to_directory(add_directory_item, movies),
        lambda series: ui_series.add_series_to_directory(add_directory_item, series)
    )

def recherche_film(query: str = "") -> None:
    ui_search.recherche_film(
        lambda movies: ui_vod.add_movies_to_directory(add_directory_item, movies),
        query
    )

def recherche_serie(query: str = "") -> None:
    ui_search.recherche_serie(
        lambda series: ui_series.add_series_to_directory(add_directory_item, series),
        query
    )

# History
def show_watch_history() -> None:
    """Show all history."""
    ui_history.show_watch_history(add_directory_item)

def show_movie_history() -> None:
    """Show only movie history."""
    ui_history.show_watch_history(add_directory_item, filter_type='movie')
    
def show_series_history() -> None:
    """Show only series history."""
    ui_history.show_watch_history(add_directory_item, filter_type='episode')

def confirm_clear_history() -> None:
    ui_history.confirm_clear_history()

def remove_from_history_ui(item_type: str, item_id: str) -> None:
    ui_history.remove_from_history_ui(item_type, item_id)

# Continue Watching
def show_continue_watching() -> None:
    ui_continue.show_continue_watching(add_directory_item)

def play_next_from_continue(series_id: str) -> None:
    ui_continue.play_next_episode(series_id)

def replay_last_from_continue(series_id: str) -> None:
    ui_continue.replay_last_episode(series_id)

def remove_from_continue(series_id: str) -> None:
    ui_continue.remove_from_continue_ui(series_id)

def confirm_clear_continue_watching() -> None:
    ui_continue.confirm_clear_continue_watching()
