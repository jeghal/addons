import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

from resources.lib import api
from resources.lib import utils

# Initialisation des ressources
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# Icons & Fanart
DEFAULT_FANART = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/fanart.jpg')
LIVE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/live_icon.png')
VOD_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/vod_icon.png')
SERIES_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/series_icon.png')
SEARCH_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/search_icon.png')
USER_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/user_info_icon.png')
CACHE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/cache_icon.png')

# Settings UI
try:
    RECENT_ITEMS_COUNT = int(ADDON.getSetting('recent_items_count'))
except ValueError:
    RECENT_ITEMS_COUNT = 100

def add_directory_item(
    label: str,
    action: str,
    is_folder: bool = True,
    icon: Optional[str] = None,
    fanart: Optional[str] = None,
    info: Optional[Dict[str, Any]] = None,
    context_menu: Optional[List[Tuple[str, str]]] = None,
    is_playable: bool = False,
    **kwargs: Any
) -> None:
    """
    Ajoute un élément de répertoire générique.
    """
    list_item = xbmcgui.ListItem(label=label)
    
    # Artwork
    art = {}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        list_item.setArt(art)
    
    # Info
    if info:
        list_item.setInfo('video', info)
    
    # Context Menu
    if context_menu:
        list_item.addContextMenuItems(context_menu, replaceItems=True)
    
    # Playable
    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
    
    # URL
    url = utils.build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=utils.get_handle(), url=url, listitem=list_item, isFolder=is_folder)

# ---------------------------
# MAIN MENU
# ---------------------------
def show_main_menu() -> None:
    add_directory_item("Live", 'list_live_categories', icon=LIVE_ICON, fanart=DEFAULT_FANART)
    add_directory_item("VOD", 'list_vod_categories', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("TVSHOWS", 'list_series_categories', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Recherche", 'search_menu', is_folder=True, icon=SEARCH_ICON, fanart=DEFAULT_FANART)
    add_directory_item("User Info", 'show_user_info', is_folder=False, icon=USER_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Effacer le cache", 'clear_cache', is_folder=False, icon=CACHE_ICON, fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_search_menu() -> None:
    add_directory_item("Rechercher un film", 'search_movies', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Rechercher une série", 'search_series', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Dernière recherche", 'last_search', is_folder=True, icon=SEARCH_ICON, fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(utils.get_handle())

def last_search() -> None:
    query = ADDON.getSetting('last_search_query')
    search_type = ADDON.getSetting('last_search_type')
    
    if not query:
        utils.notify("Info", "Aucune recherche récente.")
        return
        
    if search_type == 'movie':
        recherche_film(query)
    elif search_type == 'series':
        recherche_serie(query)
    else:
        utils.notify("Info", "Type de recherche inconnu.")

# ---------------------------
# LIVE TV
# ---------------------------
def show_live_categories(parent_id: str = "0") -> None:
    """Display all live categories in a flat list (no hierarchy)."""
    categories = api.fetch_data('action=get_live_categories')
    if not categories:
        utils.notify("Erreur", "Aucune catégorie Live trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Display all categories directly (no parent_id filtering)
    for category in categories:
        cat_id = str(category.get('category_id'))
        cat_name = category.get('category_name', 'Inconnu')
        
        add_directory_item(
            label=cat_name,
            action='list_live_channels',
            is_folder=True,
            icon=LIVE_ICON,
            fanart=DEFAULT_FANART,
            category_id=cat_id
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_live_channels(category_id: str) -> None:
    if not category_id:
        return

    channels = api.fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        xbmc.log(f"[Xtream Codes] No live channels found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Play All Option
    add_directory_item(
        label="[Lire toutes les chaînes]",
        action='play_live_playlist',
        is_folder=False,
        icon=LIVE_ICON,
        fanart=DEFAULT_FANART,
        category_id=category_id
    )

    for channel in channels:
        stream_id = str(channel.get('stream_id', ''))
        if not stream_id:
            continue
            
        name = channel.get('name', 'Inconnu')
        
        # Get icon with fallback
        icon = channel.get('stream_icon', '') or channel.get('icon', '') or LIVE_ICON
        
        # Build stream URL - Use .ts for live streams (standard for Xtream Codes)
        stream_url = f"{api.get_server_url()}/live/{api.get_username()}/{api.get_password()}/{stream_id}.ts"
        
        # Build info with EPG data if available
        info = {
            'title': name,
            'mediatype': 'video'
        }
        
        # Add EPG info if available
        epg_channel_id = channel.get('epg_channel_id', '')
        if epg_channel_id:
            info['plot'] = f"EPG ID: {epg_channel_id}"
        
        # Context menu
        context_menu = [
            ("Ajouter à la liste de lecture", f"RunPlugin({utils.build_url({'action': 'add_channel_to_playlist', 'stream_url': stream_url, 'label': name})})"),
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=name,
            action='play_channel',
            is_folder=False,
            icon=icon,
            fanart=DEFAULT_FANART,
            info=info,
            context_menu=context_menu,
            is_playable=True,
            stream_url=stream_url
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_channel(stream_url: str) -> None:
    """Play a live TV channel stream."""
    if not utils.validate_stream_url(stream_url):
        utils.notify("Erreur", "URL de stream invalide", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(utils.get_handle(), False, xbmcgui.ListItem())
        return
    
    utils.log(f"Playing channel: {stream_url}", xbmc.LOGDEBUG)
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(utils.get_handle(), True, list_item)

def add_channel_to_playlist(stream_url: str, label: str) -> None:
    """Add a live channel to the playlist."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Chaîne ajoutée.")

def play_live_playlist(category_id: str) -> None:
    channels = api.fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        return

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    
    server = api.get_server_url()
    user = api.get_username()
    pwd = api.get_password()
    
    count = 0
    for channel in channels:
        stream_id = channel.get('stream_id')
        if not stream_id:
            continue
        stream_url = f"{server}/live/{user}/{pwd}/{stream_id}.ts"
        li = xbmcgui.ListItem(label=channel.get('name', 'Inconnu'))
        li.setProperty('IsPlayable', 'true')
        li.setContentLookup(False)
        playlist.add(stream_url, li)
        count += 1
        
    if count > 0:
        xbmc.Player().play(playlist)
        utils.notify("Lecture Playlist", f"Lecture de {count} chaînes.")
    else:
        utils.notify("Erreur", "Aucune chaîne disponible.", xbmcgui.NOTIFICATION_ERROR)

# ---------------------------
# VOD (MOVIES)
# ---------------------------
def show_vod_categories(parent_id: str = "0") -> None:
    categories = api.fetch_data("action=get_vod_categories")
    if not categories:
        utils.notify("Erreur", "Aucune catégorie VOD trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Normalisation
    parent_id = str(parent_id)
    
    # Option : Films récemment ajoutés (seulement à la racine)
    if parent_id == "0":
        add_directory_item(
            label="Films récemment ajoutés",
            action='list_recent_movies',
            is_folder=True,
            icon=VOD_ICON,
            fanart=DEFAULT_FANART
        )

    # Filtrage et identification de la structure
    current_level_cats = []
    all_parent_ids = set()
    
    for cat in categories:
        pid = str(cat.get('parent_id', '0'))
        cid = str(cat.get('category_id'))
        all_parent_ids.add(pid)
        
        if pid == parent_id:
            current_level_cats.append(cat)
            
    if not current_level_cats and parent_id != "0":
        utils.notify("Info", "Aucune sous-catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle())
        return

    for category in current_level_cats:
        cat_id = str(category.get('category_id'))
        cat_name = category.get('category_name', 'Inconnu')
        
        is_folder_structure = cat_id in all_parent_ids
        
        if is_folder_structure:
            add_directory_item(
                label=cat_name,
                action='list_vod_categories',
                is_folder=True,
                icon=VOD_ICON,
                fanart=DEFAULT_FANART,
                category_id=cat_id
            )
        else:
            add_directory_item(
                label=cat_name,
                action='list_movies',
                is_folder=True,
                icon=VOD_ICON,
                fanart=DEFAULT_FANART,
                category_id=cat_id
            )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_movies(category_id: str) -> None:
    movies = api.fetch_data(f"action=get_vod_streams&category_id={category_id}")
    if not movies:
        xbmc.log(f"[Xtream Codes] No movies found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucun film disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    for movie in movies:
        movie['added_int'] = int(movie.get('added', 0))
    movies.sort(key=lambda x: x['added_int'], reverse=True)
    
    add_movies_to_directory(movies)

def show_recent_movies() -> None:
    movies = api.fetch_data("action=get_vod_streams")
    if not movies:
        return

    for movie in movies:
        movie['added_int'] = int(movie.get('added', 0))
    movies.sort(key=lambda x: x['added_int'], reverse=True)
    movies = movies[:RECENT_ITEMS_COUNT]
    
    add_movies_to_directory(movies)

def add_movies_to_directory(movies: List[Dict[str, Any]]) -> None:
    server_url = api.get_server_url()
    username = api.get_username()
    password = api.get_password()
    
    # Tell Kodi this is a movies listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'movies')
    
    # Log for debugging
    xbmc.log(f"[Xtream Codes] Loading {len(movies)} movies", xbmc.LOGDEBUG)

    for movie in movies:
        # NO REGEX CLEANING - Use raw title like series
        label = movie.get('name', 'Inconnu')
        stream_id = movie.get('stream_id')
        
        # Use helper functions for parsing
        year = utils.parse_year(movie.get('year', 0))
        rating = utils.parse_rating(movie.get('rating', 0))
        duration = utils.parse_duration(movie.get('duration', 0))
        cast = utils.parse_cast(movie.get('cast', ''))
        
        info = {
            'title': label,
            'plot': movie.get('plot', '') or movie.get('description', ''),
            'genre': movie.get('genre', ''),
            'director': movie.get('director', ''),
            'country': movie.get('country', ''),
            'mediatype': 'movie'
        }
        
        # Add optional fields only if valid
        if year > 0:
            info['year'] = year
            info['premiered'] = f"{year}-01-01"
        if rating > 0:
            info['rating'] = rating
        if duration > 0:
            info['duration'] = duration
        if cast:
            info['cast'] = cast
        
        # Additional metadata for Kodi's Information dialog
        studio = movie.get('studio', '')
        if studio:
            info['studio'] = studio
        
        tagline = movie.get('tagline', '')
        if tagline:
            info['tagline'] = tagline
        
        # Get artwork
        thumb = movie.get('stream_icon', '') or movie.get('cover', '') or VOD_ICON
        
        # Use helper for backdrop
        fanart = utils.safe_get_backdrop(movie.get('backdrop_path'), DEFAULT_FANART)
        
        stream_url = f"{server_url}/movie/{username}/{password}/{stream_id}.{movie.get('container_extension')}"
        
        # Context menu (Kodi's native "Information" menu will show movie details automatically)
        context_menu = [
            ("Ajouter à la liste de lecture", f"RunPlugin({utils.build_url({'action': 'add_movie_to_playlist', 'stream_url': stream_url, 'label': label})})"),
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=label,
            action='play_movie',
            is_folder=False,
            icon=thumb,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            is_playable=True,
            stream_url=stream_url
        )
    
    xbmc.log(f"[Xtream Codes] Finished loading {len(movies)} movies", xbmc.LOGDEBUG)
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_movie(stream_url: str) -> None:
    """Play a movie stream."""
    if not utils.validate_stream_url(stream_url):
        utils.notify("Erreur", "URL de stream invalide", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(utils.get_handle(), False, xbmcgui.ListItem())
        return
    
    utils.log(f"Playing movie: {stream_url}", xbmc.LOGDEBUG)
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(utils.get_handle(), True, list_item)

def add_movie_to_playlist(stream_url: str, label: str) -> None:
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Film ajouté.")

def show_movie_info(stream_id: str) -> None:
    """
    Affiche les détails complets d'un film via get_vod_info.
    """
    if not stream_id:
        return
    
    movie_data = api.fetch_data(f"action=get_vod_info&vod_id={stream_id}")
    if not movie_data:
        utils.notify("Erreur", "Impossible de récupérer les infos du film.", xbmcgui.NOTIFICATION_ERROR)
        return
    
    info = movie_data.get('info', {})
    movie_info = movie_data.get('movie_data', {})
    
    # Extract movie details
    title = info.get('name', 'Inconnu')
    plot = info.get('plot', '') or info.get('description', 'Aucun synopsis disponible')
    director = info.get('director', 'Inconnu')
    actors = info.get('actors', '') or info.get('cast', 'Inconnu')
    country = info.get('country', 'Inconnu')
    genre = info.get('genre', 'Inconnu')
    rating = info.get('rating', 'N/A')
    release_date = info.get('releasedate', 'Inconnu')
    duration = info.get('duration', 'Inconnu')
    tmdb_id = info.get('tmdb_id', '')
    
    # Build detailed message
    message = f"""[B]{title}[/B]

[B]Synopsis:[/B]
{plot}

[B]Réalisateur:[/B] {director}
[B]Acteurs:[/B] {actors}
[B]Genre:[/B] {genre}
[B]Pays:[/B] {country}
[B]Note:[/B] {rating}/10
[B]Durée:[/B] {duration}
[B]Date de sortie:[/B] {release_date}"""
    
    if tmdb_id:
        message += f"\n[B]TMDB ID:[/B] {tmdb_id}"
    
    # Display in text viewer
    xbmcgui.Dialog().textviewer(f"Détails - {title}", message)

def _perform_search(type_label: str, search_type: str, api_action: str, display_func: callable, items_name: str, query: str = "") -> None:
    """
    Helper function to handle search logic for both movies and series.
    """
    if not query:
        keyboard = xbmc.Keyboard("", f"Entrez le titre ({type_label})")
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText().strip().lower()
            
    if not query:
        return
    
    # Save search history
    ADDON.setSetting('last_search_query', query)
    ADDON.setSetting('last_search_type', search_type)
    
    items = api.fetch_data(f"action={api_action}")
    if items:
        found = [i for i in items if query in i.get('name', '').lower()]
        if found:
            display_func(found)
            utils.notify("Recherche", f"{len(found)} {items_name}.")
        else:
            utils.notify("Résultat", f"Aucun {type_label} trouvé.", xbmcgui.NOTIFICATION_ERROR)

def recherche_film(query: str = "") -> None:
    _perform_search("film", 'movie', 'get_vod_streams', add_movies_to_directory, "film(s) trouvé(s)", query)

def recherche_serie(query: str = "") -> None:
    _perform_search("série", 'series', 'get_series', add_series_to_directory, "série(s)", query)

def confirm_clear_cache() -> None:
    """Prompt user before clearing cache."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer le cache local ?"):
        api.clear_cache()

# ---------------------------
# TV SHOWS (SERIES)
# ---------------------------
def show_series_categories() -> None:
    categories = api.fetch_data("action=get_series_categories")
    if not categories:
        utils.notify("Erreur", "Aucune catégorie de séries trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    add_directory_item(
        label="Séries récemment ajoutées",
        action='list_recent_series',
        is_folder=True,
        icon=SERIES_ICON,
        fanart=DEFAULT_FANART
    )

    for category in categories:
        add_directory_item(
            label=category.get('category_name', 'Inconnu'),
            action='list_series',
            is_folder=True,
            icon=SERIES_ICON,
            fanart=DEFAULT_FANART,
            category_id=category.get('category_id')
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_series(category_id: str) -> None:
    series = api.fetch_data(f"action=get_series&category_id={category_id}")
    if not series:
        xbmc.log(f"[Xtream Codes] No series found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucune série disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    for serie in series:
        serie['last_modified_int'] = int(serie.get('last_modified', 0))
    series.sort(key=lambda x: x['last_modified_int'], reverse=True)
    
    add_series_to_directory(series)

def show_recent_series() -> None:
    series = api.fetch_data("action=get_series")
    if not series:
        return
    for serie in series:
        serie['last_modified_int'] = int(serie.get('last_modified', 0))
    series.sort(key=lambda x: x['last_modified_int'], reverse=True)
    series = series[:RECENT_ITEMS_COUNT]
    add_series_to_directory(series)

def add_series_to_directory(series: List[Dict[str, Any]]) -> None:
    # Tell Kodi this is a TV shows listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'tvshows')
    
    # Log for debugging
    xbmc.log(f"[Xtream Codes] Loading {len(series)} series", xbmc.LOGDEBUG)
    
    for serie in series:
        # NO REGEX CLEANING
        label = serie.get('name', 'Inconnu')
        
        # Use helper functions for parsing
        year = utils.parse_year(serie.get('releaseDate', '') or serie.get('release_date', ''))
        rating = utils.parse_rating(serie.get('rating', 0))
        cast = utils.parse_cast(serie.get('cast', ''))
        
        info = {
            'title': label,
            'plot': serie.get('plot', '') or 'Aucun synopsis',
            'genre': serie.get('genre', 'Inconnu'),
            'mediatype': 'tvshow'
        }
        
        # Add optional fields only if valid
        if year > 0:
            info['year'] = year
        if rating > 0:
            info['rating'] = rating
        
        # Add director if available
        director = serie.get('director', '')
        if director:
            info['director'] = director
        
        # Add cast if available
        if cast:
            info['cast'] = cast
        
        # Use helper for backdrop
        fanart = utils.safe_get_backdrop(serie.get('backdrop_path'), DEFAULT_FANART)
        
        icon = serie.get('cover', SERIES_ICON) or SERIES_ICON
        
        context_menu = [
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=label,
            action='list_seasons',
            is_folder=True,
            icon=icon,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            series_id=serie.get('series_id')
        )
    
    xbmc.log(f"[Xtream Codes] Finished loading {len(series)} series", xbmc.LOGDEBUG)
    xbmcplugin.endOfDirectory(utils.get_handle())

def get_season_details(season_number, saisons, info, episode_count=0):
    """
    Extract season details with proper fallbacks.
    """
    season_info = saisons.get(season_number)
    
    if season_info:
        # Extract season name (e.g., "Season 1" or custom name)
        season_name = season_info.get('name', f'Saison {season_number}')
        if not season_name or season_name.lower() == 'none':
            season_name = f'Saison {season_number}'
        
        # Get overview/plot
        plot = season_info.get('overview', '') or season_info.get('plot', '')
        if not plot:
            plot = info.get('plot', 'Aucun synopsis')
        
        # Get air date
        air_date = season_info.get('air_date', '')
        
        # Get episode count (from season metadata or actual episode list)
        ep_count = season_info.get('episode_count', episode_count)
        if not ep_count:
            ep_count = episode_count
        
        # Get rating
        rating = 0.0
        vote_avg = season_info.get('vote_average', 0)
        if vote_avg:
            try:
                rating = float(vote_avg)
            except (ValueError, TypeError):
                rating = 0.0
        
        details = {
            'title': season_name,
            'plot': plot,
            'season': season_number,
            'mediatype': 'season'
        }
        
        if ep_count:
            details['episode'] = ep_count
        if rating > 0:
            details['rating'] = rating
        if air_date:
            details['premiered'] = air_date
            details['aired'] = air_date
        
        # Get season artwork
        art_icon = season_info.get('cover', '') or season_info.get('poster_path', '')
        if not art_icon or not art_icon.startswith('http'):
            art_icon = info.get('cover', SERIES_ICON)
        
        art_fanart = season_info.get('cover_big', '') or season_info.get('backdrop_path', '')
        if not art_fanart or not art_fanart.startswith('http'):
            # Fallback to series backdrop
            backdrop = info.get('backdrop_path')
            if isinstance(backdrop, list) and backdrop:
                art_fanart = backdrop[0]
            elif isinstance(backdrop, str):
                art_fanart = backdrop
            else:
                art_fanart = DEFAULT_FANART
    else:
        # No season metadata available, use series info
        plot = info.get('plot', 'Aucun synopsis')
        
        details = {
            'title': f'Saison {season_number}',
            'plot': plot,
            'season': season_number,
            'mediatype': 'season'
        }
        
        if episode_count:
            details['episode'] = episode_count
        
        art_icon = info.get('cover', SERIES_ICON)
        
        # Get series backdrop
        backdrop = info.get('backdrop_path')
        if isinstance(backdrop, list) and backdrop:
            art_fanart = backdrop[0]
        elif isinstance(backdrop, str):
            art_fanart = backdrop
        else:
            art_fanart = DEFAULT_FANART
    
    return details, art_icon, art_fanart

def show_seasons(series_id: str) -> None:
    series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        utils.notify("Erreur", "Info série introuvable.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    seasons = series_info.get('seasons', [])
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    del series_info

    saisons_map = {s.get('season_number'): s for s in seasons}
    episodes_map = {int(k): v for k, v in episodes.items()}
    
    # Tell Kodi this is a seasons listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'seasons')

    for season_number in sorted(episodes_map.keys()):
        # Count actual episodes in this season
        episode_count = len(episodes_map.get(season_number, []))
        
        details, art_icon, art_fanart = get_season_details(
            season_number, 
            saisons_map, 
            info, 
            episode_count
        )
        
        # Build season label with episode count
        label = details['title']
        if episode_count:
            label = f"{details['title']} ({episode_count} épisodes)"
        
        add_directory_item(
            label=label,
            action='list_episodes',
            is_folder=True,
            icon=art_icon,
            fanart=art_fanart,
            info=details,
            series_id=series_id,
            season=season_number
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_episodes(series_id: str, season: str) -> None:
    series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        return

    seasons = series_info.get('seasons', [])
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    
    try:
        season_num = int(season)
    except ValueError:
        return

    saisons_map = {s.get('season_number'): s for s in seasons}
    episodes_map = {int(k): v for k, v in episodes.items()}
    
    episode_list = episodes_map.get(season_num)
    if not episode_list:
        utils.notify("Erreur", f"Aucun épisode pour la saison {season}.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    details, art_icon, art_fanart = get_season_details(
        season_num, 
        saisons_map, 
        info, 
        len(episode_list)
    )
    
    server = api.get_server_url()
    user = api.get_username()
    pwd = api.get_password()
    
    # Tell Kodi this is an episodes listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'episodes')

    for episode in episode_list:
        # NO REGEX CLEANING - RAW TITLE
        ep_title = episode.get('title', 'Inconnu')
        ep_id = episode.get('id', 'Inconnu')
        container_extension = episode.get('container_extension', 'ts')
        
        # Extract episode info (nested in 'info' key)
        # Sometimes 'info' is a list, sometimes a dict - handle both cases
        ep_data_raw = episode.get('info', {})
        if isinstance(ep_data_raw, list):
            # If it's a list, take the first element or use empty dict
            xbmc.log(f"[Xtream Codes] Episode info is a list for episode {episode.get('id', 'unknown')}, taking first element", xbmc.LOGDEBUG)
            ep_data = ep_data_raw[0] if ep_data_raw else {}
        elif isinstance(ep_data_raw, dict):
            ep_data = ep_data_raw
        else:
            ep_data = {}
        
        # Get duration from info.duration_secs (more reliable than duration string)
        duration = 0
        if isinstance(ep_data, dict):
            duration_secs = ep_data.get('duration_secs', 0)
            if duration_secs:
                try:
                    duration = int(duration_secs)
                except (ValueError, TypeError):
                    duration = 0
        
        # Get air date
        air_date = ep_data.get('air_date', '') if isinstance(ep_data, dict) else ''
        
        # Build episode info for Kodi
        ep_info = {
            'title': ep_title,
            'season': episode.get('season', season_num),
            'episode': episode.get('episode_num', 'Inconnu'),
            'duration': duration,
            'mediatype': 'episode'
        }
        
        # Add air date if available
        if air_date:
            ep_info['aired'] = air_date
            ep_info['premiered'] = air_date
        
        # Add plot from episode info or fallback to season/series plot
        plot = ''
        if isinstance(ep_data, dict):
            plot = ep_data.get('plot', '') or ep_data.get('overview', '')
        if not plot:
            plot = details.get('plot', 'Aucun synopsis')
        ep_info['plot'] = plot
        
        # Get episode thumbnail (movie_image) or fallback to season/series art
        ep_thumb = art_icon
        if isinstance(ep_data, dict):
            ep_thumb = ep_data.get('movie_image', '')
        if not ep_thumb or not ep_thumb.startswith('http'):
            ep_thumb = art_icon
        
        # Use episode backdrop if available, otherwise use season/series fanart
        ep_fanart = art_fanart
        
        stream_url = f"{server}/series/{user}/{pwd}/{ep_id}.{container_extension}"
        
        context_menu = [
            ("Ajouter à la liste de lecture", f"RunPlugin({utils.build_url({'action': 'add_episode_to_playlist', 'stream_url': stream_url, 'label': ep_title})})"),
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=ep_title,
            action='play_episode',
            is_folder=False,
            icon=ep_thumb,
            fanart=ep_fanart,
            info=ep_info,
            context_menu=context_menu,
            is_playable=True,
            stream_url=stream_url
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_episode(stream_url: str) -> None:
    """Play a TV show episode stream."""
    if not utils.validate_stream_url(stream_url):
        utils.notify("Erreur", "URL de stream invalide", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(utils.get_handle(), False, xbmcgui.ListItem())
        return
    
    utils.log(f"Playing episode: {stream_url}", xbmc.LOGDEBUG)
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(utils.get_handle(), True, list_item)

def add_episode_to_playlist(stream_url: str, label: str) -> None:
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Épisode ajouté.")



def show_user_info() -> None:
    user_info = api.fetch_data('action=user_info')
    if not user_info:
        return

    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    
    exp_date = info.get('exp_date')
    if exp_date and exp_date != '0':
        try:
            exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            exp_date = 'Inconnu'
    else:
        exp_date = 'Illimité'
        
    message = (
        f"Nom d'utilisateur: {info.get('username', 'Inconnu')}\n"
        f"Statut: {info.get('status', 'Inconnu')}\n"
        f"Date d'expiration: {exp_date}\n"
        f"Connexions actives: {info.get('active_cons', 'Inconnu')}\n"
        f"Connexions autorisées: {info.get('max_connections', 'Inconnu')}\n"
        f"Serveur: {server_info.get('url', 'Inconnu')}:{server_info.get('port', 'Inconnu')}\n"
        f"Protocole: {server_info.get('server_protocol', 'Inconnu')}\n"
        f"Fuseau horaire: {server_info.get('timezone', 'Inconnu')}\n"
        f"Heure actuelle: {server_info.get('time_now', 'Inconnu')}"
    )
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)
