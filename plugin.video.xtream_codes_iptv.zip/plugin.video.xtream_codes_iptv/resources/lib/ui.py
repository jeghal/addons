"""
Module UI principal - Core functions
Coordonne les modules UI spécialisés.
"""
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

from resources.lib import api
from resources.lib import utils
from resources.lib import ui_live
from resources.lib import ui_vod
from resources.lib import ui_series
from resources.lib import ui_search
from resources.lib import ui_history
from resources.lib import ui_series_tracker

# Initialisation des ressources
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# Icons & Fanart
DEFAULT_FANART = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/fanart.jpg')
LIVE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/live_icon.png')
VOD_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/vod_icon.png')
SERIES_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/series_icon.png')
SEARCH_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/search_icon.png')
USER_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/user_info_icon.png')
CACHE_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/cache_icon.png')

# Settings UI
try:
    RECENT_ITEMS_COUNT = int(ADDON.getSetting('recent_items_count'))
except (ValueError, TypeError):
    RECENT_ITEMS_COUNT = 100

# Initialize sub-modules
ui_live.init_resources(LIVE_ICON, DEFAULT_FANART)
ui_vod.init_resources(VOD_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT, search_icon=SEARCH_ICON, series_icon=SERIES_ICON)
ui_series.init_resources(SERIES_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT, search_icon=SEARCH_ICON)
ui_search.init_resources(SEARCH_ICON, VOD_ICON, SERIES_ICON, DEFAULT_FANART)
ui_history.init_resources(LIVE_ICON, DEFAULT_FANART)
ui_series_tracker.init_resources(SERIES_ICON, DEFAULT_FANART)

# Initialize playback monitor
try:
    from resources.lib import playback_monitor
    _playback_monitor = playback_monitor.get_monitor()
    xbmc.log("[Xtream Codes] PlaybackMonitor initialized and ready", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Xtream Codes] Failed to initialize PlaybackMonitor: {e}", xbmc.LOGWARNING)

def add_directory_item(
    label: str,
    action: str,
    is_folder: bool = True,
    icon: Optional[str] = None,
    fanart: Optional[str] = None,
    info: Optional[Dict[str, Any]] = None,
    context_menu: Optional[List[Tuple[str, str]]] = None,
    is_playable: bool = False,
    **kwargs: Any
) -> None:
    """
    Ajoute un élément de répertoire générique.
    
    Args:
        label: Titre de l'élément
        action: Action à exécuter (route)
        is_folder: True si dossier, False si fichier jouable
        icon: Chemin de l'icône
        fanart: Chemin du fanart
        info: Métadonnées vidéo (dict)
        context_menu: Liste de tuples (Label, Action) pour le menu contextuel
        is_playable: True si l'élément lance une lecture
        kwargs: Paramètres supplémentaires pour l'URL
    """
    list_item = xbmcgui.ListItem(label=label)
    
    # Artwork
    art = {}
    if icon:
        art['icon'] = art['thumb'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        list_item.setArt(art)
    
    # Info (Delegated to utils)
    if info:
        utils._set_list_item_metadata(list_item, label, info)
    
    # Context Menu
    if context_menu:
        list_item.addContextMenuItems(context_menu, replaceItems=True)
    
    # Playable Logic
    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # Helper: Store episode metadata for Next Up / Auto-play
        # This workaround helps some skins/addons that lose context on playback start
        if action == 'play_episode' and 'series_id' in kwargs and 'season' in kwargs and 'episode_num' in kwargs:
            try:
                window = xbmcgui.Window(10000)
                window.setProperty('xtream.episode.series_id', str(kwargs.get('series_id', '')))
                window.setProperty('xtream.episode.season', str(kwargs.get('season', '')))
                window.setProperty('xtream.episode.episode_num', str(kwargs.get('episode_num', '')))
                window.setProperty('xtream.episode.title', kwargs.get('title', label))
            except Exception as e:
                utils.log(f"Error storing episode metadata: {e}", xbmc.LOGWARNING)
    
    # Resume Points
    if 'resume_time' in kwargs:
        list_item.setProperty('ResumeTime', str(kwargs['resume_time']))
        if 'total_time' in kwargs:
            list_item.setProperty('TotalTime', str(kwargs['total_time']))
    
    # Build URL
    url = utils.build_url({'action': action, **kwargs})
    xbmcplugin.addDirectoryItem(handle=utils.get_handle(), url=url, listitem=list_item, isFolder=is_folder)

# ---------------------------
# MAIN MENU
# ---------------------------

def show_main_menu() -> None:
    """Display main menu."""
    add_directory_item("Direct (Live TV)", 'list_live_categories', icon=LIVE_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Films (VOD)", 'list_vod_categories', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Séries", 'list_series_categories', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Mon Compte", 'show_user_info', is_folder=False, icon=USER_ICON, fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_settings_menu() -> None:
    """Display settings and tools menu."""
    add_directory_item("Informations Compte", 'show_user_info', is_folder=False, icon=USER_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Effacer le Cache", 'clear_cache', is_folder=False, icon=CACHE_ICON, fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_user_info() -> None:
    """Display user information."""
    user_info = api.fetch_data('action=user_info')
    if not user_info:
        return

    info = user_info.get('user_info', {})
    server_info = user_info.get('server_info', {})
    
    # Format Expiration Date
    exp_timestamp = info.get('exp_date')
    if exp_timestamp and str(exp_timestamp) != '0' and str(exp_timestamp).isdigit():
        try:
            exp_date = datetime.fromtimestamp(int(exp_timestamp)).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            exp_date = 'Inconnu'
    else:
        exp_date = 'Illimité' # or 'Jamais'
        
    message = (
        f"Nom d'utilisateur: {info.get('username', 'Inconnu')}\n"
        f"Statut: {info.get('status', 'Inconnu')}\n"
        f"Date d'expiration: {exp_date}\n"
        f"Connexions actives: {info.get('active_cons', '0')}\n"
        f"Connexions autorisées: {info.get('max_connections', 'Inconnu')}\n"
        f"Serveur: {server_info.get('url', 'Inconnu')}:{server_info.get('port', '80')}\n"
        f"Protocole: {server_info.get('server_protocol', 'http')}\n"
        f"Fuseau horaire: {server_info.get('timezone', 'Inconnu')}\n"
        f"Heure actuelle: {server_info.get('time_now', 'Inconnu')}"
    )
    xbmcgui.Dialog().textviewer("Informations Utilisateur", message)

def confirm_clear_cache() -> None:
    """Prompt user before clearing cache."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer le cache local ?"):
        api.clear_cache()

# ---------------------------
# DELEGATED FUNCTIONS (Proxy to specialized modules)
# ---------------------------

# Live TV
def show_live_categories(parent_id: str = "0") -> None:
    ui_live.show_live_categories(add_directory_item, parent_id)

def show_live_channels(category_id: str) -> None:
    ui_live.show_live_channels(add_directory_item, category_id)

def play_channel(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "") -> None:
    ui_live.play_channel(stream_url, title, stream_id, stream_icon)

def add_channel_to_playlist(stream_url: str, label: str) -> None:
    ui_live.add_channel_to_playlist(stream_url, label)

def play_live_playlist(category_id: str) -> None:
    ui_live.play_live_playlist(category_id)

# VOD
def show_vod_categories(parent_id: str = "0") -> None:
    ui_vod.show_vod_categories(add_directory_item, parent_id)

def show_movies(category_id: str) -> None:
    ui_vod.show_movies(add_directory_item, category_id)

def show_recent_movies() -> None:
    ui_vod.show_recent_movies(add_directory_item)

def play_movie(stream_url: str, title: str, stream_id: str, icon: str, fanart: str, 
              plot: str, year: str, duration: str, rating: str, resume_time: int = 0) -> None:
    meta = {
        'plot': plot,
        'year': year,
        'duration': duration,
        'rating': rating,
        'mediatype': 'movie'
    }
    utils.play_stream(stream_url, 'movie', title, stream_id, icon, fanart, meta=meta, resume_time=resume_time)

def add_movie_to_playlist(stream_url: str, label: str) -> None:
    ui_vod.add_movie_to_playlist(stream_url, label)

def show_movie_options(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", 
                      stream_fanart: str = "", plot: str = "", year: str = "", duration: str = "", rating: str = "") -> None:
    ui_vod.show_movie_options_menu(add_directory_item, stream_url, title, stream_id, stream_icon, stream_fanart, plot, year, duration, rating)


# Series
def show_series_categories() -> None:
    ui_series.show_series_categories(add_directory_item)

def show_series(category_id: str) -> None:
    ui_series.show_series(add_directory_item, category_id)

def show_recent_series() -> None:
    ui_series.show_recent_series(add_directory_item)

def show_seasons(series_id: str) -> None:
    ui_series.show_seasons(add_directory_item, series_id)

def show_episodes(series_id: str, season: str) -> None:
    ui_series.show_episodes(add_directory_item, series_id, season)

def play_episode(stream_url: str, title: str, stream_id: str, icon: str, fanart: str, 
                series_id: str, season: str, episode_num: str, plot: str, duration: str, 
                premiered: str, tvshowtitle: str, resume_time: int = 0) -> None:
    meta = {
        'plot': plot,
        'duration': duration,
        'premiered': premiered,
        'tvshowtitle': tvshowtitle,
        'mediatype': 'episode',
        'season': season,
        'episode': episode_num
    }
    utils.play_stream(stream_url, 'episode', title, stream_id, icon, fanart, series_id, season, episode_num, meta, resume_time=resume_time)

def add_episode_to_playlist(stream_url: str, label: str) -> None:
    ui_series.add_episode_to_playlist(stream_url, label)


# Search
def show_search_menu() -> None:
    ui_search.show_search_menu(add_directory_item)

def last_search() -> None:
    ui_search.last_search(
        lambda movies: ui_vod.add_movies_to_directory(add_directory_item, movies),
        lambda series: ui_series.add_series_to_directory(add_directory_item, series)
    )

def recherche_film(query: str = "") -> None:
    ui_search.recherche_film(
        lambda movies: ui_vod.add_movies_to_directory(add_directory_item, movies),
        query
    )

def recherche_serie(query: str = "") -> None:
    ui_search.recherche_serie(
        lambda series: ui_series.add_series_to_directory(add_directory_item, series),
        query
    )

# History
def show_watch_history() -> None:
    ui_history.show_watch_history(add_directory_item)

def show_movie_history() -> None:
    ui_history.show_watch_history(add_directory_item, filter_type='movie')
    
def show_series_history() -> None:
    ui_history.show_watch_history(add_directory_item, filter_type='episode')

def confirm_clear_history() -> None:
    ui_history.confirm_clear_history()

def remove_from_history_ui(item_type: str, item_id: str) -> None:
    ui_history.remove_from_history_ui(item_type, item_id)

# Continue Watching
def show_continue_watching() -> None:
    ui_series_tracker.show_continue_watching(add_directory_item)

def play_next_from_continue(series_id: str) -> None:
    ui_series_tracker.play_next_episode(series_id)

def replay_last_from_continue(series_id: str) -> None:
    ui_series_tracker.replay_last_episode(series_id)

def remove_from_continue(series_id: str) -> None:
    ui_series_tracker.remove_from_continue_ui(series_id)

def confirm_clear_continue_watching() -> None:
    ui_series_tracker.confirm_clear_continue_watching()
