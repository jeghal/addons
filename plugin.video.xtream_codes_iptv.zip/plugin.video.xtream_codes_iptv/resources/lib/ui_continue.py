"""
Module UI pour "Continuer à regarder"
Affiche et gère les séries en cours de visionnage
"""
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import continue_watching
from resources.lib import api
from resources.lib import utils

# Icons
CONTINUE_ICON = None
DEFAULT_FANART = None


def init_resources(continue_icon: str, default_fanart: str) -> None:
    """Initialize module resources."""
    global CONTINUE_ICON, DEFAULT_FANART
    CONTINUE_ICON = continue_icon
    DEFAULT_FANART = default_fanart


def show_continue_watching(add_directory_item) -> None:
    """
    Affiche la liste des séries en cours de visionnage.
    """
    series_list = continue_watching.get_continue_watching_list()
    
    if not series_list:
        utils.notify("Continuer à regarder", "Aucune série en cours.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(utils.get_handle())
        return
    
    # Option pour effacer la liste
    add_directory_item(
        label="[Effacer la liste]",
        action='clear_continue_watching',
        is_folder=False,
        icon=CONTINUE_ICON,
        fanart=DEFAULT_FANART
    )
    
    # Tell Kodi this is a TV shows listing
    xbmcplugin.setContent(utils.get_handle(), 'tvshows')
    
    for series_data in series_list:
        series_id = series_data['series_id']
        series_name = series_data['series_name']
        last_watched = series_data['last_watched']
        season = last_watched['season']
        episode = last_watched['episode']
        episode_title = last_watched['title']
        icon = series_data.get('icon', CONTINUE_ICON)
        fanart = series_data.get('fanart', DEFAULT_FANART)
        
        # Utiliser les données stockées du prochain épisode (pas de requête API!)
        next_ep_data = series_data.get('next_episode')
        if next_ep_data:
            next_season = next_ep_data.get('season')
            next_episode = next_ep_data.get('episode')
        else:
            # Fallback: calculer si pas stocké (pour compatibilité avec anciennes données)
            next_season, next_episode = calculate_next_episode(series_id, season, episode)
        
        # Construire le label
        if next_season and next_episode:
            if next_season == season and next_episode == episode:
                # Même épisode = Reprendre
                label = f"{series_name} - Reprendre: S{next_season:02d}E{next_episode:02d}"
                plot = f"Reprendre: S{season:02d}E{episode:02d} - {episode_title}"
            else:
                # Épisode différent = Prochain
                label = f"{series_name} - Prochain: S{next_season:02d}E{next_episode:02d}"
                plot = f"Dernier regardé: S{season:02d}E{episode:02d} - {episode_title}\n\nProchain: S{next_season:02d}E{next_episode:02d}"
        else:
            label = f"{series_name} - Terminé"
            plot = f"Dernier regardé: S{season:02d}E{episode:02d} - {episode_title}\n\nSérie terminée"
        
        # Menu contextuel
        context_menu = [
            ("Reprendre", f"RunPlugin({utils.build_url({'action': 'play_next_from_continue', 'series_id': series_id})})"),
            ("Revoir le dernier", f"RunPlugin({utils.build_url({'action': 'play_last_from_continue', 'series_id': series_id})})"),
            ("Retirer de la liste", f"RunPlugin({utils.build_url({'action': 'remove_from_continue', 'series_id': series_id})})"),
        ]
        
        info = {
            'title': series_name,
            'plot': plot,
            'mediatype': 'tvshow'
        }
        
        # Action par défaut : reprendre (jouer le prochain épisode)
        add_directory_item(
            label=label,
            action='play_next_from_continue',
            is_folder=False,
            icon=icon,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            is_playable=True,
            series_id=series_id
        )
    
    xbmcplugin.endOfDirectory(utils.get_handle())


def calculate_next_episode(series_id: str, current_season: int, current_episode: int):
    """
    Calcule le prochain épisode à regarder.
    
    Returns:
        Tuple (next_season, next_episode) ou (None, None) si terminé
    """
    try:
        # Récupérer les infos de la série
        series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
        if not series_info:
            return None, None
        
        episodes = series_info.get('episodes', {})
        
        # Vérifier si l'épisode suivant existe dans la même saison
        season_episodes = episodes.get(str(current_season), [])
        
        # Chercher l'épisode suivant
        for ep in season_episodes:
            ep_num = int(ep.get('episode_num', 0))
            if ep_num == current_episode + 1:
                return current_season, current_episode + 1
        
        # Sinon, chercher le premier épisode de la saison suivante
        next_season = current_season + 1
        if str(next_season) in episodes:
            next_season_episodes = episodes[str(next_season)]
            if next_season_episodes:
                # Obtenir le numéro du premier épisode de la nouvelle saison (peut être 0, 1, 101...)
                first_ep = next_season_episodes[0]
                first_ep_num = int(first_ep.get('episode_num', 1))
                return next_season, first_ep_num
        
        # Aucun épisode suivant trouvé
        return None, None
        
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error calculating next episode: {e}", xbmc.LOGWARNING)
        return None, None


def play_next_episode(series_id: str) -> None:
    """
    Lance le prochain épisode d'une série.
    """
    series_data = continue_watching.get_series_info(series_id)
    if not series_data:
        utils.notify("Erreur", "Série introuvable.", xbmcgui.NOTIFICATION_ERROR)
        return
    
    last_watched = series_data['last_watched']
    current_season = last_watched['season']
    current_episode = last_watched['episode']
    
    # Calculer le prochain épisode (ou reprendre actuel)
    next_season = None
    next_episode = None
    
    # Vérifier si les infos sont déjà stockées (cas Reprendre vs Suivant)
    if 'next_episode' in series_data:
        next_data = series_data['next_episode']
        next_season = next_data.get('season')
        next_episode = next_data.get('episode')
    
    # Fallback si pas de données stockées
    if not next_season or not next_episode:
        next_season, next_episode = calculate_next_episode(series_id, current_season, current_episode)
    
    if not next_season or not next_episode:
        utils.notify("Continuer à regarder", "Série terminée !", xbmcgui.NOTIFICATION_INFO)
        return
    
    # Lancer l'épisode
    play_episode_from_continue(series_id, next_season, next_episode)


def replay_last_episode(series_id: str) -> None:
    """
    Relance le dernier épisode regardé.
    """
    series_data = continue_watching.get_series_info(series_id)
    if not series_data:
        utils.notify("Erreur", "Série introuvable.", xbmcgui.NOTIFICATION_ERROR)
        return
    
    last_watched = series_data['last_watched']
    season = last_watched['season']
    episode = last_watched['episode']
    
    # Lancer l'épisode
    play_episode_from_continue(series_id, season, episode)


def play_episode_from_continue(series_id: str, season: int, episode: int) -> None:
    """
    Lance un épisode spécifique depuis Continue Watching.
    """
    try:
        # Récupérer les infos de la série
        series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
        if not series_info:
            utils.notify("Erreur Réseau", "Impossible de contacter le serveur IPTV.", xbmcgui.NOTIFICATION_ERROR)
            return
        
        info = series_info.get('info', {})
        episodes = series_info.get('episodes', {})
        
        # Trouver l'épisode
        season_episodes = episodes.get(str(season), [])
        if not season_episodes:
            utils.notify("Saison Introuvable", f"La saison {season} n'existe pas ou plus.", xbmcgui.NOTIFICATION_ERROR)
            return
        
        episode_data = None
        for ep in season_episodes:
            if int(ep.get('episode_num', 0)) == episode:
                episode_data = ep
                break
        
        if not episode_data:
            utils.notify("Épisode Introuvable", f"L'épisode S{season:02d}E{episode:02d} n'existe pas ou plus.", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Construire l'URL de streaming
        server_url = api.get_server_url()
        username = api.get_username()
        password = api.get_password()
        
        stream_id = episode_data.get('id')
        if not stream_id:
            utils.notify("Erreur", "ID de stream manquant.", xbmcgui.NOTIFICATION_ERROR)
            return
        
        container = episode_data.get('container_extension', 'mp4')
        stream_url = f"{server_url}/series/{username}/{password}/{stream_id}.{container}"
        
        # Récupérer les métadonnées
        title = episode_data.get('title', f'Episode {episode}')
        icon = episode_data.get('info', {}).get('movie_image', info.get('cover', ''))
        fanart = info.get('backdrop_path', [''])[0] if isinstance(info.get('backdrop_path'), list) else info.get('backdrop_path', '')
        
        # Lancer la lecture
        from resources.lib import ui_series
        ui_series.play_episode(
            stream_url=stream_url,
            title=title,
            stream_id=str(stream_id),
            stream_icon=icon,
            stream_fanart=fanart,
            series_id=series_id,
            season=str(season),
            episode_num=str(episode)
        )
        
    except ConnectionError as e:
        xbmc.log(f"[Xtream Codes] Connection error playing episode: {e}", xbmc.LOGERROR)
        utils.notify("Erreur de Connexion", "Vérifiez votre connexion Internet.", xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Error playing episode from continue: {e}", xbmc.LOGERROR)
        utils.notify("Erreur Inconnue", "Impossible de lancer l'épisode. Consultez les logs.", xbmcgui.NOTIFICATION_ERROR)


def confirm_clear_continue_watching() -> None:
    """Demande confirmation avant d'effacer la liste."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer toute la liste ?"):
        continue_watching.clear_continue_watching()
        utils.notify("Continuer à regarder", "Liste effacée.", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin('Container.Refresh')


def remove_from_continue_ui(series_id: str) -> None:
    """Supprime une série de la liste."""
    continue_watching.remove_from_continue_watching(series_id)
    utils.notify("Continuer à regarder", "Série retirée de la liste.", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')
