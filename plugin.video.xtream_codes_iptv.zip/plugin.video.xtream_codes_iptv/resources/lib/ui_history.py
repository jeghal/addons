"""
Module UI pour l'historique de lecture
Affiche les derniers contenus regardés
"""
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import history
from resources.lib import utils

# Icons
HISTORY_ICON = None
DEFAULT_FANART = None

def init_resources(history_icon: str, default_fanart: str) -> None:
    """Initialize module resources."""
    global HISTORY_ICON, DEFAULT_FANART
    HISTORY_ICON = history_icon
    DEFAULT_FANART = default_fanart

def show_watch_history(add_directory_item, filter_type: str = None) -> None:
    """
    Affiche l'historique de lecture.
    Les 20 derniers contenus regardés.
    
    Args:
        filter_type: Filtrer par type ('movie', 'episode', 'live') ou None pour tout
    """
    all_items = history.get_history()
    
    # Filter if requested
    if filter_type:
        history_items = [item for item in all_items if item.get('type') == filter_type]
    else:
        history_items = all_items
    
    if not history_items:
        msg = "Aucun film dans l'historique." if filter_type == 'movie' else "Aucun contenu dans l'historique."
        utils.notify("Historique", msg, xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(utils.get_handle())
        return
    
    # Option pour effacer l'historique
    add_directory_item(
        label="[Effacer l'historique]",
        action='clear_history',
        is_folder=False,
        icon=HISTORY_ICON,
        fanart=DEFAULT_FANART
    )
    
    # Afficher les éléments
    for item in history_items:
        item_type = item.get('type', 'unknown')
        title = item.get('title', 'Inconnu')
        date = item.get('date', '')
        stream_url = item.get('stream_url', '')
        icon = item.get('icon', '') or HISTORY_ICON
        fanart = item.get('fanart', '') or DEFAULT_FANART
        item_id = item.get('id', '')
        
        # Label avec date (sans emoji)
        label = title
        if date:
            label += f" - {date}"
        
        # Info
        info = {
            'title': title,
            'plot': f"Regarde le {date}" if date else "Recemment regarde",
            'plot': f"Regarde le {date}" if date else "Recemment regarde",
            'mediatype': 'video',
            'dbtype': item_type  # Help Kodi identify type
        }
        
        # Resume Point
        resume_data = item.get('resume')
        if resume_data and isinstance(resume_data, dict):
            try:
                position = float(resume_data.get('position', 0))
                total = float(resume_data.get('total', 0))
                if position > 0:
                    # Generic Kodi Property for Resume
                    # Note: exact key depends on Kodi version, but providing it in Properties often works
                    # For ListItem.setInfo('video', ...), 'playcount' and 'overlay' are standard
                    # 'resume' is supported by some skins/versions
                    
                    # We will pass properties via kwargs to add_directory_item if supported,
                    # OR we simply set it in info expecting add_directory_item to handle it.
                    # Standard way is setProperty('ResumeTime', str(position))
                    
                    # Let's update params which are passed as kwargs to add_directory_item
                    params['resume_time'] = str(position)
                    params['total_time'] = str(total)
                    xbmc.log(f"DEBUG: Found Resume Point for {item.get('title')}: {position}", xbmc.LOGINFO)
            except:
                pass
        
        # Menu contextuel - construction de l'URL séparément pour éviter les problèmes de syntaxe
        remove_url = utils.build_url({
            'action': 'remove_from_history',
            'item_type': item_type,
            'item_id': item_id
        })
        context_menu = [
            ("Retirer de la liste", f"RunPlugin({remove_url})"),
        ]
        
        # Action de lecture selon le type
        action_map = {
            'live': 'play_channel',
            'movie': 'play_movie',
            'episode': 'play_episode'
        }
        action = action_map.get(item_type, 'play_channel')
        
        # Préparer les paramètres de base
        params = {
            'stream_url': stream_url
        }
        
        # Ajouter les métadonnées d'épisode si disponibles (pour auto-play)
        if item_type == 'episode':
            series_id = item.get('series_id', '')
            season = item.get('season', '')
            episode_num = item.get('episode_num', '')
            
            if series_id and season and episode_num:
                params['series_id'] = series_id
                params['season'] = season
                params['episode_num'] = episode_num
        
        add_directory_item(
            label=label,
            action=action,
            is_folder=False,
            icon=icon,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            is_playable=True,
            **params
        )
        
        # Apply Resume Point if available
        resume_data = item.get('resume')
        if resume_data and isinstance(resume_data, dict):
            position = resume_data.get('position', 0)
            total = resume_data.get('total', 0)
            if position > 0:
                # Retrieve the list item just added to set properties
                # This is a bit tricky with standard addDirectoryItem, usually we'd pass it in 'info'
                # But 'info' dictionary keys for resume are not standard in all Kodi versions/wrappers
                # So we update the 'info' dict passed to add_directory_item above
                pass 
                # Actually, best way is to update 'info' dict BEFORE add_directory_item
                # But since I can't easily edit the block above without a large replace,
                # I will rely on standard Kodi 'resume' handling if passed in info.
                
                # Let's check how 'add_directory_item' handles info. 
                # It passes it to setInfo.
                # So we should add 'resume' key to 'info' dict.
                
    
    xbmcplugin.endOfDirectory(utils.get_handle())

def confirm_clear_history() -> None:
    """Demande confirmation avant d'effacer l'historique."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer tout l'historique ?"):
        history.clear_history()
        utils.notify("Historique", "Historique effacé.", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin('Container.Refresh')

def remove_from_history_ui(item_type: str, item_id: str) -> None:
    """Supprime un élément de l'historique."""
    history.remove_from_history(item_type, item_id)
    utils.notify("Historique", "Élément supprimé.", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')
