"""
Module UI pour l'historique de lecture
Affiche les derniers contenus regardés
"""
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import history
from resources.lib import utils

# Icons
HISTORY_ICON = None
DEFAULT_FANART = None

def init_resources(history_icon: str, default_fanart: str) -> None:
    """Initialize module resources."""
    global HISTORY_ICON, DEFAULT_FANART
    HISTORY_ICON = history_icon
    DEFAULT_FANART = default_fanart

def show_watch_history(add_directory_item) -> None:
    """
    Affiche l'historique de lecture.
    Les 20 derniers contenus regardés.
    """
    history_items = history.get_history()
    
    if not history_items:
        utils.notify("Historique", "Aucun contenu dans l'historique.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(utils.get_handle())
        return
    
    # Option pour effacer l'historique
    add_directory_item(
        label="[Effacer l'historique]",
        action='clear_history',
        is_folder=False,
        icon=HISTORY_ICON,
        fanart=DEFAULT_FANART
    )
    
    # Afficher les éléments
    for item in history_items:
        item_type = item.get('type', 'unknown')
        title = item.get('title', 'Inconnu')
        date = item.get('date', '')
        stream_url = item.get('stream_url', '')
        icon = item.get('icon', '') or HISTORY_ICON
        fanart = item.get('fanart', '') or DEFAULT_FANART
        item_id = item.get('id', '')
        
        # Label avec date (sans emoji)
        label = title
        if date:
            label += f" - {date}"
        
        # Info
        info = {
            'title': title,
            'plot': f"Regarde le {date}" if date else "Recemment regarde",
            'mediatype': 'video'
        }
        
        # Menu contextuel - construction de l'URL séparément pour éviter les problèmes de syntaxe
        remove_url = utils.build_url({
            'action': 'remove_from_history',
            'item_type': item_type,
            'item_id': item_id
        })
        context_menu = [
            ("Supprimer", f"RunPlugin({remove_url})"),
        ]
        
        # Action de lecture selon le type
        action_map = {
            'live': 'play_channel',
            'movie': 'play_movie',
            'episode': 'play_episode'
        }
        action = action_map.get(item_type, 'play_channel')
        
        add_directory_item(
            label=label,
            action=action,
            is_folder=False,
            icon=icon,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            is_playable=True,
            stream_url=stream_url
        )
    
    xbmcplugin.endOfDirectory(utils.get_handle())

def confirm_clear_history() -> None:
    """Demande confirmation avant d'effacer l'historique."""
    if xbmcgui.Dialog().yesno("Confirmation", "Voulez-vous vraiment effacer tout l'historique ?"):
        history.clear_history()
        utils.notify("Historique", "Historique effacé.", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin('Container.Refresh')

def remove_from_history_ui(item_type: str, item_id: str) -> None:
    """Supprime un élément de l'historique."""
    history.remove_from_history(item_type, item_id)
    utils.notify("Historique", "Élément supprimé.", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')
