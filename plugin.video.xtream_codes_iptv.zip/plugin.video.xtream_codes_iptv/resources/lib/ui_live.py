"""
Module UI pour Live TV
Gère l'affichage et la lecture des chaînes de télévision en direct.
"""
import xbmc
import xbmcgui
import xbmcplugin
from typing import Optional

from resources.lib import api
from resources.lib import utils

# Icons
LIVE_ICON: Optional[str] = None
DEFAULT_FANART: Optional[str] = None

def init_resources(live_icon: str, default_fanart: str) -> None:
    """Initialize module resources."""
    global LIVE_ICON, DEFAULT_FANART
    LIVE_ICON = live_icon
    DEFAULT_FANART = default_fanart

def show_live_categories(add_directory_item, parent_id: str = "0") -> None:
    """
    Display live categories in a flat list.
    Simplified version without hierarchical navigation.
    """
    categories = api.fetch_data('action=get_live_categories')
    if not categories:
        utils.notify("Erreur", "Aucune catégorie Live trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Display all categories in a flat list
    for category in categories:
        cat_id = str(category.get('category_id'))
        cat_name = category.get('category_name', 'Inconnu')
        
        add_directory_item(
            label=cat_name,
            action='list_live_channels',
            is_folder=True,
            icon=LIVE_ICON,
            fanart=DEFAULT_FANART,
            category_id=cat_id
        )
    
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_live_channels(add_directory_item, category_id: str) -> None:
    """Display live channels for a category."""
    if not category_id:
        return

    channels = api.fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        xbmc.log(f"[Xtream Codes] No live channels found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucune chaîne disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Filter adult content if enabled
    channels = api.filter_adult_content(channels)
    
    if not channels:
        utils.notify("Info", "Aucune chaîne après filtrage.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(utils.get_handle())
        return

    # Play All Option
    add_directory_item(
        label="[Lire toutes les chaînes]",
        action='play_live_playlist',
        is_folder=False,
        icon=LIVE_ICON,
        fanart=DEFAULT_FANART,
        category_id=category_id
    )

    for channel in channels:
        stream_id = str(channel.get('stream_id', ''))
        if not stream_id:
            continue
            
        name = channel.get('name', 'Inconnu')
        
        # Get icon with fallback
        icon = channel.get('stream_icon', '') or channel.get('icon', '') or LIVE_ICON
        
        
        # Build stream URL
        stream_url = api.build_stream_url('live', stream_id, 'ts')
        
        # Build info with EPG data if available
        info = {
            'title': name,
            'mediatype': 'video'
        }
        
        # Add EPG info if available
        epg_channel_id = channel.get('epg_channel_id', '')
        if epg_channel_id:
            info['plot'] = f"EPG ID: {epg_channel_id}"
        
        add_directory_item(
            label=name,
            action='play_channel',
            is_folder=False,
            icon=icon,
            fanart=DEFAULT_FANART,
            info=info,
            is_playable=True,
            stream_url=stream_url,
            title=name,
            stream_id=stream_id,
            stream_icon=icon
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_channel(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "") -> None:
    """Play a live TV channel stream."""
    meta = {
        'title': title,
        'mediatype': 'video'
    }
    utils.play_stream(stream_url, "live", title, stream_id, stream_icon, DEFAULT_FANART, meta=meta)

def add_channel_to_playlist(stream_url: str, label: str) -> None:
    """Add a live channel to the playlist."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Chaîne ajoutée.")

def play_live_playlist(category_id: str) -> None:
    """Play all channels in a category as a playlist."""
    channels = api.fetch_data(f"action=get_live_streams&category_id={category_id}")
    if not channels:
        return

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    
    count = 0
    for channel in channels:
        stream_id = channel.get('stream_id')
        if not stream_id:
            continue
            
        stream_url = api.build_stream_url('live', stream_id, 'ts')
        li = xbmcgui.ListItem(label=channel.get('name', 'Inconnu'))
        li.setProperty('IsPlayable', 'true')
        li.setContentLookup(False)
        playlist.add(stream_url, li)
        count += 1
        
    if count > 0:
        xbmc.Player().play(playlist)
        utils.notify("Lecture Playlist", f"Lecture de {count} chaînes.")
    else:
        utils.notify("Erreur", "Aucune chaîne disponible.", xbmcgui.NOTIFICATION_ERROR)
