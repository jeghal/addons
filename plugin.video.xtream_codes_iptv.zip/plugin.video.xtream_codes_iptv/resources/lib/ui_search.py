"""
Module UI pour Search
Gère la recherche de films et séries.
"""
import xbmc
import xbmcaddon

from resources.lib import api
from resources.lib import utils

# Icons
SEARCH_ICON = None
VOD_ICON = None
SERIES_ICON = None
DEFAULT_FANART = None

ADDON = xbmcaddon.Addon()

def init_resources(search_icon: str, vod_icon: str, series_icon: str, default_fanart: str) -> None:
    """Initialize module resources."""
    global SEARCH_ICON, VOD_ICON, SERIES_ICON, DEFAULT_FANART
    SEARCH_ICON = search_icon
    VOD_ICON = vod_icon
    SERIES_ICON = series_icon
    DEFAULT_FANART = default_fanart

def show_search_menu(add_directory_item) -> None:
    """Display search menu."""
    import xbmcplugin
    add_directory_item("Rechercher un film", 'search_movies', icon=VOD_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Rechercher une série", 'search_series', icon=SERIES_ICON, fanart=DEFAULT_FANART)
    add_directory_item("Dernière recherche", 'last_search', is_folder=True, icon=SEARCH_ICON, fanart=DEFAULT_FANART)
    xbmcplugin.endOfDirectory(utils.get_handle())

def last_search(add_movies_func, add_series_func) -> None:
    """Repeat last search."""
    query = ADDON.getSetting('last_search_query')
    search_type = ADDON.getSetting('last_search_type')
    
    if not query:
        utils.notify("Info", "Aucune recherche récente.")
        return
        
    if search_type == 'movie':
        recherche_film(add_movies_func, query)
    elif search_type == 'series':
        recherche_serie(add_series_func, query)
    else:
        utils.notify("Info", "Type de recherche inconnu.")

def _perform_search(type_label: str, search_type: str, api_action: str, display_func: callable, items_name: str, query: str = "") -> None:
    """
    Helper function to handle search logic for both movies and series.
    Uses threading to fetch data while user is typing.
    """
    import threading
    import xbmcgui
    
    # Container to store result from thread
    thread_data = {'items': []}
    
    def fetch_worker():
        thread_data['items'] = api.fetch_data(f"action={api_action}")
        
    # 1. START FETCH IN BACKGROUND
    # Start downloading/loading cache immediately in a separate thread
    fetch_thread = threading.Thread(target=fetch_worker)
    fetch_thread.start()
    
    # 2. OPEN KEYBOARD (While fetch runs in background)
    if not query:
        keyboard = xbmc.Keyboard("", f"Entrez le titre ({type_label})")
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText().strip().lower()
            
    if not query:
        # User cancelled. We let the thread finish naturally (populating cache) but stop here.
        return
    
    # Save search history
    ADDON.setSetting('last_search_query', query)
    ADDON.setSetting('last_search_type', search_type)
    
    # 3. WAIT FOR DATA (If not ready yet)
    # 3. WAIT FOR DATA (If not ready yet)
    if fetch_thread.is_alive():
        # Show progress dialog if the download isn't finished
        # DialogBusy caused AttributeError on some systems, using DialogProgress instead
        p = xbmcgui.DialogProgress()
        p.create("Recherche", f"Chargement des {items_name}...")
        
        # Checking loop to allowing canceling
        while fetch_thread.is_alive():
            xbmc.sleep(100)
            if p.iscanceled():
                utils.notify("Recherche", "Annulée par l'utilisateur.")
                return
        
        p.close()
    
    items = thread_data['items']
    
    if not items:
        utils.notify("Erreur", f"Impossible de charger la liste ({type_label}).", xbmcgui.NOTIFICATION_ERROR)
        return
    
    # 4. FILTER (Instantaneous)
    found = [i for i in items if query in i.get('name', '').lower()]
    
    if found:
        # Sort: Exact match > Starts with > Contains
        found.sort(key=lambda x: 0 if x.get('name', '').lower().startswith(query) else 1)
        
        total_found = len(found)
        display_limit = 50
        
        if total_found > display_limit:
            found = found[:display_limit]
            utils.notify("Recherche", f"{total_found} {items_name} (Top {display_limit} affichés).")
        else:
            utils.notify("Recherche", f"{total_found} {items_name}.")
        
        display_func(found)
    else:
        utils.notify("Résultat", f"Aucun {type_label} trouvé.", xbmcgui.NOTIFICATION_ERROR)

def recherche_film(add_movies_func, query: str = "") -> None:
    """Search for movies."""
    _perform_search("film", 'movie', 'get_vod_streams', add_movies_func, "film(s) trouvé(s)", query)

def recherche_serie(add_series_func, query: str = "") -> None:
    """Search for series."""
    _perform_search("série", 'series', 'get_series', add_series_func, "série(s)", query)
