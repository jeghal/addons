"""
Module UI pour Series (TV Shows)
Gère l'affichage et la lecture des séries télévisées.
"""
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
from typing import List, Dict, Any, Optional, Tuple

from resources.lib import api
from resources.lib import utils

# Icons
SERIES_ICON: Optional[str] = None
SEARCH_ICON: Optional[str] = None
DEFAULT_FANART: Optional[str] = None
RECENT_ITEMS_COUNT: int = 100

def init_resources(series_icon: str, default_fanart: str, recent_count: int, search_icon: str = None) -> None:
    """Initialize module resources."""
    global SERIES_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT, SEARCH_ICON
    SERIES_ICON = series_icon
    DEFAULT_FANART = default_fanart
    RECENT_ITEMS_COUNT = recent_count
    SEARCH_ICON = search_icon

def _clean_series_title(label: str) -> str:
    """Cleans series title by removing country prefixes and year suffixes."""
    clean_title = label
    # 1. Remove country prefixes like "FR - ", "UK - ", "AR: "
    clean_title = re.sub(r'^[A-Z]{2,3}\s*[-–:]\s*', '', clean_title)
    # 2. Remove year suffixes like " (2025)", " 2024"
    clean_title = re.sub(r'\s*\(?\d{4}\)?\s*$', '', clean_title).strip()
    return clean_title

def show_series_categories(add_directory_item, parent_id: str = "0") -> None:
    """Display series categories."""
    categories = api.fetch_data("action=get_series_categories")
    if not categories:
        utils.notify("Erreur", "Aucune catégorie de séries trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Tools / Navigation
    add_directory_item("[B]Rechercher une Série[/B]", 'search_series', is_folder=True, icon=SEARCH_ICON, fanart=DEFAULT_FANART)
    add_directory_item(
        label="[B]Continuer à regarder[/B]",
        action='show_continue_watching',
        is_folder=True,
        icon=SERIES_ICON,
        fanart=DEFAULT_FANART
    )
    
    # [B]Séries récentes[/B]
    add_directory_item(
        label="[B]Séries récentes[/B]",
        action='list_recent_series',
        is_folder=True,
        icon=SEARCH_ICON,
        fanart=DEFAULT_FANART
    )

    for category in categories:
        add_directory_item(
            label=category.get('category_name', 'Inconnu'),
            action='list_series',
            is_folder=True,
            icon=SERIES_ICON,
            fanart=DEFAULT_FANART,
            category_id=category.get('category_id')
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_series(add_directory_item, category_id: str) -> None:
    """Display series for a category."""
    series = api.fetch_data(f"action=get_series&category_id={category_id}")
    if not series:
        xbmc.log(f"[Xtream Codes] No series found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucune série disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Sort by 'last_modified' descending
    try:
        series.sort(key=lambda x: int(x.get('last_modified', 0)), reverse=True)
    except (ValueError, TypeError):
        pass

    add_series_to_directory(add_directory_item, series)

def show_recent_series(add_directory_item) -> None:
    """Display recently added series."""
    # Use configurable cache duration (default 24h)
    try:
        addon = xbmcaddon.Addon()
        cache_hours = int(addon.getSetting('cache_search_duration'))
    except (ValueError, TypeError):
        cache_hours = 24
    cache_duration = cache_hours * 3600  # Convert hours to seconds
    
    series = api.fetch_data("action=get_series", cache_duration=cache_duration)
    if not series:
        return
        
    try:
        series.sort(key=lambda x: int(x.get('last_modified', 0)), reverse=True)
    except (ValueError, TypeError):
        pass
        
    series = series[:RECENT_ITEMS_COUNT]
    add_series_to_directory(add_directory_item, series)

def add_series_to_directory(add_directory_item, series: List[Dict[str, Any]]) -> None:
    """Add series to Kodi directory listing."""
    xbmcplugin.setContent(utils.get_handle(), 'tvshows')
    xbmc.log(f"[Xtream Codes] Loading {len(series)} series", xbmc.LOGDEBUG)
    
    for serie in series:
        label = serie.get('name', 'Inconnu')
        
        # Meta parsing
        year = utils.parse_year(serie.get('releaseDate', '') or serie.get('release_date', ''))
        rating = utils.parse_rating(serie.get('rating', 0))
        cast = utils.parse_cast(serie.get('cast', ''))
        
        info = {
            'title': label,
            'plot': serie.get('plot', '') or 'Aucun synopsis',
            'genre': serie.get('genre', 'Inconnu'),
            'mediatype': 'tvshow'
        }
        
        if year > 0: info['year'] = year
        if rating > 0: info['rating'] = rating
        if serie.get('director'): info['director'] = serie['director']
        if cast: info['cast'] = cast
        
        fanart = utils.safe_get_backdrop(serie.get('backdrop_path'), DEFAULT_FANART)
        icon = serie.get('cover', SERIES_ICON) or SERIES_ICON
        
        add_directory_item(
            label=label,
            action='list_seasons',
            is_folder=True,
            icon=icon,
            fanart=fanart,
            info=info,
            series_id=serie.get('series_id')
        )
    
    xbmc.log(f"[Xtream Codes] Finished loading {len(series)} series", xbmc.LOGDEBUG)
    xbmcplugin.endOfDirectory(utils.get_handle())

def get_season_details(season_number: int, saisons: Dict[Any, Any], info: Dict[str, Any], episode_count: int = 0) -> Tuple[Dict[str, Any], str, str]:
    """Extract season details with proper fallbacks and translation."""
    season_info = saisons.get(season_number) or saisons.get(str(season_number))
    
    details = {
        'season': season_number,
        'mediatype': 'season',
        'title': f'Saison {season_number}'
    }
    
    # 1. Base Info (Series Fallback)
    plot = info.get('plot', 'Aucun synopsis')
    series_backdrop = info.get('backdrop_path')
    if series_backdrop and isinstance(series_backdrop, list): series_backdrop = series_backdrop[0]
    
    art_icon = info.get('cover', SERIES_ICON)
    art_fanart = series_backdrop or DEFAULT_FANART
    
    # 2. Season Specific Info
    if season_info:
        name = season_info.get('name')
        if name and name.lower() != 'none':
            details['title'] = name
            
        s_plot = season_info.get('overview', '') or season_info.get('plot', '')
        if s_plot:
            plot = s_plot
            
        if season_info.get('air_date'):
            details['premiered'] = season_info.get('air_date')
            
        vote_avg = season_info.get('vote_average')
        if vote_avg:
            details['rating'] = utils.parse_rating(vote_avg)
            
        # Episode count override
        ep_c = season_info.get('episode_count')
        if ep_c:
             episode_count = ep_c
             
        # Artwork
        s_cover = season_info.get('cover', '') or season_info.get('poster_path', '')
        if s_cover and s_cover.startswith('http'):
            art_icon = s_cover
            
        s_backdrop = season_info.get('cover_big', '') or season_info.get('backdrop_path', '')
        if s_backdrop and s_backdrop.startswith('http'):
            art_fanart = s_backdrop

    # 3. Finalize
    # Use Shared Translation Helper
    details['plot'] = utils.get_translated_plot(plot)
    if episode_count:
        details['episode'] = episode_count
        
    return details, art_icon, art_fanart

def show_seasons(add_directory_item, series_id: str) -> None:
    """Display seasons for a series."""
    series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        utils.notify("Erreur", "Info série introuvable.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    seasons_data = series_info.get('seasons', [])
    
    saisons_map = {s.get('season_number'): s for s in seasons_data}
    episodes_map = {int(k): v for k, v in episodes.items() if k.isdigit()}
    
    xbmcplugin.setContent(utils.get_handle(), 'seasons')

    for season_number in sorted(episodes_map.keys()):
        episode_count = len(episodes_map.get(season_number, []))
        
        details, art_icon, art_fanart = get_season_details(
            season_number, 
            saisons_map, 
            info, 
            episode_count
        )
        
        label = details['title']
        if episode_count:
            label = f"{label} ({episode_count} épisodes)"
        
        add_directory_item(
            label=label,
            action='list_episodes',
            is_folder=True,
            icon=art_icon,
            fanart=art_fanart,
            info=details,
            series_id=series_id,
            season=str(season_number)
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_episodes(add_directory_item, series_id: str, season: str) -> None:
    """Display episodes for a season."""
    series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        return

    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    seasons_data = series_info.get('seasons', [])
    
    try:
        season_num = int(season)
    except ValueError:
        return

    saisons_map = {s.get('season_number'): s for s in seasons_data}
    episodes_map = {int(k): v for k, v in episodes.items() if k.isdigit()}
    
    episode_list = episodes_map.get(season_num)
    if not episode_list:
        utils.notify("Erreur", f"Aucun épisode pour la saison {season}.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Get Season details for context/fallback
    season_details, art_icon, art_fanart = get_season_details(
        season_num, 
        saisons_map, 
        info, 
        len(episode_list)
    )

    xbmcplugin.setContent(utils.get_handle(), 'episodes')
    clean_series_title = _clean_series_title(info.get('name', 'Inconnu'))

    for episode in episode_list:
        ep_title = episode.get('title', 'Inconnu')
        ep_id = str(episode.get('id', ''))
        ext = episode.get('container_extension', 'mp4')
        
        # Parse Info
        ep_data = {}
        ep_data_raw = episode.get('info')
        if isinstance(ep_data_raw, list) and ep_data_raw:
             ep_data = ep_data_raw[0]
        elif isinstance(ep_data_raw, dict):
             ep_data = ep_data_raw
             
        duration = utils.parse_duration(ep_data.get('duration_secs'))
        
        ep_info = {
            'title': ep_title,
            'season': episode.get('season', season_num),
            'episode': episode.get('episode_num', 0),
            'duration': duration,
            'mediatype': 'episode',
            'tvshowtitle': clean_series_title
        }
        
        if ep_data.get('air_date'):
            ep_info['aired'] = ep_info['premiered'] = ep_data['air_date']
            
        # Plot
        plot = ep_data.get('plot') or ep_data.get('overview') or season_details.get('plot')
        ep_info['plot'] = plot
        
        # Artwork
        img = ep_data.get('movie_image')
        ep_thumb = img if img and img.startswith('http') else art_icon
        
        # Build URL
        stream_url = api.build_stream_url('series', ep_id, ext)
        
        add_directory_item(
            label=ep_title,
            action='play_episode',
            is_folder=False,
            icon=ep_thumb,
            fanart=art_fanart,
            info=ep_info,
            is_playable=True,
            stream_url=stream_url,
            title=ep_title,
            stream_id=ep_id,
            stream_icon=art_icon, # Use Season/Series Poster for History
            stream_fanart=art_fanart,
            series_id=series_id,
            season=str(season_num),
            episode_num=str(ep_info['episode']),
            plot=plot,
            duration=str(duration),
            premiered=ep_info.get('premiered', ''),
            tvshowtitle=clean_series_title
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_episode(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "", 
                 series_id: str = "", season: str = "", episode_num: str = "",
                 plot: str = "", duration: str = "", premiered: str = "", tvshowtitle: str = "",
                 resume_time: float = 0) -> None:
    """Play a TV show episode stream."""
    
    # Store episode metadata in window properties for the PlaybackMonitor
    if series_id and season and episode_num:
        try:
            window = xbmcgui.Window(10000)
            window.setProperty('xtream.episode.series_id', str(series_id))
            window.setProperty('xtream.episode.season', str(season))
            window.setProperty('xtream.episode.episode_num', str(episode_num))
            window.setProperty('xtream.episode.title', title)
        except Exception as e:
            utils.log(f"Error storing episode metadata: {e}", xbmc.LOGWARNING)
    else:
        try:
            window = xbmcgui.Window(10000)
            window.clearProperty('xtream.episode.series_id')
            window.clearProperty('xtream.episode.season')
            window.clearProperty('xtream.episode.episode_num')
            window.clearProperty('xtream.episode.title')
        except: pass
    
    meta = {
        'title': title,
        'mediatype': 'episode',
        'plot': plot,
        'duration': duration,
        'premiered': premiered,
        'tvshowtitle': tvshowtitle,
        'season': int(season) if str(season).isdigit() else 0,
        'episode': int(episode_num) if str(episode_num).isdigit() else 0
    }
    
    utils.play_stream(
        stream_url, "episode", title, stream_id, stream_icon, stream_fanart, 
        series_id=series_id, season=season, episode_num=episode_num,
        meta=meta, resume_time=resume_time
    )


def add_episode_to_playlist(stream_url: str, label: str) -> None:
    """Add an episode to the playlist."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Épisode ajouté.")
