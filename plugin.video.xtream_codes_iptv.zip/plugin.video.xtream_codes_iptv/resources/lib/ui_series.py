"""
Module UI pour Series (TV Shows)
Gère l'affichage et la lecture des séries télévisées.
"""
import xbmc
import xbmcgui
import xbmcplugin
from typing import List, Dict, Any

from resources.lib import api
from resources.lib import utils

# Icons
SERIES_ICON = None
DEFAULT_FANART = None
RECENT_ITEMS_COUNT = 100

def init_resources(series_icon: str, default_fanart: str, recent_count: int) -> None:
    """Initialize module resources."""
    global SERIES_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT
    SERIES_ICON = series_icon
    DEFAULT_FANART = default_fanart
    RECENT_ITEMS_COUNT = recent_count

def show_series_categories(add_directory_item) -> None:
    """Display series categories."""
    categories = api.fetch_data("action=get_series_categories")
    if not categories:
        utils.notify("Erreur", "Aucune catégorie de séries trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    add_directory_item(
        label="Séries récemment ajoutées",
        action='list_recent_series',
        is_folder=True,
        icon=SERIES_ICON,
        fanart=DEFAULT_FANART
    )

    for category in categories:
        add_directory_item(
            label=category.get('category_name', 'Inconnu'),
            action='list_series',
            is_folder=True,
            icon=SERIES_ICON,
            fanart=DEFAULT_FANART,
            category_id=category.get('category_id')
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_series(add_directory_item, category_id: str) -> None:
    """Display series for a category."""
    series = api.fetch_data(f"action=get_series&category_id={category_id}")
    if not series:
        xbmc.log(f"[Xtream Codes] No series found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucune série disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    for serie in series:
        serie['last_modified_int'] = int(serie.get('last_modified', 0))
    series.sort(key=lambda x: x['last_modified_int'], reverse=True)
    
    add_series_to_directory(add_directory_item, series)

def show_recent_series(add_directory_item) -> None:
    """Display recently added series."""
    series = api.fetch_data("action=get_series")
    if not series:
        return
    for serie in series:
        serie['last_modified_int'] = int(serie.get('last_modified', 0))
    series.sort(key=lambda x: x['last_modified_int'], reverse=True)
    series = series[:RECENT_ITEMS_COUNT]
    add_series_to_directory(add_directory_item, series)

def add_series_to_directory(add_directory_item, series: List[Dict[str, Any]]) -> None:
    """Add series to Kodi directory listing."""
    # Tell Kodi this is a TV shows listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'tvshows')
    
    # Log for debugging
    xbmc.log(f"[Xtream Codes] Loading {len(series)} series", xbmc.LOGDEBUG)
    
    for serie in series:
        # NO REGEX CLEANING
        label = serie.get('name', 'Inconnu')
        
        # Use helper functions for parsing
        year = utils.parse_year(serie.get('releaseDate', '') or serie.get('release_date', ''))
        rating = utils.parse_rating(serie.get('rating', 0))
        cast = utils.parse_cast(serie.get('cast', ''))
        
        info = {
            'title': label,
            'plot': serie.get('plot', '') or 'Aucun synopsis',
            'genre': serie.get('genre', 'Inconnu'),
            'mediatype': 'tvshow'
        }
        
        # Add optional fields only if valid
        if year > 0:
            info['year'] = year
        if rating > 0:
            info['rating'] = rating
        
        # Add director if available
        director = serie.get('director', '')
        if director:
            info['director'] = director
        
        # Add cast if available
        if cast:
            info['cast'] = cast
        
        # Use helper for backdrop
        fanart = utils.safe_get_backdrop(serie.get('backdrop_path'), DEFAULT_FANART)
        
        icon = serie.get('cover', SERIES_ICON) or SERIES_ICON
        
        series_id = serie.get('series_id')
        
        context_menu = [
            ("Information", f"RunPlugin({utils.build_url({'action': 'show_series_info', 'series_id': str(series_id)})})")
,
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=label,
            action='list_seasons',
            is_folder=True,
            icon=icon,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            series_id=serie.get('series_id')
        )
    
    xbmc.log(f"[Xtream Codes] Finished loading {len(series)} series", xbmc.LOGDEBUG)
    xbmcplugin.endOfDirectory(utils.get_handle())

def get_season_details(season_number, saisons, info, episode_count=0):
    """
    Extract season details with proper fallbacks.
    """
    season_info = saisons.get(season_number)
    
    if season_info:
        # Extract season name (e.g., "Season 1" or custom name)
        season_name = season_info.get('name', f'Saison {season_number}')
        if not season_name or season_name.lower() == 'none':
            season_name = f'Saison {season_number}'
        
        # Get overview/plot
        plot = season_info.get('overview', '') or season_info.get('plot', '')
        if not plot:
            plot = info.get('plot', 'Aucun synopsis')
        
        # Translate plot to Arabic
        try:
            from resources.lib import translator
            plot_ar = translator.translate_to_arabic(plot)
            if plot_ar and plot_ar != plot:
                plot = f"{plot}\n\n{plot_ar}"
        except Exception as e:
            xbmc.log(f"[Xtream Codes] Translation failed in season view: {e}", xbmc.LOGWARNING)
        
        # Get air date
        air_date = season_info.get('air_date', '')
        
        # Get episode count (from season metadata or actual episode list)
        ep_count = season_info.get('episode_count', episode_count)
        if not ep_count:
            ep_count = episode_count
        
        # Get rating
        rating = 0.0
        vote_avg = season_info.get('vote_average', 0)
        if vote_avg:
            try:
                rating = float(vote_avg)
            except (ValueError, TypeError):
                rating = 0.0
        
        details = {
            'title': season_name,
            'plot': plot,
            'season': season_number,
            'mediatype': 'season'
        }
        
        if ep_count:
            details['episode'] = ep_count
        if rating > 0:
            details['rating'] = rating
        if air_date:
            details['premiered'] = air_date
            details['aired'] = air_date
        
        # Get season artwork
        art_icon = season_info.get('cover', '') or season_info.get('poster_path', '')
        if not art_icon or not art_icon.startswith('http'):
            art_icon = info.get('cover', SERIES_ICON)
        
        art_fanart = season_info.get('cover_big', '') or season_info.get('backdrop_path', '')
        if not art_fanart or not art_fanart.startswith('http'):
            # Fallback to series backdrop
            backdrop = info.get('backdrop_path')
            if isinstance(backdrop, list) and backdrop:
                art_fanart = backdrop[0]
            elif isinstance(backdrop, str):
                art_fanart = backdrop
            else:
                art_fanart = DEFAULT_FANART
    else:
        # No season metadata available, use series info
        plot = info.get('plot', 'Aucun synopsis')
        
        # Translate plot to Arabic
        try:
            from resources.lib import translator
            plot_ar = translator.translate_to_arabic(plot)
            if plot_ar and plot_ar != plot:
                plot = f"{plot}\n\n{plot_ar}"
        except Exception as e:
            xbmc.log(f"[Xtream Codes] Translation failed in season view: {e}", xbmc.LOGWARNING)
        
        details = {
            'title': f'Saison {season_number}',
            'plot': plot,
            'season': season_number,
            'mediatype': 'season'
        }
        
        if episode_count:
            details['episode'] = episode_count
        
        art_icon = info.get('cover', SERIES_ICON)
        
        # Get series backdrop
        backdrop = info.get('backdrop_path')
        if isinstance(backdrop, list) and backdrop:
            art_fanart = backdrop[0]
        elif isinstance(backdrop, str):
            art_fanart = backdrop
        else:
            art_fanart = DEFAULT_FANART
    
    return details, art_icon, art_fanart

def show_seasons(add_directory_item, series_id: str) -> None:
    """Display seasons for a series."""
    series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        utils.notify("Erreur", "Info série introuvable.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    seasons = series_info.get('seasons', [])
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    del series_info

    saisons_map = {s.get('season_number'): s for s in seasons}
    episodes_map = {int(k): v for k, v in episodes.items()}
    
    # Tell Kodi this is a seasons listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'seasons')

    for season_number in sorted(episodes_map.keys()):
        # Count actual episodes in this season
        episode_count = len(episodes_map.get(season_number, []))
        
        details, art_icon, art_fanart = get_season_details(
            season_number, 
            saisons_map, 
            info, 
            episode_count
        )
        
        # Build season label with episode count
        label = details['title']
        if episode_count:
            label = f"{details['title']} ({episode_count} épisodes)"
        
        add_directory_item(
            label=label,
            action='list_episodes',
            is_folder=True,
            icon=art_icon,
            fanart=art_fanart,
            info=details,
            series_id=series_id,
            season=season_number
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_episodes(add_directory_item, series_id: str, season: str) -> None:
    """Display episodes for a season."""
    series_info = api.fetch_data(f"action=get_series_info&series_id={series_id}")
    if not series_info:
        return

    seasons = series_info.get('seasons', [])
    episodes = series_info.get('episodes', {})
    info = series_info.get('info', {})
    
    try:
        season_num = int(season)
    except ValueError:
        return

    saisons_map = {s.get('season_number'): s for s in seasons}
    episodes_map = {int(k): v for k, v in episodes.items()}
    
    episode_list = episodes_map.get(season_num)
    if not episode_list:
        utils.notify("Erreur", f"Aucun épisode pour la saison {season}.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    details, art_icon, art_fanart = get_season_details(
        season_num, 
        saisons_map, 
        info, 
        len(episode_list)
    )
    
    server = api.get_server_url()
    user = api.get_username()
    pwd = api.get_password()
    
    # Tell Kodi this is an episodes listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'episodes')

    for episode in episode_list:
        # NO REGEX CLEANING - RAW TITLE
        ep_title = episode.get('title', 'Inconnu')
        ep_id = episode.get('id', 'Inconnu')
        container_extension = episode.get('container_extension', 'ts')
        
        # Extract episode info (nested in 'info' key)
        # Sometimes 'info' is a list, sometimes a dict - handle both cases
        ep_data_raw = episode.get('info', {})
        if isinstance(ep_data_raw, list):
            # If it's a list, take the first element or use empty dict
            xbmc.log(f"[Xtream Codes] Episode info is a list for episode {episode.get('id', 'unknown')}, taking first element", xbmc.LOGDEBUG)
            ep_data = ep_data_raw[0] if ep_data_raw else {}
        elif isinstance(ep_data_raw, dict):
            ep_data = ep_data_raw
        else:
            ep_data = {}
        
        # Get duration from info.duration_secs (more reliable than duration string)
        duration = 0
        if isinstance(ep_data, dict):
            duration_secs = ep_data.get('duration_secs', 0)
            if duration_secs:
                try:
                    duration = int(duration_secs)
                except (ValueError, TypeError):
                    duration = 0
        
        # Get air date
        air_date = ep_data.get('air_date', '') if isinstance(ep_data, dict) else ''
        
        # Build episode info for Kodi
        ep_info = {
            'title': ep_title,
            'season': episode.get('season', season_num),
            'episode': episode.get('episode_num', 'Inconnu'),
            'duration': duration,
            'mediatype': 'episode'
        }
        
        # Add air date if available
        if air_date:
            ep_info['aired'] = air_date
            ep_info['premiered'] = air_date
        
        # Add plot from episode info or fallback to season/series plot
        plot = ''
        if isinstance(ep_data, dict):
            plot = ep_data.get('plot', '') or ep_data.get('overview', '')
        if not plot:
            plot = details.get('plot', 'Aucun synopsis')
        ep_info['plot'] = plot
        
        # Get episode thumbnail (movie_image) or fallback to season/series art
        ep_thumb = art_icon
        if isinstance(ep_data, dict):
            ep_thumb = ep_data.get('movie_image', '')
        if not ep_thumb or not ep_thumb.startswith('http'):
            ep_thumb = art_icon
        
        # Use episode backdrop if available, otherwise use season/series fanart
        ep_fanart = art_fanart
        
        stream_url = f"{server}/series/{user}/{pwd}/{ep_id}.{container_extension}"
        
        context_menu = [
            ("Ajouter à la liste de lecture", f"RunPlugin({utils.build_url({'action': 'add_episode_to_playlist', 'stream_url': stream_url, 'label': ep_title})})"),
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=ep_title,
            action='play_episode',
            is_folder=False,
            icon=ep_thumb,
            fanart=ep_fanart,
            info=ep_info,
            context_menu=context_menu,
            is_playable=True,
            stream_url=stream_url,
            title=ep_title,
            stream_id=str(ep_id),
            stream_icon=ep_thumb,
            stream_fanart=ep_fanart,
            series_id=series_id,
            season=str(season_num),
            episode_num=str(episode.get('episode_num', ''))
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_episode(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "", 
                 series_id: str = "", season: str = "", episode_num: str = "") -> None:
    """
    Play a TV show episode stream.
    
    Args:
        stream_url: URL of the episode stream
        title: Episode title
        stream_id: Episode ID
        stream_icon: Episode thumbnail
        stream_fanart: Episode fanart
        series_id: Series ID (for auto-play next episode)
        season: Season number (for auto-play next episode)
        episode_num: Episode number (for auto-play next episode)
    """
    # Store episode metadata in window properties for the PlaybackMonitor
    # This is necessary because play_episode is called BEFORE playback starts
    utils.log(f"play_episode called - series_id='{series_id}', season='{season}', episode_num='{episode_num}', title='{title}'", xbmc.LOGINFO)
    
    if series_id and season and episode_num:
        try:
            # Store metadata in window properties
            window = xbmcgui.Window(10000)  # Home window (persistent)
            window.setProperty('xtream.episode.series_id', series_id)
            window.setProperty('xtream.episode.season', season)
            window.setProperty('xtream.episode.episode_num', episode_num)
            window.setProperty('xtream.episode.title', title)
            utils.log(f"Stored episode metadata in window properties for auto-play", xbmc.LOGINFO)
        except Exception as e:
            utils.log(f"Error storing episode metadata: {e}", xbmc.LOGWARNING)
    else:
        # Clear properties if not an episode
        try:
            window = xbmcgui.Window(10000)
            window.clearProperty('xtream.episode.series_id')
            window.clearProperty('xtream.episode.season')
            window.clearProperty('xtream.episode.episode_num')
            window.clearProperty('xtream.episode.title')
        except:
            pass
    
    # Play the stream
    utils.play_stream(stream_url, "episode", title, stream_id, stream_icon, stream_fanart)


def show_series_info(series_id: str) -> None:
    """
    Affiche les détails complets d'une série via get_series_info.
    Utilise les métadonnées enrichies de l'API avec traduction arabe.
    """
    if not series_id:
        return
    
    series_data = api.fetch_data(f"action=get_series_info&series_id={series_id}", cache_duration=7200)  # Cache 2h
    if not series_data:
        utils.notify("Erreur", "Impossible de récupérer les infos de la série.", xbmcgui.NOTIFICATION_ERROR)
        return
    
    info = series_data.get('info', {})
    
    # Extract series details
    title = info.get('name', 'Inconnu')
    plot = info.get('plot', '') or info.get('description', 'Aucun synopsis disponible')
    director = info.get('director', 'Inconnu')
    actors = info.get('cast', 'Inconnu')
    genre = info.get('genre', 'Inconnu')
    
    # Safe rating conversion
    try:
        rating = float(info.get('rating', 0))
    except (ValueError, TypeError):
        rating = 0.0
    
    release_date = info.get('releaseDate', '') or info.get('release_date', 'Inconnu')
    
    # Episode count
    episodes = series_data.get('episodes', {})
    total_episodes = sum(len(eps) for eps in episodes.values())
    season_count = len(episodes)
    
    # Translate synopsis to Arabic
    plot_ar = None
    try:
        from resources.lib import translator
        plot_ar = translator.translate_to_arabic(plot)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Translation failed: {e}", xbmc.LOGWARNING)
    
    # Build detailed message
    details = [f"[B]{title}[/B]"]
    
    # Synopsis with Arabic translation
    details.append(f"\n[B]Synopsis:[/B]\n{plot}")
    
    if plot_ar and plot_ar != plot:
        details.append(f"\n[B]الملخص (بالعربية):[/B]\n{plot_ar}")
    
    details.append(f"\n[B]Informations:[/B]")
    details.append(f"Réalisateur: {director}")
    details.append(f"Acteurs: {actors}")
    details.append(f"Genre: {genre}")
    
    if rating > 0:
        details.append(f"Note: {rating}/10")
    
    details.append(f"Date de sortie: {release_date}")
    details.append(f"Saisons: {season_count}")
    details.append(f"Épisodes: {total_episodes}")
    
    # Display in text viewer
    xbmcgui.Dialog().textviewer(f"Détails - {title}", '\n'.join(details))


def add_episode_to_playlist(stream_url: str, label: str) -> None:
    """Add an episode to the playlist."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Épisode ajouté.")
