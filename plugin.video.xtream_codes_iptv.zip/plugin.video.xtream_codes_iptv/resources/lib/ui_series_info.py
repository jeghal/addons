

def show_series_info(series_id: str) -> None:
    """
    Affiche les détails complets d'une série via get_series_info.
    Utilise les métadonnées enrichies de l'API avec traduction arabe.
    """
    if not series_id:
        return
    
    series_data = api.fetch_data(f"action=get_series_info&series_id={series_id}", cache_duration=7200)  # Cache 2h
    if not series_data:
        utils.notify("Erreur", "Impossible de récupérer les infos de la série.", xbmcgui.NOTIFICATION_ERROR)
        return
    
    info = series_data.get('info', {})
    
    # Extract series details
    title = info.get('name', 'Inconnu')
    plot = info.get('plot', '') or info.get('description', 'Aucun synopsis disponible')
    director = info.get('director', 'Inconnu')
    actors = info.get('cast', 'Inconnu')
    genre = info.get('genre', 'Inconnu')
    
    # Safe rating conversion
    try:
        rating = float(info.get('rating', 0))
    except (ValueError, TypeError):
        rating = 0.0
    
    release_date = info.get('releaseDate', '') or info.get('release_date', 'Inconnu')
    
    # Episode count
    episodes = series_data.get('episodes', {})
    total_episodes = sum(len(eps) for eps in episodes.values())
    season_count = len(episodes)
    
    # Translate synopsis to Arabic
    plot_ar = None
    try:
        from resources.lib import translator
        plot_ar = translator.translate_to_arabic(plot)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Translation failed: {e}", xbmc.LOGWARNING)
    
    # Build detailed message
    details = [f"[B]{title}[/B]"]
    
    # Synopsis with Arabic translation
    details.append(f"\n[B]Synopsis:[/B]\n{plot}")
    
    if plot_ar and plot_ar != plot:
        details.append(f"\n[B]الملخص (بالعربية):[/B]\n{plot_ar}")
    
    details.append(f"\n[B]Informations:[/B]")
    details.append(f"Réalisateur: {director}")
    details.append(f"Acteurs: {actors}")
    details.append(f"Genre: {genre}")
    
    if rating > 0:
        details.append(f"Note: {rating}/10")
    
    details.append(f"Date de sortie: {release_date}")
    details.append(f"Saisons: {season_count}")
    details.append(f"Épisodes: {total_episodes}")
    
    # Display in text viewer
    xbmcgui.Dialog().textviewer(f"Détails - {title}", '\n'.join(details))
