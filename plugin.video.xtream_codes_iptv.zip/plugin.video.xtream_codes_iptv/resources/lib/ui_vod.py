"""
Module UI pour VOD (Movies)
Gère l'affichage et la lecture des films.
"""
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
from typing import List, Dict, Any, Optional

from resources.lib import api
from resources.lib import utils

# Icons
VOD_ICON: Optional[str] = None
SEARCH_ICON: Optional[str] = None
SERIES_ICON: Optional[str] = None
DEFAULT_FANART: Optional[str] = None
RECENT_ITEMS_COUNT: int = 100

def init_resources(vod_icon: str, default_fanart: str, recent_count: int, search_icon: str = None, series_icon: str = None) -> None:
    """Initialize module resources."""
    global VOD_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT, SEARCH_ICON, SERIES_ICON
    VOD_ICON = vod_icon
    DEFAULT_FANART = default_fanart
    RECENT_ITEMS_COUNT = recent_count
    SEARCH_ICON = search_icon
    SERIES_ICON = series_icon

def _clean_movie_title(label: str, year_hint: int = 0) -> str:
    """
    Cleans movie title by removing country prefixes and years.
    
    Args:
        label: Raw title
        year_hint: Year to remove if present
    
    Returns:
        Cleaned title
    """
    clean_title = label
    # 1. Remove country prefixes like "FR - ", "UK - ", "AR: ", "DE: "
    clean_title = re.sub(r'^[A-Z]{2,3}\s*[-–:]\s*', '', clean_title)
    
    # 2. Remove year from title if present at the end
    clean_title = re.sub(r'\s*[-–]?\s*\(?(19|20)\d{2}\)?\s*$', '', clean_title).strip()
    
    return clean_title

def show_vod_categories(add_directory_item, parent_id: str = "0") -> None:
    """Display VOD categories."""
    categories = api.fetch_data("action=get_vod_categories")
    if not categories:
        utils.notify("Erreur", "Aucune catégorie VOD trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # [B]Rechercher un Film
    add_directory_item("[B]Rechercher un Film[/B]", 'search_movies', is_folder=True, icon=SEARCH_ICON, fanart=DEFAULT_FANART)
    
    # [B]Continuer à regarder[/B]
    add_directory_item(
        label="[B]Continuer à regarder[/B]",
        action='show_movie_history',
        is_folder=True,
        icon=SERIES_ICON, 
        fanart=DEFAULT_FANART
    )
    
    # [B]Films récents[/B]
    add_directory_item(
        label="[B]Films récents[/B]",
        action='list_recent_movies',
        is_folder=True,
        icon=SEARCH_ICON,
        fanart=DEFAULT_FANART
    )

    # Filter categories for current level
    current_level_cats = [c for c in categories if str(c.get('parent_id', '0')) == parent_id]
    current_level_cats.sort(key=lambda x: x.get('category_name', ''))

    for category in current_level_cats:
        cat_id = str(category.get('category_id'))
        cat_name = category.get('category_name', 'Inconnu')
        
        add_directory_item(
            label=cat_name,
            action='list_movies',
            is_folder=True,
            icon=VOD_ICON,
            fanart=DEFAULT_FANART,
            category_id=cat_id
        )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_movies(add_directory_item, category_id: str) -> None:
    """Display movies for a category."""
    movies = api.fetch_data(f"action=get_vod_streams&category_id={category_id}")
    if not movies:
        xbmc.log(f"[Xtream Codes] No movies found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucun film disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Filter adult content if enabled
    movies = api.filter_adult_content(movies)
    
    # Sort by 'added' descending
    try:
        movies.sort(key=lambda x: int(x.get('added', 0)), reverse=True)
    except (ValueError, TypeError):
        pass # Keep original order if sort fails
    
    add_movies_to_directory(add_directory_item, movies)

def show_recent_movies(add_directory_item) -> None:
    """Display recently added movies."""
    # Use configurable cache duration (default 24h)
    try:
        addon = xbmcaddon.Addon()
        cache_hours = int(addon.getSetting('cache_search_duration'))
    except (ValueError, TypeError):
        cache_hours = 24
    cache_duration = cache_hours * 3600  # Convert hours to seconds
    
    movies = api.fetch_data("action=get_vod_streams", cache_duration=cache_duration)
    if not movies:
        return

    movies = api.filter_adult_content(movies)
    
    try:
        movies.sort(key=lambda x: int(x.get('added', 0)), reverse=True)
    except (ValueError, TypeError):
        pass
        
    movies = movies[:RECENT_ITEMS_COUNT]
    add_movies_to_directory(add_directory_item, movies)

def add_movies_to_directory(add_directory_item, movies: List[Dict[str, Any]]) -> None:
    """Add movies to Kodi directory listing."""
    
    xbmcplugin.setContent(utils.get_handle(), 'movies')
    xbmc.log(f"[Xtream Codes] Loading {len(movies)} movies", xbmc.LOGDEBUG)

    for movie in movies:
        label = movie.get('name', 'Inconnu')
        
        # Year parsing
        year = utils.parse_year(movie.get('year', 0))
        if year == 0:
            # Try to find year in title
            match = re.search(r'\b(19|20)\d{2}\b', label)
            if match:
                try: year = int(match.group(0))
                except ValueError: pass
        
        # Title cleaning
        clean_title = _clean_movie_title(label, year)
        
        stream_id = movie.get('stream_id')
        rating = utils.parse_rating(movie.get('rating', 0))
        duration = utils.parse_duration(movie.get('duration', 0))
        cast = utils.parse_cast(movie.get('cast', ''))
        
        info = {
            'title': clean_title,
            'plot': movie.get('plot', '') or movie.get('description', ''),
            'genre': movie.get('genre', ''),
            'director': movie.get('director', ''),
            'country': movie.get('country', ''),
            'mediatype': 'movie'
        }
        
        if year > 0:
            info['year'] = year
            info['premiered'] = f"{year}-01-01"
        if rating > 0:
            info['rating'] = rating
        if duration > 0:
            info['duration'] = duration
        if cast:
            info['cast'] = cast
        
        if movie.get('studio'): info['studio'] = movie['studio']
        if movie.get('tagline'): info['tagline'] = movie['tagline']
        
        thumb = movie.get('stream_icon', '') or movie.get('cover', '') or VOD_ICON
        fanart = utils.safe_get_backdrop(movie.get('backdrop_path'), DEFAULT_FANART)
        
        # Extension
        ext = movie.get('container_extension', 'mp4')
        stream_url = api.build_stream_url('movie', stream_id, ext)
        
        add_directory_item(
            label=label,
            action='movie_options',
            is_folder=True,
            icon=thumb,
            fanart=fanart,
            info=info,
            is_playable=False,
            stream_url=stream_url,
            title=clean_title,
            stream_id=str(stream_id),
            stream_icon=thumb,
            stream_fanart=fanart,
            plot=info.get('plot', ''),
            year=str(year) if year > 0 else "",
            duration=str(duration) if duration > 0 else "",
            rating=str(rating) if rating > 0 else ""
        )
    
    xbmc.log(f"[Xtream Codes] Finished loading {len(movies)} movies", xbmc.LOGDEBUG)
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_movie(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "", 
               plot: str = "", year: str = "", duration: str = "", rating: str = "") -> None:
    """Play a movie stream."""
    utils.play_stream(
        stream_url=stream_url, 
        stream_type="movie", 
        title=title, 
        stream_id=stream_id, 
        icon=stream_icon, 
        fanart=stream_fanart, 
        meta={
            'title': title,
            'mediatype': 'movie',
            'plot': plot,
            'year': year,
            'duration': duration,
            'rating': rating
        }
    )

def add_movie_to_playlist(stream_url: str, label: str) -> None:
    """Add a movie to the playlist."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Film ajouté.")

def show_movie_options_menu(add_directory_item, stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "", 
                       plot: str = "", year: str = "", duration: str = "", rating: str = "") -> None:
    """
    Display the options menu for a specific movie.
    Fetches full details and shows a single 'Play' item with rich metadata.
    """
    xbmcplugin.setContent(utils.get_handle(), 'movies')
    
    # 1. Fetch detailed info
    movie_data = api.fetch_data(f"action=get_vod_info&vod_id={stream_id}", cache_duration=7200) if stream_id else None

    # 2. Base Metadata
    info_labels = {
        'title': title,
        'mediatype': 'movie',
        'plot': plot,
        'year': year,
        'duration': duration,
        'rating': rating
    }

    if movie_data:
        # Handle API returning list instead of dict
        if isinstance(movie_data, list):
            movie_data = movie_data[0] if movie_data else {}
            
        info_dict = movie_data.get('info', {})
        
        # Enrich metadata
        info_labels.update({
            'originaltitle': info_dict.get('o_name', ''),
            'director': info_dict.get('director', ''),
            'cast': utils.parse_cast(info_dict.get('actors', '') or info_dict.get('cast', '')),
            'genre': info_dict.get('genre', ''),
            'country': info_dict.get('country', ''),
            'premiered': info_dict.get('releasedate', '')
        })
        
        if info_dict.get('rating'):
            try: info_labels['rating'] = float(info_dict.get('rating'))
            except: pass
            
        if info_dict.get('duration_secs'):
            info_labels['duration'] = info_dict.get('duration_secs')
        elif info_dict.get('episode_run_time'):
             info_labels['duration'] = info_dict.get('episode_run_time') * 60
             
        if info_dict.get('releasedate'):
            try: info_labels['year'] = int(info_dict.get('releasedate')[:4])
            except: pass
            
        if info_dict.get('backdrop_path'):
            stream_fanart = utils.safe_get_backdrop(info_dict.get('backdrop_path'), stream_fanart)
        
        # 3. Translate Plot
        full_plot = info_dict.get('plot', '') or info_dict.get('description', '')
        info_labels['plot'] = utils.get_translated_plot(full_plot) if full_plot else plot

    add_directory_item(
        label=f"Lire : {title}",
        action='play_movie',
        is_folder=False,
        icon=stream_icon,
        fanart=stream_fanart,
        is_playable=True,
        stream_url=stream_url,
        title=title,
        stream_id=stream_id,
        stream_icon=stream_icon,
        stream_fanart=stream_fanart,
        info=info_labels
    )

    xbmcplugin.endOfDirectory(utils.get_handle())

