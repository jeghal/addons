"""
Module UI pour VOD (Movies)
Gère l'affichage et la lecture des films.
"""
import xbmc
import xbmcgui
import xbmcplugin
import re
from typing import List, Dict, Any

from resources.lib import api
from resources.lib import utils

# Icons
VOD_ICON = None
DEFAULT_FANART = None
RECENT_ITEMS_COUNT = 100

def init_resources(vod_icon: str, default_fanart: str, recent_count: int) -> None:
    """Initialize module resources."""
    global VOD_ICON, DEFAULT_FANART, RECENT_ITEMS_COUNT
    VOD_ICON = vod_icon
    DEFAULT_FANART = default_fanart
    RECENT_ITEMS_COUNT = recent_count

def show_vod_categories(add_directory_item, parent_id: str = "0") -> None:
    """Display VOD categories with hierarchical support."""
    categories = api.fetch_data("action=get_vod_categories")
    if not categories:
        utils.notify("Erreur", "Aucune catégorie VOD trouvée.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Normalisation
    parent_id = str(parent_id)
    
    # Option : Films récemment ajoutés (seulement à la racine)
    if parent_id == "0":
        add_directory_item(
            label="Films récemment ajoutés",
            action='list_recent_movies',
            is_folder=True,
            icon=VOD_ICON,
            fanart=DEFAULT_FANART
        )

    # Filtrage et identification de la structure
    current_level_cats = []
    all_parent_ids = set()
    
    for cat in categories:
        pid = str(cat.get('parent_id', '0'))
        cid = str(cat.get('category_id'))
        all_parent_ids.add(pid)
        
        if pid == parent_id:
            current_level_cats.append(cat)
            
    if not current_level_cats and parent_id != "0":
        utils.notify("Info", "Aucune sous-catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle())
        return

    for category in current_level_cats:
        cat_id = str(category.get('category_id'))
        cat_name = category.get('category_name', 'Inconnu')
        
        is_folder_structure = cat_id in all_parent_ids
        
        if is_folder_structure:
            add_directory_item(
                label=cat_name,
                action='list_vod_categories',
                is_folder=True,
                icon=VOD_ICON,
                fanart=DEFAULT_FANART,
                category_id=cat_id
            )
        else:
            add_directory_item(
                label=cat_name,
                action='list_movies',
                is_folder=True,
                icon=VOD_ICON,
                fanart=DEFAULT_FANART,
                category_id=cat_id
            )
    xbmcplugin.endOfDirectory(utils.get_handle())

def show_movies(add_directory_item, category_id: str) -> None:
    """Display movies for a category."""
    movies = api.fetch_data(f"action=get_vod_streams&category_id={category_id}")
    if not movies:
        xbmc.log(f"[Xtream Codes] No movies found for category {category_id}", xbmc.LOGWARNING)
        utils.notify("Erreur", "Aucun film disponible dans cette catégorie.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(utils.get_handle(), succeeded=False)
        return

    # Filter adult content if enabled
    movies = api.filter_adult_content(movies)
    
    for movie in movies:
        movie['added_int'] = int(movie.get('added', 0))
    movies.sort(key=lambda x: x['added_int'], reverse=True)
    
    add_movies_to_directory(add_directory_item, movies)

def show_recent_movies(add_directory_item) -> None:
    """Display recently added movies."""
    movies = api.fetch_data("action=get_vod_streams")
    if not movies:
        return

    # Filter adult content if enabled
    movies = api.filter_adult_content(movies)
    
    for movie in movies:
        movie['added_int'] = int(movie.get('added', 0))
    movies.sort(key=lambda x: x['added_int'], reverse=True)
    movies = movies[:RECENT_ITEMS_COUNT]
    
    add_movies_to_directory(add_directory_item, movies)

def add_movies_to_directory(add_directory_item, movies: List[Dict[str, Any]]) -> None:
    """Add movies to Kodi directory listing."""
    server_url = api.get_server_url()
    username = api.get_username()
    password = api.get_password()
    
    # Tell Kodi this is a movies listing (enables Information menu)
    xbmcplugin.setContent(utils.get_handle(), 'movies')
    
    # Log for debugging
    xbmc.log(f"[Xtream Codes] Loading {len(movies)} movies", xbmc.LOGDEBUG)

    for movie in movies:
        # Clean title for metadata (remove prefixes/suffixes)
        label = movie.get('name', 'Inconnu')
        clean_title = label
        
        # 1. Remove country prefixes like "FR - ", "UK - ", "AR: ", "DE: "
        clean_title = re.sub(r'^[A-Z]{2,3}\s*[-–:]\s*', '', clean_title)
        
        # 2. Extract and remove year
        year = utils.parse_year(movie.get('year', 0))
        if year == 0:
            # Try to find year in title
            match = re.search(r'\b(19|20)\d{2}\b', label)
            if match:
                try:
                    year = int(match.group(0))
                except ValueError:
                    pass
        
        # Remove year from title if present at the end
        clean_title = re.sub(r'\s*[-–]?\s*\(?(19|20)\d{2}\)?\s*$', '', clean_title).strip()
        
        stream_id = movie.get('stream_id')
        
        rating = utils.parse_rating(movie.get('rating', 0))
        duration = utils.parse_duration(movie.get('duration', 0))
        cast = utils.parse_cast(movie.get('cast', ''))
        
        info = {
            'title': clean_title, # Send clean title to Kodi via meta
            'plot': movie.get('plot', '') or movie.get('description', ''),
            'genre': movie.get('genre', ''),
            'director': movie.get('director', ''),
            'country': movie.get('country', ''),
            'mediatype': 'movie'
        }
        
        # Add optional fields only if valid
        if year > 0:
            info['year'] = year
            info['premiered'] = f"{year}-01-01"
        if rating > 0:
            info['rating'] = rating
        if duration > 0:
            info['duration'] = duration
        if cast:
            info['cast'] = cast
        
        # Additional metadata for Kodi's Information dialog
        studio = movie.get('studio', '')
        if studio:
            info['studio'] = studio
        
        tagline = movie.get('tagline', '')
        if tagline:
            info['tagline'] = tagline
        
        # Get artwork
        thumb = movie.get('stream_icon', '') or movie.get('cover', '') or VOD_ICON
        
        # Use helper for backdrop
        fanart = utils.safe_get_backdrop(movie.get('backdrop_path'), DEFAULT_FANART)
        
        stream_url = f"{server_url}/movie/{username}/{password}/{stream_id}.{movie.get('container_extension')}"
        
        # Context menu with Information option
        context_menu = [
            ("Information", f"RunPlugin({utils.build_url({'action': 'show_movie_info', 'stream_id': str(stream_id)})})"),
            ("Ajouter à la liste de lecture", f"RunPlugin({utils.build_url({'action': 'add_movie_to_playlist', 'stream_url': stream_url, 'label': label})})"),
            ("Effacer le cache", f"RunPlugin({utils.build_url({'action': 'clear_cache'})})")
        ]
        
        add_directory_item(
            label=label,
            action='play_movie',
            is_folder=False,
            icon=thumb,
            fanart=fanart,
            info=info,
            context_menu=context_menu,
            is_playable=True,
            stream_url=stream_url,
            title=clean_title,
            stream_id=str(stream_id),
            stream_icon=thumb,
            stream_fanart=fanart,
            plot=info.get('plot', ''),
            year=str(year) if year > 0 else "",
            duration=str(duration) if duration > 0 else "",
            rating=str(rating) if rating > 0 else ""
        )
    
    xbmc.log(f"[Xtream Codes] Finished loading {len(movies)} movies", xbmc.LOGDEBUG)
    xbmcplugin.endOfDirectory(utils.get_handle())

def play_movie(stream_url: str, title: str = "", stream_id: str = "", stream_icon: str = "", stream_fanart: str = "", 
               plot: str = "", year: str = "", duration: str = "", rating: str = "") -> None:
    """Play a movie stream."""
    
    # Build metadata dict
    meta = {
        'title': title,
        'mediatype': 'movie'
    }
    if plot: meta['plot'] = plot
    if year: meta['year'] = year
    if duration: meta['duration'] = duration
    if rating: meta['rating'] = rating
    
    utils.play_stream(stream_url, "movie", title, stream_id, stream_icon, stream_fanart, meta=meta)

def add_movie_to_playlist(stream_url: str, label: str) -> None:
    """Add a movie to the playlist."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    playlist.add(stream_url, li)
    utils.notify("Liste de lecture", "Film ajouté.")

def show_movie_info(stream_id: str) -> None:
    """
    Affiche les détails complets d'un film via get_vod_info.
    Utilise les métadonnées enrichies de l'API.
    """
    if not stream_id:
        return
    
    movie_data = api.fetch_data(f"action=get_vod_info&vod_id={stream_id}", cache_duration=7200)  # Cache 2h
    if not movie_data:
        utils.notify("Erreur", "Impossible de récupérer les infos du film.", xbmcgui.NOTIFICATION_ERROR)
        return
    
    info = movie_data.get('info', {})
    movie_info = movie_data.get('movie_data', {})
    
    # Extract movie details
    title = info.get('name', 'Inconnu')
    original_title = info.get('o_name', '')
    plot = info.get('plot', '') or info.get('description', 'Aucun synopsis disponible')
    director = info.get('director', 'Inconnu')
    actors = info.get('actors', '') or info.get('cast', 'Inconnu')
    country = info.get('country', 'Inconnu')
    genre = info.get('genre', 'Inconnu')
    
    # Safe rating conversion
    try:
        rating = float(info.get('rating', 0))
    except (ValueError, TypeError):
        rating = 0.0
    
    release_date = info.get('releasedate', 'Inconnu')
    duration = info.get('duration', 'Inconnu')
    tmdb_id = info.get('tmdb_id', '')
    
    # Technical details
    video_info = info.get('video', {})
    audio_info = info.get('audio', {})
    bitrate = info.get('bitrate', 0)
    
    # Quality label - safe conversion
    try:
        width = int(video_info.get('width', 0)) if isinstance(video_info, dict) else 0
    except (ValueError, TypeError):
        width = 0
    
    if width >= 3840:
        quality = "4K UHD"
    elif width >= 1920:
        quality = "1080p Full HD"
    elif width >= 1280:
        quality = "720p HD"
    else:
        quality = "SD"
    
    # Translate synopsis to Arabic
    plot_ar = None
    try:
        from resources.lib import translator
        plot_ar = translator.translate_to_arabic(plot)
    except Exception as e:
        xbmc.log(f"[Xtream Codes] Translation failed: {e}", xbmc.LOGWARNING)
    
    # Build detailed message
    details = [f"[B]{title}[/B]"]
    
    if original_title and original_title != title:
        details.append(f"[I]Titre original: {original_title}[/I]")
    
    # Synopsis with Arabic translation
    details.append(f"\n[B]Synopsis:[/B]\n{plot}")
    
    if plot_ar and plot_ar != plot:
        details.append(f"\n[B]الملخص (بالعربية):[/B]\n{plot_ar}")
    
    details.append(f"\n[B]Informations:[/B]")
    details.append(f"Réalisateur: {director}")
    details.append(f"Acteurs: {actors}")
    details.append(f"Genre: {genre}")
    details.append(f"Pays: {country}")
    
    if rating > 0:
        details.append(f"Note: {rating}/10")
    
    details.append(f"Durée: {duration}")
    details.append(f"Date de sortie: {release_date}")
    
    # Technical info
    if width > 0:
        details.append(f"\n[B]Qualité:[/B]")
        details.append(f"Résolution: {width}x{video_info.get('height', 0)} ({quality})")
        
        if isinstance(video_info, dict):
            codec = video_info.get('codec_name', '').upper()
            if codec:
                details.append(f"Codec vidéo: {codec}")
        
        if isinstance(audio_info, dict):
            audio_codec = audio_info.get('codec_name', '').upper()
            channels = audio_info.get('channels', 0)
            if audio_codec:
                audio_str = f"Codec audio: {audio_codec}"
                if channels == 2:
                    audio_str += " Stéréo"
                elif channels > 2:
                    audio_str += f" {channels} canaux"
                details.append(audio_str)
        
        if bitrate > 0:
            details.append(f"Bitrate: {bitrate} Kbps")
    
    if tmdb_id:
        details.append(f"\n[B]TMDB ID:[/B] {tmdb_id}")
        details.append(f"Lien: https://www.themoviedb.org/movie/{tmdb_id}")
    
    # Display in text viewer
    xbmcgui.Dialog().textviewer(f"Détails - {title}", '\n'.join(details))
