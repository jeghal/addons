import sys
import os
import json
import mimetypes
from urllib.parse import urlencode
from typing import Dict, Any, List, Optional

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# Avoid circular dependency if history imports utils
# Verified: history.py does NOT import utils.py
from resources.lib import history

# ---------------------------
# GLOBAL INITIALIZATION
# ---------------------------

# Addon Userdata Path
userdata_path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.xtream_codes_iptv/')
if not os.path.exists(userdata_path):
    os.makedirs(userdata_path, exist_ok=True)

# File-based stash for passing data to monitor
STATE_FILE = os.path.join(userdata_path, 'playback_state.json')

# Globals passed by Kodi
try:
    if len(sys.argv) > 1:
        URL = sys.argv[0]
        HANDLE = int(sys.argv[1])
    else:
        # Fallback for testing or incorrect invocation
        URL = ""
        HANDLE = -1
except (IndexError, ValueError):
    URL = ""
    HANDLE = -1

def get_handle() -> int:
    return HANDLE

def get_url() -> str:
    return URL

# ---------------------------
# LOGGING AND NOTIFICATIONS
# ---------------------------

def log(message: str, level: int = xbmc.LOGINFO) -> None:
    """
    Centralized logging function with configurable levels.
    
    Args:
        message: Message to log
        level: Log level (xbmc.LOGDEBUG, xbmc.LOGINFO, xbmc.LOGWARNING, xbmc.LOGERROR)
    """
    xbmc.log(f"[Xtream Codes] {message}", level)

def notify(title: str, message: str, icon: str = xbmcgui.NOTIFICATION_INFO, display_time: int = 3000) -> None:
    """
    Affiche une notification dans Kodi et enregistre l'événement dans le log.
    
    Args:
        title: Title of notification
        message: Body of notification
        icon: Icon path or standard icon constant
        display_time: Duration in ms
    """
    xbmcgui.Dialog().notification(title, message, icon, display_time)
    log(f"Notification: {title} - {message}", xbmc.LOGINFO)

def mask_credentials(url: str, username: str = "", password: str = "") -> str:
    """
    Mask credentials in URL for safe logging.
    """
    masked_url = url
    if username:
        masked_url = masked_url.replace(username, "***")
    if password:
        masked_url = masked_url.replace(password, "***")
    return masked_url

# ---------------------------
# PLAYBACK STATE MANAGEMENT
# ---------------------------

def save_playback_state(data: Dict[str, Any]) -> None:
    """Saves playback metadata to a temporary file for the monitor."""
    try:
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        log(f"Playback state saved: {data}", xbmc.LOGDEBUG)
    except Exception as e:
        log(f"Error saving playback state: {e}", xbmc.LOGERROR)

# ---------------------------
# URL BUILDER AND VALIDATION
# ---------------------------

def build_url(query: Dict[str, Any]) -> str:
    """
    Construit l'URL interne pour Kodi avec les paramètres donnés.
    """
    return f"{URL}?{urlencode(query)}"

def validate_stream_url(stream_url: str) -> bool:
    """
    Validate that a stream URL is properly formatted.
    """
    if not stream_url:
        log("Stream URL is empty", xbmc.LOGWARNING)
        return False
    
    if not isinstance(stream_url, str):
        log(f"Stream URL is not a string: {type(stream_url)}", xbmc.LOGWARNING)
        return False
    
    if not stream_url.startswith(('http://', 'https://')):
        log(f"Stream URL does not start with http(s): {stream_url}", xbmc.LOGWARNING)
        return False
    
    return True

# ---------------------------
# HELPER FUNCTIONS FOR PARSING
# ---------------------------

def parse_year(value: Any) -> int:
    """Parse year from various formats (int, str, ISO date)."""
    if not value:
        return 0
    try:
        if isinstance(value, int):
            return value if 1900 <= value <= 2100 else 0
        if isinstance(value, str):
            value = value.strip()
            if '-' in value:
                year_str = value.split('-')[0]
                return int(year_str) if 1900 <= int(year_str) <= 2100 else 0
            year = int(value)
            return year if 1900 <= year <= 2100 else 0
    except (ValueError, TypeError, AttributeError):
        pass
    return 0

def parse_rating(value: Any) -> float:
    """Parse rating from various formats (float, int, str)."""
    if not value:
        return 0.0
    try:
        rating = float(value)
        return rating if 0.0 <= rating <= 10.0 else 0.0
    except (ValueError, TypeError):
        return 0.0

def parse_duration(value: Any) -> int:
    """Parse duration in seconds from various formats (int, str)."""
    if not value:
        return 0
    try:
        duration = int(value)
        return duration if duration > 0 else 0
    except (ValueError, TypeError):
        return 0

def parse_cast(value: Any) -> List[str]:
    """Parse cast list from comma-separated string."""
    if not value:
        return []
    if isinstance(value, str):
        return [actor.strip() for actor in value.split(',') if actor.strip()]
    return []

def safe_get_backdrop(backdrop_value: Any, default: str = "") -> str:
    """Safely extract backdrop URL from various formats (list, str, None)."""
    if not backdrop_value:
        return default
    if isinstance(backdrop_value, list):
        for item in backdrop_value:
            if item and isinstance(item, str) and item.startswith('http'):
                return item
        return default
    if isinstance(backdrop_value, str) and backdrop_value.startswith('http'):
        return backdrop_value
    return default

# ---------------------------
# MAIN PLAYBACK FUNCTION
# ---------------------------

def get_translated_plot(original_plot: str) -> str:
    """
    Translates plot to Arabic if available.
    Returns the original plot combined with translation if successful, 
    or just the original plot if translation fails/not needed.
    """
    if not original_plot or original_plot == "Aucun synopsis":
        return original_plot
        
    try:
        from resources.lib import translator
        plot_ar = translator.translate_to_arabic(original_plot)
        if plot_ar and plot_ar.strip() != original_plot.strip():
            return f"{original_plot}\n\n[B]AR:[/B] {plot_ar}"
    except Exception as e:
        log(f"Translation failed: {e}", xbmc.LOGWARNING)
    
    return original_plot

def _set_list_item_metadata(list_item: xbmcgui.ListItem, title: str, meta: Dict[str, Any]) -> None:
    """
    Sets video metadata on a ListItem, compatible with both Matrix/Nexus+ and Legacy methods.
    
    Args:
        list_item: The ListItem object to update
        title: The display title
        meta: Dictionary of metadata
    """
    list_item.setLabel(title)
    
    if not meta:
        return

    # Kodi Matrix/Nexus+ Way (InfoTag)
    if hasattr(list_item, 'getVideoInfoTag'):
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        
        # Simple fields
        if 'plot' in meta: info_tag.setPlot(meta['plot'])
        if 'year' in meta: info_tag.setYear(parse_year(meta['year']))
        if 'duration' in meta: info_tag.setDuration(parse_duration(meta['duration']))
        if 'rating' in meta: info_tag.setRating(parse_rating(meta['rating']))
        if 'mediatype' in meta: info_tag.setMediaType(meta['mediatype'])
        if 'premiered' in meta: info_tag.setPremiered(meta['premiered'])
        if 'tvshowtitle' in meta: info_tag.setTvShowTitle(meta['tvshowtitle'])
        if 'studio' in meta: info_tag.setStudios([meta['studio']])
        if 'country' in meta: info_tag.setCountries([meta['country']])
        
        # Tagline (API variations)
        if 'tagline' in meta: 
            if hasattr(info_tag, 'setTagLine'): info_tag.setTagLine(meta['tagline'])
            elif hasattr(info_tag, 'setTagline'): info_tag.setTagline(meta['tagline'])

        # Lists (Generic handling for string/list inputs)
        if 'genre' in meta:
            val = meta['genre']
            if isinstance(val, str):
                val = [x.strip() for x in val.split(',')]
            info_tag.setGenres(val)
            
        if 'director' in meta:
            val = meta['director']
            if isinstance(val, str):
                val = [x.strip() for x in val.split(',')]
            elif not isinstance(val, list):
                val = [str(val)]
            info_tag.setDirectors(val)
            
        if 'cast' in meta:
            val = meta['cast']
            actors = []
            if isinstance(val, str):
                val = [x.strip() for x in val.split(',')]
            
            if isinstance(val, list):
                for c in val:
                    if isinstance(c, str) and c:
                        if hasattr(xbmc, 'Actor'):
                            actors.append(xbmc.Actor(name=c))
                    elif isinstance(c, dict):
                        name = c.get('name', '')
                        if name and hasattr(xbmc, 'Actor'):
                            role = c.get('role', '')
                            thumb = c.get('thumbnail', '')
                            actors.append(xbmc.Actor(name=name, role=role, thumbnail=thumb))
            
            if actors:
                info_tag.setCast(actors)

    # Legacy / Universal Way (setInfo)
    # This is strictly required for some skins and older Kodi versions
    list_item.setInfo('video', meta)

def play_stream(stream_url: str, stream_type: str = "stream", title: str = "", stream_id: str = "", 
                icon: str = "", fanart: str = "", series_id: str = "", season: str = "", episode_num: str = "",
                meta: Optional[Dict[str, Any]] = None, resume_time: Any = 0) -> None:
    """
    Generic function to play any type of stream (live, movie, episode).
    Eliminates code duplication across play_channel, play_movie, play_episode.
    Records to watch history if title and stream_id are provided.
    
    Args:
        stream_url: URL of the stream to play
        stream_type: Type of stream ('live', 'movie', 'episode')
        title: Title of the content (for history)
        stream_id: ID of the content (for history)
        icon: Icon URL (for history)
        fanart: Fanart URL (for history)
        series_id: Series ID (for history deduplication)
        season: Season number (for history)
        episode_num: Episode number (for history)
        meta: Dictionary of metadata (plot, year, duration, etc.) for OSD/Subtitles
    """
    log(f"play_stream called - type={stream_type}, title='{title}', stream_id='{stream_id}', resume={resume_time}", xbmc.LOGINFO)
    
    if not validate_stream_url(stream_url):
        log(f"Invalid stream URL for {stream_type}: {stream_url}", xbmc.LOGWARNING)
        notify("Erreur", "URL de stream invalide", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    
    log(f"Playing {stream_type}: {stream_url}", xbmc.LOGDEBUG)
    
    # 1. Add to Watch History
    if title and stream_id:
        try:
            history.add_to_history(
                item_type=stream_type,
                item_id=stream_id,
                title=title,
                stream_url=stream_url,
                icon=icon,
                fanart=fanart,
                series_id=series_id,
                season=season,
                episode_num=episode_num
            )
            log(f"Added to history: {title} ({stream_type})", xbmc.LOGDEBUG)
        except Exception as e:
            log(f"Error adding to history: {e}", xbmc.LOGWARNING)
    
    # 2. Store Playback State for Monitor
    state_data = {
        'stream_id': str(stream_id),
        'stream_type': stream_type,
        'title': title
    }
    
    if stream_type == 'episode' and series_id and season and episode_num:
        state_data.update({
            'is_episode': True,
            'series_id': str(series_id),
            'season': int(season),
            'episode_num': int(episode_num),
            'series_title': meta.get('tvshowtitle', '') if meta else ''
        })
    else:
        state_data['is_episode'] = False

    save_playback_state(state_data)
    
    # 3. Create List Item
    list_item = xbmcgui.ListItem(path=stream_url)
    
    # 4. Set Metadata
    _set_list_item_metadata(list_item, title, meta if meta else {})

    # 5. Handle Resume
    if resume_time and float(resume_time) > 0:
        s_resume = str(resume_time)
        log(f"Setting StartOffset to {s_resume}", xbmc.LOGINFO)
        list_item.setProperty('StartOffset', s_resume)
        list_item.setProperty('ResumeTime', s_resume)

    # 6. Set Artwork
    art = {}
    if icon: art['icon'] = art['thumb'] = icon
    if fanart: art['fanart'] = fanart
    if art: list_item.setArt(art)

    # 7. MIME Type & Content Lookup
    mime_type, _ = mimetypes.guess_type(stream_url)
    if mime_type:
        list_item.setMimeType(mime_type)
        
    list_item.setProperty('IsPlayable', 'true')
    list_item.setContentLookup(False)
    
    # 8. Resolve Url
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
