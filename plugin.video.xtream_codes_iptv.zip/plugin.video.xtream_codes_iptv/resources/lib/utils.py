import sys
import xbmc
import xbmcgui
import xbmcplugin
import mimetypes
from urllib.parse import urlencode
from typing import Dict, Any, List, Optional

# Globals passed by Kodi
try:
    URL = sys.argv[0]
    HANDLE = int(sys.argv[1])
except (IndexError, ValueError):
    # Fallback for testing or incorrect invocation
    URL = ""
    HANDLE = -1

def get_handle() -> int:
    return HANDLE

def get_url() -> str:
    return URL

def notify(title: str, message: str, icon: str = xbmcgui.NOTIFICATION_INFO, display_time: int = 3000) -> None:
    """
    Affiche une notification dans Kodi et enregistre l'événement dans le log.
    """
    xbmcgui.Dialog().notification(title, message, icon, display_time)
    xbmc.log(f"[Xtream Codes] {title}: {message}", xbmc.LOGINFO)

def build_url(query: Dict[str, Any]) -> str:
    """
    Construit l'URL interne pour Kodi avec les paramètres donnés.
    """
    return f"{URL}?{urlencode(query)}"

# ---------------------------
# LOGGING AND SECURITY
# ---------------------------

def log(message: str, level: int = xbmc.LOGINFO) -> None:
    """
    Centralized logging function with configurable levels.
    
    Args:
        message: Message to log
        level: Log level (xbmc.LOGDEBUG, xbmc.LOGINFO, xbmc.LOGWARNING, xbmc.LOGERROR)
    
    Examples:
        log("Starting playback", xbmc.LOGINFO)
        log("Failed to fetch data", xbmc.LOGERROR)
    """
    xbmc.log(f"[Xtream Codes] {message}", level)

def mask_credentials(url: str, username: str = "", password: str = "") -> str:
    """
    Mask credentials in URL for safe logging.
    
    Args:
        url: URL potentially containing credentials
        username: Username to mask
        password: Password to mask
    
    Returns:
        URL with masked credentials
    
    Examples:
        mask_credentials("http://server/api?username=user&password=pass", "user", "pass")
        -> "http://server/api?username=***&password=***"
    """
    masked_url = url
    if username:
        masked_url = masked_url.replace(username, "***")
    if password:
        masked_url = masked_url.replace(password, "***")
    return masked_url

def validate_stream_url(stream_url: str) -> bool:
    """
    Validate that a stream URL is properly formatted.
    
    Args:
        stream_url: URL to validate
    
    Returns:
        True if valid, False otherwise
    
    Examples:
        validate_stream_url("http://server/stream.m3u8") -> True
        validate_stream_url("") -> False
        validate_stream_url("invalid") -> False
    """
    if not stream_url:
        log("Stream URL is empty", xbmc.LOGWARNING)
        return False
    
    if not isinstance(stream_url, str):
        log(f"Stream URL is not a string: {type(stream_url)}", xbmc.LOGWARNING)
        return False
    
    if not stream_url.startswith(('http://', 'https://')):
        log(f"Stream URL does not start with http(s): {stream_url}", xbmc.LOGWARNING)
        return False
    
    return True

# ---------------------------
# HELPER FUNCTIONS FOR PARSING
# ---------------------------

def parse_year(value: Any) -> int:
    """
    Parse year from various formats (int, str, ISO date).
    Returns int year or 0 if invalid.
    
    Examples:
        parse_year(2025) -> 2025
        parse_year("2025") -> 2025
        parse_year("2025-04-03") -> 2025
        parse_year("invalid") -> 0
    """
    if not value:
        return 0
    
    try:
        # If it's already an int
        if isinstance(value, int):
            return value if 1900 <= value <= 2100 else 0
        
        # If it's a string
        if isinstance(value, str):
            value = value.strip()
            # Try ISO date format (YYYY-MM-DD)
            if '-' in value:
                year_str = value.split('-')[0]
                year = int(year_str)
                return year if 1900 <= year <= 2100 else 0
            # Try direct int conversion
            year = int(value)
            return year if 1900 <= year <= 2100 else 0
    except (ValueError, TypeError, AttributeError):
        pass
    
    return 0

def parse_rating(value: Any) -> float:
    """
    Parse rating from various formats (float, int, str).
    Returns float rating or 0.0 if invalid.
    
    Examples:
        parse_rating(7.5) -> 7.5
        parse_rating("8.2") -> 8.2
        parse_rating("invalid") -> 0.0
    """
    if not value:
        return 0.0
    
    try:
        rating = float(value)
        # Validate rating is in reasonable range (0-10)
        return rating if 0.0 <= rating <= 10.0 else 0.0
    except (ValueError, TypeError):
        return 0.0

def parse_duration(value: Any) -> int:
    """
    Parse duration in seconds from various formats (int, str).
    Returns int seconds or 0 if invalid.
    
    Examples:
        parse_duration(3600) -> 3600
        parse_duration("7200") -> 7200
        parse_duration("invalid") -> 0
    """
    if not value:
        return 0
    
    try:
        duration = int(value)
        return duration if duration > 0 else 0
    except (ValueError, TypeError):
        return 0

def parse_cast(value: Any) -> List[str]:
    """
    Parse cast list from comma-separated string.
    Returns list of actor names or empty list.
    
    Examples:
        parse_cast("Actor1, Actor2, Actor3") -> ["Actor1", "Actor2", "Actor3"]
        parse_cast("") -> []
        parse_cast(None) -> []
    """
    if not value:
        return []
    
    if isinstance(value, str):
        # Split by comma and strip whitespace
        actors = [actor.strip() for actor in value.split(',') if actor.strip()]
        return actors
    
    return []

def safe_get_backdrop(backdrop_value: Any, default: str = "") -> str:
    """
    Safely extract backdrop URL from various formats (list, str, None).
    Returns first valid HTTP URL or default.
    
    Examples:
        safe_get_backdrop(["http://url1.jpg", "http://url2.jpg"]) -> "http://url1.jpg"
        safe_get_backdrop("http://url.jpg") -> "http://url.jpg"
        safe_get_backdrop(None, "default.jpg") -> "default.jpg"
    """
    if not backdrop_value:
        return default
    
    # If it's a list, take the first valid URL
    if isinstance(backdrop_value, list):
        for item in backdrop_value:
            if item and isinstance(item, str) and item.startswith('http'):
                return item
        return default
    
    # If it's a string, validate it's a URL
    if isinstance(backdrop_value, str):
        if backdrop_value.startswith('http'):
            return backdrop_value
    
    return default


def play_stream(stream_url: str, stream_type: str = "stream", title: str = "", stream_id: str = "", icon: str = "", fanart: str = "") -> None:
    """
    Generic function to play any type of stream (live, movie, episode).
    Eliminates code duplication across play_channel, play_movie, play_episode.
    Records to watch history if title and stream_id are provided.
    
    Args:
        stream_url: URL of the stream to play
        stream_type: Type of stream ('live', 'movie', 'episode')
        title: Title of the content (for history)
        stream_id: ID of the content (for history)
        icon: Icon URL (for history)
        fanart: Fanart URL (for history)
    
    Examples:
        play_stream("http://server/live/123.ts", "live", "Channel Name", "123")
        play_stream("http://server/movie/456.mp4", "movie", "Movie Title", "456")
    """
    log(f"play_stream called - type={stream_type}, title='{title}', stream_id='{stream_id}'", xbmc.LOGINFO)
    
    if not validate_stream_url(stream_url):
        log(f"Invalid stream URL for {stream_type}: {stream_url}", xbmc.LOGWARNING)
        notify("Erreur", "URL de stream invalide", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    
    log(f"Playing {stream_type}: {stream_url}", xbmc.LOGDEBUG)
    
    # Add to history if we have the required info
    if title and stream_id:
        try:
            from resources.lib import history
            history.add_to_history(
                item_type=stream_type,
                item_id=stream_id,
                title=title,
                stream_url=stream_url,
                icon=icon,
                fanart=fanart
            )
            log(f"Added to history: {title} ({stream_type})", xbmc.LOGDEBUG)
        except Exception as e:
            log(f"Error adding to history: {e}", xbmc.LOGWARNING)
    
    list_item = xbmcgui.ListItem(path=stream_url)
    
    # Optimisation: Définir le type MIME pour éviter que Kodi ne scanne le fichier
    mime_type, _ = mimetypes.guess_type(stream_url)
    if mime_type:
        list_item.setMimeType(mime_type)
        
    list_item.setProperty('IsPlayable', 'true')
    list_item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

