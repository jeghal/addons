#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Service pour maintenir le PlaybackMonitor actif en permanence
Ce service tourne en arrière-plan pendant toute la session Kodi
"""
import xbmc
import xbmcaddon

# Import du monitor
from resources.lib import playback_monitor

if __name__ == '__main__':
    addon = xbmcaddon.Addon()
    monitor = xbmc.Monitor()
    
    xbmc.log("[Xtream Codes Service] Starting playback monitor service", xbmc.LOGINFO)
    
    # Créer et garder le monitor actif
    playback_mon = playback_monitor.get_monitor()
    xbmc.log("[Xtream Codes Service] PlaybackMonitor is now active and listening", xbmc.LOGINFO)
    
    # Boucle principale - garde le service actif
    while not monitor.abortRequested():
        # Attendre 1 seconde ou jusqu'à ce que Kodi demande l'arrêt
        if monitor.waitForAbort(1):
            break
    
    xbmc.log("[Xtream Codes Service] Playback monitor service stopped", xbmc.LOGINFO)
