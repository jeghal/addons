#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de test pour l'API Xtream Codes
Teste tous les endpoints et affiche les réponses pour améliorer l'intégration.
"""

import json
import sys
import os
import getpass
from urllib.request import urlopen, Request, URLError, HTTPError
from datetime import datetime
from typing import Optional, Dict, Any

# Fix encoding for Windows console
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Configuration
SERVER_URL = "http://cf.cdn-24.net"
USERNAME = "77b0c2964"
PASSWORD = ""  # Sera demandé au démarrage

TIMEOUT = 15

class Colors:
    """Codes couleur ANSI pour l'affichage terminal"""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header(text: str):
    """Affiche un en-tête formaté"""
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*80}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{text.center(80)}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{'='*80}{Colors.ENDC}\n")

def print_success(text: str):
    """Affiche un message de succès"""
    print(f"{Colors.OKGREEN}[OK] {text}{Colors.ENDC}")

def print_error(text: str):
    """Affiche un message d'erreur"""
    print(f"{Colors.FAIL}[ERREUR] {text}{Colors.ENDC}")

def print_info(text: str):
    """Affiche un message d'information"""
    print(f"{Colors.OKCYAN}[INFO] {text}{Colors.ENDC}")

def print_warning(text: str):
    """Affiche un avertissement"""
    print(f"{Colors.WARNING}[ATTENTION] {text}{Colors.ENDC}")

def fetch_endpoint(endpoint: str, description: str) -> Optional[Dict[str, Any]]:
    """
    Teste un endpoint de l'API Xtream Codes
    
    Args:
        endpoint: L'endpoint à tester (ex: "action=get_live_categories")
        description: Description de l'endpoint
    
    Returns:
        Les données JSON ou None en cas d'erreur
    """
    url = f"{SERVER_URL}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    
    print(f"\n{Colors.BOLD}Test: {description}{Colors.ENDC}")
    print(f"Endpoint: {endpoint}")
    
    try:
        headers = {'User-Agent': 'Xtream Codes API Tester'}
        req = Request(url, headers=headers)
        
        start_time = datetime.now()
        with urlopen(req, timeout=TIMEOUT) as response:
            data = response.read().decode('utf-8')
            elapsed = (datetime.now() - start_time).total_seconds()
            
            result = json.loads(data)
            
            # Affichage des statistiques
            print_success(f"Succès (temps: {elapsed:.2f}s)")
            
            # Analyse du résultat
            if isinstance(result, list):
                print_info(f"Type: Liste avec {len(result)} éléments")
                if len(result) > 0:
                    print_info(f"Premier élément: {list(result[0].keys()) if isinstance(result[0], dict) else type(result[0])}")
            elif isinstance(result, dict):
                print_info(f"Type: Dictionnaire avec {len(result)} clés")
                print_info(f"Clés: {list(result.keys())}")
            else:
                print_warning(f"Type inattendu: {type(result)}")
            
            return result
            
    except HTTPError as e:
        print_error(f"Erreur HTTP {e.code}: {e.reason}")
        return None
    except URLError as e:
        print_error(f"Erreur de connexion: {e.reason}")
        return None
    except json.JSONDecodeError as e:
        print_error(f"Erreur JSON: {e}")
        return None
    except Exception as e:
        print_error(f"Erreur inattendue: {e}")
        return None

def save_response(filename: str, data: Any):
    """Sauvegarde une réponse dans un fichier JSON"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print_success(f"Réponse sauvegardée: {filename}")
    except Exception as e:
        print_error(f"Erreur lors de la sauvegarde: {e}")

def test_all_endpoints():
    """Teste tous les endpoints de l'API Xtream Codes"""
    
    global PASSWORD
    
    print_header("TEST DE L'API XTREAM CODES")
    
    print(f"Serveur: {SERVER_URL}")
    print(f"Utilisateur: {USERNAME}")
    
    # Demander le mot de passe si non configuré
    if not PASSWORD:
        print_info("Le mot de passe n'est pas configuré dans le script.")
        try:
            PASSWORD = getpass.getpass("Entrez le mot de passe: ")
        except Exception as e:
            print_error(f"Erreur lors de la saisie du mot de passe: {e}")
            return
    
    if not PASSWORD:
        print_error("ERREUR: Le mot de passe est requis!")
        return
    
    print(f"Mot de passe: {'*' * len(PASSWORD)}")
    
    # Liste des endpoints à tester
    endpoints = [
        # Informations utilisateur
        ("", "Informations utilisateur et serveur"),
        
        # Live TV
        ("action=get_live_categories", "Catégories Live TV"),
        ("action=get_live_streams", "Toutes les chaînes Live"),
        
        # VOD (Films)
        ("action=get_vod_categories", "Catégories VOD"),
        ("action=get_vod_streams", "Tous les films VOD"),
        
        # Séries
        ("action=get_series_categories", "Catégories Séries"),
        ("action=get_series", "Toutes les séries"),
        
        # EPG
        ("action=get_simple_data_table&stream_id=1", "EPG pour une chaîne (exemple)"),
        ("action=get_short_epg&stream_id=1&limit=10", "EPG court (exemple)"),
    ]
    
    results = {}
    
    for endpoint, description in endpoints:
        result = fetch_endpoint(endpoint, description)
        if result:
            results[description] = result
            
            # Sauvegarde des réponses importantes
            if "Catégories" in description or "Informations" in description:
                safe_filename = description.replace(" ", "_").replace("/", "_").lower()
                save_response(f"test_response_{safe_filename}.json", result)
    
    # Résumé
    print_header("RÉSUMÉ DES TESTS")
    
    total = len(endpoints)
    success = len(results)
    failed = total - success
    
    print(f"Total d'endpoints testés: {total}")
    print_success(f"Succès: {success}")
    if failed > 0:
        print_error(f"Échecs: {failed}")
    
    # Analyse détaillée des résultats
    print_header("ANALYSE DÉTAILLÉE")
    
    # Informations utilisateur
    if "Informations utilisateur et serveur" in results:
        user_info = results["Informations utilisateur et serveur"]
        print(f"\n{Colors.BOLD}Informations du compte:{Colors.ENDC}")
        
        if 'user_info' in user_info:
            ui = user_info['user_info']
            print(f"  - Statut: {ui.get('status', 'N/A')}")
            print(f"  - Connexions actives: {ui.get('active_cons', 'N/A')}")
            print(f"  - Connexions max: {ui.get('max_connections', 'N/A')}")
            
            exp_date = ui.get('exp_date')
            if exp_date and exp_date != '0':
                try:
                    exp = datetime.fromtimestamp(int(exp_date)).strftime('%Y-%m-%d %H:%M:%S')
                    print(f"  - Expiration: {exp}")
                except:
                    print(f"  - Expiration: {exp_date}")
            else:
                print(f"  - Expiration: Illimité")
        
        if 'server_info' in user_info:
            si = user_info['server_info']
            print(f"\n{Colors.BOLD}Informations du serveur:{Colors.ENDC}")
            print(f"  - URL: {si.get('url', 'N/A')}")
            print(f"  - Port: {si.get('port', 'N/A')}")
            print(f"  - Protocole: {si.get('server_protocol', 'N/A')}")
            print(f"  - Fuseau horaire: {si.get('timezone', 'N/A')}")
    
    # Statistiques Live TV
    if "Catégories Live TV" in results:
        categories = results["Catégories Live TV"]
        print(f"\n{Colors.BOLD}Live TV:{Colors.ENDC}")
        print(f"  - Nombre de catégories: {len(categories)}")
        if len(categories) > 0:
            print(f"  - Exemples: {', '.join([c.get('category_name', 'N/A') for c in categories[:5]])}")
    
    if "Toutes les chaînes Live" in results:
        channels = results["Toutes les chaînes Live"]
        print(f"  - Nombre total de chaînes: {len(channels)}")
        if len(channels) > 0:
            print(f"  - Exemples: {', '.join([c.get('name', 'N/A') for c in channels[:5]])}")
    
    # Statistiques VOD
    if "Catégories VOD" in results:
        categories = results["Catégories VOD"]
        print(f"\n{Colors.BOLD}VOD (Films):{Colors.ENDC}")
        print(f"  - Nombre de catégories: {len(categories)}")
        if len(categories) > 0:
            print(f"  - Exemples: {', '.join([c.get('category_name', 'N/A') for c in categories[:5]])}")
    
    if "Tous les films VOD" in results:
        movies = results["Tous les films VOD"]
        print(f"  - Nombre total de films: {len(movies)}")
        if len(movies) > 0:
            print(f"  - Exemples: {', '.join([m.get('name', 'N/A') for m in movies[:5]])}")
    
    # Statistiques Séries
    if "Catégories Séries" in results:
        categories = results["Catégories Séries"]
        print(f"\n{Colors.BOLD}Séries TV:{Colors.ENDC}")
        print(f"  - Nombre de catégories: {len(categories)}")
        if len(categories) > 0:
            print(f"  - Exemples: {', '.join([c.get('category_name', 'N/A') for c in categories[:5]])}")
    
    if "Toutes les séries" in results:
        series = results["Toutes les séries"]
        print(f"  - Nombre total de séries: {len(series)}")
        if len(series) > 0:
            print(f"  - Exemples: {', '.join([s.get('name', 'N/A') for s in series[:5]])}")
    
    # Recommandations
    print_header("RECOMMANDATIONS POUR L'ADDON")
    
    print(f"{Colors.BOLD}1. Gestion du cache:{Colors.ENDC}")
    print("   - Privilégier le cache pour les catégories (changent rarement)")
    print("   - Rafraîchir régulièrement les listes de contenus")
    print("   - EPG à rafraîchir fréquemment (toutes les heures)")
    
    print(f"\n{Colors.BOLD}2. Optimisations:{Colors.ENDC}")
    print("   - Charger les catégories en priorité")
    print("   - Lazy loading pour les listes complètes")
    print("   - Pagination si plus de 1000 éléments")
    
    print(f"\n{Colors.BOLD}3. Gestion d'erreurs:{Colors.ENDC}")
    print("   - Vérifier le statut du compte avant chaque session")
    print("   - Gérer les timeouts (certains endpoints peuvent être lents)")
    print("   - Retry logic pour les erreurs réseau")
    
    print(f"\n{Colors.BOLD}4. Métadonnées:{Colors.ENDC}")
    print("   - Utiliser get_vod_info pour les détails complets des films")
    print("   - Utiliser get_series_info pour les détails des séries")
    print("   - Parser correctement les dates et durées")

if __name__ == "__main__":
    try:
        test_all_endpoints()
    except KeyboardInterrupt:
        print_warning("\n\nTest interrompu par l'utilisateur")
        sys.exit(0)
    except Exception as e:
        print_error(f"\n\nErreur fatale: {e}")
        sys.exit(1)
