#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de test automatique avec credentials
"""

import json
import sys
import os
from urllib.request import urlopen, Request, URLError, HTTPError
from datetime import datetime

# Fix encoding for Windows console
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Configuration avec credentials fournis
SERVER_URL = "http://amigo8k.me:80"
USERNAME = "77b0c2964"
PASSWORD = "aa0b37c54"
TIMEOUT = 15

def test_endpoint(endpoint, description):
    """Teste un endpoint"""
    url = f"{SERVER_URL}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    
    print(f"\n{'='*80}")
    print(f"Test: {description}")
    print(f"{'='*80}")
    
    try:
        req = Request(url, headers={'User-Agent': 'Xtream API Tester'})
        start = datetime.now()
        
        with urlopen(req, timeout=TIMEOUT) as response:
            data = response.read().decode('utf-8')
            elapsed = (datetime.now() - start).total_seconds()
            
            result = json.loads(data)
            
            print(f"[OK] Succès (temps: {elapsed:.2f}s)")
            
            # Analyse
            if isinstance(result, list):
                print(f"[INFO] Type: Liste - {len(result)} éléments")
                if len(result) > 0 and isinstance(result[0], dict):
                    print(f"[INFO] Clés du premier élément: {list(result[0].keys())}")
                    print(f"\n[INFO] Premier élément:")
                    print(json.dumps(result[0], indent=2, ensure_ascii=False))
            elif isinstance(result, dict):
                print(f"[INFO] Type: Dictionnaire - {len(result)} clés")
                print(f"[INFO] Clés: {list(result.keys())}")
                print(f"\n[INFO] Contenu:")
                print(json.dumps(result, indent=2, ensure_ascii=False)[:2000])
            
            # Sauvegarde
            filename = f"api_response_{description.replace(' ', '_').lower()}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            print(f"\n[OK] Sauvegardé: {filename}")
            
            return result
            
    except Exception as e:
        print(f"[ERREUR] {e}")
        return None

def main():
    """Fonction principale"""
    print("="*80)
    print("TEST COMPLET DE L'API XTREAM CODES")
    print("="*80)
    print(f"\nServeur: {SERVER_URL}")
    print(f"Utilisateur: {USERNAME}")
    print(f"Mot de passe: {'*' * len(PASSWORD)}")
    
    # Liste complète des endpoints
    endpoints = [
        ("", "01_User_Info"),
        ("action=get_live_categories", "02_Live_Categories"),
        ("action=get_live_streams", "03_Live_All_Channels"),
        ("action=get_vod_categories", "04_VOD_Categories"),
        ("action=get_vod_streams", "05_VOD_All_Movies"),
        ("action=get_series_categories", "06_Series_Categories"),
        ("action=get_series", "07_Series_All"),
    ]
    
    results = {}
    for endpoint, desc in endpoints:
        result = test_endpoint(endpoint, desc)
        if result:
            results[desc] = result
    
    # Analyse finale
    print(f"\n{'='*80}")
    print("ANALYSE FINALE")
    print(f"{'='*80}")
    
    print(f"\n[INFO] Tests réussis: {len(results)}/{len(endpoints)}")
    
    # Statistiques détaillées
    if "01_User_Info" in results:
        ui = results["01_User_Info"].get('user_info', {})
        si = results["01_User_Info"].get('server_info', {})
        print(f"\n[COMPTE]")
        print(f"  Statut: {ui.get('status', 'N/A')}")
        print(f"  Connexions: {ui.get('active_cons', 'N/A')}/{ui.get('max_connections', 'N/A')}")
        exp = ui.get('exp_date')
        if exp and exp != '0':
            try:
                exp_date = datetime.fromtimestamp(int(exp)).strftime('%Y-%m-%d %H:%M:%S')
                print(f"  Expiration: {exp_date}")
            except:
                print(f"  Expiration: {exp}")
        print(f"\n[SERVEUR]")
        print(f"  URL: {si.get('url', 'N/A')}:{si.get('port', 'N/A')}")
        print(f"  Protocole: {si.get('server_protocol', 'N/A')}")
    
    if "02_Live_Categories" in results:
        cats = results["02_Live_Categories"]
        print(f"\n[LIVE TV]")
        print(f"  Catégories: {len(cats)}")
        if cats:
            print(f"  Exemples: {', '.join([c.get('category_name', 'N/A') for c in cats[:5]])}")
    
    if "03_Live_All_Channels" in results:
        channels = results["03_Live_All_Channels"]
        print(f"  Total chaînes: {len(channels)}")
    
    if "04_VOD_Categories" in results:
        cats = results["04_VOD_Categories"]
        print(f"\n[VOD]")
        print(f"  Catégories: {len(cats)}")
        if cats:
            print(f"  Exemples: {', '.join([c.get('category_name', 'N/A') for c in cats[:5]])}")
    
    if "05_VOD_All_Movies" in results:
        movies = results["05_VOD_All_Movies"]
        print(f"  Total films: {len(movies)}")
    
    if "06_Series_Categories" in results:
        cats = results["06_Series_Categories"]
        print(f"\n[SERIES]")
        print(f"  Catégories: {len(cats)}")
        if cats:
            print(f"  Exemples: {', '.join([c.get('category_name', 'N/A') for c in cats[:5]])}")
    
    if "07_Series_All" in results:
        series = results["07_Series_All"]
        print(f"  Total séries: {len(series)}")
    
    print(f"\n[OK] Tous les fichiers JSON ont été sauvegardés!")
    print(f"[INFO] Vous pouvez maintenant analyser les réponses pour améliorer l'addon.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n[ERREUR] {e}")
        import traceback
        traceback.print_exc()
