#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de test simplifié pour l'API Xtream Codes
Utilise les credentials de settings.xml
"""

import json
import sys
import os
import xml.etree.ElementTree as ET
from urllib.request import urlopen, Request, URLError, HTTPError
from datetime import datetime

# Fix encoding for Windows console
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

def load_settings():
    """Charge les paramètres depuis settings.xml"""
    settings_file = os.path.join(os.path.dirname(__file__), 'resources', 'settings.xml')
    
    try:
        tree = ET.parse(settings_file)
        root = tree.getroot()
        
        server_url = None
        username = None
        password = None
        
        for setting in root.findall('.//setting'):
            setting_id = setting.get('id')
            default = setting.get('default', '')
            
            if setting_id == 'server_url':
                server_url = default
            elif setting_id == 'username':
                username = default
            elif setting_id == 'password':
                password = default
        
        return server_url, username, password
    except Exception as e:
        print(f"[ERREUR] Impossible de lire settings.xml: {e}")
        return None, None, None

def test_endpoint(server_url, username, password, endpoint, description):
    """Teste un endpoint"""
    url = f"{server_url}/player_api.php?username={username}&password={password}&{endpoint}"
    
    print(f"\n{'='*80}")
    print(f"Test: {description}")
    print(f"Endpoint: {endpoint}")
    print(f"{'='*80}")
    
    try:
        req = Request(url, headers={'User-Agent': 'Xtream API Tester'})
        start = datetime.now()
        
        with urlopen(req, timeout=15) as response:
            data = response.read().decode('utf-8')
            elapsed = (datetime.now() - start).total_seconds()
            
            result = json.loads(data)
            
            print(f"[OK] Succès (temps: {elapsed:.2f}s)")
            
            # Affichage du résultat
            if isinstance(result, list):
                print(f"[INFO] Type: Liste - {len(result)} éléments")
                if len(result) > 0:
                    print(f"\n[INFO] Exemple du premier élément:")
                    print(json.dumps(result[0], indent=2, ensure_ascii=False)[:500] + "...")
            elif isinstance(result, dict):
                print(f"[INFO] Type: Dictionnaire - {len(result)} clés")
                print(f"[INFO] Clés: {list(result.keys())}")
                print(f"\n[INFO] Contenu:")
                print(json.dumps(result, indent=2, ensure_ascii=False)[:1000] + "...")
            
            # Sauvegarde
            filename = f"response_{description.replace(' ', '_').lower()}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            print(f"[OK] Sauvegardé: {filename}")
            
            return result
            
    except HTTPError as e:
        print(f"[ERREUR] HTTP {e.code}: {e.reason}")
    except URLError as e:
        print(f"[ERREUR] Connexion: {e.reason}")
    except json.JSONDecodeError as e:
        print(f"[ERREUR] JSON: {e}")
    except Exception as e:
        print(f"[ERREUR] {e}")
    
    return None

def main():
    """Fonction principale"""
    print("="*80)
    print("TEST RAPIDE DE L'API XTREAM CODES")
    print("="*80)
    
    # Charger les paramètres
    server_url, username, password = load_settings()
    
    if not all([server_url, username]):
        print("[ERREUR] Impossible de charger les paramètres depuis settings.xml")
        return
    
    print(f"\nServeur: {server_url}")
    print(f"Utilisateur: {username}")
    
    # Demander le mot de passe si vide
    if not password:
        import getpass
        password = getpass.getpass("Entrez le mot de passe: ")
    
    if not password:
        print("[ERREUR] Mot de passe requis!")
        return
    
    print(f"Mot de passe: {'*' * len(password)}")
    
    # Tests rapides
    endpoints = [
        ("", "User Info"),
        ("action=get_live_categories", "Live Categories"),
        ("action=get_vod_categories", "VOD Categories"),
        ("action=get_series_categories", "Series Categories"),
    ]
    
    results = {}
    for endpoint, desc in endpoints:
        result = test_endpoint(server_url, username, password, endpoint, desc)
        if result:
            results[desc] = result
    
    # Résumé
    print(f"\n{'='*80}")
    print("RÉSUMÉ")
    print(f"{'='*80}")
    print(f"Tests réussis: {len(results)}/{len(endpoints)}")
    
    # Statistiques
    if "User Info" in results:
        ui = results["User Info"].get('user_info', {})
        print(f"\n[INFO] Compte:")
        print(f"  - Statut: {ui.get('status', 'N/A')}")
        print(f"  - Connexions: {ui.get('active_cons', 'N/A')}/{ui.get('max_connections', 'N/A')}")
    
    if "Live Categories" in results:
        print(f"\n[INFO] Live TV: {len(results['Live Categories'])} catégories")
    
    if "VOD Categories" in results:
        print(f"[INFO] VOD: {len(results['VOD Categories'])} catégories")
    
    if "Series Categories" in results:
        print(f"[INFO] Séries: {len(results['Series Categories'])} catégories")
    
    print(f"\n[OK] Tests terminés!")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[ATTENTION] Interrompu par l'utilisateur")
    except Exception as e:
        print(f"\n[ERREUR] Erreur fatale: {e}")
        import traceback
        traceback.print_exc()
