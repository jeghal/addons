import unittest
from unittest.mock import patch, MagicMock
import sys
import os
import socket
from urllib.error import URLError, HTTPError

# Mock Kodi modules before importing api
sys.modules['xbmc'] = MagicMock()
sys.modules['xbmcaddon'] = MagicMock()
sys.modules['xbmcgui'] = MagicMock()
sys.modules['xbmcplugin'] = MagicMock()
sys.modules['xbmcvfs'] = MagicMock()

# Setup paths
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

import api

class TestConnectionHandling(unittest.TestCase):
    
    def setUp(self):
        # Reset cache
        api._data_cache = api.PersistentCache()
        api._data_cache.get = MagicMock(return_value=None)
        api._data_cache.set = MagicMock()
        
        # Mock global settings variables that were read at import time
        api.USERNAME = "test_user"
        api.PASSWORD = "test_pass"
        api.SERVER_URL = "http://fake-server.com"
        
        # Reset retry logic delays to speed up tests
        self.original_sleep = api.time.sleep
        api.time.sleep = MagicMock()
        
    def tearDown(self):
        api.time.sleep = self.original_sleep

    @patch('api.urlopen')
    @patch('api.notify')
    @patch('api.log')
    def test_dns_error(self, mock_log, mock_notify, mock_urlopen):
        """Test specific handling of socket.gaierror (DNS error)"""
        # Configure mock to raise socket.gaierror
        mock_urlopen.side_effect = socket.gaierror("Name or service not known")
        
        # Call fetch_data
        result = api.fetch_data("action=test", use_cache=False, max_retries=1)
        
        # Assertions
        self.assertIsNone(result)
        # Check that specific DNS error was logged
        log_calls = [args[0] for args, _ in mock_log.call_args_list]
        self.assertTrue(any("DNS Error" in call for call in log_calls), "DNS Error not logged properly")
        # Check user notification
        mock_notify.assert_called_with("Erreur de connexion", "Serveur introuvable. Vérifiez l'URL.", api.xbmcgui.NOTIFICATION_ERROR)

    @patch('api.urlopen')
    @patch('api.notify')
    @patch('api.log')
    def test_connection_refused(self, mock_log, mock_notify, mock_urlopen):
        """Test handling of ConnectionRefusedError"""
        mock_urlopen.side_effect = ConnectionRefusedError("Connection refused")
        
        result = api.fetch_data("action=test", use_cache=False, max_retries=1)
        
        self.assertIsNone(result)
        mock_notify.assert_called_with("Erreur de connexion", "Connexion refusée par le serveur.", api.xbmcgui.NOTIFICATION_ERROR)

    @patch('api.urlopen')
    @patch('api.notify')
    @patch('api.log')
    def test_timeout_error(self, mock_log, mock_notify, mock_urlopen):
        """Test handling of TimeoutError"""
        mock_urlopen.side_effect = TimeoutError("Timed out")
        
        result = api.fetch_data("action=test", use_cache=False, max_retries=1)
        
        self.assertIsNone(result)
        mock_notify.assert_called_with("Timeout", "Le serveur est trop lent à répondre.", api.xbmcgui.NOTIFICATION_ERROR)

    @patch('api.urlopen')
    @patch('api.notify')
    @patch('api.log')
    def test_urllib_wrapped_dns_error(self, mock_log, mock_notify, mock_urlopen):
        """Test catching a DNS error wrapped inside a URLError"""
        # URLError often wraps the underlying socket error
        mock_urlopen.side_effect = URLError(socket.gaierror("Name or service not known"))
        
        result = api.fetch_data("action=test", use_cache=False, max_retries=1)
        
        self.assertIsNone(result)
        mock_notify.assert_called_with("Erreur de connexion", "Serveur introuvable. Vérifiez l'URL.", api.xbmcgui.NOTIFICATION_ERROR)

if __name__ == '__main__':
    unittest.main()
