#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test de l'endpoint get_vod_info pour obtenir les détails d'un film
"""

import json
import sys
import ssl
from urllib.request import urlopen, Request

# Fix encoding for Windows console
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Désactiver la vérification SSL pour les certificats auto-signés
ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

# Configuration
SERVER_URL = "http://amigo8k.me:80"
USERNAME = "77b0c2964"
PASSWORD = "aa0b37c54"
TIMEOUT = 15

# ID du premier film de la liste (Wrong Package - 2025)
MOVIE_ID = "1024302"

def test_vod_info(movie_id):
    """Teste l'endpoint get_vod_info"""
    endpoint = f"action=get_vod_info&vod_id={movie_id}"
    url = f"{SERVER_URL}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    
    print("="*80)
    print(f"Test: get_vod_info pour le film ID {movie_id}")
    print("="*80)
    
    try:
        req = Request(url, headers={'User-Agent': 'Xtream API Tester'})
        
        with urlopen(req, timeout=TIMEOUT, context=ssl_context) as response:
            data = response.read().decode('utf-8')
            result = json.loads(data)
            
            print("\n[OK] Succès!")
            
            # Afficher la structure
            print(f"\n[INFO] Clés principales: {list(result.keys())}")
            
            # Afficher les détails
            print("\n" + "="*80)
            print("DÉTAILS DU FILM")
            print("="*80)
            
            # Info générale
            if 'info' in result:
                info = result['info']
                print("\n[INFO] Informations générales:")
                for key, value in info.items():
                    if isinstance(value, str) and len(value) > 100:
                        print(f"  {key}: {value[:100]}...")
                    else:
                        print(f"  {key}: {value}")
            
            # Movie data
            if 'movie_data' in result:
                movie_data = result['movie_data']
                print("\n[MOVIE_DATA] Données du film:")
                for key, value in movie_data.items():
                    print(f"  {key}: {value}")
            
            # Sauvegarder
            filename = f"api_response_vod_info_{movie_id}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            print(f"\n[OK] Sauvegardé: {filename}")
            
            # Afficher le JSON complet
            print("\n" + "="*80)
            print("JSON COMPLET")
            print("="*80)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
            return result
            
    except Exception as e:
        print(f"[ERREUR] {e}")
        import traceback
        traceback.print_exc()
        return None

def main():
    """Fonction principale"""
    print("="*80)
    print("TEST DE L'ENDPOINT get_vod_info")
    print("="*80)
    print(f"\nServeur: {SERVER_URL}")
    print(f"Film ID: {MOVIE_ID}")
    
    result = test_vod_info(MOVIE_ID)
    
    if result:
        print("\n" + "="*80)
        print("ANALYSE")
        print("="*80)
        
        # Analyser les champs disponibles
        if 'info' in result:
            info = result['info']
            print("\n[CHAMPS DISPONIBLES dans 'info']:")
            print(f"  - Nombre de champs: {len(info)}")
            print(f"  - Champs: {', '.join(info.keys())}")
            
            # Vérifier les champs importants
            important_fields = ['name', 'plot', 'cast', 'director', 'genre', 'rating', 'duration', 'releasedate', 'backdrop_path', 'tmdb_id']
            print("\n[CHAMPS IMPORTANTS]:")
            for field in important_fields:
                value = info.get(field, 'N/A')
                if isinstance(value, str) and len(value) > 50:
                    print(f"  {field}: {value[:50]}... (tronqué)")
                else:
                    print(f"  {field}: {value}")
        
        print("\n[OK] Test terminé!")
    else:
        print("\n[ERREUR] Le test a échoué")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n[ERREUR] {e}")
        import traceback
        traceback.print_exc()
