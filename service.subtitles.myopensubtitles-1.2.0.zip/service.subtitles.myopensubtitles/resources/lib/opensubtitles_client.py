import hashlib
import json
import socket
import urllib.error
import urllib.request
import urllib.parse
import xbmc
import time
import xbmcvfs

class OpenSubtitlesClient:
    BASE_URL = "https://api.opensubtitles.com/api/v1"

    def __init__(self, api_key, user_agent):
        self.api_key = api_key
        self.user_agent = user_agent
        self.username = None
        self.password = None
        self.token = None
        self.last_error = None
        self.headers = {
            'Api-Key': self.api_key,
            'User-Agent': self.user_agent,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        # Try to load cached token
        self._load_cached_token()

    def _get_cache_path(self):
        return xbmcvfs.translatePath("special://temp/os_token_%s.json" % hashlib.sha256((str(self.api_key) + "\0" + str(self.username or "")).encode("utf-8")).hexdigest()[:20])

    def _load_cached_token(self):
        try:
            cache_path = self._get_cache_path()
            if xbmcvfs.exists(cache_path):
                with xbmcvfs.File(cache_path) as f:
                    data = json.loads(f.read())
                    # Check expiry (24h = 86400s)
                    if data.get('expiry', 0) > time.time() and isinstance(data.get('token'), str) and data.get('token'):
                        self.token = data.get('token')
                        self.headers['Authorization'] = f"Bearer {self.token}"
                        xbmc.log("OpenSubtitles: Loaded valid token from cache", xbmc.LOGDEBUG)
                        return
                    else:
                        xbmc.log("OpenSubtitles: Cached token expired", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"OpenSubtitles Cache Load Error: {e}", xbmc.LOGWARNING)

    def _save_cached_token(self, token):
        try:
            cache_path = self._get_cache_path()
            data = {
                'token': token,
                'expiry': time.time() + 86400 # 24 hours
            }
            with xbmcvfs.File(cache_path, 'w') as f:
                f.write(json.dumps(data))
            xbmc.log("OpenSubtitles: Token saved to cache", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"OpenSubtitles Cache Save Error: {e}", xbmc.LOGWARNING)

    def set_credentials(self, username, password):
        self.username = username
        self.password = password
        self.token = None
        self.headers.pop("Authorization", None)
        self._load_cached_token()

    def _clear_token(self):
        self.token = None
        self.headers.pop('Authorization', None)
        try:
            xbmcvfs.delete(self._get_cache_path())
        except Exception:
            pass

    def _request_json(self, path, payload=None, refresh=True):
        self.last_error = None
        for attempt in range(2 if refresh else 1):
            request = urllib.request.Request(
                self.BASE_URL + path,
                data=json.dumps(payload).encode('utf-8') if payload is not None else None,
                headers=self.headers, method='POST' if payload is not None else 'GET')
            try:
                with urllib.request.urlopen(request, timeout=12) as response:
                    body = response.read(2 * 1024 * 1024 + 1)
                if len(body) > 2 * 1024 * 1024:
                    raise ValueError('Response too large')
                result = json.loads(body)
                if not isinstance(result, dict):
                    raise ValueError('Invalid response')
                self.last_error = None
                return result
            except urllib.error.HTTPError as error:
                code = error.code
                error.close()
                if code == 401 and refresh and attempt == 0 and self.username and self.password:
                    self._clear_token()
                    if self.login():
                        continue
                self.last_error = 'http_' + str(code)
            except (socket.timeout, TimeoutError):
                self.last_error = 'timeout'
            except (ValueError, UnicodeError):
                self.last_error = 'invalid_response'
            except Exception:
                self.last_error = 'network_error'
            return None
        return None

    def login(self):
        if not self.username or not self.password:
            self.last_error = 'credentials_missing'
            return False
        result = self._request_json('/login', {'username': self.username, 'password': self.password}, refresh=False)
        token = result.get('token') if result else None
        if not isinstance(token, str) or not token:
            self.last_error = self.last_error or 'invalid_response'
            return False
        self.token = token
        self.headers['Authorization'] = 'Bearer ' + token
        self._save_cached_token(token)
        return True

    def search_subtitles(self, query=None, imdb_id=None, tmdb_id=None, season=None, episode=None, languages='en'):
        params = {'languages': languages}
        normalized = str(imdb_id or '')
        if normalized.lower().startswith('tt'):
            normalized = normalized[2:]
        if normalized.isascii() and normalized.isdigit():
            params['imdb_id'] = int(normalized)
        if tmdb_id:
            params['tmdb_id'] = tmdb_id
        if query and not (params.get('imdb_id') or params.get('tmdb_id')):
            params['query'] = query
        if season is not None:
            params['season_number'] = season
        if episode is not None:
            params['episode_number'] = episode
        result = self._request_json('/subtitles?' + urllib.parse.urlencode(params))
        return result if result is not None else {'data': [], 'error': self.last_error}

    def download_subtitle(self, file_id):
        try:
            value = int(file_id)
            if value <= 0:
                raise ValueError('Invalid file id')
        except (TypeError, ValueError, OverflowError):
            self.last_error = 'invalid_file_id'
            return None
        if not self.token and self.username and self.password and not self.login():
            return None
        result = self._request_json('/download', {'file_id': value})
        if result is None:
            return None
        return {key: result.get(key) for key in ('link', 'file_name', 'requests', 'remaining')}
