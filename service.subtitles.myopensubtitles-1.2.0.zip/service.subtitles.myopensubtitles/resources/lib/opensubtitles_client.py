import hashlib
import json
import urllib.error
import urllib.request
import urllib.parse
import xbmc
import time
import xbmcvfs

class OpenSubtitlesClient:
    BASE_URL = "https://api.opensubtitles.com/api/v1"

    def __init__(self, api_key, user_agent):
        self.api_key = api_key
        self.user_agent = user_agent
        self.username = None
        self.password = None
        self.token = None
        self.headers = {
            'Api-Key': self.api_key,
            'User-Agent': self.user_agent,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        # Try to load cached token
        self._load_cached_token()

    def _get_cache_path(self):
        return xbmcvfs.translatePath("special://temp/os_token_%s.json" % hashlib.sha256((str(self.api_key) + "\0" + str(self.username or "")).encode("utf-8")).hexdigest()[:20])

    def _load_cached_token(self):
        try:
            cache_path = self._get_cache_path()
            if xbmcvfs.exists(cache_path):
                with xbmcvfs.File(cache_path) as f:
                    data = json.loads(f.read())
                    # Check expiry (24h = 86400s)
                    if data.get('expiry', 0) > time.time() and isinstance(data.get('token'), str) and data.get('token'):
                        self.token = data.get('token')
                        self.headers['Authorization'] = f"Bearer {self.token}"
                        xbmc.log("OpenSubtitles: Loaded valid token from cache", xbmc.LOGDEBUG)
                        return
                    else:
                        xbmc.log("OpenSubtitles: Cached token expired", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"OpenSubtitles Cache Load Error: {e}", xbmc.LOGWARNING)

    def _save_cached_token(self, token):
        try:
            cache_path = self._get_cache_path()
            data = {
                'token': token,
                'expiry': time.time() + 86400 # 24 hours
            }
            with xbmcvfs.File(cache_path, 'w') as f:
                f.write(json.dumps(data))
            xbmc.log("OpenSubtitles: Token saved to cache", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"OpenSubtitles Cache Save Error: {e}", xbmc.LOGWARNING)

    def set_credentials(self, username, password):
        self.username = username
        self.password = password
        self.token = None
        self.headers.pop("Authorization", None)
        self._load_cached_token()

    def login(self):
        """
        Login to get a bearer token.
        """
        if not self.username or not self.password:
            return False
            
        url = f"{self.BASE_URL}/login"
        payload = {
            "username": self.username,
            "password": self.password
        }
        
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=self.headers, method='POST')
        
        try:
            with urllib.request.urlopen(req, timeout=12) as response:
                result = json.loads(response.read())
                self.token = result.get('token')
                if self.token:
                    # Update headers with token
                    self.headers['Authorization'] = f"Bearer {self.token}"
                    self._save_cached_token(self.token)
                    return True
        except Exception as e:
            xbmc.log(f"OpenSubtitles Login Error: {e}", xbmc.LOGERROR)
        
        return False

    def search_subtitles(self, query=None, imdb_id=None, tmdb_id=None, season=None, episode=None, languages='en'):
        """
        Search for subtitles. 
        Note: You need to implement the actual API call logic here correctly 
        according to OpenSubtitles.com API v1 documentation.
        """
        
        # Auto-login if needed and possible
        if not self.token and self.username and self.password:
            self.login()

        url = f"{self.BASE_URL}/subtitles"
        params = {
            'languages': languages,
        }
        
        if imdb_id:
            
            normalized_imdb = str(imdb_id).removeprefix('tt')
            if normalized_imdb.isdigit():
                params['imdb_id'] = int(normalized_imdb)
        if tmdb_id:
            params['tmdb_id'] = tmdb_id
        if query and not (params.get('imdb_id') or params.get('tmdb_id')):
            params['query'] = query
        if season:
            params['season_number'] = season
        if episode:
            params['episode_number'] = episode

        # Construct query string
        query_string = urllib.parse.urlencode(params)
        full_url = f"{url}?{query_string}"
        
        xbmc.log("OpenSubtitles: searching subtitles", xbmc.LOGDEBUG)

        req = urllib.request.Request(full_url, headers=self.headers)
        try:
            with urllib.request.urlopen(req, timeout=12) as response:
                return json.loads(response.read())
        except urllib.error.HTTPError as e:
            if e.code == 401 and self.username and self.password:
                self.token = None
                self.headers.pop('Authorization', None)
                if self.login():
                    try:
                        with urllib.request.urlopen(urllib.request.Request(full_url, headers=self.headers), timeout=12) as response:
                            return json.loads(response.read())
                    except Exception:
                        pass
            xbmc.log('OpenSubtitles search HTTP error %s' % e.code, xbmc.LOGWARNING)
            return {'data': []}
        except Exception as e:
            xbmc.log(f"OpenSubtitles API Error: {e}", xbmc.LOGERROR)
            return {'data': []} 

    def download_subtitle(self, file_id):
        """
        Get download link for a subtitle file.
        """
        if not file_id:
            return None
            
        if not self.token:
            # Try to login if we have credentials
            if self.username and self.password:
                 if not self.login():
                     xbmc.log("Service: Login failed before download", xbmc.LOGERROR)
                     return None
            else:
                 # Attempt download without token (may fail or use IP quota)
                 pass

        url = f"{self.BASE_URL}/download"
        payload = {
            "file_id": int(file_id)
        }
        
        # Ensure headers include token if available
        # (Already handled in login() by updating self.headers, but just in case)
        
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=self.headers, method='POST')
        
        try:
            with urllib.request.urlopen(req, timeout=12) as response:
                result = json.loads(response.read())
                return {
                    'link': result.get('link'),
                    'file_name': result.get('file_name'),
                    'requests': result.get('requests'),
                    'remaining': result.get('remaining')
                }
        except Exception as e:
            xbmc.log(f"OpenSubtitles Download API Error: {e}", xbmc.LOGERROR)
            return None
