import sys
import os
import urllib.parse
import re
from functools import wraps
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Import providers
from resources.lib.opensubtitles_client import OpenSubtitlesClient
from resources.lib.subdl_client import SubDLClient

# Get the addon handle and settings
__addon__ = xbmcaddon.Addon()

def get_params(param_string):
    param_string = param_string.replace('?', '')
    return dict(urllib.parse.parse_qsl(param_string))

def clean_search_title(title, year=None):
    title = str(title or '').strip()
    # Provider language tags are not part of the film/series title.
    title = re.sub(r'^(?:\s*\|[^|]{1,16}\|\s*)+', '', title)
    title = re.sub(r'^\[(?:FR|EN|AR|US|UK|BR|IT|DE|ES|NL|PT|MULTI|VOSTFR)\]\s*', '', title, flags=re.I)
    suffix = re.search(r'\s*\((\d{4})\)\s*$', title)
    if suffix and str(year or '') == suffix.group(1):
        title = title[:suffix.start()]
    return title.strip()


def _provider_error(provider, code):
    messages = {'http_401': 'Session refusée. Vérifiez votre compte.',
                'http_403': 'Accès refusé. Vérifiez les autorisations.',
                'http_429': 'Limite de requêtes atteinte. Réessayez plus tard.',
                'timeout': 'Le délai de connexion est dépassé.',
                'invalid_response': 'Réponse du service illisible.'}
    message = messages.get(str(code), 'Service indisponible. Réessayez plus tard.')
    xbmcgui.Dialog().notification(provider, message, xbmcgui.NOTIFICATION_ERROR, 5000)


def _download_url(file_id, language, season, episode):
    params = {'action': 'download', 'file_id': file_id, 'lang': language}
    for key, value in [('season', season), ('episode', episode)]:
        if value is not None:
            params[key] = value
    return 'plugin://' + __addon__.getAddonInfo('id') + '/?' + urllib.parse.urlencode(params)


def _directory_request(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        finally:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
    return wrapped


@_directory_request
def search(item):
    """
    Search for subtitles based on the item dict provided by Kodi.
    """
    # Load settings dynamically
    enable_opensubtitles = __addon__.getSetting('enable_opensubtitles') == 'true'
    enable_subdl = __addon__.getSetting('enable_subdl') == 'true'
    languages = __addon__.getSetting('languages')

    all_results = []
    
    # Extract info from item
    title = item.get('tvshowtitle') or item.get('originaltitle') or item.get('title')
    year = item.get('year')
    title = clean_search_title(title, year)
    imdb_id = item.get('imdb_id')
    tmdb_id = item.get('tmdb_id')
    season = item.get('season')
    episode = item.get('episode')
    
    # Kodi providers sometimes put a TMDb numeric identifier in IMDBNumber.
    # Never send a numeric value to an IMDb-specific API parameter.
    imdb_id = str(imdb_id or '').strip()
    imdb_id = imdb_id.lower() if re.fullmatch(r'tt\d{5,12}', imdb_id, re.I) else None
    tmdb_id = str(tmdb_id or '').strip()
    tmdb_id = str(int(tmdb_id)) if tmdb_id.isdigit() and int(tmdb_id) > 0 else None
    if str(season if season is not None else '').isdigit() and str(episode if episode is not None else '').isdigit():
        season, episode = int(season), int(episode)
    else:
        season, episode = None, None

    # VALIDATION FIX: If IMDB ID matches TMDB ID, it's likely a Kodi fallback error.
    if imdb_id and tmdb_id and str(imdb_id) == str(tmdb_id):
        xbmc.log(f"Service: Ignored invalid IMDb ID {imdb_id} (matches TMDb ID)", xbmc.LOGINFO)
        imdb_id = None
    
    # --- 1. OpenSubtitles Search ---
    if enable_opensubtitles:
        try:
            api_key = __addon__.getSetting('api_key')
            user_agent = __addon__.getSetting('user_agent')
            username = __addon__.getSetting('username')
            password = __addon__.getSetting('password')
            
            client_os = OpenSubtitlesClient(api_key, user_agent)
            if username and password:
                client_os.set_credentials(username, password)
            
            results_os = client_os.search_subtitles(
                query=title,
                imdb_id=imdb_id,
                tmdb_id=tmdb_id,
                season=season,
                episode=episode,
                languages=languages
            )
            
            if title and (imdb_id or tmdb_id) and not (results_os or {}).get('data') and not (results_os or {}).get('error'):
                xbmc.log('Service: OpenSubtitles ID search empty; retrying by title', xbmc.LOGINFO)
                results_os = client_os.search_subtitles(
                    query=title, imdb_id=None, tmdb_id=None,
                    season=season, episode=episode, languages=languages)

            if (results_os or {}).get('error'):
                _provider_error('OpenSubtitles', results_os['error'])

            if results_os and 'data' in results_os:
                for sub in results_os.get('data') or []:
                    if not isinstance(sub, dict):
                        continue
                    sub['provider_source'] = 'opensubtitles'
                    all_results.append(sub)
        except Exception as e:
            xbmc.log(f"Service: OpenSubtitles search error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("OpenSubtitles", "Search Error", xbmcgui.NOTIFICATION_ERROR, 3000)

    # --- 2. SubDL Search ---
    if enable_subdl:
        try:
            subdl_key = __addon__.getSetting('subdl_api_key')
            if subdl_key:
                client_subdl = SubDLClient(subdl_key)
                results_subdl = client_subdl.search_subtitles(
                    title=title,
                    year=year,
                    imdb_id=imdb_id,
                    tmdb_id=tmdb_id,
                    season=season,
                    episode=episode,
                    languages=languages
                )
                # Some Kodi streams expose IDs that SubDL cannot resolve. Retry
                # using the series title only when the ID search finds nothing.
                if isinstance(results_subdl, dict) and not results_subdl.get('subtitles') and title and (imdb_id or tmdb_id) and not results_subdl.get('error'):
                    xbmc.log('Service: SubDL ID search empty; retrying by title', xbmc.LOGINFO)
                    results_subdl = client_subdl.search_subtitles(
                        title=title, year=year, imdb_id=None, tmdb_id=None,
                        season=season, episode=episode, languages=languages
                    )
                if isinstance(results_subdl, dict) and results_subdl.get('error'):
                    _provider_error('SubDL', results_subdl['error'])
                if isinstance(results_subdl, dict):
                    xbmc.log('Service: SubDL response status=%s, subtitles=%s, results=%s, error=%s' % (
                        results_subdl.get('status'),
                        len(results_subdl.get('subtitles') or []),
                        len(results_subdl.get('results') or []),
                        bool(results_subdl.get('error'))), xbmc.LOGINFO)
                # SubDL subtitle entries belong to `subtitles`. `results` may
                # contain film matches, not downloadable subtitles.
                data_subdl = results_subdl.get('subtitles', []) if isinstance(results_subdl, dict) else (results_subdl if isinstance(results_subdl, list) else [])
                if not isinstance(data_subdl, list):
                    data_subdl = []
                for sub in data_subdl:
                    if not isinstance(sub, dict):
                        continue
                    link = sub.get('url') or sub.get('full_link') or sub.get('link')
                    if not isinstance(link, str) or not link.strip():
                        continue
                    sub['provider_source'] = 'subdl'
                    all_results.append(sub)
            else:
                xbmc.log("Service: SubDL enabled but no API Key set.", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"Service: SubDL search error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("SubDL", "Search Error", xbmcgui.NOTIFICATION_ERROR, 3000)

    # One selectable result per distinct OpenSubtitles file.
    expanded, seen = [], set()
    for sub in all_results:
        if sub.get('provider_source') != 'opensubtitles':
            expanded.append(sub)
            continue
        attrs = sub.get('attributes') or {}
        if not isinstance(attrs, dict):
            continue
        for file_info in attrs.get('files') or []:
            if not isinstance(file_info, dict):
                continue
            file_id = file_info.get('file_id')
            if not str(file_id or '').isdigit() or int(file_id) <= 0:
                continue
            identity = (str(file_id), str(attrs.get('language') or ''))
            if identity in seen:
                continue
            seen.add(identity)
            mapped = dict(sub)
            mapped['attributes'] = dict(attrs, files=[file_info])
            expanded.append(mapped)
    all_results = expanded

    # --- Process & Display Results ---
    for sub in all_results:
        try:
            provider = sub.get('provider_source')
            
            if provider == 'opensubtitles':
                # OpenSubtitles Mapping
                attrs = sub.get('attributes', {})
                files = attrs.get('files', [])
                if not files:
                    continue
                
                file_info = files[0]
                file_id = file_info.get('file_id') # standard ID
                file_name = file_info.get('file_name', 'Unknown')
                language = attrs.get('language', 'Unknown')
                release = attrs.get('release', 'Unknown')
                ratings = attrs.get('ratings', 0)
                is_hi = attrs.get('hearing_impaired', False)
                
                lang_code = language.upper() if language else 'UNK'
                details = f"[OS] {release} — {file_name}"
                if is_hi: details += " [HI]"
                try:
                    valid_rating = float(ratings)
                except (ValueError, TypeError):
                    valid_rating = 0
                if 0 < valid_rating <= 10: details += f" ★{valid_rating:.1f}"

                list_item = xbmcgui.ListItem(label=lang_code, label2=details)
                # Use modern InfoTagVideo API instead of deprecated setInfo()
                tag = list_item.getVideoInfoTag()
                tag.setTitle(file_name)
                if 0 < valid_rating <= 10:
                    tag.setRating(valid_rating)
                list_item.setProperty('sync', 'false')
                if is_hi: list_item.setProperty('hearing_impaired', 'true')
                
                url = _download_url(file_id, language, season, episode)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
            
            elif provider == 'subdl':
                # SubDL Mapping
                # Adjust based on likely API fields: 'name', 'url', 'language', 'rating'
                file_name = sub.get('name', sub.get('release_name', 'Unknown'))
                language = sub.get('lang', sub.get('language', 'Unknown'))
                # 'url' might be the download link or page. usage of client logic needed.
                download_link = sub.get('url') or sub.get('full_link') or sub.get('link')
                
                rating = str(sub.get('rating', '0'))
                
                if download_link:
                    import base64
                    encoded_link = base64.urlsafe_b64encode(download_link.encode()).decode()
                    file_id = f"subdl_{encoded_link}"
                    
                    lang_code = language[:2].upper() if language else 'DL'
                    details = f"[SubDL] {file_name} ★{rating}"
                    
                    list_item = xbmcgui.ListItem(label=lang_code, label2=details)
                    # Use modern InfoTagVideo API instead of deprecated setInfo()
                    tag = list_item.getVideoInfoTag()
                    tag.setTitle(file_name)
                    try:
                        numeric_rating = float(rating)
                        if 0 < numeric_rating <= 10:
                            tag.setRating(numeric_rating)
                    except (ValueError, TypeError):
                        pass
                    list_item.setProperty('sync', 'false')
                    
                    url = _download_url(file_id, language, season, episode)
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

        except Exception as e:
            xbmc.log(f"Service: Error creating list item for {provider}: {e}", xbmc.LOGERROR)


def safe_subtitle_name(filename, lang=None):
    # Never trust remote archive entries or API-provided filenames.
    filename = str(filename or 'subtitle.srt').replace('\\', '/').split('/')[-1]
    stem, ext = os.path.splitext(filename)
    stem = re.sub(r'[^\w. -]', '_', stem, flags=re.UNICODE).strip(' .')[:110] or 'subtitle'
    language = re.sub(r'[^a-zA-Z0-9_-]', '', str(lang or ''))[:12]
    ext = ext.lower() if ext.lower() in ('.srt', '.ass', '.ssa', '.vtt', '.sub') else '.srt'
    if language and not stem.lower().endswith('.' + language.lower()):
        stem += '.' + language
    return stem + ext


def _episode_number(value):
    value = str(value if value is not None else '')
    return int(value) if value.isascii() and value.isdigit() else None


def select_archive_entry(entries, season=None, episode=None, lang=None):
    season, episode = _episode_number(season), _episode_number(episode)
    candidates = list(entries)
    if not candidates:
        return None
    if season is not None and episode is not None:
        patterns = [r'(?i)(?<![a-z0-9])s0*%de0*%d(?![0-9])' % (season, episode),
                    r'(?i)(?<![0-9])0*%dx0*%d(?![0-9])' % (season, episode)]
        exact = [entry for entry in candidates if any(re.search(pattern, entry.filename) for pattern in patterns)]
        if len(exact) == 1:
            return exact[0]
        if exact:
            candidates = exact
        elif len(candidates) == 1 and not re.search(r'(?i)s[0-9]+e[0-9]+|[0-9]+x[0-9]+', candidates[0].filename):
            return candidates[0]
    elif len(candidates) == 1:
        return candidates[0]
    candidates.sort(key=lambda entry: (not entry.filename.lower().endswith('.srt'), entry.filename.lower()))
    choice = xbmcgui.Dialog().select('Choisir le fichier de sous-titres', [entry.filename for entry in candidates])
    return candidates[choice] if 0 <= choice < len(candidates) else None


@_directory_request
def download(file_id, lang=None, season=None, episode=None):
    provider = 'SubDL' if str(file_id).startswith('subdl_') else 'OpenSubtitles'
    try:
        if provider == 'SubDL':
            import base64
            link = base64.urlsafe_b64decode(str(file_id)[6:]).decode('utf-8')
            client = SubDLClient(__addon__.getSetting('subdl_api_key'))
            info = client.download_subtitle(link)
            if not info:
                _provider_error(provider, 'network_error')
                return
            content, filename = info.get('content'), info.get('file_name') or 'subtitle.zip'
            if filename.lower().endswith('.zip') or (content and content.startswith(b'PK')):
                import io, zipfile
                with zipfile.ZipFile(io.BytesIO(content)) as archive:
                    if len(archive.infolist()) > 1000:
                        raise ValueError('Too many archive members')
                    entries = [entry for entry in archive.infolist() if not entry.is_dir()
                               and entry.filename.lower().endswith(('.srt', '.ass', '.ssa', '.vtt', '.sub'))
                               and 0 < entry.file_size <= 5 * 1024 * 1024]
                    if not entries:
                        raise ValueError('No supported subtitle')
                    selected = select_archive_entry(entries, season, episode, lang)
                    if selected is None:
                        return
                    filename = selected.filename
                    with archive.open(selected) as member:
                        content = member.read(5 * 1024 * 1024 + 1)
        else:
            client = OpenSubtitlesClient(__addon__.getSetting('api_key'), __addon__.getSetting('user_agent'))
            username, password = __addon__.getSetting('username'), __addon__.getSetting('password')
            if username and password:
                client.set_credentials(username, password)
            info = client.download_subtitle(file_id)
            if not info or not info.get('link'):
                _provider_error(provider, client.last_error or 'invalid_response')
                return
            filename = info.get('file_name') or 'subtitle.srt'
            import urllib.request
            parsed = urllib.parse.urlsplit(info['link'])
            if parsed.scheme != 'https' or not parsed.hostname:
                raise ValueError('Invalid download link')
            request = urllib.request.Request(info['link'], headers={'User-Agent': __addon__.getSetting('user_agent')})
            with urllib.request.urlopen(request, timeout=12) as response:
                content = response.read(5 * 1024 * 1024 + 1)
        if not isinstance(content, bytes) or not content or len(content) > 5 * 1024 * 1024:
            raise ValueError('Invalid subtitle size')
        profile = xbmcvfs.translatePath('special://profile/')
        os.makedirs(profile, exist_ok=True)
        import uuid
        filename = uuid.uuid4().hex[:8] + '_' + safe_subtitle_name(filename, lang)
        with open(os.path.join(profile, filename), 'wb') as output:
            output.write(content)
        path = 'special://profile/' + filename
        item = xbmcgui.ListItem(label=filename)
        item.setPath(path)
        item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=path, listitem=item, isFolder=False)
    except Exception as error:
        xbmc.log('Subtitle download failed: ' + type(error).__name__, xbmc.LOGWARNING)
        _provider_error(provider, 'invalid_response')


if __name__ == '__main__':
    # Parse params
    params = {}
    if len(sys.argv) > 2:
        try:
            params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
        except Exception as e:
            xbmc.log(f"Service: Error parsing params: {e}", xbmc.LOGERROR)

    action = params.get('action')
    xbmc.log(f"Service: Action='{action}', Params={params}", xbmc.LOGINFO)

    if action == 'search':
        item = {}
        item['title'] = xbmc.getInfoLabel("VideoPlayer.Title")
        item['originaltitle'] = xbmc.getInfoLabel("VideoPlayer.OriginalTitle")
        item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season'] = xbmc.getInfoLabel("VideoPlayer.Season")
        item['episode'] = xbmc.getInfoLabel("VideoPlayer.Episode")
        item['tvshowtitle'] = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        
        item['imdb_id'] = xbmc.getInfoLabel("VideoPlayer.UniqueId(imdb)")
        if not item['imdb_id']:
            item['imdb_id'] = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
            
        item['tmdb_id'] = xbmc.getInfoLabel("VideoPlayer.UniqueId(tmdb)")
        
        xbmc.log(f"Service Search: Title='{item['title']}', IMDB='{item['imdb_id']}', TMDB='{item['tmdb_id']}'", xbmc.LOGINFO)
        search(item)

    elif action == 'manualsearch':
        item = {}
        item['title'] = params.get('searchstring')
        item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season'] = xbmc.getInfoLabel("VideoPlayer.Season")
        item['episode'] = xbmc.getInfoLabel("VideoPlayer.Episode")
        item['tvshowtitle'] = params.get('searchstring') or xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        xbmc.log(f"Service Manual Search: Query='{item['title']}'", xbmc.LOGINFO)
        search(item)

    elif action == 'download':
        file_id = params.get('file_id')
        lang = params.get('lang')
        download(file_id, lang, params.get('season'), params.get('episode'))
