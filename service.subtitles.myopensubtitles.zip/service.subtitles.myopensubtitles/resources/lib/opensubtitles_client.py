import json
import urllib.request
import urllib.parse
import xbmc

class OpenSubtitlesClient:
    BASE_URL = "https://api.opensubtitles.com/api/v1"

    def __init__(self, api_key, user_agent):
        self.api_key = api_key
        self.user_agent = user_agent
        self.username = None
        self.password = None
        self.token = None
        self.headers = {
            'Api-Key': self.api_key,
            'User-Agent': self.user_agent,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

    def set_credentials(self, username, password):
        self.username = username
        self.password = password

    def login(self):
        """
        Login to get a bearer token.
        """
        if not self.username or not self.password:
            return False
            
        url = f"{self.BASE_URL}/login"
        payload = {
            "username": self.username,
            "password": self.password
        }
        
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=self.headers, method='POST')
        
        try:
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read())
                self.token = result.get('token')
                if self.token:
                    # Update headers with token
                    self.headers['Authorization'] = f"Bearer {self.token}"
                    return True
        except Exception as e:
            xbmc.log(f"OpenSubtitles Login Error: {e}", xbmc.LOGERROR)
        
        return False

    def search_subtitles(self, query=None, imdb_id=None, tmdb_id=None, season=None, episode=None, languages='en'):
        """
        Search for subtitles. 
        Note: You need to implement the actual API call logic here correctly 
        according to OpenSubtitles.com API v1 documentation.
        """
        url = f"{self.BASE_URL}/subtitles"
        params = {
            'languages': languages,
        }
        
        if imdb_id:
            params['imdb_id'] = int(imdb_id.replace('tt', ''))
        if tmdb_id:
            params['tmdb_id'] = tmdb_id
        if query and not (imdb_id or tmdb_id):
            params['query'] = query
        if season:
            params['season_number'] = season
        if episode:
            params['episode_number'] = episode

        # Construct query string
        query_string = urllib.parse.urlencode(params)
        full_url = f"{url}?{query_string}"
        
        xbmc.log(f"OpenSubtitles Search URL: {full_url}", xbmc.LOGINFO)

        req = urllib.request.Request(full_url, headers=self.headers)
        try:
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read())
        except Exception as e:
            xbmc.log(f"OpenSubtitles API Error: {e}", xbmc.LOGERROR)
            return {'data': []} 

    def download_subtitle(self, file_id):
        """
        Get download link for a subtitle file.
        """
        if not file_id:
            return None
            
        if not self.token:
            # Try to login if we have credentials
            if self.username and self.password:
                 if not self.login():
                     xbmc.log("Service: Login failed before download", xbmc.LOGERROR)
                     return None
            else:
                 # Attempt download without token (may fail or use IP quota)
                 pass

        url = f"{self.BASE_URL}/download"
        payload = {
            "file_id": int(file_id)
        }
        
        # Ensure headers include token if available
        # (Already handled in login() by updating self.headers, but just in case)
        
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=self.headers, method='POST')
        
        try:
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read())
                return {
                    'link': result.get('link'),
                    'file_name': result.get('file_name'),
                    'requests': result.get('requests'),
                    'remaining': result.get('remaining')
                }
        except Exception as e:
            xbmc.log(f"OpenSubtitles Download API Error: {e}", xbmc.LOGERROR)
            return None
