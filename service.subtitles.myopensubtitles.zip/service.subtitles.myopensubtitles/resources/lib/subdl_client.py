import json
import urllib.request
import urllib.parse
import xbmc

class SubDLClient:
    BASE_URL = "https://api.subdl.com/api/v1"

    def __init__(self, api_key):
        self.api_key = api_key
        # SubDL typically expects the API key in the query parameters or Authorization header.
        # Based on research, it's often a Bearer token or simply an api_key param.
        # We'll assume standard Bearer token for modern APIs or try param if that fails.
        # Let's try to find a standard way. Many sources say 'api_key' param.
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json'
        }

    def search_subtitles(self, title, year=None, imdb_id=None, tmdb_id=None, season=None, episode=None, languages='en'):
        """
        Search for subtitles on SubDL.
        """
        if not self.api_key:
            return {'results': []}

        # Endpoint derived from community knowledge: /subtitles
        url = f"{self.BASE_URL}/subtitles"
        
        params = {
            'api_key': self.api_key,
            'subs_per_page': 30,
            'languages': languages
        }

        # SubDL often prefers IMDB ID if available
        if imdb_id:
            # Ensure format tt1234567
            if not str(imdb_id).startswith('tt'):
                 params['imdb_id'] = f"tt{imdb_id}"
            else:
                 params['imdb_id'] = imdb_id
        elif tmdb_id:
            params['tmdb_id'] = tmdb_id
        elif title:
            params['film_name'] = title
        
        if year:
             params['year'] = year

        # TV Show specifics
        if season and episode:
            params['season_number'] = season
            params['episode_number'] = episode
            # If searching by name for TV shows, the param might be different or handled by 'film_name' + s/e
            # but usually ID is best.

        query_string = urllib.parse.urlencode(params)
        full_url = f"{url}?{query_string}"
        
        xbmc.log(f"SubDL Search URL: {full_url.replace(self.api_key, 'OBFUSCATED')}", xbmc.LOGINFO)

        try:
            req = urllib.request.Request(full_url, headers=self.headers)
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read())
        except Exception as e:
            xbmc.log(f"SubDL API Error: {e}", xbmc.LOGERROR)
            return {'results': [], 'status': False}

    def download_subtitle(self, full_link):
        """
        Download the subtitle. 
        SubDL search results usually provide a direct download link or a redirect link.
        If the link requires the API key appended, we handle it here.
        """
        if not full_link:
            return None
            
        # Sometimes the link provided in search results already includes what is needed.
        # But if it's a protected endpoint, we might need to append the API key if not present.
        
        target_url = full_link
        # Handle relative URLs (common with SubDL API)
        if target_url.startswith('/'):
            target_url = f"https://dl.subdl.com{target_url}"
        
        if self.api_key and 'api_key=' not in target_url:
             if '?' in target_url:
                  target_url += f"&api_key={self.api_key}"
             else:
                  target_url += f"?api_key={self.api_key}"

        try:
            req = urllib.request.Request(target_url, headers=self.headers)
            with urllib.request.urlopen(req) as response:
                content = response.read()
                # Try to get filename from headers
                content_disposition = response.getheader('Content-Disposition')
                file_name = "subdl_subtitle.zip" # Default fallback
                
                if content_disposition:
                    # Parse filename="example.zip"
                    import re
                    fname = re.findall('filename="(.+)"', content_disposition)
                    if fname:
                        file_name = fname[0]
                
                return {
                    'content': content,
                    'file_name': file_name
                }
        except Exception as e:
            xbmc.log(f"SubDL Download Error: {e}", xbmc.LOGERROR)
            return None
