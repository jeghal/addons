import sys
import os
import urllib.parse
import re
import re
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Import providers
from resources.lib.opensubtitles_client import OpenSubtitlesClient
from resources.lib.subdl_client import SubDLClient

# Get the addon handle and settings
__addon__ = xbmcaddon.Addon()

def get_params(param_string):
    param_string = param_string.replace('?', '')
    return dict(urllib.parse.parse_qsl(param_string))

def search(item):
    """
    Search for subtitles based on the item dict provided by Kodi.
    """
    # Load settings dynamically
    enable_opensubtitles = __addon__.getSetting('enable_opensubtitles') == 'true'
    enable_subdl = __addon__.getSetting('enable_subdl') == 'true'
    languages = __addon__.getSetting('languages')

    all_results = []
    
    # Extract info from item
    title = item.get('tvshowtitle') or item.get('originaltitle') or item.get('title')
    year = item.get('year')
    imdb_id = item.get('imdb_id')
    tmdb_id = item.get('tmdb_id')
    season = item.get('season')
    episode = item.get('episode')
    
    # Kodi providers sometimes put a TMDb numeric identifier in IMDBNumber.
    # Never send a numeric value to an IMDb-specific API parameter.
    imdb_id = str(imdb_id or '').strip()
    imdb_id = imdb_id.lower() if re.fullmatch(r'tt\d{5,12}', imdb_id, re.I) else None
    tmdb_id = str(tmdb_id or '').strip()
    tmdb_id = str(int(tmdb_id)) if tmdb_id.isdigit() and int(tmdb_id) > 0 else None
    if str(season or '').isdigit() and str(episode or '').isdigit():
        season, episode = int(season), int(episode)
    else:
        season, episode = None, None

    # VALIDATION FIX: If IMDB ID matches TMDB ID, it's likely a Kodi fallback error.
    if imdb_id and tmdb_id and str(imdb_id) == str(tmdb_id):
        xbmc.log(f"Service: Ignored invalid IMDb ID {imdb_id} (matches TMDb ID)", xbmc.LOGINFO)
        imdb_id = None
    
    # --- 1. OpenSubtitles Search ---
    if enable_opensubtitles:
        try:
            api_key = __addon__.getSetting('api_key')
            user_agent = __addon__.getSetting('user_agent')
            username = __addon__.getSetting('username')
            password = __addon__.getSetting('password')
            
            client_os = OpenSubtitlesClient(api_key, user_agent)
            if username and password:
                client_os.set_credentials(username, password)
            
            results_os = client_os.search_subtitles(
                query=title,
                imdb_id=imdb_id,
                tmdb_id=tmdb_id,
                season=season,
                episode=episode,
                languages=languages
            )
            
            if results_os and 'data' in results_os:
                for sub in results_os.get('data', []):
                    sub['provider_source'] = 'opensubtitles'
                    all_results.append(sub)
        except Exception as e:
            xbmc.log(f"Service: OpenSubtitles search error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("OpenSubtitles", "Search Error", xbmcgui.NOTIFICATION_ERROR, 3000)

    # --- 2. SubDL Search ---
    if enable_subdl:
        try:
            subdl_key = __addon__.getSetting('subdl_api_key')
            if subdl_key:
                client_subdl = SubDLClient(subdl_key)
                results_subdl = client_subdl.search_subtitles(
                    title=title,
                    year=year,
                    imdb_id=imdb_id,
                    tmdb_id=tmdb_id,
                    season=season,
                    episode=episode,
                    languages=languages
                )
                # Some Kodi streams expose IDs that SubDL cannot resolve. Retry
                # using the series title only when the ID search finds nothing.
                if isinstance(results_subdl, dict) and not results_subdl.get('subtitles') and not results_subdl.get('results') and title and (imdb_id or tmdb_id) and not results_subdl.get('error'):
                    xbmc.log('Service: SubDL ID search empty; retrying by title', xbmc.LOGINFO)
                    results_subdl = client_subdl.search_subtitles(
                        title=title, year=year, imdb_id=None, tmdb_id=None,
                        season=season, episode=episode, languages=languages
                    )
                if isinstance(results_subdl, dict):
                    xbmc.log('Service: SubDL response status=%s, subtitles=%s, results=%s, error=%s' % (
                        results_subdl.get('status'),
                        len(results_subdl.get('subtitles') or []),
                        len(results_subdl.get('results') or []),
                        bool(results_subdl.get('error'))), xbmc.LOGINFO)
                # SubDL subtitle entries belong to `subtitles`. `results` may
                # contain film matches, not downloadable subtitles.
                data_subdl = results_subdl.get('subtitles', []) if isinstance(results_subdl, dict) else (results_subdl if isinstance(results_subdl, list) else [])
                if not isinstance(data_subdl, list):
                    data_subdl = []
                for sub in data_subdl:
                    if not isinstance(sub, dict):
                        continue
                    link = sub.get('url') or sub.get('full_link') or sub.get('link')
                    if not isinstance(link, str) or not link.strip():
                        continue
                    sub['provider_source'] = 'subdl'
                    all_results.append(sub)
            else:
                xbmc.log("Service: SubDL enabled but no API Key set.", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"Service: SubDL search error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("SubDL", "Search Error", xbmcgui.NOTIFICATION_ERROR, 3000)

    # --- Process & Display Results ---
    for sub in all_results:
        try:
            provider = sub.get('provider_source')
            
            if provider == 'opensubtitles':
                # OpenSubtitles Mapping
                attrs = sub.get('attributes', {})
                files = attrs.get('files', [])
                if not files:
                    continue
                
                file_info = files[0]
                file_id = file_info.get('file_id') # standard ID
                file_name = file_info.get('file_name', 'Unknown')
                language = attrs.get('language', 'Unknown')
                release = attrs.get('release', 'Unknown')
                ratings = attrs.get('ratings', 0)
                is_hi = attrs.get('hearing_impaired', False)
                
                lang_code = language.upper() if language else 'UNK'
                details = f"[OS] {release}"
                if is_hi: details += " [HI]"
                try:
                    valid_rating = float(ratings)
                except (ValueError, TypeError):
                    valid_rating = 0
                if 0 < valid_rating <= 10: details += f" ★{valid_rating:.1f}"

                list_item = xbmcgui.ListItem(label=lang_code, label2=details)
                # Use modern InfoTagVideo API instead of deprecated setInfo()
                tag = list_item.getVideoInfoTag()
                tag.setTitle(file_name)
                if 0 < valid_rating <= 10:
                    tag.setRating(valid_rating)
                list_item.setProperty('sync', 'false')
                if is_hi: list_item.setProperty('hearing_impaired', 'true')
                
                url = f"plugin://{__addon__.getAddonInfo('id')}/?action=download&file_id={file_id}&lang={language}"
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
            
            elif provider == 'subdl':
                # SubDL Mapping
                # Adjust based on likely API fields: 'name', 'url', 'language', 'rating'
                file_name = sub.get('name', sub.get('release_name', 'Unknown'))
                language = sub.get('lang', sub.get('language', 'Unknown'))
                # 'url' might be the download link or page. usage of client logic needed.
                download_link = sub.get('url') or sub.get('full_link') or sub.get('link')
                
                rating = str(sub.get('rating', '0'))
                
                if download_link:
                    import base64
                    encoded_link = base64.urlsafe_b64encode(download_link.encode()).decode()
                    file_id = f"subdl_{encoded_link}"
                    
                    lang_code = language[:2].upper() if language else 'DL'
                    details = f"[SubDL] {file_name} ★{rating}"
                    
                    list_item = xbmcgui.ListItem(label=lang_code, label2=details)
                    # Use modern InfoTagVideo API instead of deprecated setInfo()
                    tag = list_item.getVideoInfoTag()
                    tag.setTitle(file_name)
                    try:
                        numeric_rating = float(rating)
                        if 0 < numeric_rating <= 10:
                            tag.setRating(numeric_rating)
                    except (ValueError, TypeError):
                        pass
                    list_item.setProperty('sync', 'false')
                    
                    url = f"plugin://{__addon__.getAddonInfo('id')}/?action=download&file_id={file_id}&lang={language}"
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

        except Exception as e:
            xbmc.log(f"Service: Error creating list item for {provider}: {e}", xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def safe_subtitle_name(filename, lang=None):
    # Never trust remote archive entries or API-provided filenames.
    filename = str(filename or 'subtitle.srt').replace('\\', '/').split('/')[-1]
    stem, ext = os.path.splitext(filename)
    stem = re.sub(r'[^\w. -]', '_', stem, flags=re.UNICODE).strip(' .')[:110] or 'subtitle'
    language = re.sub(r'[^a-zA-Z0-9_-]', '', str(lang or ''))[:12]
    ext = ext.lower() if ext.lower() in ('.srt', '.ass', '.ssa', '.vtt', '.sub') else '.srt'
    if language and not stem.lower().endswith('.' + language.lower()):
        stem += '.' + language
    return stem + ext


def download(file_id, lang=None):
    """
    Download the subtitle file.
    """
    profile_dir = xbmcvfs.translatePath("special://profile/")
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)

    # --- SubDL Download ---
    if file_id.startswith('subdl_'):
        import base64
        try:
            encoded_link = file_id.replace('subdl_', '')
            download_link = base64.urlsafe_b64decode(encoded_link).decode()
            
            subdl_key = __addon__.getSetting('subdl_api_key')
            client_subdl = SubDLClient(subdl_key)
            
            download_info = client_subdl.download_subtitle(download_link)
            if not download_info:
                xbmc.log("Service: SubDL download failed", xbmc.LOGERROR)
                xbmcgui.Dialog().notification("SubDL", "Download Failed", xbmcgui.NOTIFICATION_ERROR, 3000)
                return

            content = download_info.get('content')
            file_name = download_info.get('file_name', 'subdl.srt')
            
            # SubDL often returns ZIP files. Extract if needed.
            if file_name.lower().endswith('.zip') or (content and content.startswith(b'PK')):
                import zipfile
                import io
                try:
                    with zipfile.ZipFile(io.BytesIO(content)) as z:
                        supported = ('.srt', '.ass', '.ssa', '.vtt', '.sub')
                        entries = [entry for entry in z.infolist()
                                   if not entry.is_dir()
                                   and entry.filename.lower().endswith(supported)
                                   and 0 < entry.file_size <= 5 * 1024 * 1024]
                        if not entries:
                            raise ValueError('No valid subtitle file in archive')
                        # Prefer SRT and files matching the requested language.
                        lang_hint = (lang or '').lower()[:2]
                        entries.sort(key=lambda e: (not e.filename.lower().endswith('.srt'),
                            not (lang_hint and lang_hint in e.filename.lower()), e.file_size))
                        selected = entries[0]
                        file_name = selected.filename
                        content = z.read(selected)
                        xbmc.log('Service: Extracted subtitle from SubDL archive', xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"Service: Error extracting SubDL zip: {e}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("SubDL", "Zip Extraction Failed", xbmcgui.NOTIFICATION_ERROR, 3000)
                    return

            final_filename = safe_subtitle_name(file_name, lang)

            import uuid
            final_filename = uuid.uuid4().hex[:8] + '_' + final_filename
            local_path = os.path.join(profile_dir, final_filename)
            with open(local_path, "wb") as f:
                f.write(content)
                
            xbmc.log(f"Service: SubDL Downloaded to {local_path}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("SubDL", "Subtitle Downloaded", xbmcgui.NOTIFICATION_INFO, 3000)
            
            # Inform Kodi
            special_source_path = f"special://profile/{final_filename}"
            list_item = xbmcgui.ListItem(label=final_filename)
            list_item.setPath(special_source_path)
            list_item.setContentLookup(False)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=special_source_path, listitem=list_item, isFolder=False)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            return

        except Exception as e:
            xbmc.log(f"Service: SubDL Download Exception: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("SubDL", f"Error: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

    # --- OpenSubtitles Download (Default) ---
    try:
        api_key = __addon__.getSetting('api_key')
        user_agent = __addon__.getSetting('user_agent')
        client = OpenSubtitlesClient(api_key, user_agent)
        
        username = __addon__.getSetting('username')
        password = __addon__.getSetting('password')
        if username and password:
            client.set_credentials(username, password)
            
        download_info = client.download_subtitle(file_id)
        
        if not download_info:
            xbmc.log("Service: Failed to get download info", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("OpenSubtitles", "Download Info Failed", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        link = download_info.get('link')
        file_name = download_info.get('file_name', 'subtitle.srt')
        
        final_filename = safe_subtitle_name(file_name, lang)

        import uuid
        final_filename = uuid.uuid4().hex[:8] + '_' + final_filename
        local_path = os.path.join(profile_dir, final_filename)
        
        if link:
            import urllib.request
            req = urllib.request.Request(link, headers={'User-Agent': user_agent})
            with urllib.request.urlopen(req, timeout=12) as response:
                content = response.read(5 * 1024 * 1024 + 1)
            if len(content) > 5 * 1024 * 1024:
                raise ValueError("Subtitle too large")
            with open(local_path, "wb") as f:
                f.write(content)
                
            xbmc.log(f"Service: Downloaded to {local_path}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("OpenSubtitles", "Subtitle Downloaded", xbmcgui.NOTIFICATION_INFO, 3000)
            
            special_source_path = f"special://profile/{final_filename}"
            list_item = xbmcgui.ListItem(label=final_filename)
            list_item.setPath(special_source_path)
            list_item.setContentLookup(False)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=special_source_path, listitem=list_item, isFolder=False)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            
    except Exception as e:
        xbmc.log(f"Service: OS Download Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("OpenSubtitles", "Download Failed", xbmcgui.NOTIFICATION_ERROR, 3000)


if __name__ == '__main__':
    # Parse params
    params = {}
    if len(sys.argv) > 2:
        try:
            params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
        except Exception as e:
            xbmc.log(f"Service: Error parsing params: {e}", xbmc.LOGERROR)

    action = params.get('action')
    xbmc.log(f"Service: Action='{action}', Params={params}", xbmc.LOGINFO)

    if action == 'search':
        item = {}
        item['title'] = xbmc.getInfoLabel("VideoPlayer.Title")
        item['originaltitle'] = xbmc.getInfoLabel("VideoPlayer.OriginalTitle")
        item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season'] = xbmc.getInfoLabel("VideoPlayer.Season")
        item['episode'] = xbmc.getInfoLabel("VideoPlayer.Episode")
        item['tvshowtitle'] = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        
        item['imdb_id'] = xbmc.getInfoLabel("VideoPlayer.UniqueId(imdb)")
        if not item['imdb_id']:
            item['imdb_id'] = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
            
        item['tmdb_id'] = xbmc.getInfoLabel("VideoPlayer.UniqueId(tmdb)")
        
        xbmc.log(f"Service Search: Title='{item['title']}', IMDB='{item['imdb_id']}', TMDB='{item['tmdb_id']}'", xbmc.LOGINFO)
        search(item)

    elif action == 'manualsearch':
        item = {}
        item['title'] = params.get('searchstring')
        item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season'] = xbmc.getInfoLabel("VideoPlayer.Season")
        item['episode'] = xbmc.getInfoLabel("VideoPlayer.Episode")
        item['tvshowtitle'] = params.get('searchstring') or xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        xbmc.log(f"Service Manual Search: Query='{item['title']}'", xbmc.LOGINFO)
        search(item)

    elif action == 'download':
        file_id = params.get('file_id')
        lang = params.get('lang')
        if file_id:
            download(file_id, lang)
