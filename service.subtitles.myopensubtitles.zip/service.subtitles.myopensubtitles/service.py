import sys
import os
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.opensubtitles_client import OpenSubtitlesClient

# Get the addon handle and settings
__addon__ = xbmcaddon.Addon()
__api_key__ = __addon__.getSetting('api_key')
__user_agent__ = __addon__.getSetting('user_agent')
__languages__ = __addon__.getSetting('languages')

def get_params(param_string):
    param_string = param_string.replace('?', '')
    return dict(urllib.parse.parse_qsl(param_string))

def search(item):
    """
    Search for subtitles based on the item dict provided by Kodi.
    """
    client = OpenSubtitlesClient(__api_key__, __user_agent__)
    
    # Extract info from item
    title = item.get('title')
    year = item.get('year')
    imdb_id = item.get('imdb_id')
    tmdb_id = item.get('tmdb_id')
    season = item.get('season')
    episode = item.get('episode')
    
    # VALIDATION FIX: If IMDB ID matches TMDB ID, it's likely a Kodi fallback error.
    if imdb_id and tmdb_id and str(imdb_id) == str(tmdb_id):
        xbmc.log(f"Service: Ignored invalid IMDb ID {imdb_id} (matches TMDb ID)", xbmc.LOGINFO)
        imdb_id = None
    
    # Perform search
    results = client.search_subtitles(
        query=title,
        imdb_id=imdb_id,
        tmdb_id=tmdb_id,
        season=season,
        episode=episode,
        languages=__languages__
    )

    # Process results and add to kodi list
    for sub in results.get('data', []):
        try:
            attrs = sub.get('attributes', {})
            files = attrs.get('files', [])
            if not files:
                continue
                
            # Use the first file info for now
            file_info = files[0]
            file_id = file_info.get('file_id')
            file_name = file_info.get('file_name', 'Unknown')
            
            language = attrs.get('language', 'Unknown')
            release = attrs.get('release', 'Unknown')
            ratings = attrs.get('ratings', 0)

            # Log raw attributes for debugging
            xbmc.log(f"Service: Found subtitle. Lang='{language}', Release='{release}', FileID='{file_id}'", xbmc.LOGINFO)
            
            # Format label: (LangKey) Release Name
            # Kodi usually prefers full language names like 'English', 'Arabic' in the label for parsing,
            # or standard codes in brackets (en) (ar).
            # OpenSubtitles v1 returns standard codes or names depending on response? 
            # Usually 'language' field is text like 'ar' or 'Arabic'.
            
            # Kodi Subtitle Dialog typically has columns: Language | Name | ...
            # 'label' usually maps to Language, 'label2' to Name.
            
            # Label = Language Code (e.g. AR)
            lang_code = language.upper() if language else 'UNK'
            
            # Label2 = Release Name [HI] ★Rating
            details = release
            if attrs.get('hearing_impaired'):
                details += " [HI]"
            if ratings and float(ratings) > 0:
                details += f" ★{str(ratings)[:3]}"

            # Use label2 for the main text info
            list_item = xbmcgui.ListItem(label=lang_code, label2=details)
            list_item.setInfo('video', {
                'title': file_name, 
                'rating': str(ratings)
            })
            
            # Properties for Kodi Subtitle UI
            list_item.setProperty('sync', 'false') 
            if attrs.get('hearing_impaired'):
                list_item.setProperty('hearing_impaired', 'true')
            
            # Construct download URL
            # Pass 'lang' to download so we can name the file correctly
            url = f"plugin://{__addon__.getAddonInfo('id')}/?action=download&file_id={file_id}&lang={language}"
            
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
            
        except Exception as e:
            xbmc.log(f"Error processing subtitle: {e}", xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def download(file_id, lang=None):
    """
    Download the subtitle file.
    """
    client = OpenSubtitlesClient(__api_key__, __user_agent__)
    
    # Credentials
    username = __addon__.getSetting('username')
    password = __addon__.getSetting('password')
    if username and password:
        client.set_credentials(username, password)
        
    download_info = client.download_subtitle(file_id)
    
    if not download_info:
        xbmc.log("Service: Failed to get download info", xbmc.LOGERROR)
        return

    link = download_info.get('link')
    original_file_name = download_info.get('file_name', 'subtitle.srt')
    
    # Ensure filename has language code for Kodi to parse
    # Kodi expects: filename.lang.srt or similar
    # If lang is provided (e.g. 'ar' or 'en'), insert it
    file_name = original_file_name
    if lang:
        name, ext = os.path.splitext(original_file_name)
        # Avoid double language code if already present
        if not name.endswith(f".{lang}"):
             file_name = f"{name}.{lang}{ext}"
    
    if not link:
        xbmc.log("Service: No download link found", xbmc.LOGERROR)
        return
        
    # Download the file content
    try:
        import urllib.request
        # Prepare download directory in addon profile to avoid conflict with special://temp
        # and ensure unique source path for Kodi VFS
        profile_dir = xbmcvfs.translatePath("special://profile/")
        if not os.path.exists(profile_dir):
            os.makedirs(profile_dir)
            
        # Clean up filename for saving
        # Logic to avoid double extension and double language
        base_name = os.path.splitext(file_name)[0]
        # Remove existing language code if present at end of base_name to re-append cleanly
        if lang:
            if base_name.endswith(f".{lang}"):
                base_name = base_name[:-len(lang)-1]
            final_filename = f"{base_name}.{lang}.srt"
        else:
            final_filename = f"{base_name}.srt"
        
        # Save to the profile directory
        local_path = os.path.join(profile_dir, final_filename)
        
        req = urllib.request.Request(link, headers={'User-Agent': __user_agent__})
        with urllib.request.urlopen(req) as response:
            content = response.read()
            
        with open(local_path, "wb") as f:
            f.write(content)
            
        xbmc.log(f"Service: Downloaded to {local_path}", xbmc.LOGINFO)
        
        # Pass the special protocol path to Kodi
        # This tells Kodi where to find the file we just saved
        special_source_path = f"special://profile/{final_filename}"
        
        list_item = xbmcgui.ListItem(label=final_filename)
        list_item.setPath(special_source_path)
        list_item.setContentLookup(False)
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=special_source_path, listitem=list_item, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
    except Exception as e:
        xbmc.log(f"Service: Download error: {e}", xbmc.LOGERROR)

if __name__ == '__main__':
    # Parse params
    params = {}
    if len(sys.argv) > 2:
        try:
            # sys.argv[2] is the query string, e.g. "?action=download&file_id=123&lang=ar"
            params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
        except Exception as e:
            xbmc.log(f"Service: Error parsing params: {e}", xbmc.LOGERROR)

    action = params.get('action')
    
    xbmc.log(f"Service: Action='{action}', Params={params}", xbmc.LOGINFO)

    if action == 'search':
        item = {}
        item['title'] = xbmc.getInfoLabel("VideoPlayer.Title")
        item['originaltitle'] = xbmc.getInfoLabel("VideoPlayer.OriginalTitle")
        item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season'] = xbmc.getInfoLabel("VideoPlayer.Season")
        item['episode'] = xbmc.getInfoLabel("VideoPlayer.Episode")
        item['tvshowtitle'] = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        
        # Correctly retrieve IDs using UniqueId info labels
        # Kodi maps 'tmdb' to 'VideoPlayer.UniqueId(tmdb)' and 'imdb' to 'VideoPlayer.UniqueId(imdb)'
        # or 'VideoPlayer.IMDBNumber' if set via setInfo('video', {'imdbnumber': ...})
        
        item['imdb_id'] = xbmc.getInfoLabel("VideoPlayer.UniqueId(imdb)")
        if not item['imdb_id']:
            item['imdb_id'] = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
            
        item['tmdb_id'] = xbmc.getInfoLabel("VideoPlayer.UniqueId(tmdb)")
        
        # Log what we found to debug
        xbmc.log(f"Service Search: Title='{item['title']}', IMDB='{item['imdb_id']}', TMDB='{item['tmdb_id']}'", xbmc.LOGINFO)
        
        search(item)

    elif action == 'manualsearch':
        # Handle manual search
        # params usually contains: 'searchstring'
        item = {}
        item['title'] = params.get('searchstring')
        # We might not have IDs for manual search, but try to grab year etc if possible from player?
        # Usually manual search is just a string query.
        item['year'] = xbmc.getInfoLabel("VideoPlayer.Year") 
        
        xbmc.log(f"Service Manual Search: Query='{item['title']}'", xbmc.LOGINFO)
        search(item)

    elif action == 'download':
        file_id = params.get('file_id')
        lang = params.get('lang')
        if file_id:
            download(file_id, lang)
    
    else:
        # Default fallback (some skins call the plugin without params to list services?)
        # Or running as background service.
        pass
